import { Router, Request, Response } from 'express';
import sharp from 'sharp';
import fs from 'fs';
import path from 'path';
import {
  readDb,
  writeDb,
  PlatformRecord,
  BatchRecord,
  AnnouncementRecord,
  UpcomingRecord,
  SettingsRecord,
} from './db';
import {
  authenticateAdmin,
  requireAdminAuth,
  isTokenValid,
  revokeAdminToken,
  changeAdminPassword,
  getStudentAccessConfig,
  verifyStudentAccessCode,
  updateStudentAccessConfig,
} from './auth';

const router = Router();

// ==========================================
// AUTHENTICATION ROUTES
// ==========================================

router.post('/auth/login', (req: Request, res: Response) => {
  const { email, password, mpin } = req.body || {};
  const pass = (password || mpin || '').trim();
  const userEmail = (email && typeof email === 'string' && email.trim()) ? email.trim() : '';

  if (!pass) {
    res.status(400).json({ error: 'Access Denied' });
    return;
  }

  const result = authenticateAdmin(userEmail, pass);
  if (!result.success) {
    res.status(401).json({ error: 'Access Denied' });
    return;
  }

  res.json({
    success: true,
    token: result.token,
    user: {
      email: 'admin',
      role: 'SuperAdmin',
    },
  });
});

router.post('/admin/change-password', requireAdminAuth, (req: Request, res: Response) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!currentPassword || !newPassword) {
    res.status(400).json({ error: 'Current password and new password are required' });
    return;
  }

  const result = changeAdminPassword(currentPassword, newPassword);
  if (!result.success) {
    res.status(400).json({ error: result.error });
    return;
  }

  res.json({ success: true, message: 'Password updated successfully' });
});

router.get('/auth/verify', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ authenticated: false });
    return;
  }
  const token = authHeader.split(' ')[1];
  const valid = isTokenValid(token);
  res.json({ authenticated: valid });
});

router.post('/auth/logout', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    revokeAdminToken(token);
  }
  res.json({ success: true });
});

// ==========================================
// STUDENT ACCESS UNLOCK ROUTES
// ==========================================

// Public: Get student access info
router.get('/student-access/info', (_req: Request, res: Response) => {
  const config = getStudentAccessConfig();
  res.json({
    free: false,
    feeText: config.feeText || '₹149',
    feeAmount: config.feeAmount || 149,
    telegramBotUrl: config.telegramBotUrl || 'https://t.me/Freestudycampusbot',
    telegramBotHandle: config.telegramBotHandle || '@Freestudycampusbot',
    upiId: config.upiId || '9472981955@ybl',
    qrImageUrl: config.qrImageUrl || '',
  });
});

// Public: Verify student access code
router.post('/student-access/verify', (req: Request, res: Response) => {
  const { code } = req.body || {};
  if (!code) {
    res.status(400).json({ error: 'Please enter the Student Access Password.' });
    return;
  }

  const result = verifyStudentAccessCode(code);
  if (!result.success) {
    res.status(401).json({ error: result.error || 'Access Denied' });
    return;
  }

  res.json({
    success: true,
    message: 'Student Access Unlocked Successfully!',
    token: `unlocked_${Date.now()}`,
  });
});

// Admin: View current student access code and settings (Admin Only)
router.get('/admin/student-access', requireAdminAuth, (_req: Request, res: Response) => {
  const config = getStudentAccessConfig();
  res.json({
    accessCode: config.accessCode,
    feeText: config.feeText,
    feeAmount: config.feeAmount,
    telegramBotUrl: config.telegramBotUrl,
    telegramBotHandle: config.telegramBotHandle,
    upiId: config.upiId,
    qrImageUrl: config.qrImageUrl,
    updatedAt: config.updatedAt,
  });
});

// Admin: Change Student Access Code and settings (Admin Only)
router.post('/admin/student-access', requireAdminAuth, (req: Request, res: Response) => {
  const { newCode, feeText, feeAmount, telegramBotUrl, telegramBotHandle, upiId, qrImageUrl } = req.body || {};
  const result = updateStudentAccessConfig({
    newCode,
    feeText,
    feeAmount,
    telegramBotUrl,
    telegramBotHandle,
    upiId,
    qrImageUrl,
  });

  if (!result.success) {
    res.status(400).json({ error: result.error });
    return;
  }

  res.json({
    success: true,
    message: 'Student Access Password & Settings updated successfully.',
    config: {
      accessCode: result.config?.accessCode,
      feeText: result.config?.feeText,
      feeAmount: result.config?.feeAmount,
      telegramBotUrl: result.config?.telegramBotUrl,
      telegramBotHandle: result.config?.telegramBotHandle,
      upiId: result.config?.upiId,
      qrImageUrl: result.config?.qrImageUrl,
      updatedAt: result.config?.updatedAt,
    },
  });
});

// ==========================================
// PUBLIC CONSUMER ROUTES
// ==========================================

router.get('/platforms', (_req: Request, res: Response) => {
  const db = readDb();
  const availablePlatforms = db.platforms
    .filter((p) => p.isAvailable)
    .sort((a, b) => a.displayOrder - b.displayOrder);
  res.json(availablePlatforms);
});

router.get('/batches', (req: Request, res: Response) => {
  const { platformId, status, search, category } = req.query;
  const db = readDb();
  let batches = db.batches.filter((b) => b.isAvailable);

  if (platformId) {
    batches = batches.filter((b) => b.platformId === platformId);
  }
  if (status && status !== 'All') {
    batches = batches.filter((b) => b.status === status);
  }
  if (category && category !== 'ALL') {
    batches = batches.filter((b) => b.category.toUpperCase() === (category as string).toUpperCase());
  }
  if (search) {
    const q = (search as string).toLowerCase().trim();
    batches = batches.filter(
      (b) =>
        b.title.toLowerCase().includes(q) ||
        b.shortDescription.toLowerCase().includes(q) ||
        b.teacherName.toLowerCase().includes(q) ||
        b.subject.toLowerCase().includes(q) ||
        b.category.toLowerCase().includes(q)
    );
  }

  batches.sort((a, b) => a.displayOrder - b.displayOrder);
  res.json(batches);
});

router.get('/announcements', (_req: Request, res: Response) => {
  const db = readDb();
  const activeAnnouncements = db.announcements.filter((a) => a.isActive);
  res.json(activeAnnouncements);
});

router.get('/upcoming', (_req: Request, res: Response) => {
  const db = readDb();
  res.json(db.upcoming);
});

router.get('/settings', (_req: Request, res: Response) => {
  const db = readDb();
  res.json(db.settings);
});

// ==========================================
// PROTECTED ADMIN ROUTES
// ==========================================

// Dashboard Statistics
router.get('/admin/stats', requireAdminAuth, (_req: Request, res: Response) => {
  const db = readDb();
  const totalPlatforms = db.platforms.length;
  const totalBatches = db.batches.length;
  const activeBatches = db.batches.filter((b) => b.status === 'Active' && b.isAvailable).length;
  const upcomingBatches = db.batches.filter((b) => b.status === 'Upcoming').length + db.upcoming.length;

  res.json({
    totalPlatforms,
    totalBatches,
    activeBatches,
    upcomingBatches,
  });
});

// Platform Management
router.get('/admin/platforms', requireAdminAuth, (_req: Request, res: Response) => {
  const db = readDb();
  const platforms = [...db.platforms].sort((a, b) => a.displayOrder - b.displayOrder);
  res.json(platforms);
});

router.post('/admin/platforms', requireAdminAuth, (req: Request, res: Response) => {
  const { id, name, tagline, description, accentColor, externalUrl, logo, isAvailable } = req.body;
  if (!name || !externalUrl) {
    res.status(400).json({ error: 'Batch Name and Link are required' });
    return;
  }

  const db = readDb();
  const cleanName = (name || '').trim();
  const slug = cleanName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  const finalId = id || (slug.length > 0 ? slug : `batch-${Date.now()}`);

  const existing = db.platforms.find((p) => p.id === finalId);
  if (existing) {
    res.status(409).json({ error: `A batch with name "${cleanName}" already exists` });
    return;
  }

  const maxOrder = db.platforms.reduce((max, p) => Math.max(max, p.displayOrder || 0), 0);
  const now = new Date().toISOString();

  const newPlatform: PlatformRecord = {
    id: finalId,
    name: cleanName,
    tagline: (tagline || 'Authorized Learning Partner').trim(),
    description: (description || '').trim(),
    accentColor: accentColor || '#00e5ff',
    externalUrl: externalUrl.trim(),
    logo: logo ? logo.trim() : cleanName.slice(0, 2).toUpperCase(),
    displayOrder: maxOrder + 1,
    isAvailable: isAvailable !== false,
    totalBatches: 0,
    createdAt: now,
    updatedAt: now,
  };

  db.platforms.push(newPlatform);
  writeDb(db);
  res.status(201).json(newPlatform);
});

router.put('/admin/platforms/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  const index = db.platforms.findIndex((p) => p.id === id);

  if (index === -1) {
    res.status(404).json({ error: 'Platform not found' });
    return;
  }

  const existing = db.platforms[index];
  const {
    name,
    tagline,
    description,
    accentColor,
    externalUrl,
    logo,
    isAvailable,
    displayOrder,
  } = req.body;

  const updated: PlatformRecord = {
    ...existing,
    name: name !== undefined ? name.trim() : existing.name,
    tagline: tagline !== undefined ? tagline.trim() : existing.tagline,
    description: description !== undefined ? description.trim() : existing.description,
    accentColor: accentColor || existing.accentColor,
    externalUrl: externalUrl !== undefined ? externalUrl.trim() : existing.externalUrl,
    logo: logo !== undefined ? logo.trim() : existing.logo,
    isAvailable: isAvailable !== undefined ? Boolean(isAvailable) : existing.isAvailable,
    displayOrder: displayOrder !== undefined ? Number(displayOrder) : existing.displayOrder,
    updatedAt: new Date().toISOString(),
  };

  db.platforms[index] = updated;
  writeDb(db);
  res.json(updated);
});

router.delete('/admin/platforms/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  const initialLength = db.platforms.length;
  db.platforms = db.platforms.filter((p) => p.id !== id);

  if (db.platforms.length === initialLength) {
    res.status(404).json({ error: 'Batch not found in database' });
    return;
  }

  // Also remove associated batches
  db.batches = db.batches.filter((b) => b.platformId !== id);
  writeDb(db);
  res.json({ success: true, message: 'Deleted successfully' });
});

router.post('/admin/platforms/:id/reorder', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const { direction } = req.body; // 'up' | 'down'
  const db = readDb();

  const currentPlatform = db.platforms.find((p) => p.id === id);
  if (!currentPlatform) {
    res.status(404).json({ error: 'Platform not found' });
    return;
  }

  const sortedPlatforms = [...db.platforms].sort((a, b) => a.displayOrder - b.displayOrder);
  const idx = sortedPlatforms.findIndex((p) => p.id === id);
  const targetIdx = direction === 'up' ? idx - 1 : idx + 1;

  if (targetIdx >= 0 && targetIdx < sortedPlatforms.length) {
    const swapTarget = sortedPlatforms[targetIdx];
    const tempOrder = currentPlatform.displayOrder;
    currentPlatform.displayOrder = swapTarget.displayOrder;
    swapTarget.displayOrder = tempOrder;

    // Normalise order indices
    sortedPlatforms.sort((a, b) => a.displayOrder - b.displayOrder);
    sortedPlatforms.forEach((p, i) => {
      p.displayOrder = i + 1;
    });

    writeDb(db);
  }

  res.json({ success: true, platforms: db.platforms.sort((a, b) => a.displayOrder - b.displayOrder) });
});

router.post('/admin/platforms/reorder', requireAdminAuth, (req: Request, res: Response) => {
  const { ids } = req.body;
  if (!Array.isArray(ids)) {
    res.status(400).json({ error: 'ids array is required' });
    return;
  }

  const db = readDb();
  const map = new Map(db.platforms.map((p) => [p.id, p]));
  const reordered: PlatformRecord[] = [];

  ids.forEach((id, index) => {
    const p = map.get(id);
    if (p) {
      p.displayOrder = index + 1;
      reordered.push(p);
      map.delete(id);
    }
  });

  // Append any leftover
  map.forEach((p) => {
    p.displayOrder = reordered.length + 1;
    reordered.push(p);
  });

  db.platforms = reordered;
  writeDb(db);
  res.json({ success: true, platforms: reordered });
});

// Batch Management
router.get('/admin/batches', requireAdminAuth, (req: Request, res: Response) => {
  const { platformId } = req.query;
  const db = readDb();
  let batches = [...db.batches];
  if (platformId) {
    batches = batches.filter((b) => b.platformId === platformId);
  }
  batches.sort((a, b) => a.displayOrder - b.displayOrder);
  res.json(batches);
});

router.post('/admin/batches', requireAdminAuth, (req: Request, res: Response) => {
  const {
    platformId,
    title,
    shortDescription,
    thumbnail,
    teacherName,
    subject,
    category,
    batchUrl,
    startDate,
    status,
    isFeatured,
    isAvailable,
  } = req.body;

  if (!title || !batchUrl) {
    res.status(400).json({ error: 'Batch Name and Batch URL are required' });
    return;
  }

  const db = readDb();
  const targetPlatformId = platformId || 'physics-wallah';
  const platform = db.platforms.find((p) => p.id === targetPlatformId);

  if (!platform) {
    res.status(400).json({ error: 'Target platform does not exist' });
    return;
  }

  const maxOrder = db.batches
    .filter((b) => b.platformId === targetPlatformId)
    .reduce((max, b) => Math.max(max, b.displayOrder || 0), 0);

  const now = new Date().toISOString();
  const id = `batch-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

  const newBatch: BatchRecord = {
    id,
    platformId: targetPlatformId,
    title: title.trim(),
    shortDescription: (shortDescription || '').trim(),
    thumbnail:
      (thumbnail || '').trim() ||
      'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=600&auto=format&fit=crop&q=80',
    teacherName: (teacherName || 'Faculty Mentor').trim(),
    subject: (subject || 'General Study').trim(),
    category: (category || 'JEE').trim().toUpperCase(),
    batchUrl: batchUrl.trim(),
    startDate: startDate || new Date().toISOString().slice(0, 10),
    status: status === 'Upcoming' || status === 'Completed' ? status : 'Active',
    displayOrder: maxOrder + 1,
    isFeatured: Boolean(isFeatured),
    isAvailable: isAvailable !== false,
    createdAt: now,
    updatedAt: now,
  };

  db.batches.push(newBatch);

  // Update platform total batch count
  platform.totalBatches = db.batches.filter((b) => b.platformId === targetPlatformId).length;

  writeDb(db);
  res.status(201).json(newBatch);
});

router.put('/admin/batches/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  const index = db.batches.findIndex((b) => b.id === id);

  if (index === -1) {
    res.status(404).json({ error: 'Batch not found' });
    return;
  }

  const existing = db.batches[index];
  const {
    title,
    shortDescription,
    thumbnail,
    teacherName,
    subject,
    category,
    batchUrl,
    startDate,
    status,
    isFeatured,
    isAvailable,
    displayOrder,
  } = req.body;

  const updated: BatchRecord = {
    ...existing,
    title: title !== undefined ? title.trim() : existing.title,
    shortDescription: shortDescription !== undefined ? shortDescription.trim() : existing.shortDescription,
    thumbnail: thumbnail !== undefined ? thumbnail.trim() : existing.thumbnail,
    teacherName: teacherName !== undefined ? teacherName.trim() : existing.teacherName,
    subject: subject !== undefined ? subject.trim() : existing.subject,
    category: category !== undefined ? category.trim().toUpperCase() : existing.category,
    batchUrl: batchUrl !== undefined ? batchUrl.trim() : existing.batchUrl,
    startDate: startDate !== undefined ? startDate : existing.startDate,
    status: status !== undefined ? status : existing.status,
    isFeatured: isFeatured !== undefined ? Boolean(isFeatured) : existing.isFeatured,
    isAvailable: isAvailable !== undefined ? Boolean(isAvailable) : existing.isAvailable,
    displayOrder: displayOrder !== undefined ? Number(displayOrder) : existing.displayOrder,
    updatedAt: new Date().toISOString(),
  };

  db.batches[index] = updated;
  writeDb(db);
  res.json(updated);
});

router.delete('/admin/batches/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  const target = db.batches.find((b) => b.id === id);

  if (!target) {
    res.status(404).json({ error: 'Batch not found' });
    return;
  }

  db.batches = db.batches.filter((b) => b.id !== id);

  // Update platform count
  const platform = db.platforms.find((p) => p.id === target.platformId);
  if (platform) {
    platform.totalBatches = db.batches.filter((b) => b.platformId === target.platformId).length;
  }

  writeDb(db);
  res.json({ success: true, message: 'Batch successfully deleted' });
});

router.post('/admin/batches/:id/reorder', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const { direction } = req.body; // 'up' | 'down'
  const db = readDb();

  const currentBatch = db.batches.find((b) => b.id === id);
  if (!currentBatch) {
    res.status(404).json({ error: 'Batch not found' });
    return;
  }

  const platformBatches = db.batches
    .filter((b) => b.platformId === currentBatch.platformId)
    .sort((a, b) => a.displayOrder - b.displayOrder);

  const idx = platformBatches.findIndex((b) => b.id === id);
  const targetIdx = direction === 'up' ? idx - 1 : idx + 1;

  if (targetIdx >= 0 && targetIdx < platformBatches.length) {
    const swapTarget = platformBatches[targetIdx];
    const tempOrder = currentBatch.displayOrder;
    currentBatch.displayOrder = swapTarget.displayOrder;
    swapTarget.displayOrder = tempOrder;
    writeDb(db);
  }

  res.json({ success: true });
});

router.post('/admin/batches/:id/toggle-feature', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  const batch = db.batches.find((b) => b.id === id);

  if (!batch) {
    res.status(404).json({ error: 'Batch not found' });
    return;
  }

  batch.isFeatured = !batch.isFeatured;
  batch.updatedAt = new Date().toISOString();
  writeDb(db);
  res.json(batch);
});

router.post('/admin/batches/:id/toggle-status', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  const batch = db.batches.find((b) => b.id === id);

  if (!batch) {
    res.status(404).json({ error: 'Batch not found' });
    return;
  }

  batch.isAvailable = !batch.isAvailable;
  batch.updatedAt = new Date().toISOString();
  writeDb(db);
  res.json(batch);
});

// Upcoming Batches Management
router.post('/admin/upcoming', requireAdminAuth, (req: Request, res: Response) => {
  const { batchName, platform, description, thumbnail, expectedDate, externalUrl, status } = req.body;
  if (!batchName) {
    res.status(400).json({ error: 'Batch Name is required' });
    return;
  }

  const db = readDb();
  const id = `up-${Date.now()}`;

  const newUpcoming: UpcomingRecord = {
    id,
    batchName: batchName.trim(),
    platform: (platform || 'Physics Wallah').trim(),
    description: (description || '').trim(),
    thumbnail:
      (thumbnail || '').trim() ||
      'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&auto=format&fit=crop&q=80',
    expectedDate: expectedDate || 'Coming Soon',
    externalUrl: (externalUrl || '').trim(),
    status: status === 'In Preparation' ? 'In Preparation' : 'Upcoming',
    createdAt: new Date().toISOString(),
  };

  db.upcoming.push(newUpcoming);
  writeDb(db);
  res.status(201).json(newUpcoming);
});

router.put('/admin/upcoming/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  const index = db.upcoming.findIndex((u) => u.id === id);

  if (index === -1) {
    res.status(404).json({ error: 'Upcoming batch not found' });
    return;
  }

  db.upcoming[index] = {
    ...db.upcoming[index],
    ...req.body,
  };

  writeDb(db);
  res.json(db.upcoming[index]);
});

router.delete('/admin/upcoming/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  db.upcoming = db.upcoming.filter((u) => u.id !== id);
  writeDb(db);
  res.json({ success: true });
});

// Announcements Management
router.post('/admin/announcements', requireAdminAuth, (req: Request, res: Response) => {
  const { title, message, date, link, isActive } = req.body;
  if (!title || !message) {
    res.status(400).json({ error: 'Title and Message are required' });
    return;
  }

  const db = readDb();
  const id = `ann-${Date.now()}`;

  const newAnn: AnnouncementRecord = {
    id,
    title: title.trim(),
    message: message.trim(),
    date: date || new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
    link: (link || '').trim(),
    isActive: isActive !== false,
    createdAt: new Date().toISOString(),
  };

  db.announcements.push(newAnn);
  writeDb(db);
  res.status(201).json(newAnn);
});

router.put('/admin/announcements/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  const index = db.announcements.findIndex((a) => a.id === id);

  if (index === -1) {
    res.status(404).json({ error: 'Announcement not found' });
    return;
  }

  db.announcements[index] = {
    ...db.announcements[index],
    ...req.body,
  };

  writeDb(db);
  res.json(db.announcements[index]);
});

router.delete('/admin/announcements/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  db.announcements = db.announcements.filter((a) => a.id !== id);
  writeDb(db);
  res.json({ success: true });
});

// Settings Management
router.put('/admin/settings', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  const updatedSettings: SettingsRecord = {
    ...db.settings,
    ...req.body,
  };
  db.settings = updatedSettings;
  writeDb(db);
  res.json(updatedSettings);
});

// Official Brand Logo & PWA App Icons Upload
router.post('/admin/upload-official-logo', requireAdminAuth, async (req: Request, res: Response) => {
  try {
    const { imageData } = req.body || {};
    
    // Handle logo reset/removal
    if (typeof imageData === 'string' && imageData.trim() === '') {
      const db = readDb();
      db.settings.logo = '/logo.png';
      db.settings.updatedAt = new Date().toISOString();
      writeDb(db);
      res.json({
        success: true,
        logoUrl: '/logo.png',
        message: 'Logo reset to default Free Study Campus brand icon',
      });
      return;
    }

    if (!imageData || typeof imageData !== 'string') {
      res.status(400).json({ error: 'Valid image data is required' });
      return;
    }

    const base64Data = imageData.replace(/^data:image\/[a-zA-Z+]+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');

    const publicDir = path.resolve(process.cwd(), 'public');
    if (!fs.existsSync(publicDir)) {
      fs.mkdirSync(publicDir, { recursive: true });
    }

    // 1. Save 512x512 PNG
    await sharp(buffer)
      .resize(512, 512)
      .png({ quality: 100, compressionLevel: 9 })
      .toFile(path.join(publicDir, 'pwa-512x512.png'));

    // 2. Save 192x192 PNG
    await sharp(buffer)
      .resize(192, 192)
      .png({ quality: 100, compressionLevel: 9 })
      .toFile(path.join(publicDir, 'pwa-192x192.png'));

    // 3. Apple Touch Icon 180x180
    await sharp(buffer)
      .resize(180, 180)
      .png({ quality: 100 })
      .toFile(path.join(publicDir, 'apple-touch-icon.png'));

    // 4. Favicon 64x64 PNG
    await sharp(buffer)
      .resize(64, 64)
      .png({ quality: 100 })
      .toFile(path.join(publicDir, 'favicon.png'));

    // 5. Favicon 32x32 ICO
    await sharp(buffer)
      .resize(32, 32)
      .png()
      .toFile(path.join(publicDir, 'favicon.ico'));

    // 6. Maskable icons (with 15% safe padding for Android launchers)
    const inner512 = await sharp(buffer).resize(410, 410).toBuffer();
    await sharp({
      create: {
        width: 512,
        height: 512,
        channels: 4,
        background: { r: 1, g: 3, b: 7, alpha: 1 },
      },
    })
      .composite([{ input: inner512, gravity: 'center' }])
      .png({ quality: 100 })
      .toFile(path.join(publicDir, 'pwa-maskable-512x512.png'));

    const inner192 = await sharp(buffer).resize(154, 154).toBuffer();
    await sharp({
      create: {
        width: 192,
        height: 192,
        channels: 4,
        background: { r: 1, g: 3, b: 7, alpha: 1 },
      },
    })
      .composite([{ input: inner192, gravity: 'center' }])
      .png({ quality: 100 })
      .toFile(path.join(publicDir, 'pwa-maskable-192x192.png'));

    // 7. Save official full copy
    await sharp(buffer)
      .resize(1024, 1024, { fit: 'inside' })
      .png({ quality: 100 })
      .toFile(path.join(publicDir, 'official-logo.png'));

    // 8. Save universal logo.png fallback
    await sharp(buffer)
      .resize(512, 512, { fit: 'inside' })
      .png({ quality: 100 })
      .toFile(path.join(publicDir, 'logo.png'));

    // Update settings in database with updatedAt timestamp for cache busting
    const db = readDb();
    db.settings.logo = '/logo.png';
    db.settings.updatedAt = new Date().toISOString();
    writeDb(db);

    res.json({
      success: true,
      logoUrl: '/logo.png',
      message: 'Official Free Study Campus logo and PWA icons successfully updated across website and Home Screen!',
    });
  } catch (err: unknown) {
    console.error('Failed to process uploaded logo:', err);
    res.status(500).json({ error: 'Failed to process logo image.' });
  }
});

// ==========================================
// STUDENT HELP & SUPPORT SYSTEM ROUTES
// ==========================================
// STUDENT SUPPORT & NOTIFICATION SYSTEM
// ==========================================

const SUPPORT_DB_FILE = path.resolve(process.cwd(), 'data', 'support_tickets.json');
const NOTIFICATIONS_DB_FILE = path.resolve(process.cwd(), 'data', 'notifications.json');

export interface SupportMessageRecord {
  id: string;
  sender: 'student' | 'admin';
  senderName: string;
  senderUsername?: string;
  text: string;
  screenshotUrl?: string | null;
  createdAt: string;
}

export interface SupportTicketRecord {
  id: string;
  studentId: string;
  studentName: string;
  studentUsername: string;
  subject: string;
  category?: string;
  description: string;
  screenshotUrl?: string | null;
  status: 'Pending' | 'In Progress' | 'Resolved';
  adminReply?: string | null;
  adminRepliedAt?: string | null;
  messages: SupportMessageRecord[];
  createdAt: string;
  updatedAt: string;
}

export interface NotificationRecord {
  id: string;
  targetRole: 'admin' | 'student';
  studentId?: string;
  studentUsername?: string;
  title: string;
  message: string;
  ticketId?: string;
  type: 'ticket_created' | 'ticket_replied' | 'status_updated' | 'announcement';
  read: boolean;
  createdAt: string;
}

function normalizeTicket(t: any): SupportTicketRecord {
  const messages: SupportMessageRecord[] = Array.isArray(t.messages) && t.messages.length > 0
    ? t.messages
    : [
        {
          id: `msg_${t.id}_init`,
          sender: 'student',
          senderName: t.studentName || 'Student',
          senderUsername: t.studentUsername || '',
          text: t.description || '',
          screenshotUrl: t.screenshotUrl || null,
          createdAt: t.createdAt || new Date().toISOString(),
        },
        ...(t.adminReply
          ? [
              {
                id: `msg_${t.id}_reply`,
                sender: 'admin' as const,
                senderName: 'Campus Administrator',
                text: t.adminReply,
                createdAt: t.adminRepliedAt || t.updatedAt || new Date().toISOString(),
              },
            ]
          : []),
      ];

  return {
    id: String(t.id),
    studentId: String(t.studentId || ''),
    studentName: String(t.studentName || 'Student'),
    studentUsername: String(t.studentUsername || '').toLowerCase(),
    subject: String(t.subject || ''),
    category: t.category || undefined,
    description: String(t.description || ''),
    screenshotUrl: t.screenshotUrl || null,
    status: (t.status as any) || 'Pending',
    adminReply: t.adminReply || null,
    adminRepliedAt: t.adminRepliedAt || null,
    messages,
    createdAt: t.createdAt || new Date().toISOString(),
    updatedAt: t.updatedAt || new Date().toISOString(),
  };
}

function readSupportDb(): SupportTicketRecord[] {
  try {
    if (fs.existsSync(SUPPORT_DB_FILE)) {
      const data = fs.readFileSync(SUPPORT_DB_FILE, 'utf-8');
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed.map(normalizeTicket);
      }
    }
  } catch (err) {
    console.error('Error reading support db:', err);
  }
  return [];
}

function writeSupportDb(tickets: SupportTicketRecord[]): void {
  try {
    const dir = path.dirname(SUPPORT_DB_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(SUPPORT_DB_FILE, JSON.stringify(tickets, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing support db:', err);
  }
}

function readNotificationsDb(): NotificationRecord[] {
  try {
    if (fs.existsSync(NOTIFICATIONS_DB_FILE)) {
      const data = fs.readFileSync(NOTIFICATIONS_DB_FILE, 'utf-8');
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err) {
    console.error('Error reading notifications db:', err);
  }
  return [];
}

function writeNotificationsDb(notifs: NotificationRecord[]): void {
  try {
    const dir = path.dirname(NOTIFICATIONS_DB_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(NOTIFICATIONS_DB_FILE, JSON.stringify(notifs.slice(0, 300), null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing notifications db:', err);
  }
}

function addNotification(notif: Omit<NotificationRecord, 'id' | 'read' | 'createdAt'> & { id?: string }): NotificationRecord {
  const notifs = readNotificationsDb();
  const now = new Date().toISOString();

  // Prevent duplicate notification within 5 seconds for same ticket and type
  const isDuplicate = notifs.some(
    (n) =>
      n.ticketId === notif.ticketId &&
      n.type === notif.type &&
      n.targetRole === notif.targetRole &&
      Date.now() - new Date(n.createdAt).getTime() < 5000
  );

  if (isDuplicate) {
    return notifs[0];
  }

  const newNotif: NotificationRecord = {
    id: notif.id || `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    targetRole: notif.targetRole,
    studentId: notif.studentId,
    studentUsername: notif.studentUsername,
    title: notif.title,
    message: notif.message,
    ticketId: notif.ticketId,
    type: notif.type,
    read: false,
    createdAt: now,
  };

  notifs.unshift(newNotif);
  writeNotificationsDb(notifs);
  return newNotif;
}

// Student: Submit problem/query
router.post('/support/submit', (req: Request, res: Response) => {
  const { studentId, studentName, studentUsername, subject, category, description, screenshotUrl } = req.body || {};
  if (!studentId || !subject || !description) {
    res.status(400).json({ error: 'Student ID, subject, and description are required.' });
    return;
  }

  // Validate screenshot format & size if provided
  if (screenshotUrl && typeof screenshotUrl === 'string') {
    if (!screenshotUrl.startsWith('data:image/') && !screenshotUrl.startsWith('http')) {
      res.status(400).json({ error: 'Screenshot must be a valid image format (PNG, JPG, WebP).' });
      return;
    }
    if (screenshotUrl.length > 12 * 1024 * 1024) {
      res.status(400).json({ error: 'Screenshot file size exceeds 8MB limit.' });
      return;
    }
  }

  const tickets = readSupportDb();
  const now = new Date().toISOString();
  const ticketId = req.body.id || `ticket_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

  const initialMessage: SupportMessageRecord = {
    id: `msg_${Date.now()}_init`,
    sender: 'student',
    senderName: String(studentName || 'Student').trim(),
    senderUsername: String(studentUsername || '').trim().toLowerCase(),
    text: String(description).trim(),
    screenshotUrl: screenshotUrl || null,
    createdAt: now,
  };

  const newTicket: SupportTicketRecord = {
    id: ticketId,
    studentId: String(studentId),
    studentName: String(studentName || 'Student').trim(),
    studentUsername: String(studentUsername || '').trim().toLowerCase(),
    subject: String(subject).trim(),
    category: category ? String(category).trim() : undefined,
    description: String(description).trim(),
    screenshotUrl: screenshotUrl || null,
    status: 'Pending',
    adminReply: null,
    adminRepliedAt: null,
    messages: [initialMessage],
    createdAt: now,
    updatedAt: now,
  };

  tickets.unshift(newTicket);
  writeSupportDb(tickets);

  // Notify Admin of new student query
  addNotification({
    id: `notif_admin_new_${newTicket.id}`,
    targetRole: 'admin',
    title: 'New Student Query',
    message: `${newTicket.studentName} (@${newTicket.studentUsername}) submitted: "${newTicket.subject}"`,
    ticketId: newTicket.id,
    type: 'ticket_created',
  });

  res.json({ success: true, ticket: newTicket });
});

// Student & Admin: Send follow-up message in the same conversation
router.post('/support/:id/message', (req: Request, res: Response) => {
  const { id } = req.params;
  const { sender, senderName, senderUsername, text, screenshotUrl } = req.body || {};

  if (!text || !text.trim()) {
    res.status(400).json({ error: 'Message text cannot be empty.' });
    return;
  }

  if (screenshotUrl && typeof screenshotUrl === 'string') {
    if (!screenshotUrl.startsWith('data:image/') && !screenshotUrl.startsWith('http')) {
      res.status(400).json({ error: 'Screenshot must be a valid image format.' });
      return;
    }
  }

  const tickets = readSupportDb();
  const ticket = tickets.find((t) => t.id === id);
  if (!ticket) {
    res.status(404).json({ error: 'Support ticket not found.' });
    return;
  }

  const now = new Date().toISOString();
  const isSenderAdmin = sender === 'admin';

  const newMsg: SupportMessageRecord = {
    id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    sender: isSenderAdmin ? 'admin' : 'student',
    senderName: isSenderAdmin ? 'Campus Administrator' : (senderName || ticket.studentName),
    senderUsername: isSenderAdmin ? undefined : (senderUsername || ticket.studentUsername),
    text: String(text).trim(),
    screenshotUrl: screenshotUrl || null,
    createdAt: now,
  };

  if (!Array.isArray(ticket.messages)) {
    ticket.messages = [];
  }
  ticket.messages.push(newMsg);
  ticket.updatedAt = now;

  if (isSenderAdmin) {
    ticket.adminReply = newMsg.text;
    ticket.adminRepliedAt = now;
    // Notify Student
    addNotification({
      targetRole: 'student',
      studentId: ticket.studentId,
      studentUsername: ticket.studentUsername,
      title: 'Admin Replied to Your Query',
      message: `Admin replied on "${ticket.subject}": "${newMsg.text.slice(0, 100)}"`,
      ticketId: ticket.id,
      type: 'ticket_replied',
    });
  } else {
    // If ticket was resolved, mark back to In Progress
    if (ticket.status === 'Resolved') {
      ticket.status = 'In Progress';
    }
    // Notify Admin
    addNotification({
      targetRole: 'admin',
      title: 'Student Follow-up Message',
      message: `${ticket.studentName} (@${ticket.studentUsername}) sent a message on: "${ticket.subject}"`,
      ticketId: ticket.id,
      type: 'ticket_replied',
    });
  }

  writeSupportDb(tickets);
  res.json({ success: true, message: newMsg, ticket });
});

// Student: Get own tickets
router.get('/support/student/:studentId', (req: Request, res: Response) => {
  const { studentId } = req.params;
  const tickets = readSupportDb();
  const filtered = tickets.filter(
    (t) => t.studentId === studentId || t.studentUsername.toLowerCase() === studentId.toLowerCase()
  );
  res.json({ success: true, tickets: filtered });
});

// Admin: Get all tickets (Admin Only)
router.get('/admin/support', requireAdminAuth, (_req: Request, res: Response) => {
  const tickets = readSupportDb();
  res.json({ success: true, tickets });
});

// Admin: Reply to ticket (Admin Only)
router.post('/admin/support/:id/reply', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const { reply, status = 'Resolved' } = req.body || {};
  if (!reply || !reply.trim()) {
    res.status(400).json({ error: 'Reply text is required.' });
    return;
  }

  const tickets = readSupportDb();
  const now = new Date().toISOString();
  let targetTicket: SupportTicketRecord | null = null;

  const updated = tickets.map((t) => {
    if (t.id === id) {
      const adminMessage: SupportMessageRecord = {
        id: `msg_${Date.now()}_admin_reply`,
        sender: 'admin',
        senderName: 'Campus Administrator',
        text: reply.trim(),
        createdAt: now,
      };

      const messages = Array.isArray(t.messages) ? [...t.messages, adminMessage] : [adminMessage];
      const mod: SupportTicketRecord = {
        ...t,
        adminReply: reply.trim(),
        adminRepliedAt: now,
        status: status || 'Resolved',
        messages,
        updatedAt: now,
      };
      targetTicket = mod;
      return mod;
    }
    return t;
  });

  if (!targetTicket) {
    res.status(404).json({ error: 'Support ticket not found.' });
    return;
  }

  writeSupportDb(updated);

  // Notify student of admin reply
  addNotification({
    targetRole: 'student',
    studentId: (targetTicket as SupportTicketRecord).studentId,
    studentUsername: (targetTicket as SupportTicketRecord).studentUsername,
    title: 'Admin Replied to Your Query',
    message: `Admin replied to "${(targetTicket as SupportTicketRecord).subject}": "${reply.trim().slice(0, 100)}"`,
    ticketId: id,
    type: 'ticket_replied',
  });

  res.json({ success: true, message: 'Reply sent successfully.', ticket: targetTicket });
});

// Admin: Update ticket status (Admin Only)
router.post('/admin/support/:id/status', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body || {};
  if (!status || !['Pending', 'In Progress', 'Resolved'].includes(status)) {
    res.status(400).json({ error: 'Valid status is required (Pending, In Progress, Resolved).' });
    return;
  }

  const tickets = readSupportDb();
  const now = new Date().toISOString();
  let targetTicket: SupportTicketRecord | null = null;

  const updated = tickets.map((t) => {
    if (t.id === id) {
      const mod: SupportTicketRecord = {
        ...t,
        status,
        updatedAt: now,
      };
      targetTicket = mod;
      return mod;
    }
    return t;
  });

  if (!targetTicket) {
    res.status(404).json({ error: 'Support ticket not found.' });
    return;
  }

  writeSupportDb(updated);

  // Notify student of status update
  addNotification({
    targetRole: 'student',
    studentId: (targetTicket as SupportTicketRecord).studentId,
    studentUsername: (targetTicket as SupportTicketRecord).studentUsername,
    title: 'Query Status Updated',
    message: `Your query "${(targetTicket as SupportTicketRecord).subject}" is now marked as "${status}".`,
    ticketId: id,
    type: 'status_updated',
  });

  res.json({ success: true, message: 'Status updated successfully.', ticket: targetTicket });
});

// Admin: Delete ticket (Admin Only)
router.delete('/admin/support/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const tickets = readSupportDb();
  const filtered = tickets.filter((t) => t.id !== id);
  writeSupportDb(filtered);

  // Also clean up notifications for this ticket
  const notifs = readNotificationsDb().filter((n) => n.ticketId !== id);
  writeNotificationsDb(notifs);

  res.json({ success: true, message: 'Ticket deleted successfully.' });
});

// ==========================================
// NOTIFICATIONS API
// ==========================================

// Student: Get notifications
router.get('/notifications/student/:studentId', (req: Request, res: Response) => {
  const { studentId } = req.params;
  const notifs = readNotificationsDb();
  const filtered = notifs
    .filter(
      (n) =>
        n.targetRole === 'student' &&
        (n.studentId === studentId || (n.studentUsername && n.studentUsername.toLowerCase() === studentId.toLowerCase()))
    )
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  res.json({ success: true, notifications: filtered });
});

// Student: Mark notifications as read
router.post('/notifications/student/:studentId/read', (req: Request, res: Response) => {
  const { studentId } = req.params;
  const { notificationId, markAll = false } = req.body || {};

  const notifs = readNotificationsDb();
  let changed = false;

  const updated = notifs.map((n) => {
    if (
      n.targetRole === 'student' &&
      (n.studentId === studentId || (n.studentUsername && n.studentUsername.toLowerCase() === studentId.toLowerCase()))
    ) {
      if (markAll || (notificationId && n.id === notificationId)) {
        changed = true;
        return { ...n, read: true };
      }
    }
    return n;
  });

  if (changed) {
    writeNotificationsDb(updated);
  }

  res.json({ success: true, message: 'Notifications updated.' });
});

// Admin: Get notifications (Admin Only)
router.get('/admin/notifications', requireAdminAuth, (_req: Request, res: Response) => {
  const notifs = readNotificationsDb();
  const adminNotifs = notifs
    .filter((n) => n.targetRole === 'admin')
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  res.json({ success: true, notifications: adminNotifs });
});

// Admin: Mark notifications as read (Admin Only)
router.post('/admin/notifications/read', requireAdminAuth, (req: Request, res: Response) => {
  const { notificationId, markAll = false } = req.body || {};
  const notifs = readNotificationsDb();
  let changed = false;

  const updated = notifs.map((n) => {
    if (n.targetRole === 'admin') {
      if (markAll || (notificationId && n.id === notificationId)) {
        changed = true;
        return { ...n, read: true };
      }
    }
    return n;
  });

  if (changed) {
    writeNotificationsDb(updated);
  }

  res.json({ success: true, message: 'Admin notifications updated.' });
});

// ==========================================
// BATCH DEMOS MANAGEMENT & STUDENT API
// ==========================================
const BATCH_DEMOS_FILE = path.resolve(process.cwd(), 'data', 'batch_demos.json');

const INITIAL_SERVER_DEMOS = [
  {
    id: 'demo_pw_physics',
    title: 'PHYSICS WALLAH DEMO',
    platformName: 'Physics Wallah',
    platformLogo: 'PW',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoId: 'dQw4w9WgXcQ',
    description: 'Complete Teaching Methodology & Full Chapter Sample Lecture',
    displayOrder: 1,
    isAvailable: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'demo_tb_matric',
    title: 'TARGET BOARD DEMO',
    platformName: 'Target Board',
    platformLogo: 'TB',
    videoUrl: 'https://www.youtube.com/watch?v=3JZ_D3ELwOQ',
    videoId: '3JZ_D3ELwOQ',
    description: 'Special Foundation & Board Exam Preparation Methodology',
    displayOrder: 2,
    isAvailable: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'demo_unacademy_jee',
    title: 'UNACADEMY DEMO',
    platformName: 'Unacademy',
    platformLogo: 'UA',
    videoUrl: 'https://www.youtube.com/watch?v=kJQP7kiw5Fk',
    videoId: 'kJQP7kiw5Fk',
    description: 'Live Interactive Session & Concept Clarity Demo',
    displayOrder: 3,
    isAvailable: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

function readBatchDemosDb(): any[] {
  try {
    if (fs.existsSync(BATCH_DEMOS_FILE)) {
      const data = fs.readFileSync(BATCH_DEMOS_FILE, 'utf-8');
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (err) {
    console.error('Error reading batch demos db:', err);
  }
  return INITIAL_SERVER_DEMOS;
}

function writeBatchDemosDb(demos: any[]): void {
  try {
    const dir = path.dirname(BATCH_DEMOS_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(BATCH_DEMOS_FILE, JSON.stringify(demos, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing batch demos db:', err);
  }
}

// Student: Get batch demos (only isAvailable = true unless ?all=true)
router.get('/batch-demos', (req: Request, res: Response) => {
  const showAll = req.query.all === 'true';
  const demos = readBatchDemosDb();
  const sorted = [...demos].sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
  const filtered = showAll ? sorted : sorted.filter((d) => d.isAvailable !== false);
  res.json({ success: true, demos: filtered });
});

// Admin: Get all batch demos (including disabled)
router.get('/admin/batch-demos', (req: Request, res: Response) => {
  const demos = readBatchDemosDb();
  const sorted = [...demos].sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
  res.json({ success: true, demos: sorted });
});

// Admin: Create new demo
router.post('/admin/batch-demos', (req: Request, res: Response) => {
  const { title, platformName, platformLogo, videoUrl, videoId, description, isAvailable, displayOrder } = req.body || {};
  if (!title || !videoUrl) {
    res.status(400).json({ error: 'Title and videoUrl are required' });
    return;
  }
  const demos = readBatchDemosDb();
  const id = req.body.id || `demo_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();
  const newDemo = {
    id,
    title: String(title).trim(),
    platformName: String(platformName || 'Free Study Campus').trim(),
    platformLogo: String(platformLogo || '').trim(),
    videoUrl: String(videoUrl).trim(),
    videoId: String(videoId || '').trim(),
    description: String(description || '').trim(),
    displayOrder: typeof displayOrder === 'number' ? displayOrder : demos.length + 1,
    isAvailable: isAvailable !== false,
    createdAt: now,
    updatedAt: now,
  };
  demos.push(newDemo);
  demos.sort((a, b) => a.displayOrder - b.displayOrder);
  writeBatchDemosDb(demos);
  res.json({ success: true, demo: newDemo });
});

// Admin: Update demo
router.put('/admin/batch-demos/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const patch = req.body || {};
  const demos = readBatchDemosDb();
  const idx = demos.findIndex((d) => d.id === id);
  if (idx === -1) {
    res.status(404).json({ error: 'Demo not found' });
    return;
  }
  const updated = {
    ...demos[idx],
    ...patch,
    updatedAt: new Date().toISOString(),
  };
  demos[idx] = updated;
  demos.sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
  writeBatchDemosDb(demos);
  res.json({ success: true, demo: updated });
});

// Admin: Delete demo
router.delete('/admin/batch-demos/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const demos = readBatchDemosDb();
  const filtered = demos.filter((d) => d.id !== id);
  writeBatchDemosDb(filtered);
  res.json({ success: true, message: 'Demo deleted successfully' });
});

// Admin: Reorder demos
router.post('/admin/batch-demos/reorder', (req: Request, res: Response) => {
  const { orderedIds } = req.body || {};
  if (!Array.isArray(orderedIds)) {
    res.status(400).json({ error: 'orderedIds array required' });
    return;
  }
  const demos = readBatchDemosDb();
  const updated = demos.map((d) => {
    const order = orderedIds.indexOf(d.id);
    return order !== -1 ? { ...d, displayOrder: order + 1 } : d;
  });
  updated.sort((a, b) => a.displayOrder - b.displayOrder);
  writeBatchDemosDb(updated);
  res.json({ success: true, demos: updated });
});

export default router;
