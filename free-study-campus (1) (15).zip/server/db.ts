import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const DB_FILE = path.join(DATA_DIR, 'campus_db.json');

export interface PlatformRecord {
  id: string;
  name: string;
  tagline: string;
  description: string;
  accentColor: string;
  externalUrl: string;
  logo: string;
  displayOrder: number;
  isAvailable: boolean;
  totalBatches?: number;
  createdAt: string;
  updatedAt: string;
}

export interface BatchRecord {
  id: string;
  platformId: string;
  title: string;
  shortDescription: string;
  thumbnail: string;
  teacherName: string;
  subject: string;
  category: string;
  batchUrl: string;
  startDate: string;
  status: 'Active' | 'Upcoming' | 'Completed';
  displayOrder: number;
  isFeatured: boolean;
  isAvailable: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AnnouncementRecord {
  id: string;
  title: string;
  message: string;
  date: string;
  link?: string;
  isActive: boolean;
  createdAt: string;
}

export interface UpcomingRecord {
  id: string;
  batchName: string;
  platform: string;
  description: string;
  thumbnail: string;
  expectedDate: string;
  externalUrl?: string;
  status: 'Upcoming' | 'In Preparation';
  createdAt: string;
}

export interface SettingsRecord {
  websiteName: string;
  tagline: string;
  logo: string;
  defaultTheme: string;
  maintenanceMode: boolean;
  announcementBanner: string;
  contactLink: string;
  telegramChannelUrl?: string;
  telegramBotUrl?: string;
  telegramBotHandle?: string;
  upiId?: string;
  qrImageUrl?: string;
  feeText?: string;
  customSettings?: Record<string, string>;
  updatedAt?: string;
}

export interface CampusDatabase {
  platforms: PlatformRecord[];
  batches: BatchRecord[];
  announcements: AnnouncementRecord[];
  upcoming: UpcomingRecord[];
  settings: SettingsRecord;
}

const DEFAULT_DB: CampusDatabase = {
  platforms: [
    {
      id: 'target-board',
      name: 'Target Board',
      tagline: 'Authorized Learning Partner',
      description: '',
      accentColor: '#00e5ff',
      externalUrl: 'https://targetboard.com.in',
      logo: 'TB',
      displayOrder: 1,
      isAvailable: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'nexttoppers',
      name: 'NextToppers',
      tagline: 'Authorized Learning Partner',
      description: '',
      accentColor: '#00e5ff',
      externalUrl: 'https://nexttoppers.com',
      logo: 'NT',
      displayOrder: 2,
      isAvailable: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'vidyakul',
      name: 'Vidyakul',
      tagline: 'Authorized Learning Partner',
      description: '',
      accentColor: '#00e5ff',
      externalUrl: 'https://vidyakul.com',
      logo: 'VK',
      displayOrder: 3,
      isAvailable: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ],
  batches: [],
  announcements: [
    {
      id: 'ann-1',
      title: 'New Session 2026-2027 Batches Live!',
      message: 'Lakshya JEE and Yakeen NEET study batches have been updated with complete formula compendiums.',
      date: 'September 2026',
      link: 'https://pwthor.live/study/batches',
      isActive: true,
      createdAt: new Date().toISOString(),
    },
  ],
  upcoming: [
    {
      id: 'up-1',
      batchName: 'Arjuna JEE 2027 Comprehensive Foundation',
      platform: 'Physics Wallah',
      description: 'Comprehensive 2-year integrated course with foundational kinematics, vectors, and organic basics.',
      thumbnail: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&auto=format&fit=crop&q=80',
      expectedDate: 'October 15, 2026',
      externalUrl: 'https://pwthor.live/study/batches',
      status: 'Upcoming',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'up-2',
      batchName: 'NEET 2027 Sprint Biology & Biomolecules',
      platform: 'Physics Wallah',
      description: 'NCERT diagram masterclass and rapid active recall sessions for medical aspirants.',
      thumbnail: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=600&auto=format&fit=crop&q=80',
      expectedDate: 'November 01, 2026',
      externalUrl: 'https://pwthor.live/study/batches',
      status: 'In Preparation',
      createdAt: new Date().toISOString(),
    },
  ],
  settings: {
    websiteName: 'FREE STUDY CAMPUS',
    tagline: 'Learn More. Grow More.',
    logo: '',
    defaultTheme: 'cyan',
    maintenanceMode: false,
    announcementBanner: 'Free and authorized study resources for competitive exam aspirants nationwide.',
    contactLink: 'https://t.me/freestudycampus',
    telegramChannelUrl: 'https://t.me/freestudycampus',
    telegramBotUrl: 'https://t.me/Freestudycampusbot',
    telegramBotHandle: '@Freestudycampusbot',
    upiId: '77630159@ybl',
    feeText: '₹49',
  },
};

// Initialize DB file if not exists
export function initDb(): CampusDatabase {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2), 'utf-8');
      return DEFAULT_DB;
    }

    const content = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(content);
    const parsedPlatforms = Array.isArray(parsed.platforms) ? parsed.platforms : DEFAULT_DB.platforms;

    const merged: CampusDatabase = {
      platforms: parsedPlatforms,
      batches: Array.isArray(parsed.batches) ? parsed.batches : DEFAULT_DB.batches,
      announcements: Array.isArray(parsed.announcements) ? parsed.announcements : DEFAULT_DB.announcements,
      upcoming: Array.isArray(parsed.upcoming) ? parsed.upcoming : DEFAULT_DB.upcoming,
      settings: { ...DEFAULT_DB.settings, ...(parsed.settings || {}) },
    };
    return merged;
  } catch (err) {
    console.error('Error reading campus database, falling back to defaults:', err);
    return DEFAULT_DB;
  }
}

export function readDb(): CampusDatabase {
  return initDb();
}

export function writeDb(data: CampusDatabase): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tempFile = `${DB_FILE}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempFile, DB_FILE);
  } catch (err) {
    console.error('Error writing campus database:', err);
    throw new Error('Database write failed');
  }
}
