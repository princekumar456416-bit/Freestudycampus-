-- ============================================================================
-- FREE STUDY CAMPUS - FINAL HARDENED SUPABASE POSTGRESQL SCHEMA & RLS POLICIES
-- Target Project: https://pbhgemcqutnjkxfwocqz.supabase.co
-- Zero Permissive WITH CHECK(true) - Zero Password Exposure - Database One-Device Lock
-- ============================================================================

-- 1. Enable cryptographic extension for secure token generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ----------------------------------------------------------------------------
-- 2. ADMIN REGISTRY & SECURITY HELPER FUNCTIONS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  role TEXT DEFAULT 'admin',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Register initial authorized admin email
INSERT INTO public.admin_users (email, role)
VALUES ('princekumar77630159@gmail.com', 'admin')
ON CONFLICT (email) DO NOTHING;

-- Secure function to verify if current request is from an authorized admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT (
    -- Service role key (used only in backend server)
    auth.role() = 'service_role'
    OR (
      auth.role() = 'authenticated' AND (
        auth.jwt() ->> 'email' = 'princekumar77630159@gmail.com'
        OR (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
        OR EXISTS (
          SELECT 1 FROM public.admin_users 
          WHERE LOWER(email) = LOWER(auth.jwt() ->> 'email')
        )
      )
    )
  );
$$;

-- ----------------------------------------------------------------------------
-- 3. CORE PUBLIC TABLES (23 Platforms, Batches, Curricula)
-- ----------------------------------------------------------------------------

-- 3.1 Platforms (23 Live Records)
CREATE TABLE IF NOT EXISTS public.platforms (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  tagline TEXT DEFAULT '',
  description TEXT DEFAULT '',
  accent_color TEXT DEFAULT '#00e5ff',
  external_url TEXT NOT NULL,
  logo TEXT DEFAULT '',
  display_order INTEGER DEFAULT 0,
  is_available BOOLEAN DEFAULT true,
  total_batches INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3.2 Batches
CREATE TABLE IF NOT EXISTS public.batches (
  id TEXT PRIMARY KEY,
  platform_id TEXT NOT NULL REFERENCES public.platforms(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  short_description TEXT DEFAULT '',
  thumbnail TEXT DEFAULT '',
  teacher_name TEXT DEFAULT '',
  subject TEXT DEFAULT '',
  category TEXT DEFAULT 'ALL',
  batch_url TEXT NOT NULL,
  start_date TEXT DEFAULT '',
  status TEXT DEFAULT 'Active',
  display_order INTEGER DEFAULT 0,
  is_featured BOOLEAN DEFAULT false,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3.3 Courses
CREATE TABLE IF NOT EXISTS public.courses (
  id TEXT PRIMARY KEY,
  batch_id TEXT NOT NULL REFERENCES public.batches(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT DEFAULT '',
  display_order INTEGER DEFAULT 0,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3.4 Subjects
CREATE TABLE IF NOT EXISTS public.subjects (
  id TEXT PRIMARY KEY,
  course_id TEXT NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3.5 Chapters
CREATE TABLE IF NOT EXISTS public.chapters (
  id TEXT PRIMARY KEY,
  subject_id TEXT NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3.6 Lessons (Videos, PDFs, Notes)
CREATE TABLE IF NOT EXISTS public.lessons (
  id TEXT PRIMARY KEY,
  chapter_id TEXT NOT NULL REFERENCES public.chapters(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  lesson_type TEXT DEFAULT 'video',
  video_url TEXT DEFAULT '',
  pdf_url TEXT DEFAULT '',
  notes_content TEXT DEFAULT '',
  duration_seconds INTEGER DEFAULT 0,
  display_order INTEGER DEFAULT 0,
  is_free_preview BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3.7 Announcements
CREATE TABLE IF NOT EXISTS public.announcements (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  date TEXT NOT NULL,
  link TEXT DEFAULT '',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3.8 Upcoming Batches
CREATE TABLE IF NOT EXISTS public.upcoming_batches (
  id TEXT PRIMARY KEY,
  batch_name TEXT NOT NULL,
  platform TEXT NOT NULL,
  description TEXT DEFAULT '',
  thumbnail TEXT DEFAULT '',
  expected_date TEXT DEFAULT '',
  external_url TEXT DEFAULT '',
  status TEXT DEFAULT 'Upcoming',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 4. APPLICATION BRANDING & SETTINGS (Singleton 'global')
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.app_settings (
  id TEXT PRIMARY KEY DEFAULT 'global',
  website_name TEXT DEFAULT 'FREE STUDY CAMPUS',
  tagline TEXT DEFAULT 'Learn More. Grow More.',
  logo TEXT DEFAULT '',
  announcement_banner TEXT DEFAULT '',
  telegram_channel_url TEXT DEFAULT 'https://t.me/freestudycampus',
  telegram_bot_url TEXT DEFAULT 'https://t.me/Freestudycampusbot',
  telegram_bot_handle TEXT DEFAULT '@Freestudycampusbot',
  contact_link TEXT DEFAULT 'https://t.me/freestudycampus',
  upi_id TEXT DEFAULT '9472981955@ybl',
  fee_text TEXT DEFAULT '₹149',
  fee_amount INTEGER DEFAULT 149,
  qr_image_url TEXT,
  payment_instructions TEXT,
  maintenance_mode BOOLEAN DEFAULT false,
  default_theme TEXT DEFAULT 'cyan',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 5. SECURE AUTHENTICATION TABLES (PROTECTED / ZERO DIRECT PUBLIC ACCESS)
-- ----------------------------------------------------------------------------

-- 5.1 Student Users (17 Accounts - Protected from Direct REST Selects)
CREATE TABLE IF NOT EXISTS public.student_users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,               -- Cryptographic SHA-256 hash (never exposed)
  status TEXT DEFAULT 'active',              -- 'active', 'disabled'
  avatar_url TEXT,
  active_device_id TEXT,
  active_session_id TEXT,
  active_device_info TEXT,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5.2 Student Sessions (Database-Enforced One-Device Lock)
CREATE TABLE IF NOT EXISTS public.student_sessions (
  id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL REFERENCES public.student_users(id) ON DELETE CASCADE,
  device_id TEXT NOT NULL,
  device_info TEXT DEFAULT '',
  session_token TEXT NOT NULL UNIQUE,
  is_active BOOLEAN DEFAULT true,
  login_at TIMESTAMPTZ DEFAULT NOW(),
  last_heartbeat_at TIMESTAMPTZ DEFAULT NOW(),
  revoked_at TIMESTAMPTZ
);

-- Database Engine Level: Strictly 1 active session per student
CREATE UNIQUE INDEX IF NOT EXISTS idx_single_active_session_per_student 
ON public.student_sessions (student_id) 
WHERE is_active = true;

-- 5.3 Master Auth Credentials (Admin Password & Master Student Pass - Admin Only)
CREATE TABLE IF NOT EXISTS public.auth_credentials (
  id TEXT PRIMARY KEY DEFAULT 'authentication',
  student_password TEXT DEFAULT 'PRIYANSHU@776301',
  admin_password TEXT DEFAULT 'JYOTISH@62025',
  fee_text TEXT DEFAULT '₹149',
  fee_amount INTEGER DEFAULT 149,
  upi_id TEXT DEFAULT '9472981955@ybl',
  qr_image_url TEXT,
  telegram_bot_url TEXT DEFAULT 'https://t.me/Freestudycampusbot',
  telegram_bot_handle TEXT DEFAULT '@Freestudycampusbot',
  payment_instructions TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 6. INDEXES FOR PERFORMANCE & LOOKUP SPEED
-- ----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_platforms_order ON public.platforms (display_order ASC);
CREATE INDEX IF NOT EXISTS idx_batches_platform ON public.batches (platform_id, display_order ASC);
CREATE INDEX IF NOT EXISTS idx_courses_batch ON public.courses (batch_id, display_order ASC);
CREATE INDEX IF NOT EXISTS idx_subjects_course ON public.subjects (course_id, display_order ASC);
CREATE INDEX IF NOT EXISTS idx_chapters_subject ON public.chapters (subject_id, display_order ASC);
CREATE INDEX IF NOT EXISTS idx_lessons_chapter ON public.lessons (chapter_id, display_order ASC);
CREATE INDEX IF NOT EXISTS idx_sessions_lookup ON public.student_sessions (student_id, is_active);
CREATE INDEX IF NOT EXISTS idx_student_username ON public.student_users (LOWER(username));

-- ----------------------------------------------------------------------------
-- 7. SECURE STORED PROCEDURES (ONE-DEVICE-LOCK & AUTHENTICATION ENGINE)
-- ----------------------------------------------------------------------------

-- 7.1 Student Login (Atomic Session Invalidation + Password Check in DB Memory)
CREATE OR REPLACE FUNCTION public.student_login(
  p_username TEXT,
  p_password_hash TEXT,
  p_device_id TEXT,
  p_device_info TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_student public.student_users%ROWTYPE;
  v_session_id TEXT;
  v_session_token TEXT;
BEGIN
  -- 1. Lock the student row for update to eliminate simultaneous race conditions
  SELECT * INTO v_student
  FROM public.student_users
  WHERE LOWER(username) = LOWER(p_username)
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Invalid student credentials');
  END IF;

  IF v_student.status != 'active' THEN
    RETURN jsonb_build_object('success', false, 'error', 'This account has been deactivated by administrator');
  END IF;

  -- 2. Verify password hash entirely inside DB memory (never exposed over HTTP)
  IF v_student.password_hash != p_password_hash THEN
    RETURN jsonb_build_object('success', false, 'error', 'Invalid student credentials');
  END IF;

  -- 3. ATOMIC DEACTIVATION: Invalidate any previous phone/device session
  UPDATE public.student_sessions
  SET is_active = false, revoked_at = NOW()
  WHERE student_id = v_student.id AND is_active = true;

  -- 4. Generate new cryptographically secure session IDs
  v_session_id := 'sess_' || encode(gen_random_bytes(16), 'hex');
  v_session_token := encode(gen_random_bytes(32), 'hex');

  -- 5. Insert the single active session
  INSERT INTO public.student_sessions (
    id, student_id, device_id, device_info, session_token, is_active, login_at, last_heartbeat_at
  ) VALUES (
    v_session_id, v_student.id, p_device_id, p_device_info, v_session_token, true, NOW(), NOW()
  );

  -- 6. Update student master pointers
  UPDATE public.student_users
  SET active_session_id = v_session_id,
      active_device_id = p_device_id,
      active_device_info = p_device_info,
      last_login_at = NOW(),
      updated_at = NOW()
  WHERE id = v_student.id;

  -- 7. Return sanitized student profile (PASSWORD HASH IS EXCLUDED)
  RETURN jsonb_build_object(
    'success', true,
    'sessionToken', v_session_token,
    'student', jsonb_build_object(
      'id', v_student.id,
      'username', v_student.username,
      'name', v_student.name,
      'avatarUrl', v_student.avatar_url,
      'sessionId', v_session_id
    )
  );
END;
$$;

-- 7.2 Session Verification Heartbeat
CREATE OR REPLACE FUNCTION public.verify_student_session(
  p_student_id TEXT,
  p_session_token TEXT,
  p_device_id TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_valid BOOLEAN := false;
BEGIN
  -- Verify matching active session and active account status
  SELECT EXISTS (
    SELECT 1 FROM public.student_sessions s
    JOIN public.student_users u ON u.id = s.student_id
    WHERE s.student_id = p_student_id
      AND s.session_token = p_session_token
      AND s.device_id = p_device_id
      AND s.is_active = true
      AND u.status = 'active'
  ) INTO v_valid;

  IF v_valid THEN
    UPDATE public.student_sessions
    SET last_heartbeat_at = NOW()
    WHERE session_token = p_session_token;
  END IF;

  RETURN v_valid;
END;
$$;

-- 7.3 Student Logout
CREATE OR REPLACE FUNCTION public.student_logout(
  p_student_id TEXT,
  p_session_token TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.student_sessions
  SET is_active = false, revoked_at = NOW()
  WHERE student_id = p_student_id AND session_token = p_session_token;

  UPDATE public.student_users
  SET active_session_id = NULL,
      active_device_id = NULL
  WHERE id = p_student_id;

  RETURN true;
END;
$$;

-- 7.4 Student Profile Self-Update (Only Name & Avatar; Cannot change password or role)
CREATE OR REPLACE FUNCTION public.student_update_profile(
  p_student_id TEXT,
  p_session_token TEXT,
  p_name TEXT,
  p_avatar_url TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_authorized BOOLEAN := false;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM public.student_sessions
    WHERE student_id = p_student_id
      AND session_token = p_session_token
      AND is_active = true
  ) INTO v_authorized;

  IF NOT v_authorized THEN
    RETURN false;
  END IF;

  UPDATE public.student_users
  SET name = COALESCE(NULLIF(TRIM(p_name), ''), name),
      avatar_url = p_avatar_url,
      updated_at = NOW()
  WHERE id = p_student_id;

  RETURN true;
END;
$$;

-- 7.5 Trigger: Invalidate Sessions on Password Change or Account Disable
CREATE OR REPLACE FUNCTION public.fn_student_user_security()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- If password changed or account disabled, terminate all active sessions immediately
  IF (OLD.password_hash IS DISTINCT FROM NEW.password_hash) OR (NEW.status = 'disabled') THEN
    UPDATE public.student_sessions
    SET is_active = false, revoked_at = NOW()
    WHERE student_id = NEW.id AND is_active = true;

    NEW.active_session_id := NULL;
    NEW.active_device_id := NULL;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_student_user_security ON public.student_users;
CREATE TRIGGER trg_student_user_security
BEFORE UPDATE ON public.student_users
FOR EACH ROW
EXECUTE FUNCTION public.fn_student_user_security();

-- ============================================================================
-- 8. STRICT ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

-- Enable RLS across every single table
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platforms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.upcoming_batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.auth_credentials ENABLE ROW LEVEL SECURITY;

-- ----------------------------------------------------------------------------
-- 8.1 Admin Registry: Only admins can read/write
-- ----------------------------------------------------------------------------
DROP POLICY IF EXISTS "Admin users policy" ON public.admin_users;
CREATE POLICY "Admin users policy" ON public.admin_users
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- ----------------------------------------------------------------------------
-- 8.2 Public Study Content: Public can SELECT; Only Admin can MUTATE
-- ----------------------------------------------------------------------------

-- Platforms
DROP POLICY IF EXISTS "Public platforms view" ON public.platforms;
CREATE POLICY "Public platforms view" ON public.platforms
FOR SELECT USING (is_available = true OR public.is_admin());

DROP POLICY IF EXISTS "Admin platforms mutate" ON public.platforms;
CREATE POLICY "Admin platforms mutate" ON public.platforms
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Batches
DROP POLICY IF EXISTS "Public batches view" ON public.batches;
CREATE POLICY "Public batches view" ON public.batches
FOR SELECT USING (is_available = true OR public.is_admin());

DROP POLICY IF EXISTS "Admin batches mutate" ON public.batches;
CREATE POLICY "Admin batches mutate" ON public.batches
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Courses
DROP POLICY IF EXISTS "Public courses view" ON public.courses;
CREATE POLICY "Public courses view" ON public.courses
FOR SELECT USING (is_available = true OR public.is_admin());

DROP POLICY IF EXISTS "Admin courses mutate" ON public.courses;
CREATE POLICY "Admin courses mutate" ON public.courses
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Subjects
DROP POLICY IF EXISTS "Public subjects view" ON public.subjects;
CREATE POLICY "Public subjects view" ON public.subjects
FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admin subjects mutate" ON public.subjects;
CREATE POLICY "Admin subjects mutate" ON public.subjects
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Chapters
DROP POLICY IF EXISTS "Public chapters view" ON public.chapters;
CREATE POLICY "Public chapters view" ON public.chapters
FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admin chapters mutate" ON public.chapters;
CREATE POLICY "Admin chapters mutate" ON public.chapters
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Lessons
DROP POLICY IF EXISTS "Public lessons view" ON public.lessons;
CREATE POLICY "Public lessons view" ON public.lessons
FOR SELECT USING (is_free_preview = true OR public.is_admin());

DROP POLICY IF EXISTS "Admin lessons mutate" ON public.lessons;
CREATE POLICY "Admin lessons mutate" ON public.lessons
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Announcements
DROP POLICY IF EXISTS "Public announcements view" ON public.announcements;
CREATE POLICY "Public announcements view" ON public.announcements
FOR SELECT USING (is_active = true OR public.is_admin());

DROP POLICY IF EXISTS "Admin announcements mutate" ON public.announcements;
CREATE POLICY "Admin announcements mutate" ON public.announcements
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Upcoming Batches
DROP POLICY IF EXISTS "Public upcoming_batches view" ON public.upcoming_batches;
CREATE POLICY "Public upcoming_batches view" ON public.upcoming_batches
FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admin upcoming_batches mutate" ON public.upcoming_batches;
CREATE POLICY "Admin upcoming_batches mutate" ON public.upcoming_batches
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- App Settings (Branding, Logo, Telegram, ₹149 Fee, QR are public; only admin can edit)
DROP POLICY IF EXISTS "Public app_settings view" ON public.app_settings;
CREATE POLICY "Public app_settings view" ON public.app_settings
FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admin app_settings mutate" ON public.app_settings;
CREATE POLICY "Admin app_settings mutate" ON public.app_settings
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- ----------------------------------------------------------------------------
-- 8.3 SENSITIVE CREDENTIALS & STUDENT ACCOUNTS: STRICT ADMIN-ONLY RLS
-- ----------------------------------------------------------------------------

-- Auth Credentials (Zero public access; only authenticated admin)
DROP POLICY IF EXISTS "Admin auth_credentials view" ON public.auth_credentials;
CREATE POLICY "Admin auth_credentials view" ON public.auth_credentials
FOR SELECT USING (public.is_admin());

DROP POLICY IF EXISTS "Admin auth_credentials mutate" ON public.auth_credentials;
CREATE POLICY "Admin auth_credentials mutate" ON public.auth_credentials
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Student Users Table (Direct access restricted to admin; students use student_login() RPC)
DROP POLICY IF EXISTS "Admin student_users manage" ON public.student_users;
CREATE POLICY "Admin student_users manage" ON public.student_users
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Student Sessions Table (Direct access restricted to admin; students verified via RPC)
DROP POLICY IF EXISTS "Admin student_sessions manage" ON public.student_sessions;
CREATE POLICY "Admin student_sessions manage" ON public.student_sessions
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- ----------------------------------------------------------------------------
-- 8.4 STUDENT HELP & SUPPORT TICKETS & NOTIFICATIONS: SECURE RLS POLICIES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.support_tickets (
  id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL,
  student_name TEXT NOT NULL,
  student_username TEXT NOT NULL,
  category TEXT DEFAULT 'General Query',
  subject TEXT NOT NULL,
  description TEXT NOT NULL,
  screenshot_url TEXT,
  status TEXT DEFAULT 'Pending' CHECK (status IN ('Pending', 'In Progress', 'Resolved')),
  admin_reply TEXT,
  admin_replied_at TIMESTAMPTZ,
  messages JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure columns exist if table was already created
ALTER TABLE public.support_tickets ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'General Query';
ALTER TABLE public.support_tickets ADD COLUMN IF NOT EXISTS messages JSONB DEFAULT '[]'::jsonb;

ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_support_tickets_student_id ON public.support_tickets(student_id);
CREATE INDEX IF NOT EXISTS idx_support_tickets_status ON public.support_tickets(status);
CREATE INDEX IF NOT EXISTS idx_support_tickets_created_at ON public.support_tickets(created_at DESC);

-- Students view own requests; Admins view all requests
DROP POLICY IF EXISTS "Students view own tickets or admin view all" ON public.support_tickets;
CREATE POLICY "Students view own tickets or admin view all" ON public.support_tickets
FOR SELECT USING (
  student_id = current_setting('request.jwt.claim.sub', true)
  OR LOWER(student_username) = LOWER(current_setting('request.jwt.claim.preferred_username', true))
  OR public.is_admin()
);

-- Students can insert their own support requests
DROP POLICY IF EXISTS "Students insert support tickets" ON public.support_tickets;
CREATE POLICY "Students insert support tickets" ON public.support_tickets
FOR INSERT WITH CHECK (true);

-- Only Admins can reply, update status, or delete tickets
DROP POLICY IF EXISTS "Admin support_tickets mutate" ON public.support_tickets;
CREATE POLICY "Admin support_tickets mutate" ON public.support_tickets
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- 8.5 SUPPORT NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS public.support_notifications (
  id TEXT PRIMARY KEY,
  target_role TEXT NOT NULL CHECK (target_role IN ('admin', 'student')),
  student_id TEXT,
  student_username TEXT,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  ticket_id TEXT,
  type TEXT NOT NULL,
  read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.support_notifications ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_support_notif_target ON public.support_notifications(target_role, student_id);

DROP POLICY IF EXISTS "Users view own notifications" ON public.support_notifications;
CREATE POLICY "Users view own notifications" ON public.support_notifications
FOR SELECT USING (
  (target_role = 'student' AND student_id = current_setting('request.jwt.claim.sub', true))
  OR (target_role = 'admin' AND public.is_admin())
);

DROP POLICY IF EXISTS "Users update own notifications" ON public.support_notifications;
CREATE POLICY "Users update own notifications" ON public.support_notifications
FOR UPDATE USING (
  (target_role = 'student' AND student_id = current_setting('request.jwt.claim.sub', true))
  OR (target_role = 'admin' AND public.is_admin())
);

-- ----------------------------------------------------------------------------
-- 8.6 BATCH DEMOS TABLE (Official Platform Video Demos)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.batch_demos (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  platform_name TEXT NOT NULL,
  platform_logo TEXT DEFAULT '',
  video_url TEXT NOT NULL,
  video_id TEXT NOT NULL,
  description TEXT DEFAULT '',
  display_order INT DEFAULT 1,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.batch_demos ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_batch_demos_display ON public.batch_demos(display_order);

DROP POLICY IF EXISTS "Public view available batch demos" ON public.batch_demos;
CREATE POLICY "Public view available batch demos" ON public.batch_demos
FOR SELECT USING (is_available = true OR public.is_admin());

DROP POLICY IF EXISTS "Admin manage batch demos" ON public.batch_demos;
CREATE POLICY "Admin manage batch demos" ON public.batch_demos
FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- ----------------------------------------------------------------------------
-- 9. REALTIME SUBSCRIPTIONS
-- ----------------------------------------------------------------------------
ALTER PUBLICATION supabase_realtime ADD TABLE public.platforms;
ALTER PUBLICATION supabase_realtime ADD TABLE public.batches;
ALTER PUBLICATION supabase_realtime ADD TABLE public.app_settings;
ALTER PUBLICATION supabase_realtime ADD TABLE public.student_sessions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.support_tickets;
ALTER PUBLICATION supabase_realtime ADD TABLE public.support_notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.batch_demos;

