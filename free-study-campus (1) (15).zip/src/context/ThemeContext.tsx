import React, { createContext, useContext, useEffect, useState } from 'react';
import { ThemeConfig, ThemeType, AccentColor, AccentColorPreset } from '../types';

export const ACCENT_PRESETS: AccentColorPreset[] = [
  { id: 'cyan', name: 'Electric Cyan', hex: '#00e5ff', glow: 'rgba(0, 229, 255, 0.3)' },
  { id: 'white', name: 'Pure White', hex: '#ffffff', glow: 'rgba(255, 255, 255, 0.25)' },
  { id: 'emerald', name: 'Neon Mint', hex: '#10b981', glow: 'rgba(16, 185, 129, 0.3)' },
  { id: 'violet', name: 'Royal Violet', hex: '#a855f7', glow: 'rgba(168, 85, 247, 0.3)' },
  { id: 'amber', name: 'Solar Amber', hex: '#f59e0b', glow: 'rgba(245, 158, 11, 0.3)' },
  { id: 'rose', name: 'Ruby Scarlet', hex: '#ff2e4d', glow: 'rgba(255, 46, 77, 0.32)' },
  { id: 'blue', name: 'Cobalt Sky', hex: '#3b82f6', glow: 'rgba(59, 130, 246, 0.3)' },
  { id: 'lime', name: 'Cyber Lime', hex: '#84cc16', glow: 'rgba(132, 204, 22, 0.3)' },
];

export const THEMES: Record<ThemeType, ThemeConfig> = {
  cyber: {
    id: 'cyber',
    name: 'Cyber Cyan',
    label: 'Deep Obsidian & Electric Cyan',
    isLight: false,
    primaryColor: '#00e5ff',
    secondaryColor: '#38bdf8',
    accentColor: '#00e5ff',
    accentGlow: 'rgba(0, 229, 255, 0.28)',
    bgHex: '#07090e',
    surfaceHex: '#0d1322',
    cardBg: 'rgba(13, 19, 34, 0.88)',
    borderColor: 'rgba(0, 229, 255, 0.16)',
    textColor: '#f8fafc',
    textMuted: '#94a3b8',
    activeRing: 'ring-cyan-400',
    badgeBg: 'rgba(0, 229, 255, 0.12)',
    previewColors: ['#07090e', '#0d1322', '#00e5ff'],
  },
  monochrome: {
    id: 'monochrome',
    name: 'Obsidian Dark',
    label: 'Dark & Pure White',
    isLight: false,
    primaryColor: '#ffffff',
    secondaryColor: '#e4e4e7',
    accentColor: '#ffffff',
    accentGlow: 'rgba(255, 255, 255, 0.16)',
    bgHex: '#09090b',
    surfaceHex: '#121216',
    cardBg: 'rgba(18, 18, 22, 0.92)',
    borderColor: 'rgba(255, 255, 255, 0.12)',
    textColor: '#ffffff',
    textMuted: '#a1a1aa',
    activeRing: 'ring-white',
    badgeBg: 'rgba(255, 255, 255, 0.1)',
    previewColors: ['#09090b', '#18181b', '#ffffff'],
  },
  light: {
    id: 'light',
    name: 'Pearl White',
    label: 'Clean Crisp Day Mode',
    isLight: true,
    primaryColor: '#09090b',
    secondaryColor: '#27272a',
    accentColor: '#0284c7',
    accentGlow: 'rgba(2, 132, 199, 0.15)',
    bgHex: '#f8fafc',
    surfaceHex: '#ffffff',
    cardBg: 'rgba(255, 255, 255, 0.95)',
    borderColor: 'rgba(0, 0, 0, 0.1)',
    textColor: '#09090b',
    textMuted: '#64748b',
    activeRing: 'ring-cyan-600',
    badgeBg: 'rgba(2, 132, 199, 0.08)',
    previewColors: ['#f8fafc', '#ffffff', '#09090b'],
  },
  obsidian: {
    id: 'obsidian',
    name: 'Midnight Pitch',
    label: 'True OLED Black & Silver',
    isLight: false,
    primaryColor: '#ffffff',
    secondaryColor: '#d4d4d8',
    accentColor: '#e4e4e7',
    accentGlow: 'rgba(255, 255, 255, 0.12)',
    bgHex: '#000000',
    surfaceHex: '#0d0d10',
    cardBg: 'rgba(13, 13, 16, 0.96)',
    borderColor: 'rgba(255, 255, 255, 0.1)',
    textColor: '#ffffff',
    textMuted: '#a1a1aa',
    activeRing: 'ring-zinc-400',
    badgeBg: 'rgba(255, 255, 255, 0.08)',
    previewColors: ['#000000', '#121214', '#ffffff'],
  },
  emerald: {
    id: 'emerald',
    name: 'Emerald Scholar',
    label: 'Obsidian Forest & Mint Green',
    isLight: false,
    primaryColor: '#34d399',
    secondaryColor: '#10b981',
    accentColor: '#10b981',
    accentGlow: 'rgba(16, 185, 129, 0.26)',
    bgHex: '#040f0c',
    surfaceHex: '#0b1f19',
    cardBg: 'rgba(11, 31, 25, 0.9)',
    borderColor: 'rgba(52, 211, 153, 0.2)',
    textColor: '#ecfdf5',
    textMuted: '#a7f3d0',
    activeRing: 'ring-emerald-400',
    badgeBg: 'rgba(16, 185, 129, 0.15)',
    previewColors: ['#040f0c', '#0b1f19', '#34d399'],
  },
  violet: {
    id: 'violet',
    name: 'Cosmic Violet',
    label: 'Deep Amethyst & Lavender',
    isLight: false,
    primaryColor: '#c084fc',
    secondaryColor: '#a855f7',
    accentColor: '#a855f7',
    accentGlow: 'rgba(168, 85, 247, 0.28)',
    bgHex: '#0d061c',
    surfaceHex: '#180f30',
    cardBg: 'rgba(24, 15, 48, 0.9)',
    borderColor: 'rgba(192, 132, 252, 0.2)',
    textColor: '#faf5ff',
    textMuted: '#d8b4fe',
    activeRing: 'ring-purple-400',
    badgeBg: 'rgba(168, 85, 247, 0.15)',
    previewColors: ['#0d061c', '#180f30', '#c084fc'],
  },
  amber: {
    id: 'amber',
    name: 'Solar Amber',
    label: 'Dark Gold & Warm Amber',
    isLight: false,
    primaryColor: '#fbbf24',
    secondaryColor: '#f59e0b',
    accentColor: '#f59e0b',
    accentGlow: 'rgba(245, 158, 11, 0.26)',
    bgHex: '#120d04',
    surfaceHex: '#1f1508',
    cardBg: 'rgba(31, 21, 8, 0.9)',
    borderColor: 'rgba(251, 191, 36, 0.2)',
    textColor: '#fffbeb',
    textMuted: '#fde68a',
    activeRing: 'ring-amber-400',
    badgeBg: 'rgba(245, 158, 11, 0.15)',
    previewColors: ['#120d04', '#1f1508', '#fbbf24'],
  },
  rose: {
    id: 'rose',
    name: 'Ruby Red',
    label: 'Red & Pure White Theme',
    isLight: false,
    primaryColor: '#ff2e4d',
    secondaryColor: '#ffffff',
    accentColor: '#ff2e4d',
    accentGlow: 'rgba(255, 46, 77, 0.28)',
    bgHex: '#080608',
    surfaceHex: '#120b0e',
    cardBg: 'rgba(18, 12, 16, 0.88)',
    borderColor: 'rgba(255, 46, 77, 0.22)',
    textColor: '#ffffff',
    textMuted: '#e2d8dc',
    activeRing: 'ring-red-500',
    badgeBg: 'rgba(255, 46, 77, 0.14)',
    previewColors: ['#080608', '#ff2e4d', '#ffffff'],
  },
};

interface ThemeContextProps {
  theme: ThemeType;
  accent: AccentColor;
  accentHex: string;
  currentThemeColor: string;
  config: ThemeConfig;
  setTheme: (theme: ThemeType) => void;
  setAccent: (accent: AccentColor) => void;
  setCustomAccentHex: (hex: string) => void;
  toggleLightDark: () => void;
}

const ThemeContext = createContext<ThemeContextProps>({
  theme: 'rose',
  accent: 'rose',
  accentHex: '#ff2e4d',
  currentThemeColor: '#ff2e4d',
  config: THEMES.rose,
  setTheme: () => {},
  setAccent: () => {},
  setCustomAccentHex: () => {},
  toggleLightDark: () => {},
});

const THEME_STORAGE_KEY = 'free_study_campus_theme';
const ACCENT_STORAGE_KEY = 'free_study_campus_accent';
const ACCENT_HEX_STORAGE_KEY = 'free_study_campus_accent_hex';

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<ThemeType>(() => {
    try {
      const stored = localStorage.getItem(THEME_STORAGE_KEY) as ThemeType;
      if (stored && THEMES[stored]) return stored;
    } catch {
      // ignore
    }
    return 'rose';
  });

  const [accent, setAccentState] = useState<AccentColor>(() => {
    try {
      const stored = localStorage.getItem(ACCENT_STORAGE_KEY) as AccentColor;
      if (stored && ACCENT_PRESETS.some((a) => a.id === stored)) return stored;
    } catch {
      // ignore
    }
    return 'rose';
  });

  const [accentHex, setAccentHexState] = useState<string>(() => {
    try {
      const stored = localStorage.getItem(ACCENT_HEX_STORAGE_KEY);
      if (stored) return stored;
    } catch {
      // ignore
    }
    return '#ff2e4d';
  });

  const baseConfig = THEMES[theme] || THEMES.rose;
  const currentThemeColor = accentHex || baseConfig.primaryColor || '#ff2e4d';

  const config: ThemeConfig = {
    ...baseConfig,
    primaryColor: currentThemeColor,
    accentColor: currentThemeColor,
    accentGlow: `${currentThemeColor}33`,
    borderColor: `${currentThemeColor}33`,
  };

  const setTheme = (newTheme: ThemeType) => {
    setThemeState(newTheme);
    const themeConfig = THEMES[newTheme];
    if (themeConfig) {
      setAccentHexState(themeConfig.primaryColor);
      setAccentState((themeConfig.id as AccentColor) || 'rose');
      try {
        localStorage.setItem(THEME_STORAGE_KEY, newTheme);
        localStorage.setItem(ACCENT_STORAGE_KEY, (themeConfig.id as AccentColor) || 'rose');
        localStorage.setItem(ACCENT_HEX_STORAGE_KEY, themeConfig.primaryColor);
      } catch {
        // ignore
      }
    }
  };

  const setAccent = (newAccent: AccentColor) => {
    setAccentState(newAccent);
    const preset = ACCENT_PRESETS.find((a) => a.id === newAccent);
    if (preset) {
      setAccentHexState(preset.hex);
      try {
        localStorage.setItem(ACCENT_STORAGE_KEY, newAccent);
        localStorage.setItem(ACCENT_HEX_STORAGE_KEY, preset.hex);
      } catch {
        // ignore
      }
    }
  };

  const setCustomAccentHex = (hex: string) => {
    setAccentHexState(hex);
    try {
      localStorage.setItem(ACCENT_HEX_STORAGE_KEY, hex);
    } catch {
      // ignore
    }
  };

  const toggleLightDark = () => {
    if (theme === 'light') {
      setTheme('cyber');
    } else {
      setTheme('light');
    }
  };

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-theme', theme);
    root.setAttribute('data-accent', accent);

    if (config.isLight) {
      root.classList.add('light-mode');
      root.classList.remove('dark-mode');
    } else {
      root.classList.add('dark-mode');
      root.classList.remove('light-mode');
    }

    root.style.setProperty('--color-primary', currentThemeColor);
    root.style.setProperty('--color-secondary', config.secondaryColor);
    root.style.setProperty('--color-accent', currentThemeColor);
    root.style.setProperty('--color-glow', `${currentThemeColor}40`);
    root.style.setProperty('--card-theme-accent', currentThemeColor);
    root.style.setProperty('--card-theme-glow', `${currentThemeColor}33`);
    root.style.setProperty('--color-bg', config.bgHex);
    root.style.setProperty('--color-surface', config.surfaceHex);
    root.style.setProperty('--color-card-bg', config.cardBg);
    root.style.setProperty('--color-border', `${currentThemeColor}2e`);
    root.style.setProperty('--color-text', config.textColor);
    root.style.setProperty('--color-text-muted', config.textMuted);

    document.body.style.backgroundColor = config.bgHex;
    document.body.style.color = config.textColor;
  }, [theme, accent, accentHex, currentThemeColor, config]);

  return (
    <ThemeContext.Provider
      value={{
        theme,
        accent,
        accentHex,
        currentThemeColor,
        config,
        setTheme,
        setAccent,
        setCustomAccentHex,
        toggleLightDark,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
