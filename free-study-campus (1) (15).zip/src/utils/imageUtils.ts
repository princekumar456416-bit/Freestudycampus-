/**
 * Utility functions for Batch Logo upload, processing, validation, and compression.
 * Works purely in-browser on mobile devices and desktops without any external dependencies.
 */

export const ALLOWED_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'];
export const ALLOWED_EXTENSIONS = ['.png', '.jpg', '.jpeg', '.webp'];

/**
 * Checks if a string represents an image source (data URL, HTTPS/HTTP URL, or relative path).
 */
export function isImageSource(value?: string | null): boolean {
  if (!value) return false;
  const str = value.trim();
  return (
    str.startsWith('data:image/') ||
    str.startsWith('http://') ||
    str.startsWith('https://') ||
    str.startsWith('/') ||
    str.startsWith('blob:')
  );
}

/**
 * Generates clean 2-letter uppercase initials for placeholder logos.
 */
export function getBatchInitials(name?: string): string {
  if (!name) return 'SC';
  const clean = name.trim();
  if (!clean) return 'SC';
  const words = clean.split(/\s+/).filter(Boolean);
  if (words.length >= 2) {
    return (words[0][0] + words[1][0]).toUpperCase();
  }
  return clean.slice(0, 2).toUpperCase();
}

/**
 * Validates selected file format for Batch Logo.
 */
export function validateImageFile(file: File): { valid: boolean; error?: string } {
  if (!file) {
    return { valid: false, error: 'No file selected.' };
  }

  const fileType = (file.type || '').toLowerCase();
  const fileName = (file.name || '').toLowerCase();

  const matchesType = ALLOWED_IMAGE_TYPES.some((t) => fileType.includes(t.replace('image/', '')));
  const matchesExt = ALLOWED_EXTENSIONS.some((ext) => fileName.endsWith(ext));

  if (!matchesType && !matchesExt) {
    return {
      valid: false,
      error: 'Please select a valid image file (PNG, JPG, JPEG, or WEBP).',
    };
  }

  // Soft limit before browser compression (15MB)
  if (file.size > 15 * 1024 * 1024) {
    return {
      valid: false,
      error: 'Image is too large. Please select an image under 15MB.',
    };
  }

  return { valid: true };
}

/**
 * Resizes and compresses an image file to a lightweight data URL.
 * Preserves aspect ratio, eliminates distortion, and keeps the payload under ~30-40KB
 * for fast loading and seamless JSON / localStorage persistence.
 */
export async function compressAndCropBatchLogo(
  file: File,
  maxDimension = 280,
  quality = 0.85
): Promise<string> {
  const validation = validateImageFile(file);
  if (!validation.valid) {
    throw new Error(validation.error || 'Invalid image file');
  }

  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();

    reader.onerror = () => {
      reject(new Error('Failed to read image file from device.'));
    };

    reader.onload = () => {
      const dataUrl = reader.result as string;
      const img = new Image();

      img.onerror = () => {
        reject(new Error('Selected file could not be decoded as an image.'));
      };

      img.onload = () => {
        try {
          let { width, height } = img;

          // Scale down while strictly preserving aspect ratio
          if (width > maxDimension || height > maxDimension) {
            if (width >= height) {
              height = Math.round((height * maxDimension) / width);
              width = maxDimension;
            } else {
              width = Math.round((width * maxDimension) / height);
              height = maxDimension;
            }
          }

          // Ensure minimum valid dimensions
          width = Math.max(1, width);
          height = Math.max(1, height);

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext('2d', { alpha: true });
          if (!ctx) {
            // Fallback to original read if canvas context fails
            resolve(dataUrl);
            return;
          }

          // High quality downsampling
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(img, 0, 0, width, height);

          // Attempt WebP export for highest compression efficiency
          let output = '';
          try {
            output = canvas.toDataURL('image/webp', quality);
          } catch {
            output = '';
          }

          // If browser doesn't support canvas toDataURL with webp or if blank
          if (!output || !output.startsWith('data:image/webp')) {
            // Fall back to PNG if transparent, or JPEG
            const isPng = file.type.toLowerCase().includes('png');
            output = canvas.toDataURL(isPng ? 'image/png' : 'image/jpeg', quality);
          }

          resolve(output);
        } catch (err) {
          console.warn('Canvas compression encountered an issue, using reader fallback:', err);
          resolve(dataUrl);
        }
      };

      img.src = dataUrl;
    };

    reader.readAsDataURL(file);
  });
}

/**
 * Specifically optimizes and formats the Official Website & PWA Web Logo.
 * Produces a square 512x512 high-resolution, low-payload image (~30-60KB)
 * preserving transparency and high fidelity for header, splash screen, favicon, and PWA icon.
 */
export async function compressOfficialWebLogo(file: File): Promise<string> {
  if (!file) {
    throw new Error('Please select an image file');
  }

  // Broad accept for Android mobile photo pickers
  const fileType = (file.type || '').toLowerCase();
  const fileName = (file.name || '').toLowerCase();
  const isImage = fileType.startsWith('image/') ||
    ALLOWED_EXTENSIONS.some((ext) => fileName.endsWith(ext));

  if (!isImage) {
    throw new Error('Please select a valid image file (PNG, JPG, or WEBP)');
  }

  if (file.size > 20 * 1024 * 1024) {
    throw new Error('Image size is too large. Please select an image under 20MB.');
  }

  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();

    reader.onerror = () => {
      reject(new Error('Failed to read image file from your device.'));
    };

    reader.onload = () => {
      const dataUrl = reader.result as string;
      const img = new Image();

      img.onerror = () => {
        reject(new Error('Unable to decode image. Please try a different photo.'));
      };

      img.onload = () => {
        try {
          const TARGET_SIZE = 512;
          const canvas = document.createElement('canvas');
          canvas.width = TARGET_SIZE;
          canvas.height = TARGET_SIZE;

          const ctx = canvas.getContext('2d', { alpha: true });
          if (!ctx) {
            resolve(dataUrl);
            return;
          }

          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';

          // Center-fit the image inside 512x512 with proper aspect ratio
          const scale = Math.min(TARGET_SIZE / img.width, TARGET_SIZE / img.height);
          const drawWidth = Math.round(img.width * scale);
          const drawHeight = Math.round(img.height * scale);
          const offsetX = Math.round((TARGET_SIZE - drawWidth) / 2);
          const offsetY = Math.round((TARGET_SIZE - drawHeight) / 2);

          // Clear transparent canvas
          ctx.clearRect(0, 0, TARGET_SIZE, TARGET_SIZE);
          ctx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);

          // Prefer PNG to preserve transparency for clean logos
          let output = '';
          try {
            output = canvas.toDataURL('image/png', 0.95);
          } catch {
            output = '';
          }

          // If output is too large (> 300KB), compress with WebP
          if (!output || output.length > 300 * 1024) {
            try {
              const webpOutput = canvas.toDataURL('image/webp', 0.9);
              if (webpOutput.startsWith('data:image/webp')) {
                output = webpOutput;
              }
            } catch {
              // keep existing
            }
          }

          resolve(output || dataUrl);
        } catch (err) {
          console.warn('Official logo canvas processing failed, fallback to raw read:', err);
          resolve(dataUrl);
        }
      };

      img.src = dataUrl;
    };

    reader.readAsDataURL(file);
  });
}

