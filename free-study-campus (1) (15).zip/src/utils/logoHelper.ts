/**
 * Global Logo Helper: Single Source of Truth for Free Study Campus logo.
 * Ensures that whenever Admin updates the logo in Admin Panel,
 * all parts of the website (Header, Splash Screen, Admin Header, PWA)
 * automatically display the fresh logo with cache busting and zero blank state.
 */

export const DEFAULT_FALLBACK_LOGO = '/logo.png';

export function getWebsiteLogo(logoFromSettings?: string | null, updatedAt?: string | null): string {
  if (logoFromSettings && typeof logoFromSettings === 'string') {
    const trimmed = logoFromSettings.trim();
    if (trimmed.length > 0 && trimmed !== 'null' && trimmed !== 'undefined') {
      // Data URLs can be used directly without cache-busting
      if (trimmed.startsWith('data:') || trimmed.startsWith('blob:')) {
        return trimmed;
      }
      // Remote URLs or local paths with timestamp cache buster
      const timestamp = updatedAt ? new Date(updatedAt).getTime() : Date.now();
      const separator = trimmed.includes('?') ? '&' : '?';
      return `${trimmed}${separator}v=${timestamp}`;
    }
  }
  // Default fallback if no custom logo is set yet
  return DEFAULT_FALLBACK_LOGO;
}

/**
 * Validates that an image URL or data URL is decodable and renderable by browser
 * before committing it to database or settings.
 */
export function verifyImageUrl(url: string, timeoutMs = 4000): Promise<boolean> {
  if (!url || typeof url !== 'string' || !url.trim()) return Promise.resolve(false);
  const clean = url.trim();
  if (clean === 'null' || clean === 'undefined') return Promise.resolve(false);

  return new Promise((resolve) => {
    let finished = false;
    const img = new Image();
    const timer = setTimeout(() => {
      if (!finished) {
        finished = true;
        resolve(false);
      }
    }, timeoutMs);

    img.onload = () => {
      if (!finished) {
        finished = true;
        clearTimeout(timer);
        resolve(true);
      }
    };

    img.onerror = () => {
      if (!finished) {
        finished = true;
        clearTimeout(timer);
        resolve(false);
      }
    };

    img.src = clean;
  });
}

/**
 * Dynamically updates document favicon, shortcut icon, and apple touch icon
 * across the browser tab and mobile home screen shortcut with cache busting.
 */
export function updateDocumentFavicon(logoUrl: string): void {
  if (typeof document === 'undefined' || !logoUrl) return;

  // Use clean favicon path if data URL is too long
  const targetFavicon = (logoUrl && !logoUrl.startsWith('data:')) ? logoUrl : '/favicon.png';

  try {
    const iconLinks = document.querySelectorAll<HTMLLinkElement>(
      "link[rel*='icon'], link[rel='apple-touch-icon']"
    );

    iconLinks.forEach((link) => {
      link.href = targetFavicon;
    });

    // If no favicon link exists in head, create one
    if (iconLinks.length === 0) {
      const link = document.createElement('link');
      link.rel = 'icon';
      link.href = targetFavicon;
      document.head.appendChild(link);
    }
  } catch (err) {
    console.warn('Failed to dynamically update document favicon:', err);
  }
}


