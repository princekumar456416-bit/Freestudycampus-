export type ThemeType =
  | 'monochrome'
  | 'light'
  | 'obsidian'
  | 'emerald'
  | 'cyber'
  | 'violet'
  | 'amber'
  | 'rose';

export type AccentColor =
  | 'white'
  | 'cyan'
  | 'emerald'
  | 'violet'
  | 'amber'
  | 'rose'
  | 'blue'
  | 'lime';

export interface AccentColorPreset {
  id: AccentColor;
  name: string;
  hex: string;
  glow: string;
}

export interface ThemeConfig {
  id: ThemeType;
  name: string;
  label: string;
  isLight?: boolean;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  accentGlow: string;
  bgHex: string;
  surfaceHex: string;
  cardBg: string;
  borderColor: string;
  textColor: string;
  textMuted: string;
  activeRing: string;
  badgeBg: string;
  previewColors: [string, string, string];
}

export type NavView =
  | 'HOME'
  | 'PLATFORMS'
  | 'UPCOMING'
  | 'SUPPORT'
  | 'PROFILE'
  | 'BATCH_DEMO';

export type TabType = NavView;

export interface ClassSession {
  id: string;
  title: string;
  subject: string;
  teacher: string;
  time: string;
  duration: string;
  status: 'Live' | 'Upcoming' | 'Completed';
  thumbnail?: string;
  videoUrl?: string;
  notesUrl?: string;
  chapterTitle?: string;
}

export interface EnrolledBatch {
  id: string;
  title: string;
  category: string;
  subtitle: string;
  thumbnail: string;
  faculty: string;
  isEnrolled?: boolean;
  totalClasses?: number;
  todayClasses?: ClassSession[];
}

export interface AppAnnouncement {
  id: string;
  batchId?: string;
  author: string;
  authorAvatar?: string;
  date: string;
  time: string;
  isNew: boolean;
  title: string;
  description: string;
  bannerImage?: string;
  link?: string;
  tags?: string[];
  filterTime: 'Today' | 'Yesterday' | 'Older';
}

export interface BatchItem {
  id: string;
  title: string;
  subtitle?: string;
  category: string;
  badge?: string;
  originalPrice?: string;
  freePrice?: string;
  features?: string[];
  thumbnail?: string;
  teacherName?: string;
  subject?: string;
  batchUrl?: string;
  isAvailable?: boolean;
  isEnrolled?: boolean;
  educators?: string[];
  lecturesCount?: number;
  notesCount?: number;
  rating?: number;
  featured?: boolean;
  lectures?: LectureItem[];
  notes?: NoteItem[];
}

export interface LectureItem {
  id: string;
  title: string;
  duration: string;
  educator: string;
  subject: 'Physics' | 'Chemistry' | 'Mathematics' | 'Biology' | 'General' | string;
  videoUrl?: string;
  notesCount: number;
  summary: string;
  keyTopics: string[];
}

export interface NoteItem {
  id: string;
  title: string;
  subject: string;
  pages: number;
  fileSize: string;
  description: string;
  downloadUrl?: string;
}

export interface PlatformItem {
  id: string;
  name: string;
  tagline: string;
  description: string;
  accentColor: string;
  externalUrl: string;
  logo?: string;
  totalBatches?: number;
  totalNotes?: number;
  isAvailable: boolean;
  batches?: BatchItem[];
}

export interface UserProfile {
  name: string;
  email: string;
  avatarSeed: string;
  avatarUrl?: string;
  gradeLevel: string;
  targetExam: string;
  studyMinutes: number;
  savedNotes: string[];
  bookmarkedLectures: string[];
  streakDays: number;
}
