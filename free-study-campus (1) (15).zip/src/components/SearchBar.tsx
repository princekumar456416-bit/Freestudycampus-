import React, { useState } from 'react';
import { Search, X, Sparkles } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface SearchBarProps {
  searchQuery?: string;
  query?: string;
  onSearchChange?: (q: string) => void;
  onQueryChange?: (q: string) => void;
  placeholder?: string;
  onSelectTag?: (tag: string) => void;
  selectedTag?: string;
  tags?: string[];
}

export const SearchBar: React.FC<SearchBarProps> = React.memo(({
  searchQuery,
  query,
  onSearchChange,
  onQueryChange,
  placeholder = 'Search study platforms by name...',
  onSelectTag,
  selectedTag,
  tags = ['All', 'Physics Wallah', 'Target Board', 'Vidyakul'],
}) => {
  const { currentThemeColor, config } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';
  const [isFocused, setIsFocused] = useState(false);

  const activeQuery = query !== undefined ? query : searchQuery || '';
  const setQuery = onQueryChange || onSearchChange || (() => {});
  const quickPills = tags;

  return (
    <div className="w-full flex flex-col gap-2.5">
      {/* Search Input Bar - Luxury Dark Obsidian Glass Surface with Specular Top Edge */}
      <div
        className="group relative flex items-center w-full rounded-2xl transition-all duration-300 bg-gradient-to-b from-[#150c12]/92 to-[#0c070a]/96 backdrop-blur-xl"
        style={{
          border: `1px solid ${isFocused ? `${themeColor}66` : 'rgba(255, 255, 255, 0.08)'}`,
          boxShadow: isFocused
            ? `0 10px 28px -4px rgba(0, 0, 0, 0.75), 0 0 20px -2px ${themeColor}35, inset 0 1px 0 rgba(255, 255, 255, 0.15)`
            : '0 6px 20px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.06)',
        }}
      >
        {/* Specular Inner Glare */}
        <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/[0.04] to-transparent pointer-events-none rounded-t-2xl" />

        <div className="pl-4 pr-2 flex items-center pointer-events-none relative z-10">
          <Search
            className="w-4.5 h-4.5 transition-colors duration-300"
            style={{
              color: isFocused ? themeColor : '#94a3b8',
            }}
          />
        </div>

        <input
          type="text"
          value={activeQuery}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder={placeholder}
          className="relative z-10 w-full py-3.5 pr-4 bg-transparent text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none tracking-wide"
        />

        {activeQuery && (
          <button
            onClick={() => setQuery('')}
            type="button"
            aria-label="Clear search"
            className="relative z-10 p-1.5 mr-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Modern Filter Chips - Smooth Touch Scrolling & Theme Glow */}
      {onSelectTag && (
        <div className="flex items-center gap-2 overflow-x-auto py-1 scrollbar-none text-xs touch-pan-x overscroll-x-contain select-none">
          <div className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5 mr-0.5 shrink-0 select-none">
            <Sparkles className="w-3.5 h-3.5" style={{ color: themeColor }} />
            <span className="tracking-wide">Filter:</span>
          </div>
          {quickPills.map((tag) => {
            const isTagActive = selectedTag === tag || (!selectedTag && tag === 'All');
            return (
              <button
                key={tag}
                type="button"
                onClick={() => onSelectTag(tag === 'All' ? '' : tag)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-200 cursor-pointer select-none active:scale-95 ${
                  isTagActive
                    ? 'text-white border font-bold'
                    : 'text-slate-300 hover:text-white bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 shadow-sm'
                }`}
                style={
                  isTagActive
                    ? {
                        backgroundColor: `${themeColor}20`,
                        borderColor: `${themeColor}60`,
                        boxShadow: `0 0 14px -2px ${themeColor}40, inset 0 1px 0 rgba(255, 255, 255, 0.18)`,
                      }
                    : undefined
                }
              >
                {tag}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
});
