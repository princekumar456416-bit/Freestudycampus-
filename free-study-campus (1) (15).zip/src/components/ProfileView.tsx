import React, { useState, useRef, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';
import { UserProfile } from '../types';
import { ThemeSwitcher } from './ThemeSwitcher';
import { compressAndCropBatchLogo } from '../utils/imageUtils';
import { StudentUser } from '../services/studentUserService';
import {
  User,
  Camera,
  Sparkles,
  Bookmark,
  BookOpen,
  Edit3,
  Check,
  RotateCcw,
  Loader2,
  Smartphone,
  Shield,
  LogOut,
  ShieldCheck,
  Calendar,
  Lock,
  X,
  AlertCircle,
  GraduationCap,
  Hash,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface ProfileViewProps {
  user: UserProfile;
  student?: StudentUser | null;
  studentAvatarUrl?: string | null;
  onUpdateAvatar?: (avatarUrl: string) => Promise<void>;
  onUpdateUser: (updated: Partial<UserProfile>) => void;
  onReplaySplash: () => void;
  onOpenAdmin: () => void;
  onLogoutStudent?: () => void;
  onOpenSupport?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = React.memo(({
  user,
  student,
  studentAvatarUrl,
  onUpdateAvatar,
  onUpdateUser,
  onReplaySplash,
  onOpenAdmin,
  onLogoutStudent,
}) => {
  const { config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Avatar Preview State
  const [avatarPreview, setAvatarPreview] = useState<string | null>(
    studentAvatarUrl || user.avatarUrl || (user.avatarSeed?.startsWith('data:') ? user.avatarSeed : null)
  );
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [photoMessage, setPhotoMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Profile Edit State
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [nameInput, setNameInput] = useState(user.name || 'Student');
  const [targetExamInput, setTargetExamInput] = useState(user.targetExam || 'NEET / JEE 2026');
  const [gradeLevelInput, setGradeLevelInput] = useState(user.gradeLevel || 'Class 12th');
  const [editSuccessMessage, setEditSuccessMessage] = useState<string | null>(null);

  const { isInstalled, triggerInstall } = usePWAInstall();

  // Sync avatarPreview whenever props change
  useEffect(() => {
    if (studentAvatarUrl) {
      setAvatarPreview(studentAvatarUrl);
    } else if (user.avatarUrl) {
      setAvatarPreview(user.avatarUrl);
    } else if (user.avatarSeed?.startsWith('data:') || user.avatarSeed?.startsWith('http')) {
      setAvatarPreview(user.avatarSeed);
    }
  }, [studentAvatarUrl, user.avatarUrl, user.avatarSeed]);

  // Keep local inputs in sync with user state
  useEffect(() => {
    setNameInput(user.name || 'Student');
    setTargetExamInput(user.targetExam || 'NEET / JEE 2026');
    setGradeLevelInput(user.gradeLevel || 'Class 12th');
  }, [user.name, user.targetExam, user.gradeLevel]);

  const handleSaveProfile = () => {
    const trimmedName = nameInput.trim();
    if (!trimmedName) {
      setPhotoMessage({ type: 'error', text: 'Display Name cannot be empty.' });
      return;
    }

    onUpdateUser({
      name: trimmedName,
      targetExam: targetExamInput.trim() || undefined,
      gradeLevel: gradeLevelInput.trim() || undefined,
    });

    setIsEditingProfile(false);
    setEditSuccessMessage('Profile details updated successfully!');
    setTimeout(() => setEditSuccessMessage(null), 3000);
  };

  const handleCancelEdit = () => {
    setNameInput(user.name || 'Student');
    setTargetExamInput(user.targetExam || 'NEET / JEE 2026');
    setGradeLevelInput(user.gradeLevel || 'Class 12th');
    setIsEditingProfile(false);
  };

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingPhoto(true);
    setPhotoMessage(null);

    try {
      // Compress and crop image to a crisp 280x280 square for avatar
      const compressedDataUrl = await compressAndCropBatchLogo(file, 280, 0.85);
      setAvatarPreview(compressedDataUrl);

      if (onUpdateAvatar) {
        await onUpdateAvatar(compressedDataUrl);
      }
      onUpdateUser({ avatarUrl: compressedDataUrl, avatarSeed: compressedDataUrl });
      setPhotoMessage({ type: 'success', text: 'Profile photo updated successfully!' });
      setTimeout(() => setPhotoMessage(null), 3500);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to process image';
      setPhotoMessage({ type: 'error', text: `Upload Error: ${msg}` });
      setTimeout(() => setPhotoMessage(null), 5000);
    } finally {
      setIsUploadingPhoto(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const displayName = user.name || student?.name || 'Student';
  const username = student?.username || user.name?.toLowerCase().replace(/\s+/g, '_') || 'student';
  const accountCreated = student?.createdAt
    ? new Date(student.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    : 'Active';

  return (
    <div
      className="w-full pb-24 flex flex-col gap-4 sm:gap-6 max-w-3xl mx-auto select-none"
      style={{
        transform: 'translateZ(0)',
        contain: 'layout style',
      }}
    >
      {/* Hidden File Input for Profile Photo Upload */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handlePhotoSelect}
        accept="image/png, image/jpeg, image/jpg, image/webp"
        className="hidden"
      />

      {/* ======================================================== */}
      {/* 1. LUXURY STUDENT PROFILE HEADER CARD                    */}
      {/* ======================================================== */}
      <section className="relative rounded-3xl p-5 sm:p-7 glass-panel border border-white/[0.08] overflow-hidden shadow-2xl">
        {/* Subtle Specular Top Hairline Rim */}
        <div
          className="absolute top-0 inset-x-0 h-[1.5px] pointer-events-none opacity-50"
          style={{
            background: `linear-gradient(90deg, transparent 0%, ${themeColor}66 25%, #ffffffcc 50%, ${themeColor}66 75%, transparent 100%)`,
          }}
        />

        {/* Ambient Warm Obsidian Glow */}
        <div
          className="absolute -top-12 -right-12 w-48 h-48 rounded-full pointer-events-none opacity-25"
          style={{
            background: `radial-gradient(circle, ${themeColor}66 0%, transparent 70%)`,
          }}
        />

        <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-4 sm:gap-6 text-center sm:text-left">
          {/* Avatar Pedestal with Luminous Ring and Camera Trigger */}
          <div className="relative group shrink-0 flex items-center justify-center">
            {/* Ambient Halo */}
            <div
              className="absolute -inset-1.5 rounded-full pointer-events-none opacity-30 group-hover:opacity-60 transition-opacity duration-300"
              style={{
                background: `radial-gradient(circle, ${themeColor}77 0%, transparent 70%)`,
              }}
            />

            {/* Circular Avatar Container */}
            <div
              className="relative z-10 w-24 h-24 sm:w-28 sm:h-28 rounded-full flex items-center justify-center overflow-hidden transition-all duration-300 shadow-[0_12px_32px_rgba(0,0,0,0.85)] border-2 border-white/15 group-hover:border-white/30"
              style={{
                backgroundColor: '#0a0508',
                boxShadow: `0 12px 30px -6px rgba(0, 0, 0, 0.9), 0 0 16px -2px ${themeColor}33`,
              }}
            >
              {avatarPreview ? (
                <img
                  src={avatarPreview}
                  alt={displayName}
                  className="w-full h-full object-cover rounded-full aspect-square select-none pointer-events-none transition-transform duration-300 group-hover:scale-105"
                />
              ) : (
                <div
                  className="w-full h-full flex items-center justify-center text-white"
                  style={{
                    background: `linear-gradient(135deg, ${themeColor}cc 0%, #150a10 100%)`,
                  }}
                >
                  <User className="w-12 h-12 text-white/90 drop-shadow-md" />
                </div>
              )}

              {/* Uploading Spinner */}
              {isUploadingPhoto && (
                <div className="absolute inset-0 bg-black/75 backdrop-blur-sm flex flex-col items-center justify-center gap-1 rounded-full z-20">
                  <Loader2 className="w-6 h-6 text-white animate-spin" />
                  <span className="text-[9px] font-bold text-white tracking-widest uppercase">Saving</span>
                </div>
              )}
            </div>

            {/* Quick Camera Action Button on Avatar */}
            <button
              type="button"
              disabled={isUploadingPhoto}
              onClick={() => fileInputRef.current?.click()}
              className="absolute z-20 -bottom-1 -right-1 w-8.5 h-8.5 rounded-full flex items-center justify-center border-2 border-[#090508] text-white shadow-xl cursor-pointer hover:scale-110 active:scale-95 transition-all"
              style={{
                backgroundColor: themeColor,
                boxShadow: `0 4px 14px ${themeColor}66`,
              }}
              title={avatarPreview ? 'Change Profile Photo' : 'Upload Profile Photo'}
              aria-label="Upload Profile Photo"
            >
              <Camera className="w-4 h-4 text-white" />
            </button>
          </div>

          {/* Student Identity Information */}
          <div className="flex-1 flex flex-col gap-2 min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="flex items-center justify-center sm:justify-start gap-2">
                  <h1 className="text-xl sm:text-2xl font-extrabold text-white font-display tracking-tight truncate">
                    {displayName}
                  </h1>

                  {!isEditingProfile && (
                    <button
                      onClick={() => setIsEditingProfile(true)}
                      type="button"
                      className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                      title="Edit Profile Information"
                      aria-label="Edit Profile"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Username & One-Device Verified Status */}
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-1">
                  <span className="text-xs font-mono text-slate-300 font-bold bg-white/[0.06] border border-white/10 px-2.5 py-0.5 rounded-lg">
                    @{username}
                  </span>

                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/25 px-2.5 py-0.5 rounded-lg">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>1-Device Protected</span>
                  </span>
                </div>
              </div>

              {/* Edit Profile Action Button */}
              {!isEditingProfile && (
                <button
                  type="button"
                  onClick={() => setIsEditingProfile(true)}
                  className="btn-secondary-glass inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold self-center sm:self-auto cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" style={{ color: themeColor }} />
                  <span>Edit Profile</span>
                </button>
              )}
            </div>

            {/* Clean Unboxed Metadata: Target Exam & Grade */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs text-slate-400 font-medium pt-1">
              <span className="text-slate-200">{user.gradeLevel || 'Class 12th'}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="text-slate-300">{user.targetExam || 'NEET / JEE 2026'}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Joined {accountCreated}</span>
            </div>

            {/* Photo / Edit Success & Error Messages */}
            {photoMessage && (
              <div
                className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl mt-1 self-center sm:self-start animate-in fade-in ${
                  photoMessage.type === 'success'
                    ? 'text-emerald-300 bg-emerald-500/10 border border-emerald-500/25'
                    : 'text-rose-300 bg-rose-500/10 border border-rose-500/25'
                }`}
              >
                {photoMessage.type === 'success' ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                )}
                <span>{photoMessage.text}</span>
              </div>
            )}

            {editSuccessMessage && (
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl text-emerald-300 bg-emerald-500/10 border border-emerald-500/25 mt-1 self-center sm:self-start animate-in fade-in">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{editSuccessMessage}</span>
              </div>
            )}
          </div>
        </div>

        {/* ======================================================== */}
        {/* INLINE EDIT PROFILE FORM (Smoothly Revealed)             */}
        {/* ======================================================== */}
        {isEditingProfile && (
          <div className="mt-5 pt-5 border-t border-white/10 flex flex-col gap-3.5 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                <Edit3 className="w-4 h-4" style={{ color: themeColor }} />
                <span>Edit Profile Information</span>
              </h3>

              <button
                type="button"
                onClick={handleCancelEdit}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                title="Cancel Editing"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Full Name */}
              <div className="flex flex-col gap-1 text-left">
                <label className="text-[11px] font-semibold text-slate-300 uppercase tracking-wide">
                  Display Name
                </label>
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  placeholder="Enter full name"
                  className="w-full bg-[#0d070b]/90 border border-white/15 focus:border-red-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:shadow-[0_0_12px_rgba(255,46,77,0.3)] transition-all font-sans"
                />
              </div>

              {/* Target Exam */}
              <div className="flex flex-col gap-1 text-left">
                <label className="text-[11px] font-semibold text-slate-300 uppercase tracking-wide">
                  Target Exam
                </label>
                <input
                  type="text"
                  value={targetExamInput}
                  onChange={(e) => setTargetExamInput(e.target.value)}
                  placeholder="e.g. NEET 2026, JEE 2026"
                  className="w-full bg-[#0d070b]/90 border border-white/15 focus:border-red-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:shadow-[0_0_12px_rgba(255,46,77,0.3)] transition-all font-sans"
                />
              </div>

              {/* Grade / Class */}
              <div className="flex flex-col gap-1 text-left">
                <label className="text-[11px] font-semibold text-slate-300 uppercase tracking-wide">
                  Class / Level
                </label>
                <input
                  type="text"
                  value={gradeLevelInput}
                  onChange={(e) => setGradeLevelInput(e.target.value)}
                  placeholder="e.g. Class 12th, Dropper"
                  className="w-full bg-[#0d070b]/90 border border-white/15 focus:border-red-500 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:shadow-[0_0_12px_rgba(255,46,77,0.3)] transition-all font-sans"
                />
              </div>
            </div>

            {/* Action Buttons: Save & Cancel */}
            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={handleCancelEdit}
                className="btn-secondary-glass px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleSaveProfile}
                className="btn-primary-red inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer shadow-md"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Save Changes</span>
              </button>
            </div>
          </div>
        )}
      </section>

      {/* ======================================================== */}
      {/* 2. ACCOUNT & SECURITY DETAILS CARD                       */}
      {/* ======================================================== */}
      <section className="rounded-3xl p-5 sm:p-6 glass-panel border border-white/[0.08] shadow-xl flex flex-col gap-4">
        <div className="flex items-center justify-between pb-2 border-b border-white/[0.06]">
          <h2 className="text-sm sm:text-base font-bold text-white font-display flex items-center gap-2">
            <ShieldCheck className="w-4 h-4" style={{ color: themeColor }} />
            <span>Account &amp; Security Overview</span>
          </h2>

          <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/25 px-2.5 py-0.5 rounded-full">
            Active Account
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          {/* Item 1: Student Account ID */}
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border border-white/10"
              style={{ backgroundColor: `${themeColor}15`, color: themeColor }}
            >
              <Hash className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Account ID
              </span>
              <span className="text-xs font-mono font-semibold text-white truncate block">
                {student?.id ? `FSC-${student.id.substring(0, 10)}` : 'FSC-STUDENT-01'}
              </span>
            </div>
          </div>

          {/* Item 2: Username */}
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border border-white/10"
              style={{ backgroundColor: `${themeColor}15`, color: themeColor }}
            >
              <User className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Assigned Username
              </span>
              <span className="text-xs font-mono font-semibold text-white truncate block">
                @{username}
              </span>
            </div>
          </div>

          {/* Item 3: Device Binding */}
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
              <Lock className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Device Lock Status
              </span>
              <span className="text-xs font-semibold text-emerald-300 truncate block">
                Locked to This Device (Secure)
              </span>
            </div>
          </div>

          {/* Item 4: Educational Status */}
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/[0.03] border border-white/[0.06]">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border border-white/10"
              style={{ backgroundColor: `${themeColor}15`, color: themeColor }}
            >
              <GraduationCap className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Study Track
              </span>
              <span className="text-xs font-semibold text-white truncate block">
                {user.targetExam || 'NEET / JEE 2026'} ({user.gradeLevel || 'Class 12th'})
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* 3. SAVED STUDY MATERIAL & BOOKMARKS                      */}
      {/* ======================================================== */}
      <section className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
        {/* Saved Formula Sheets Card */}
        <div className="rounded-3xl p-4 sm:p-5 glass-panel border border-white/[0.08] shadow-lg flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <BookOpen className="w-4 h-4" style={{ color: themeColor }} />
              <span>Saved Notes &amp; Formulas</span>
            </span>
            <span
              className="px-2.5 py-0.5 rounded-lg text-xs font-bold font-mono border"
              style={{
                backgroundColor: `${themeColor}18`,
                borderColor: `${themeColor}35`,
                color: themeColor,
              }}
            >
              {user?.savedNotes?.length ?? 0} Saved
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed font-sans">
            {(user?.savedNotes?.length ?? 0) > 0
              ? 'Formulas and handwritten sheets saved for offline exam revision.'
              : 'Browse study platforms to save formulas and lecture archives for quick revision.'}
          </p>
        </div>

        {/* Bookmarked Lectures Card */}
        <div className="rounded-3xl p-4 sm:p-5 glass-panel border border-white/[0.08] shadow-lg flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Bookmark className="w-4 h-4" style={{ color: themeColor }} />
              <span>Bookmarked Lectures</span>
            </span>
            <span
              className="px-2.5 py-0.5 rounded-lg text-xs font-bold font-mono border"
              style={{
                backgroundColor: `${themeColor}18`,
                borderColor: `${themeColor}35`,
                color: themeColor,
              }}
            >
              {user?.bookmarkedLectures?.length ?? 0} Lectures
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed font-sans">
            {(user?.bookmarkedLectures?.length ?? 0) > 0
              ? 'Lectures saved in your active study queue.'
              : 'Bookmark key lectures across platforms to access them instantly from your profile.'}
          </p>
        </div>
      </section>

      {/* ======================================================== */}
      {/* 4. THEME & COLOR ATMOSPHERE                              */}
      {/* ======================================================== */}
      <section className="rounded-3xl p-5 sm:p-6 glass-panel border border-white/[0.08] shadow-xl flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-md border border-white/10"
              style={{ backgroundColor: `${themeColor}18`, color: themeColor }}
            >
              <Sparkles className="w-4.5 h-4.5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white font-display">
                Theme &amp; Visual Atmosphere
              </h2>
              <p className="text-xs text-slate-400">
                Personalize your campus aesthetic across all sections
              </p>
            </div>
          </div>
        </div>

        <ThemeSwitcher variant="expanded" showLabel={true} />
      </section>

      {/* ======================================================== */}
      {/* 5. ACCOUNT ACTIONS & DEVICE MANAGEMENT FOOTER             */}
      {/* ======================================================== */}
      <section className="flex flex-col gap-3 pt-1">
        <div className="flex flex-wrap items-center justify-center gap-2.5">
          {!isInstalled && (
            <button
              onClick={triggerInstall}
              type="button"
              className="flex items-center gap-2 text-xs font-semibold px-4 py-2.5 rounded-2xl glass-panel border border-white/10 hover:border-white/25 transition-all active:scale-95 cursor-pointer shadow-md text-white"
            >
              <Smartphone className="w-3.5 h-3.5" style={{ color: themeColor }} />
              <span>Install Campus App (Android)</span>
            </button>
          )}

          <button
            onClick={onReplaySplash}
            type="button"
            className="flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-white px-4 py-2.5 rounded-2xl glass-panel border border-white/10 hover:border-white/20 transition-all active:scale-95 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" style={{ color: themeColor }} />
            <span>Replay Splash Intro</span>
          </button>

          <button
            onClick={onOpenAdmin}
            type="button"
            className="flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-white px-4 py-2.5 rounded-2xl glass-panel border border-white/10 hover:border-white/20 transition-all active:scale-95 cursor-pointer"
          >
            <Shield className="w-3.5 h-3.5 text-zinc-400" />
            <span>Admin Control</span>
          </button>
        </div>

        {/* Student Logout & Device Unbinding Action */}
        {onLogoutStudent && (
          <div className="pt-2 flex justify-center">
            <button
              type="button"
              onClick={onLogoutStudent}
              className="inline-flex items-center gap-2 text-xs font-bold px-5 py-2.5 rounded-2xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/25 transition-all duration-200 active:scale-95 cursor-pointer shadow-md"
              title="Log out and unbind this device so you can login on another phone"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-400" />
              <span>Logout &amp; Unbind Device</span>
            </button>
          </div>
        )}
      </section>
    </div>
  );
});

ProfileView.displayName = 'ProfileView';
