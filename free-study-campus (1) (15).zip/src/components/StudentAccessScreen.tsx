import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  Lock,
  User,
  KeyRound,
  Eye,
  EyeOff,
  Send,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  Loader2,
  CheckCircle2,
  Sparkles,
  Palette,
  X,
  Check,
  Copy,
  ScanLine,
  QrCode,
  Shield,
  Smartphone,
  CheckCircle,
  ArrowRight,
  Zap,
  Play,
  Video,
} from 'lucide-react';
import {
  subscribeAuthConfig,
  getCachedAuthConfig,
  getLatestAuthConfig,
} from '../services/authConfigService';
import { SAVED_PAYMENT_CONFIG } from '../services/savedPaymentFallback';
import { loginStudentUser, StudentUser } from '../services/studentUserService';
import { useTheme, THEMES, ACCENT_PRESETS } from '../context/ThemeContext';
import { ThemeType } from '../types';
import { CampusLogo } from './CampusLogo';
import { AnimatedLogoBorder } from './AnimatedLogoBorder';
import { HomeParticles } from './HomeParticles';
import { DeveloperCredit } from './DeveloperCredit';

interface StudentAccessScreenProps {
  onUnlockSuccess: (student?: StudentUser, sessionId?: string) => void;
  onOpenAdmin: () => void;
  onOpenDemos?: () => void;
  terminationNotice?: string | null;
  telegramChannelUrl?: string;
  logoUrl?: string;
}

export const StudentAccessScreen: React.FC<StudentAccessScreenProps> = ({
  onUnlockSuccess,
  onOpenAdmin,
  onOpenDemos,
  terminationNotice,
  telegramChannelUrl,
  logoUrl,
}) => {
  const { theme, setTheme, accent, setAccent, config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config?.primaryColor || '#00e5ff';

  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [errorMessage, setErrorMessage] = useState(terminationNotice || '');
  const [successAnimation, setSuccessAnimation] = useState(false);
  const [isColorModalOpen, setIsColorModalOpen] = useState(false);
  const [usernameFocused, setUsernameFocused] = useState(false);
  const [passwordFocused, setPasswordFocused] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);

  const availableThemes: ThemeType[] = [
    'rose',
    'cyber',
    'emerald',
    'violet',
    'amber',
    'obsidian',
    'monochrome',
  ];

  // Contrast text color calculation for primary action buttons
  const isDarkButtonText =
    ['cyber', 'monochrome', 'amber'].includes(theme) ||
    ['cyan', 'white', 'amber', 'lime'].includes(accent);
  const buttonTextColor = isDarkButtonText ? '#09090b' : '#ffffff';

  // Settings from Supabase database in real-time
  const [info, setInfo] = useState(() => {
    const cached = getCachedAuthConfig();
    const feeText = (cached.feeText || SAVED_PAYMENT_CONFIG.feeText).trim();
    const feeAmount =
      typeof cached.feeAmount === 'number' && !isNaN(cached.feeAmount)
        ? cached.feeAmount
        : parseFloat(feeText.replace(/[^\d.]/g, '')) || SAVED_PAYMENT_CONFIG.feeAmount;

    return {
      feeText,
      feeAmount,
      telegramBotUrl: cached.telegramBotUrl || SAVED_PAYMENT_CONFIG.telegramBotUrl,
      telegramBotHandle: cached.telegramBotHandle || SAVED_PAYMENT_CONFIG.telegramBotHandle,
      upiId: cached.upiId || SAVED_PAYMENT_CONFIG.upiId,
      qrImageUrl: cached.qrImageUrl || SAVED_PAYMENT_CONFIG.qrImageUrl,
      paymentInstructions:
        cached.paymentInstructions ||
        SAVED_PAYMENT_CONFIG.paymentInstructions,
    };
  });

  const [generatedQr, setGeneratedQr] = useState<string>(() => {
    const cached = getCachedAuthConfig();
    return cached.qrImageUrl || SAVED_PAYMENT_CONFIG.qrImageUrl;
  });

  useEffect(() => {
    if (terminationNotice) {
      setErrorMessage(terminationNotice);
    }
  }, [terminationNotice]);

  useEffect(() => {
    // Immediate direct fetch from Supabase on mount
    getLatestAuthConfig()
      .then((cfg) => {
        if (cfg) {
          const feeText = (cfg.feeText || SAVED_PAYMENT_CONFIG.feeText).trim();
          const feeAmount =
            typeof cfg.feeAmount === 'number' && !isNaN(cfg.feeAmount)
              ? cfg.feeAmount
              : parseFloat(feeText.replace(/[^\d.]/g, '')) || SAVED_PAYMENT_CONFIG.feeAmount;

          setInfo({
            feeText,
            feeAmount,
            telegramBotUrl: cfg.telegramBotUrl || SAVED_PAYMENT_CONFIG.telegramBotUrl,
            telegramBotHandle: cfg.telegramBotHandle || SAVED_PAYMENT_CONFIG.telegramBotHandle,
            upiId: cfg.upiId || SAVED_PAYMENT_CONFIG.upiId,
            qrImageUrl: cfg.qrImageUrl || SAVED_PAYMENT_CONFIG.qrImageUrl,
            paymentInstructions:
              cfg.paymentInstructions ||
              SAVED_PAYMENT_CONFIG.paymentInstructions,
          });
        }
      })
      .catch(() => {});

    // Real-time listener for central payment and fee changes
    const unsubscribe = subscribeAuthConfig((cfg) => {
      if (cfg) {
        const feeText = (cfg.feeText || SAVED_PAYMENT_CONFIG.feeText).trim();
        const feeAmount =
          typeof cfg.feeAmount === 'number' && !isNaN(cfg.feeAmount)
            ? cfg.feeAmount
            : parseFloat(feeText.replace(/[^\d.]/g, '')) || SAVED_PAYMENT_CONFIG.feeAmount;

        setInfo({
          feeText,
          feeAmount,
          telegramBotUrl: cfg.telegramBotUrl || SAVED_PAYMENT_CONFIG.telegramBotUrl,
          telegramBotHandle: cfg.telegramBotHandle || SAVED_PAYMENT_CONFIG.telegramBotHandle,
          upiId: cfg.upiId || SAVED_PAYMENT_CONFIG.upiId,
          qrImageUrl: cfg.qrImageUrl || SAVED_PAYMENT_CONFIG.qrImageUrl,
          paymentInstructions:
            cfg.paymentInstructions ||
            SAVED_PAYMENT_CONFIG.paymentInstructions,
        });
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // Generate clean, high-resolution UPI QR Code if custom QR is not set
  useEffect(() => {
    if (info.qrImageUrl) {
      setGeneratedQr(info.qrImageUrl);
      return;
    }

    const numericAmount =
      typeof info.feeAmount === 'number' && !isNaN(info.feeAmount)
        ? info.feeAmount
        : parseFloat(String(info.feeText).replace(/[^\d.]/g, '')) || 49;

    const formattedAmount = numericAmount.toFixed(2);

    const upiUrl = `upi://pay?pa=${encodeURIComponent(
      info.upiId || '77630159@ybl'
    )}&pn=${encodeURIComponent('FREE STUDY CAMPUS')}&am=${encodeURIComponent(
      formattedAmount
    )}&cu=INR&tn=${encodeURIComponent('Student Access')}`;

    QRCode.toDataURL(upiUrl, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 360,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    })
      .then((url) => {
        setGeneratedQr(url);
      })
      .catch((err) => {
        console.warn('QR code generation notice:', err);
      });
  }, [info.feeAmount, info.feeText, info.upiId, info.qrImageUrl]);

  const handleCopyUpi = () => {
    if (info.upiId) {
      navigator.clipboard.writeText(info.upiId);
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2200);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUser = usernameInput.trim().toLowerCase();
    const cleanPass = passwordInput.trim();

    if (!cleanUser || !cleanPass) {
      setErrorMessage('Please enter both Username and Password');
      return;
    }

    setIsVerifying(true);
    setErrorMessage('');

    try {
      const result = await loginStudentUser(cleanUser, cleanPass);
      if (result.success && result.student) {
        setSuccessAnimation(true);
        setTimeout(() => {
          onUnlockSuccess(result.student, result.sessionId);
        }, 350);
      } else {
        setErrorMessage(result.error || 'Incorrect Username or Password. Please check your credentials.');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Database is synchronizing. Please retry.';
      setErrorMessage(msg);
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-between px-4 py-5 sm:py-7 relative overflow-x-hidden bg-[#06080d] text-slate-100 selection:bg-cyan-500/25 selection:text-cyan-100">
      {/* 1. Subtle Floating Background Particles - Lightweight 60fps GPU animation */}
      <HomeParticles themeColor={themeColor} />

      {/* 2. Cinematic Multi-Layered Ambient Radial Lighting */}
      <div
        className="fixed -top-20 left-1/2 -translate-x-1/2 w-[340px] sm:w-[620px] h-[340px] sm:h-[460px] rounded-full blur-[130px] pointer-events-none opacity-35 transition-all duration-700 animate-ambient-pulse"
        style={{
          background: `radial-gradient(circle, ${themeColor}60 0%, #0284c730 45%, transparent 70%)`,
          transform: 'translateZ(0)',
        }}
      />
      <div
        className="fixed bottom-0 right-1/4 w-[280px] sm:w-[480px] h-[280px] sm:h-[380px] rounded-full blur-[140px] pointer-events-none opacity-20 transition-all duration-700"
        style={{
          background: 'radial-gradient(circle, rgba(56, 189, 248, 0.25) 0%, transparent 70%)',
          transform: 'translateZ(0)',
        }}
      />
      <div
        className="fixed top-1/2 -left-20 w-[240px] sm:w-[360px] h-[240px] sm:h-[360px] rounded-full blur-[120px] pointer-events-none opacity-15 transition-all duration-700"
        style={{
          background: `radial-gradient(circle, ${themeColor}35 0%, transparent 65%)`,
          transform: 'translateZ(0)',
        }}
      />

      {/* 3. Top Floating Glass Header Bar */}
      <header className="w-full max-w-md mx-auto flex items-center justify-between px-3 py-2 rounded-2xl bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl relative z-20 mb-4 shadow-lg shadow-black/40">
        <div className="flex items-center gap-2.5">
          <AnimatedLogoBorder shape="rounded-rect" borderRadius={10} accentColor={themeColor}>
            <div className="w-8 h-8 rounded-[10px] bg-[#080d14] p-1 flex items-center justify-center">
              <CampusLogo
                logoUrl={logoUrl}
                className="w-full h-full object-contain"
                alt="Free Study Campus Logo"
              />
            </div>
          </AnimatedLogoBorder>
          <div className="flex items-baseline gap-1">
            <span className="text-xs sm:text-sm font-black font-display tracking-tight text-white">
              FREE STUDY
            </span>
            <span
              className="text-xs sm:text-sm font-bold font-display tracking-tight"
              style={{ color: themeColor }}
            >
              CAMPUS
            </span>
          </div>
        </div>

        {/* Real-time Theme & Color Picker Trigger */}
        <button
          onClick={() => setIsColorModalOpen(true)}
          type="button"
          aria-label="Change Theme & Color"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.05] border border-white/10 hover:border-white/25 text-xs font-semibold text-slate-300 hover:text-white transition-all active:scale-95 cursor-pointer shadow-sm backdrop-blur-md"
          title="Change Theme & Color"
        >
          <Palette className="w-3.5 h-3.5 transition-transform hover:rotate-12" style={{ color: themeColor }} />
          <span className="text-[11px] font-bold">Theme</span>
          <span
            className="w-2 h-2 rounded-full ml-0.5"
            style={{ backgroundColor: themeColor, boxShadow: `0 0 8px ${themeColor}` }}
          />
        </button>
      </header>

      {/* Main Content Column */}
      <div className="w-full max-w-md mx-auto flex flex-col gap-5 sm:gap-6 relative z-10 py-1">
        {/* ======================================================== */}
        {/* 1. STUDENT LOGIN CARD (HERO BRANDING + FORM)             */}
        {/* ======================================================== */}
        <div
          className="rounded-3xl p-6 sm:p-7 border bg-[#0a0e17]/92 flex flex-col gap-5 relative overflow-hidden backdrop-blur-2xl transition-all duration-300 shadow-2xl"
          style={{
            borderColor: `${themeColor}38`,
            boxShadow: `0 20px 54px -10px rgba(0,0,0,0.9), 0 0 28px -6px ${themeColor}28`,
          }}
        >
          {/* Top Specular Neon Accent Line */}
          <div
            className="absolute top-0 left-0 right-0 h-[2px] opacity-85"
            style={{
              background: `linear-gradient(90deg, transparent 5%, ${themeColor} 50%, transparent 95%)`,
            }}
          />

          {/* Heading with Prominent Animated Logo Emblem */}
          <div className="text-center flex flex-col items-center">
            {/* Official Logo with Continuous Animated Neon Energy Beam */}
            <div className="relative mb-3 flex items-center justify-center">
              {/* Underlying Soft Breathing Aura */}
              <div
                className="absolute -inset-3 rounded-full blur-xl pointer-events-none transition-all duration-700"
                style={{
                  background: `radial-gradient(circle, ${themeColor}45 0%, transparent 70%)`,
                  animation: 'heroLogoBreathing 5s ease-in-out infinite',
                }}
              />

              <AnimatedLogoBorder shape="circle" accentColor={themeColor}>
                <div
                  className="w-20 h-20 sm:w-22 sm:h-22 rounded-full flex items-center justify-center p-3 bg-[#070b12] shadow-2xl transition-transform duration-300 hover:scale-105 overflow-hidden"
                  style={{
                    boxShadow: `0 8px 24px -4px rgba(0,0,0,0.85), inset 0 0 16px ${themeColor}22`,
                  }}
                >
                  <CampusLogo
                    logoUrl={logoUrl}
                    className="w-full h-full object-contain aspect-square select-none pointer-events-none"
                    alt="Free Study Campus Logo"
                  />
                </div>
              </AnimatedLogoBorder>
            </div>

            {/* Portal Badge Kicker */}
            <div
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase mb-2 backdrop-blur-md"
              style={{
                border: `1px solid ${themeColor}44`,
                backgroundColor: `${themeColor}14`,
                color: themeColor,
                boxShadow: `0 0 12px ${themeColor}20`,
              }}
            >
              <Lock className="w-3 h-3" style={{ color: themeColor }} />
              <span>STUDENT ACCESS PORTAL</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white font-display tracking-tight leading-tight">
              Student Login
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 font-medium max-w-xs leading-relaxed">
              Enter your assigned Username and Password to unlock all lectures &amp; study batches.
            </p>
          </div>

          {/* Login Form */}
          <form onSubmit={handleLoginSubmit} className="flex flex-col gap-3.5">
            {/* Username Input */}
            <div className="relative w-full">
              <User
                className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none transition-colors duration-200"
                style={{ color: usernameFocused ? themeColor : '#94a3b8' }}
              />
              <input
                type="text"
                required
                autoComplete="username"
                value={usernameInput}
                onFocus={() => setUsernameFocused(true)}
                onBlur={() => setUsernameFocused(false)}
                onChange={(e) => {
                  setUsernameInput(e.target.value);
                  if (errorMessage) setErrorMessage('');
                }}
                placeholder="Enter Username"
                className="w-full bg-[#05080f]/80 border rounded-2xl pl-11 pr-4 py-3.5 text-sm text-white placeholder-slate-400 focus:outline-none transition-all font-mono"
                style={{
                  borderColor: usernameFocused ? themeColor : 'rgba(255, 255, 255, 0.12)',
                  boxShadow: usernameFocused ? `0 0 18px ${themeColor}38, inset 0 1px 2px rgba(0,0,0,0.5)` : 'none',
                }}
              />
            </div>

            {/* Password Input */}
            <div className="relative w-full">
              <KeyRound
                className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none transition-colors duration-200"
                style={{ color: passwordFocused ? themeColor : '#94a3b8' }}
              />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                autoComplete="current-password"
                value={passwordInput}
                onFocus={() => setPasswordFocused(true)}
                onBlur={() => setPasswordFocused(false)}
                onChange={(e) => {
                  setPasswordInput(e.target.value);
                  if (errorMessage) setErrorMessage('');
                }}
                placeholder="Enter Password"
                className="w-full bg-[#05080f]/80 border rounded-2xl pl-11 pr-12 py-3.5 text-sm text-white placeholder-slate-400 focus:outline-none transition-all font-sans"
                style={{
                  borderColor: passwordFocused ? themeColor : 'rgba(255, 255, 255, 0.12)',
                  boxShadow: passwordFocused ? `0 0 18px ${themeColor}38, inset 0 1px 2px rgba(0,0,0,0.5)` : 'none',
                }}
              />

              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer rounded-lg hover:bg-white/5"
                title={showPassword ? 'Hide Password' : 'Show Password'}
                aria-label={showPassword ? 'Hide Password' : 'Show Password'}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" style={{ color: themeColor }} />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Error Notification */}
            {errorMessage && (
              <div
                className="p-3.5 rounded-2xl border text-xs flex items-start gap-2.5 animate-in fade-in duration-200"
                style={{
                  backgroundColor: 'rgba(56, 12, 22, 0.9)',
                  borderColor: `${themeColor}60`,
                  color: '#fecdd3',
                  boxShadow: `0 0 16px ${themeColor}22`,
                }}
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: themeColor }} />
                <span className="leading-relaxed font-medium">{errorMessage}</span>
              </div>
            )}

            {/* High-Impact Login Button with Dynamic Theme Gradient & Tactile Press */}
            <button
              type="submit"
              disabled={isVerifying}
              className="w-full py-3.5 px-6 rounded-2xl font-black text-sm tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 mt-1 active:scale-[0.98] select-none"
              style={{
                background: `linear-gradient(135deg, ${themeColor} 0%, color-mix(in srgb, ${themeColor} 70%, black) 100%)`,
                color: buttonTextColor,
                border: '1px solid rgba(255, 255, 255, 0.28)',
                boxShadow: `0 6px 22px -2px ${themeColor}66, inset 0 1px 1px rgba(255, 255, 255, 0.4)`,
              }}
            >
              {isVerifying ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>Verifying Credentials...</span>
                </>
              ) : successAnimation ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-white" />
                  <span>Access Granted!</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>UNLOCK ACCESS</span>
                </>
              )}
            </button>

            {/* Premium WATCH DEMO Button - Immediately Below UNLOCK ACCESS, works without student login or purchase */}
            <button
              type="button"
              onClick={onOpenDemos}
              className="w-full py-3.5 px-4 sm:px-5 rounded-2xl font-black transition-all duration-300 flex items-center justify-between gap-3 cursor-pointer active:scale-[0.98] select-none shadow-xl group relative overflow-hidden"
              style={{
                backgroundColor: 'rgba(255, 46, 77, 0.1)',
                border: `1.5px solid ${themeColor}55`,
                boxShadow: `0 8px 26px -6px ${themeColor}30, inset 0 1px 0 rgba(255, 255, 255, 0.2)`,
              }}
              title="Watch official platform sample batch demos without login"
            >
              {/* Subtle Ambient Radial Glow */}
              <div
                className="absolute -right-8 -top-8 w-32 h-32 rounded-full blur-2xl pointer-events-none opacity-40 group-hover:opacity-75 transition-opacity duration-500"
                style={{ backgroundColor: themeColor }}
              />

              <div className="flex items-center gap-3 z-10 min-w-0">
                <div
                  className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center shadow-lg shrink-0 transition-transform duration-300 group-hover:scale-110"
                  style={{
                    background: `linear-gradient(135deg, ${themeColor} 0%, #b30021 100%)`,
                    border: '1px solid rgba(255, 255, 255, 0.35)',
                    boxShadow: `0 4px 14px ${themeColor}60`,
                  }}
                >
                  <Play className="w-4.5 h-4.5 text-white fill-white ml-0.5 drop-shadow" />
                </div>
                <div className="flex flex-col text-left min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-black tracking-wider text-xs sm:text-sm text-white font-display">
                      WATCH DEMO
                    </span>
                    <span
                      className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider text-white border shadow-sm"
                      style={{
                        backgroundColor: `${themeColor}40`,
                        borderColor: `${themeColor}80`,
                      }}
                    >
                      FREE ACCESS
                    </span>
                  </div>
                  <span className="text-[10.5px] sm:text-[11px] text-slate-300 font-medium normal-case truncate">
                    Physics Wallah • Target Board • Unacademy &amp; more
                  </span>
                </div>
              </div>

              <div
                className="flex items-center gap-1 z-10 shrink-0 text-white px-2.5 py-1 rounded-xl bg-white/10 border border-white/10 group-hover:bg-white/20 transition-all text-xs font-bold"
              >
                <span className="hidden sm:inline">Explore</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
          </form>

          {/* 1-Phone & Security Notice */}
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400 text-center pt-2 border-t border-white/10">
            <Smartphone className="w-3.5 h-3.5 shrink-0" style={{ color: themeColor }} />
            <span>1 Phone / 1 Active Account Protected</span>
          </div>
        </div>

        {/* ======================================================== */}
        {/* 2. SCANNER / PAYMENT / GET CREDENTIALS CARD              */}
        {/* ======================================================== */}
        <div
          className="rounded-3xl p-5 sm:p-7 bg-[#0a0e17]/95 flex flex-col gap-4 backdrop-blur-2xl transition-all duration-300 relative overflow-hidden shadow-2xl border"
          style={{
            borderColor: `${themeColor}38`,
            boxShadow: `0 20px 50px -10px rgba(0,0,0,0.9), 0 0 28px -6px ${themeColor}25`,
          }}
        >
          {/* Top Specular Neon Line */}
          <div
            className="absolute top-0 left-0 right-0 h-[2px] opacity-80"
            style={{
              background: `linear-gradient(90deg, transparent 5%, ${themeColor} 50%, transparent 95%)`,
            }}
          />

          {/* Header & Section Title */}
          <div className="text-center flex flex-col items-center">
            <div
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-1.5 backdrop-blur-md select-none"
              style={{
                backgroundColor: `${themeColor}18`,
                borderColor: `${themeColor}50`,
                borderWidth: '1px',
                color: themeColor,
                boxShadow: `0 0 14px ${themeColor}22`,
              }}
            >
              <ScanLine className="w-3.5 h-3.5" style={{ color: themeColor }} />
              <span>INSTANT STUDENT REGISTRATION</span>
            </div>

            <h2 className="text-base sm:text-lg font-black text-white font-display tracking-tight">
              Get Login Credentials
            </h2>
            <p className="text-xs text-slate-300 font-medium leading-relaxed max-w-sm mt-0.5">
              {info.paymentInstructions ||
                'Scan QR code, pay the verification fee, and send screenshot to our Telegram Bot to receive your account credentials instantly.'}
            </p>
          </div>

          {/* Connected 3-Step Interactive Workflow */}
          <div className="grid grid-cols-3 gap-2 py-1">
            <div className="flex flex-col items-center text-center p-2 rounded-xl bg-white/[0.03] border border-white/5 relative">
              <span
                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black mb-1 shadow-sm"
                style={{ backgroundColor: `${themeColor}25`, color: themeColor, border: `1px solid ${themeColor}50` }}
              >
                1
              </span>
              <span className="text-[10px] text-slate-200 font-bold leading-tight">
                Scan &amp; Pay
              </span>
              <span className="text-[9px] text-slate-400 mt-0.5 font-medium leading-tight hidden sm:block">
                Via any UPI app
              </span>
            </div>

            <div className="flex flex-col items-center text-center p-2 rounded-xl bg-white/[0.03] border border-white/5 relative">
              <span
                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black mb-1 shadow-sm"
                style={{ backgroundColor: `${themeColor}25`, color: themeColor, border: `1px solid ${themeColor}50` }}
              >
                2
              </span>
              <span className="text-[10px] text-slate-200 font-bold leading-tight">
                Screenshot
              </span>
              <span className="text-[9px] text-slate-400 mt-0.5 font-medium leading-tight hidden sm:block">
                Keep payment proof
              </span>
            </div>

            <div className="flex flex-col items-center text-center p-2 rounded-xl bg-white/[0.03] border border-white/5 relative">
              <span
                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black mb-1 shadow-sm"
                style={{ backgroundColor: `${themeColor}25`, color: themeColor, border: `1px solid ${themeColor}50` }}
              >
                3
              </span>
              <span className="text-[10px] text-slate-200 font-bold leading-tight">
                Get Password
              </span>
              <span className="text-[9px] text-slate-400 mt-0.5 font-medium leading-tight hidden sm:block">
                In Telegram Bot
              </span>
            </div>
          </div>

          {/* QR Code Container with High-Definition Frame, Corner Reticles & Smooth Laser Line */}
          <div className="flex flex-col items-center justify-center gap-3">
            <div
              className="relative p-3 bg-white rounded-2xl shadow-2xl flex items-center justify-center transition-transform hover:scale-[1.02] overflow-hidden"
              style={{
                border: `2px solid ${themeColor}50`,
                boxShadow: `0 14px 40px -8px rgba(0,0,0,0.85), 0 0 24px ${themeColor}33`,
              }}
            >
              {/* 4 Corner Reticle Accents in themeColor */}
              <div
                className="absolute top-1 left-1 w-3.5 h-3.5 border-t-2 border-l-2 pointer-events-none z-20"
                style={{ borderColor: themeColor }}
              />
              <div
                className="absolute top-1 right-1 w-3.5 h-3.5 border-t-2 border-r-2 pointer-events-none z-20"
                style={{ borderColor: themeColor }}
              />
              <div
                className="absolute bottom-1 left-1 w-3.5 h-3.5 border-b-2 border-l-2 pointer-events-none z-20"
                style={{ borderColor: themeColor }}
              />
              <div
                className="absolute bottom-1 right-1 w-3.5 h-3.5 border-b-2 border-r-2 pointer-events-none z-20"
                style={{ borderColor: themeColor }}
              />

              {/* Smooth Continuous Laser Scan Line */}
              <div
                className="scanner-laser-line absolute left-2 right-2 h-[2px] pointer-events-none z-10"
                style={{
                  background: `linear-gradient(90deg, transparent 0%, ${themeColor} 50%, transparent 100%)`,
                  boxShadow: `0 0 10px ${themeColor}, 0 0 18px ${themeColor}aa`,
                }}
              />

              {generatedQr ? (
                <img
                  src={generatedQr}
                  alt="Payment QR Code for Free Study Campus"
                  className="w-44 h-44 object-contain rounded-lg relative z-0 select-none"
                  loading="eager"
                />
              ) : (
                <div className="w-44 h-44 flex items-center justify-center bg-slate-100 rounded-lg">
                  <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
                </div>
              )}
            </div>

            {/* Fee Badge & UPI Copy Box */}
            <div className="text-center w-full flex flex-col items-center gap-2">
              <div
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/[0.04] border shadow-sm"
                style={{ borderColor: `${themeColor}40` }}
              >
                <span className="text-xs font-semibold text-slate-300">One-Time Campus Fee:</span>
                <span className="text-sm font-black font-mono tracking-tight" style={{ color: themeColor }}>
                  {info.feeText || `₹${info.feeAmount}`}
                </span>
                <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider pl-1 border-l border-white/10">
                  Lifetime
                </span>
              </div>

              {/* Click-to-copy UPI row */}
              <div className="w-full max-w-xs flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-white/[0.04] border border-white/10">
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className="text-[11px] text-slate-400 font-semibold shrink-0">UPI:</span>
                  <span className="text-xs font-mono font-bold text-white truncate select-all">{info.upiId}</span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyUpi}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white text-xs font-bold transition-all cursor-pointer active:scale-95 shrink-0"
                  title="Copy UPI ID"
                  aria-label="Copy UPI ID"
                >
                  {copiedUpi ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-300">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Telegram Bot Action */}
          <a
            href={info.telegramBotUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 px-4 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.98] cursor-pointer text-white relative overflow-hidden group"
            style={{
              background: `linear-gradient(135deg, ${themeColor}22 0%, ${themeColor}12 100%)`,
              border: `1.5px solid ${themeColor}50`,
              boxShadow: `0 6px 20px -4px ${themeColor}25`,
            }}
          >
            <Send className="w-4 h-4 shrink-0 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-transform" style={{ color: themeColor }} />
            <span className="tracking-wide">Send Screenshot to Bot ({info.telegramBotHandle})</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-70 shrink-0" />
          </a>
        </div>

        {/* ======================================================== */}
        {/* 3. TELEGRAM FOLLOW CARD — BOTTOM OF LOGIN PAGE           */}
        {/* ======================================================== */}
        <div
          className="rounded-3xl p-5 sm:p-6 backdrop-blur-2xl transition-all duration-300 relative overflow-hidden border shadow-xl"
          style={{
            backgroundColor: 'rgba(10, 14, 22, 0.92)',
            borderColor: `${themeColor}38`,
            boxShadow: `0 14px 40px -10px rgba(0,0,0,0.85), 0 0 20px -6px ${themeColor}22`,
          }}
        >
          {/* Subtle Ambient Glow */}
          <div
            className="absolute -right-8 -bottom-8 w-36 h-36 rounded-full blur-2xl pointer-events-none opacity-20"
            style={{ backgroundColor: themeColor }}
          />

          <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
            <div className="flex items-center gap-3.5">
              <div
                className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 shadow-md transition-transform hover:scale-105"
                style={{
                  backgroundColor: `${themeColor}20`,
                  border: `1px solid ${themeColor}44`,
                }}
              >
                <Send className="w-5 h-5" style={{ color: themeColor }} />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-white font-display">
                  Join Our Telegram Channel
                </h3>
                <p className="text-xs text-slate-300 leading-snug mt-0.5 font-medium">
                  Get real-time batch alerts, notes, portal updates &amp; student support.
                </p>
              </div>
            </div>

            <a
              href={telegramChannelUrl || info.telegramBotUrl || 'https://t.me/freestudycampus'}
              target="_blank"
              rel="noopener noreferrer"
              className="apple-press w-full sm:w-auto px-5 py-2.5 rounded-xl text-xs font-bold transition-all duration-300 flex items-center justify-center gap-2 shadow-lg cursor-pointer shrink-0"
              style={{
                background: `linear-gradient(135deg, ${themeColor} 0%, color-mix(in srgb, ${themeColor} 80%, black) 100%)`,
                color: buttonTextColor,
                border: '1px solid rgba(255, 255, 255, 0.22)',
                boxShadow: `0 4px 16px ${themeColor}55`,
              }}
            >
              <span>Join Channel</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Developer Attribution with glowing name */}
        <DeveloperCredit className="my-2" />

        {/* Footer Admin portal link */}
        <div className="flex items-center justify-center pt-1 pb-4">
          <button
            onClick={onOpenAdmin}
            type="button"
            className="text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer py-1.5 px-3.5 rounded-lg hover:bg-white/5 active:scale-95"
          >
            Admin Control Portal →
          </button>
        </div>
      </div>

      {/* ======================================================== */}
      {/* THEME & COLOR PICKER MODAL ON LOGIN SCREEN              */}
      {/* ======================================================== */}
      {isColorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div
            className="relative w-full max-w-md rounded-3xl p-6 border bg-[#0a0e17] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.9)] overflow-hidden transition-all duration-300"
            style={{
              borderColor: `${themeColor}40`,
            }}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <div
                  className="w-8 h-8 rounded-xl flex items-center justify-center shadow-lg"
                  style={{
                    backgroundColor: `${themeColor}22`,
                    color: themeColor,
                  }}
                >
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-display">
                    Theme &amp; Color System
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Select your preferred study atmosphere
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsColorModalOpen(false)}
                type="button"
                className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-zinc-400 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Atmosphere Presets */}
            <div className="mt-5 space-y-4 max-h-[60vh] overflow-y-auto pr-1">
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 block mb-2.5">
                  Select Theme Palette
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {availableThemes.map((tKey) => {
                    const tConfig = THEMES[tKey];
                    if (!tConfig) return null;
                    const isActive = theme === tKey;

                    return (
                      <button
                        key={tKey}
                        onClick={() => setTheme(tKey)}
                        type="button"
                        className={`flex items-center gap-3 p-3 rounded-2xl border text-left transition-all duration-200 cursor-pointer ${
                          isActive
                            ? 'bg-white/[0.08] ring-1 scale-[1.02]'
                            : 'bg-white/[0.02] hover:bg-white/[0.05] border-white/10 opacity-75 hover:opacity-100'
                        }`}
                        style={{
                          borderColor: isActive ? tConfig.primaryColor : 'rgba(255, 255, 255, 0.1)',
                          boxShadow: isActive ? `0 0 14px ${tConfig.accentGlow}` : 'none',
                        }}
                      >
                        {/* Dual-color preview dot */}
                        <div
                          className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 shadow-md"
                          style={{
                            background: `linear-gradient(135deg, ${tConfig.previewColors[0]}, ${tConfig.previewColors[2]})`,
                            border: `2px solid ${tConfig.primaryColor}`,
                          }}
                        >
                          {isActive && <Check className="w-3 h-3 text-white drop-shadow" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-bold text-white truncate">
                            {tConfig.name}
                          </p>
                          <p className="text-[10px] text-zinc-400 truncate">
                            {tConfig.label.split('&')[1]?.trim() || tConfig.label}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Accent Colors */}
              <div className="pt-3 border-t border-white/10">
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 block mb-2.5">
                  Quick Accent Color
                </label>
                <div className="flex flex-wrap items-center gap-2.5">
                  {ACCENT_PRESETS.map((p) => {
                    const isSelected = accent === p.id;
                    return (
                      <button
                        key={p.id}
                        onClick={() => setAccent(p.id)}
                        type="button"
                        title={p.name}
                        className={`relative w-8 h-8 rounded-full transition-all duration-200 cursor-pointer flex items-center justify-center ${
                          isSelected
                            ? 'scale-110 ring-2 ring-white ring-offset-2 ring-offset-black'
                            : 'hover:scale-105 opacity-80 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: p.hex }}
                      >
                        {isSelected && (
                          <Check className="w-3.5 h-3.5 text-black drop-shadow font-bold" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="mt-6 pt-4 border-t border-white/10 flex justify-end">
              <button
                onClick={() => setIsColorModalOpen(false)}
                type="button"
                className="px-5 py-2.5 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-lg"
                style={{
                  background: `linear-gradient(135deg, ${themeColor} 0%, color-mix(in srgb, ${themeColor} 80%, black) 100%)`,
                  color: buttonTextColor,
                  border: '1px solid rgba(255, 255, 255, 0.22)',
                  boxShadow: `0 4px 16px ${themeColor}55`,
                }}
              >
                Apply Theme
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
