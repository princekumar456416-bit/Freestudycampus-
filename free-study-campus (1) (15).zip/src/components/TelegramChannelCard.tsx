import React from 'react';
import { ExternalLink, Sparkles } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface TelegramChannelCardProps {
  className?: string;
  channelUrl?: string;
}

export const TelegramChannelCard: React.FC<TelegramChannelCardProps> = ({ className = '', channelUrl }) => {
  const { config } = useTheme();
  const telegramUrl = (channelUrl && channelUrl.trim()) ? channelUrl.trim() : 'https://t.me/freestudycampus';

  return (
    <div className={`w-full max-w-2xl mx-auto my-6 sm:my-8 px-1 sm:px-0 ${className}`}>
      <a
        href={telegramUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Join Our Telegram Channel on Telegram"
        className="interactive-card group relative block w-full rounded-2xl sm:rounded-3xl p-5 sm:p-6 transition-all duration-300 overflow-hidden border cursor-pointer select-none backdrop-blur-2xl"
        style={{
          backgroundColor: config.cardBg,
          borderColor: 'rgba(34, 158, 217, 0.35)',
          boxShadow: '0 8px 32px -4px rgba(0, 136, 204, 0.18), 0 2px 10px -2px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.08)',
        }}
      >
        {/* Ambient background accent glows */}
        <div
          className="absolute -top-16 -right-16 w-44 h-44 rounded-full blur-[80px] pointer-events-none opacity-30 transition-opacity duration-500 group-hover:opacity-50"
          style={{ backgroundColor: '#0088cc' }}
        />
        <div
          className="absolute -bottom-16 -left-16 w-44 h-44 rounded-full blur-[80px] pointer-events-none opacity-20 transition-opacity duration-500 group-hover:opacity-40"
          style={{ backgroundColor: config.primaryColor }}
        />

        {/* Subtle top highlights */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#229ED9] to-transparent opacity-60 group-hover:opacity-100 transition-opacity duration-300" />

        <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-center justify-between gap-5 sm:gap-6">
          {/* Left section: Icon + Text */}
          <div className="flex items-center sm:items-start gap-4 text-center sm:text-left flex-1 min-w-0">
            {/* Telegram 3D Circular Logo Icon */}
            <div className="relative shrink-0">
              <div
                className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center text-white shadow-lg transition-transform duration-300 group-hover:scale-110"
                style={{
                  background: 'linear-gradient(135deg, #2AABEE 0%, #229ED9 50%, #0088cc 100%)',
                  boxShadow: '0 6px 20px -2px rgba(34, 158, 217, 0.5), inset 0 1px 2px rgba(255,255,255,0.4)',
                }}
              >
                {/* Official Telegram Paper Plane Icon */}
                <svg
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  className="w-7 h-7 sm:w-8 sm:h-8 transform -translate-x-0.5 translate-y-0.5 text-white drop-shadow-sm"
                >
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
                </svg>
              </div>

              {/* Pulsing online badge indicator */}
              <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500 border-2 border-[#0c101a]" />
              </span>
            </div>

            {/* Texts */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <h3 className="text-lg sm:text-xl font-black text-white font-display tracking-tight leading-snug group-hover:text-cyan-300 transition-colors">
                  Join Our Telegram Channel
                </h3>
                <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-500/15 text-blue-400 border border-blue-500/30">
                  <Sparkles className="w-2.5 h-2.5" />
                  Free
                </span>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 mt-1 font-medium leading-relaxed">
                Latest Updates, Study Materials &amp; Important Notifications ke liye hamare Telegram Channel se judein.
              </p>
            </div>
          </div>

          {/* Right section / Action Button */}
          <div className="w-full sm:w-auto shrink-0">
            <div
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 sm:py-3 rounded-xl sm:rounded-2xl text-white font-bold text-sm tracking-wide transition-all duration-300 shadow-md group-hover:shadow-lg group-hover:shadow-[#229ED9]/40 group-hover:brightness-110 active:scale-95"
              style={{
                background: 'linear-gradient(135deg, #229ED9 0%, #0088cc 100%)',
              }}
            >
              {/* Telegram mini icon */}
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 shrink-0">
                <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
              </svg>
              <span>Join Telegram Channel</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-80 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </div>
        </div>
      </a>
    </div>
  );
};
