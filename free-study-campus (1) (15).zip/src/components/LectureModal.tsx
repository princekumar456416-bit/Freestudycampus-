import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { LectureItem } from '../types';
import { X, Play, Clock, CheckCircle, FileText, Share2, Bookmark, Check } from 'lucide-react';

interface LectureModalProps {
  lecture: LectureItem | null;
  onClose: () => void;
  onBookmarkToggle?: (id: string) => void;
  isBookmarked?: boolean;
}

export const LectureModal: React.FC<LectureModalProps> = ({
  lecture,
  onClose,
  onBookmarkToggle,
  isBookmarked = false,
}) => {
  const { config } = useTheme();
  const [completedTopics, setCompletedTopics] = useState<Record<string, boolean>>({});
  const [copied, setCopied] = useState(false);

  if (!lecture) return null;

  const toggleTopic = (topic: string) => {
    setCompletedTopics((prev) => ({
      ...prev,
      [topic]: !prev[topic],
    }));
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl overflow-y-auto animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl rounded-3xl overflow-hidden bg-[#0c080b]/95 border border-red-500/25 shadow-[0_24px_64px_-12px_rgba(0,0,0,0.9),0_0_36px_-6px_rgba(220,38,38,0.3)] my-8 transition-all backdrop-blur-2xl"
      >
        {/* Top Specular Gradient Line */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-red-500 to-transparent opacity-80" />

        {/* Header Bar */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg text-xs font-black tracking-wider uppercase bg-red-950/40 text-red-300 border border-red-500/30">
              {lecture.subject}
            </span>
            <span className="text-xs text-slate-400 flex items-center gap-1 font-mono">
              <Clock className="w-3.5 h-3.5 text-red-400" />
              {lecture.duration}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {onBookmarkToggle && (
              <button
                onClick={() => onBookmarkToggle(lecture.id)}
                type="button"
                className="p-2 rounded-xl text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                title={isBookmarked ? 'Remove Bookmark' : 'Bookmark Lecture'}
              >
                <Bookmark
                  className="w-4 h-4 text-red-400"
                  fill={isBookmarked ? '#ef4444' : 'none'}
                />
              </button>
            )}
            <button
              onClick={handleShare}
              type="button"
              className="p-2 rounded-xl text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
              title="Share Lecture"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              type="button"
              aria-label="Close modal"
              className="p-2 rounded-xl text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Video / Visual Simulation Area */}
        <div className="relative aspect-video w-full bg-black/90 flex items-center justify-center overflow-hidden border-b border-white/10">
          <div
            className="absolute inset-0 opacity-25 pointer-events-none"
            style={{
              background: 'radial-gradient(circle at center, rgba(220, 38, 38, 0.4), transparent 70%)',
            }}
          />

          <div className="relative z-10 flex flex-col items-center text-center px-6">
            <div
              className="relative w-16 h-16 rounded-full flex items-center justify-center border-2 border-red-500/50 shadow-[0_0_24px_rgba(220,38,38,0.6)] mb-3 cursor-pointer group transition-transform hover:scale-110 active:scale-95 bg-red-600/20"
            >
              <div className="absolute -inset-1 rounded-full bg-red-500/30 blur-md pointer-events-none animate-logo-aura" />
              <Play className="w-7 h-7 ml-1 text-white drop-shadow-md relative z-10" />
            </div>
            <p className="text-sm font-bold text-white">Free Authorized Open Lecture</p>
            <p className="text-xs text-slate-400 mt-1 max-w-sm">
              Provided via Physics Wallah Educational Open Vault for academic study
            </p>
          </div>
        </div>

        {/* Content Details */}
        <div className="p-5 sm:p-6 flex flex-col gap-4">
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white font-display">
              {lecture.title}
            </h3>
            <p className="text-xs text-slate-400 mt-1 font-medium">
              Lead Educator: <span className="text-slate-200">{lecture.educator}</span>
            </p>
          </div>

          <p className="text-sm text-slate-300 leading-relaxed bg-white/[0.03] p-3.5 rounded-2xl border border-white/5">
            {lecture.summary}
          </p>

          {/* Key Topics Checklist */}
          {lecture.keyTopics && lecture.keyTopics.length > 0 && (
            <div>
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-red-400" />
                Core Topics Covered ({Object.values(completedTopics).filter(Boolean).length}/{lecture.keyTopics.length})
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {lecture.keyTopics.map((topic) => {
                  const isDone = !!completedTopics[topic];
                  return (
                    <button
                      key={topic}
                      type="button"
                      onClick={() => toggleTopic(topic)}
                      className={`flex items-center gap-2.5 p-2.5 rounded-xl text-xs text-left transition-all border cursor-pointer ${
                        isDone
                          ? 'text-white bg-red-950/30 border-red-500/40'
                          : 'text-slate-400 hover:text-slate-200 bg-white/5 border-white/5'
                      }`}
                    >
                      <CheckCircle
                        className="w-4 h-4 shrink-0 transition-colors"
                        style={{ color: isDone ? '#ef4444' : '#64748b' }}
                      />
                      <span className={isDone ? 'line-through opacity-80' : ''}>{topic}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div className="flex items-center justify-between pt-3 border-t border-white/10 text-xs text-slate-400">
            <span>Free Student Access Granted</span>
            <button
              onClick={onClose}
              type="button"
              className="btn-primary-red px-5 py-2.5 rounded-xl font-bold text-xs transition-all active:scale-95 cursor-pointer shadow-md"
            >
              Done Studying
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
