import React, { useState, useEffect, useMemo } from 'react';
import { useTheme } from '../context/ThemeContext';
import { PlatformItem } from '../types';
import { BatchRecord } from '../../server/db';
import { api, safeDataCache, ConnectionStatusInfo } from '../services/api';
import {
  ArrowLeft,
  Atom,
  CheckCircle2,
  ExternalLink,
  Search,
  BookOpen,
  Calendar,
  Layers,
  Sparkles,
  RefreshCw,
  Star,
  WifiOff,
} from 'lucide-react';

interface PhysicsWallahPageProps {
  platform: PlatformItem;
  onBack: () => void;
  savedNotes: string[];
  bookmarkedLectures: string[];
  onToggleBookmark: (id: string) => void;
  onToggleSaveNote: (id: string) => void;
}

export const PhysicsWallahPage: React.FC<PhysicsWallahPageProps> = ({
  platform,
  onBack,
}) => {
  const { config } = useTheme();

  // Dynamic live batches initialized from safe local cache so they NEVER disappear
  const [batches, setBatches] = useState<BatchRecord[]>(() =>
    safeDataCache.getBatches('physics-wallah')
  );
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Upcoming' | 'Completed'>('All');
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatusInfo>(safeDataCache.getStatus());

  useEffect(() => {
    return safeDataCache.subscribeStatus((st) => setConnectionStatus(st));
  }, []);

  const fetchLiveBatches = async () => {
    setIsLoading(true);
    try {
      const data = await api.getBatches({ platformId: 'physics-wallah' });
      // NEVER overwrite with empty array on error or quota exhaustion!
      if (Array.isArray(data) && data.length > 0) {
        setBatches(data);
      } else if (safeDataCache.isConfirmedEmpty('batches')) {
        setBatches([]);
      }
    } catch (err) {
      console.warn('Live batches sync notice (keeping saved batches):', err);
      // Keep existing data visible!
      const cached = safeDataCache.getBatches('physics-wallah');
      if (cached.length > 0) {
        setBatches(cached);
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLiveBatches();
  }, []);

  // Filter batches
  const filteredBatches = useMemo(() => {
    return batches.filter((batch) => {
      const matchesStatus = statusFilter === 'All' || batch.status === statusFilter;
      if (!matchesStatus) return false;

      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase();
      return (
        batch.title.toLowerCase().includes(q) ||
        batch.shortDescription.toLowerCase().includes(q) ||
        batch.teacherName.toLowerCase().includes(q) ||
        batch.subject.toLowerCase().includes(q) ||
        batch.category.toLowerCase().includes(q)
      );
    });
  }, [batches, statusFilter, searchQuery]);

  return (
    <div className="w-full pb-24 flex flex-col gap-6 max-w-4xl mx-auto animate-in fade-in duration-300">
      {/* Top Header with Back Button */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          type="button"
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl glass-panel border transition-all duration-300 hover:-translate-x-1 cursor-pointer text-xs font-semibold text-slate-300 hover:text-white"
          style={{ borderColor: config.borderColor }}
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Campus</span>
        </button>

        <button
          onClick={fetchLiveBatches}
          type="button"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-white/10 text-[11px] font-mono text-slate-400 hover:text-white transition-colors"
          title="Refresh latest batches from database"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Sync Batches</span>
        </button>
      </div>

      {/* Platform Hero Card */}
      <div
        className="rounded-3xl p-6 sm:p-8 glass-panel border relative overflow-hidden"
        style={{
          borderColor: config.borderColor,
          boxShadow: `0 10px 40px -10px ${config.accentGlow}`,
        }}
      >
        <div
          className="absolute -right-16 -top-16 w-56 h-56 rounded-full blur-3xl pointer-events-none opacity-30"
          style={{ backgroundColor: config.primaryColor }}
        />

        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            {/* Logo Emblem */}
            <div
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex items-center justify-center border shrink-0 shadow-xl"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.06)',
                borderColor: config.borderColor,
                boxShadow: `0 0 20px ${config.accentGlow}`,
              }}
            >
              <div className="relative flex items-center justify-center">
                <Atom className="w-10 h-10" style={{ color: config.primaryColor }} />
                <span className="absolute text-[10px] font-black tracking-tighter text-white">
                  PW
                </span>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display tracking-tight">
                  PHYSICS WALLAH
                </h1>
                <span title="Authorized Learning Partner" className="inline-flex">
                  <CheckCircle2 className="w-5 h-5 shrink-0" style={{ color: config.primaryColor }} />
                </span>
              </div>
              <p className="text-xs sm:text-sm font-medium mt-1" style={{ color: config.primaryColor }}>
                Free & authorized learning resources
              </p>
              <p className="text-xs text-slate-300 mt-1 max-w-xl">
                Access chapter-wise lecture archives, daily practice sheets, formula compendiums, and solved question sets.
              </p>
            </div>
          </div>

          <a
            href="https://pwthor.live/study/batches"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary-red flex items-center gap-2 px-5 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 shadow-lg cursor-pointer shrink-0 self-start sm:self-auto"
          >
            <span>Open Portal</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* SEARCH BATCHES & STATUS FILTERS */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        {/* Search Bar */}
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Batches by title, teacher, or subject..."
            className="w-full bg-[#0e090c]/80 border border-white/10 focus:border-red-500 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:shadow-[0_0_16px_rgba(220,38,38,0.35)] transition-all font-sans"
          />
        </div>

        {/* Status Filters: All, Active, Upcoming, Completed */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {(['All', 'Active', 'Upcoming', 'Completed'] as const).map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              type="button"
              className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                statusFilter === status
                  ? 'bg-red-600 border-red-500 text-white font-bold shadow-[0_0_12px_rgba(220,38,38,0.4)]'
                  : 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:border-white/20'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* BATCHES LISTING */}
      {filteredBatches.length === 0 ? (
        <div
          className="rounded-3xl p-12 text-center glass-panel border flex flex-col items-center justify-center gap-3"
          style={{ borderColor: 'rgba(255, 255, 255, 0.08)' }}
        >
          {searchQuery ? (
            <>
              <Layers className="w-10 h-10 text-slate-500" />
              <h3 className="text-base font-bold text-white">No Batches Found</h3>
              <p className="text-xs text-slate-400 max-w-sm">
                No curriculum matching "{searchQuery}". Reset filters to see all available batches.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('All');
                }}
                type="button"
                className="mt-2 px-4 py-2 rounded-xl text-xs font-bold text-black"
                style={{ backgroundColor: config.primaryColor }}
              >
                Reset Filters
              </button>
            </>
          ) : connectionStatus.isUnavailable ? (
            <>
              <WifiOff className="w-10 h-10 text-amber-400" />
              <h3 className="text-base font-bold text-white">Connection Temporarily Unavailable</h3>
              <p className="text-xs text-slate-400 max-w-sm">
                Unable to reach batch database right now. Showing saved curriculum data where available.
              </p>
              <button
                onClick={fetchLiveBatches}
                type="button"
                className="mt-2 inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-black cursor-pointer shadow-md"
                style={{ backgroundColor: config.primaryColor }}
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry Sync</span>
              </button>
            </>
          ) : (
            <>
              <Layers className="w-10 h-10 text-slate-500" />
              <h3 className="text-base font-bold text-white">No Batches Available</h3>
              <p className="text-xs text-slate-400 max-w-sm">
                No batches currently active in this category.
              </p>
            </>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredBatches.map((batch) => (
            <div
              key={batch.id}
              className="interactive-card rounded-3xl p-5 bg-[#0e090c]/95 border border-white/10 flex flex-col justify-between gap-4 transition-all duration-200 hover:-translate-y-1.5 hover:border-red-500/40 hover:shadow-[0_16px_44px_-10px_rgba(0,0,0,0.85),0_0_24px_-6px_rgba(220,38,38,0.35)] group relative overflow-hidden select-none"
            >
              {/* Top Specular Gradient Highlight Line */}
              <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-red-500/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

              {/* Card Header & Details */}
              <div className="flex flex-col gap-3">
                <div className="relative overflow-hidden rounded-2xl aspect-video w-full border border-white/10 bg-black/40 shadow-inner group-hover:border-red-500/30 transition-colors">
                  <img
                    src={batch.thumbnail}
                    alt={batch.title}
                    loading="lazy"
                    decoding="async"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  {batch.isFeatured && (
                    <div className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-lg bg-red-600 text-white font-black text-[10px] flex items-center gap-1 shadow-[0_2px_10px_rgba(220,38,38,0.5)] border border-red-400/40">
                      <Star className="w-3 h-3 fill-current" />
                      <span>FEATURED</span>
                    </div>
                  )}

                  {/* Status Badge */}
                  <div className="absolute top-2.5 right-2.5">
                    <span
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold tracking-wider uppercase border backdrop-blur-md shadow-md ${
                        batch.status === 'Active'
                          ? 'bg-emerald-950/85 text-emerald-400 border-emerald-500/40'
                          : batch.status === 'Upcoming'
                          ? 'bg-amber-950/85 text-amber-400 border-amber-500/40'
                          : 'bg-slate-900/85 text-slate-400 border-slate-500/40'
                      }`}
                    >
                      {batch.status}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-red-950/40 text-red-400 border border-red-500/25">
                      {batch.category}
                    </span>
                    <span className="text-xs text-slate-400 font-semibold">
                      {batch.subject}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white font-display mt-0.5 group-hover:text-red-100 transition-colors line-clamp-1">
                    {batch.title}
                  </h3>

                  <p className="text-xs text-slate-400 font-medium">
                    Mentor: <strong className="text-slate-200">{batch.teacherName}</strong>
                  </p>

                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed font-sans">
                    {batch.shortDescription}
                  </p>
                </div>
              </div>

              {/* Card Footer: Open Batch Button */}
              <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-3">
                <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-medium">
                  <Calendar className="w-3.5 h-3.5 text-red-400" />
                  <span>Starts: {batch.startDate}</span>
                </div>

                <a
                  href={batch.batchUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary-red inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold tracking-wider uppercase transition-all duration-200 hover:scale-105 active:scale-95 shadow-md cursor-pointer select-none"
                >
                  <span>OPEN BATCH</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
