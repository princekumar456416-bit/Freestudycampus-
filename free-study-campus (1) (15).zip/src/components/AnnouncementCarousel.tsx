import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AnnouncementRecord } from '../../server/db';
import { Bell, ChevronLeft, ChevronRight, ExternalLink, Sparkles } from 'lucide-react';

interface AnnouncementCarouselProps {
  announcements: AnnouncementRecord[];
  themeColor: string;
}

export const AnnouncementCarousel: React.FC<AnnouncementCarouselProps> = ({
  announcements,
  themeColor,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Touch tracking for mobile swipe gestures
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);
  const isSwiping = useRef(false);

  const total = announcements.length;

  // Ensure index stays in bounds if announcements array length changes
  useEffect(() => {
    if (currentIndex >= total && total > 0) {
      setCurrentIndex(total - 1);
    }
  }, [total, currentIndex]);

  const handleNext = useCallback(() => {
    if (total <= 1) return;
    setCurrentIndex((prev) => (prev + 1) % total);
  }, [total]);

  const handlePrev = useCallback(() => {
    if (total <= 1) return;
    setCurrentIndex((prev) => (prev - 1 + total) % total);
  }, [total]);

  // Subtle auto-advance every 6 seconds when not hovered/touched
  useEffect(() => {
    if (total <= 1 || isPaused) return;
    const timer = setInterval(() => {
      handleNext();
    }, 6000);
    return () => clearInterval(timer);
  }, [total, isPaused, handleNext]);

  // Touch Event Handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    setIsPaused(true);
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
    touchEndX.current = e.touches[0].clientX;
    isSwiping.current = false;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchStartX.current === null || touchStartY.current === null) return;
    const currentX = e.touches[0].clientX;
    const currentY = e.touches[0].clientY;
    const diffX = touchStartX.current - currentX;
    const diffY = touchStartY.current - currentY;

    // Detect horizontal swipe intent vs vertical page scroll
    if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 10) {
      isSwiping.current = true;
      touchEndX.current = currentX;
    }
  };

  const handleTouchEnd = () => {
    if (isSwiping.current && touchStartX.current !== null && touchEndX.current !== null) {
      const diffX = touchStartX.current - touchEndX.current;
      const minSwipeDistance = 40; // Pixels required to trigger slide transition
      if (diffX > minSwipeDistance) {
        handleNext();
      } else if (diffX < -minSwipeDistance) {
        handlePrev();
      }
    }
    touchStartX.current = null;
    touchStartY.current = null;
    touchEndX.current = null;
    isSwiping.current = false;
    setTimeout(() => setIsPaused(false), 2000);
  };

  // 1. CLEAN COMPACT EMPTY STATE (0 Announcements)
  if (total === 0) {
    return (
      <div
        className="w-full rounded-2xl px-4 py-3 border flex items-center justify-between gap-3 text-xs select-none backdrop-blur-xl transition-all"
        style={{
          backgroundColor: 'rgba(14, 9, 16, 0.75)',
          borderColor: 'rgba(255, 255, 255, 0.08)',
          boxShadow: '0 4px 20px -2px rgba(0, 0, 0, 0.5)',
        }}
      >
        <div className="flex items-center gap-2.5 text-slate-400">
          <div
            className="w-7 h-7 rounded-xl flex items-center justify-center shrink-0 border border-white/10"
            style={{ backgroundColor: `${themeColor}12`, color: themeColor }}
          >
            <Bell className="w-3.5 h-3.5" />
          </div>
          <span className="text-[12px] text-slate-300">
            No active campus notices. All platforms and study batches are running smoothly.
          </span>
        </div>
      </div>
    );
  }

  // 2. SINGLE ANNOUNCEMENT STATE (1 Announcement - No unnecessary controls)
  if (total === 1) {
    const item = announcements[0];
    return (
      <div
        className="relative w-full rounded-2xl p-3 sm:px-4 sm:py-3.5 border flex flex-col sm:flex-row sm:items-center justify-between gap-3 select-none backdrop-blur-2xl transition-all shadow-xl overflow-hidden"
        style={{
          backgroundColor: 'rgba(15, 9, 16, 0.92)',
          borderColor: `${themeColor}33`,
          boxShadow: `0 10px 30px -4px rgba(0, 0, 0, 0.7), 0 0 20px -4px ${themeColor}22, inset 0 1px 1px rgba(255, 255, 255, 0.12)`,
        }}
      >
        {/* Subtle Ambient Red Glow */}
        <div
          className="absolute -top-10 -left-10 w-32 h-32 rounded-full blur-2xl pointer-events-none opacity-30"
          style={{ backgroundColor: themeColor }}
        />

        <div className="flex items-start sm:items-center gap-3 min-w-0 z-10">
          <div
            className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border shadow-md"
            style={{
              backgroundColor: `${themeColor}18`,
              borderColor: `${themeColor}40`,
              color: themeColor,
            }}
          >
            <Bell className="w-4 h-4" />
          </div>

          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span
                className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md border shrink-0"
                style={{
                  backgroundColor: `${themeColor}22`,
                  borderColor: `${themeColor}44`,
                  color: themeColor,
                }}
              >
                Notice
              </span>
              {item.date && (
                <span className="text-[11px] text-slate-400 font-medium">
                  {item.date}
                </span>
              )}
            </div>
            <p className="text-xs sm:text-[13px] text-slate-200 font-medium mt-1 leading-relaxed">
              <span className="font-bold text-white mr-1.5">{item.title}:</span>
              <span>{item.message}</span>
            </p>
          </div>
        </div>

        {item.link && (
          <a
            href={item.link}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 self-end sm:self-center flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl border transition-all active:scale-95 cursor-pointer shadow-md z-10"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.06)',
              borderColor: `${themeColor}44`,
              color: '#ffffff',
            }}
          >
            <span>View Link</span>
            <ExternalLink className="w-3.5 h-3.5" style={{ color: themeColor }} />
          </a>
        )}
      </div>
    );
  }

  // 3. MULTI-ANNOUNCEMENT PREMIUM SLIDING CAROUSEL (2+ Announcements)
  const currentAnnouncement = announcements[currentIndex];

  return (
    <div
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className="relative w-full rounded-3xl border select-none backdrop-blur-2xl transition-all shadow-2xl overflow-hidden group"
      style={{
        backgroundColor: 'rgba(15, 8, 16, 0.94)',
        borderColor: `${themeColor}38`,
        boxShadow: `0 12px 35px -6px rgba(0, 0, 0, 0.8), 0 0 25px -4px ${themeColor}28, inset 0 1px 1px rgba(255, 255, 255, 0.15)`,
      }}
    >
      {/* Top Specular Glaze */}
      <div className="absolute inset-x-8 top-0 h-1/2 rounded-t-full bg-gradient-to-b from-white/10 to-transparent pointer-events-none" />

      {/* Ambient Accent Glow */}
      <div
        className="absolute -top-12 -right-12 w-40 h-40 rounded-full blur-3xl pointer-events-none opacity-25 transition-all duration-700"
        style={{ backgroundColor: themeColor }}
      />

      {/* Slide Container with Continuous Sliding Track */}
      <div className="relative overflow-hidden w-full p-3.5 sm:p-4">
        <div
          className="flex transition-transform duration-400 ease-[cubic-bezier(0.25,1,0.5,1)] will-change-transform"
          style={{ transform: `translate3d(-${currentIndex * 100}%, 0, 0)` }}
        >
          {announcements.map((item, index) => (
            <div
              key={item.id}
              className="w-full shrink-0 flex flex-col sm:flex-row sm:items-center justify-between gap-3 min-w-0"
            >
              {/* Left Content Area */}
              <div className="flex items-start sm:items-center gap-3 min-w-0 flex-1">
                <div
                  className="w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 border shadow-md mt-0.5 sm:mt-0"
                  style={{
                    backgroundColor: `${themeColor}1c`,
                    borderColor: `${themeColor}44`,
                    color: themeColor,
                  }}
                >
                  <Bell className="w-4 h-4 animate-pulse" />
                </div>

                <div className="flex flex-col min-w-0 pr-2">
                  {/* Category & Badge Header Row */}
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span
                      className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md border shrink-0"
                      style={{
                        backgroundColor: `${themeColor}22`,
                        borderColor: `${themeColor}44`,
                        color: themeColor,
                      }}
                    >
                      Notice {index + 1} of {total}
                    </span>
                    {item.date && (
                      <span className="text-[11px] text-slate-400 font-medium">
                        {item.date}
                      </span>
                    )}
                  </div>

                  {/* Announcement Title & Description */}
                  <p className="text-xs sm:text-[13.5px] text-slate-200 font-medium leading-relaxed">
                    <span className="font-bold text-white mr-1.5">{item.title}:</span>
                    <span>{item.message}</span>
                  </p>
                </div>
              </div>

              {/* Action Link (If provided) */}
              {item.link && (
                <a
                  href={item.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="shrink-0 self-end sm:self-center flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl border transition-all active:scale-95 cursor-pointer shadow-md"
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.06)',
                    borderColor: `${themeColor}44`,
                    color: '#ffffff',
                  }}
                >
                  <span>View Details</span>
                  <ExternalLink className="w-3.5 h-3.5" style={{ color: themeColor }} />
                </a>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Carousel Footer: Left/Right Arrow Navigation & Dot Indicators */}
      <div className="px-3.5 sm:px-4 pb-2.5 pt-1 border-t border-white/5 flex items-center justify-between gap-3 text-xs">
        {/* Navigation Dots */}
        <div className="flex items-center gap-1.5">
          {announcements.map((item, idx) => {
            const isActive = idx === currentIndex;
            return (
              <button
                key={`dot_${item.id}`}
                onClick={() => setCurrentIndex(idx)}
                type="button"
                aria-label={`Go to slide ${idx + 1}`}
                className={`transition-all duration-300 cursor-pointer rounded-full h-1.5 ${
                  isActive ? 'w-5 shadow-[0_0_8px_#ff2e4d]' : 'w-1.5 bg-white/20 hover:bg-white/40'
                }`}
                style={{
                  backgroundColor: isActive ? themeColor : undefined,
                }}
              />
            );
          })}
        </div>

        {/* Counter Badge & Next/Prev Controls */}
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono font-bold text-slate-400 bg-white/5 px-2 py-0.5 rounded-md border border-white/10">
            {currentIndex + 1} / {total}
          </span>

          <div className="flex items-center gap-1">
            <button
              onClick={handlePrev}
              type="button"
              aria-label="Previous announcement"
              className="p-1 rounded-lg bg-white/5 hover:bg-white/15 border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer active:scale-90"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleNext}
              type="button"
              aria-label="Next announcement"
              className="p-1 rounded-lg bg-white/5 hover:bg-white/15 border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer active:scale-90"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
