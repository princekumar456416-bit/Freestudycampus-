import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { NoteItem } from '../types';
import { X, Download, FileText, CheckCircle2, Bookmark, Eye } from 'lucide-react';

interface NotesModalProps {
  note: NoteItem | null;
  onClose: () => void;
  onSaveNoteToggle?: (id: string) => void;
  isSaved?: boolean;
}

export const NotesModal: React.FC<NotesModalProps> = ({
  note,
  onClose,
  onSaveNoteToggle,
  isSaved = false,
}) => {
  const { config } = useTheme();
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  if (!note) return null;

  const handleDownload = () => {
    setDownloading(true);
    setTimeout(() => {
      setDownloading(false);
      setDownloaded(true);
      setTimeout(() => setDownloaded(false), 3000);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl overflow-y-auto animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-xl rounded-3xl overflow-hidden bg-[#0c080b]/95 border border-red-500/25 shadow-[0_24px_64px_-12px_rgba(0,0,0,0.9),0_0_36px_-6px_rgba(220,38,38,0.3)] my-8 transition-all backdrop-blur-2xl"
      >
        {/* Top Specular Gradient Line */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-red-500 to-transparent opacity-80" />

        {/* Header Bar */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider bg-red-950/40 text-red-300 border border-red-500/30">
              {note.subject}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {note.pages} Pages · {note.fileSize}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {onSaveNoteToggle && (
              <button
                onClick={() => onSaveNoteToggle(note.id)}
                type="button"
                className="p-2 rounded-xl text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                title={isSaved ? 'Remove from Saved' : 'Save for Offline'}
              >
                <Bookmark
                  className="w-4 h-4 text-red-400"
                  fill={isSaved ? '#ef4444' : 'none'}
                />
              </button>
            )}
            <button
              onClick={onClose}
              type="button"
              aria-label="Close modal"
              className="p-2 rounded-xl text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Interactive Notes Simulation Preview */}
        <div className="p-6 flex flex-col gap-5">
          <div className="flex items-start gap-4">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border border-red-500/30 bg-red-950/30 text-red-400 shadow-[0_0_15px_rgba(220,38,38,0.3)]"
            >
              <FileText className="w-7 h-7" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-white font-display">
                {note.title}
              </h3>
              <p className="text-xs text-slate-400 mt-1 font-medium">
                Verified Free Study Campus Educational Note
              </p>
            </div>
          </div>

          <p className="text-sm text-slate-300 leading-relaxed bg-white/[0.03] p-4 rounded-2xl border border-white/5 font-sans">
            {note.description}
          </p>

          {/* Interactive Document Sheet Reader Preview */}
          <div
            className="rounded-2xl p-4 border border-white/10 flex flex-col gap-3 font-mono text-xs text-slate-300 bg-black/60 shadow-inner"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-2 text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5 text-red-400 font-bold">
                <Eye className="w-3.5 h-3.5" />
                Instant Fast Reader Sheet
              </span>
              <span className="text-slate-500">100% Free Open Education</span>
            </div>

            <div className="space-y-2 py-1 text-slate-300 text-xs font-sans">
              <p className="text-emerald-400 font-semibold">• High-Yield Concept Keypoints Included</p>
              <p>• NCERT line-by-line assertions with highlighted exceptions</p>
              <p>• Clean diagrams, derivations, and standard solved PYQ models</p>
              <p className="text-slate-400">• Formatted for mobile reading and rapid exam-day revision</p>
            </div>
          </div>

          {/* Download & Action Buttons */}
          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={handleDownload}
              disabled={downloading}
              type="button"
              className="btn-primary-red flex-1 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer shadow-md"
            >
              {downloading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Preparing High-Res PDF...</span>
                </>
              ) : downloaded ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-white" />
                  <span>PDF Downloaded to Device!</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Download Free PDF ({note.fileSize})</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
