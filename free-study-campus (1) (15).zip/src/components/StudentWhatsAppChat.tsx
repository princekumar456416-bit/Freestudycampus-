import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Send,
  Image as ImageIcon,
  CheckCheck,
  Clock,
  ShieldCheck,
  X,
  Maximize2,
  AlertCircle,
  Sparkles,
  RefreshCw,
  ChevronDown,
  RotateCcw,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { StudentUser } from '../services/studentUserService';
import {
  SupportTicket,
  SupportMessage,
  fetchStudentTickets,
  submitSupportTicket,
  sendFollowUpMessage,
  subscribeStudentTickets,
  markChatAsReadByStudent,
} from '../services/supportService';

interface StudentWhatsAppChatProps {
  student: StudentUser | null;
  onClose: () => void;
  initialTicketId?: string | null;
}

export const StudentWhatsAppChat: React.FC<StudentWhatsAppChatProps> = ({
  student,
  onClose,
  initialTicketId,
}) => {
  const { config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';

  const [ticket, setTicket] = useState<SupportTicket | null>(null);
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const [selectedPhotoName, setSelectedPhotoName] = useState<string>('');
  const [isSending, setIsSending] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [failedMessageData, setFailedMessageData] = useState<{ text: string; photo: string | null } | null>(null);
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatScrollContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom of conversation
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    scrollToBottom('auto');
  }, [messages.length]);

  // Handle scroll detection for "Scroll to bottom" button
  const handleScroll = () => {
    if (!chatScrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = chatScrollContainerRef.current;
    const isNearBottom = scrollHeight - scrollTop - clientHeight < 120;
    setShowScrollBottom(!isNearBottom);
  };

  // Load and subscribe to student's persistent chat conversation
  useEffect(() => {
    if (!student?.id) return;
    setIsLoading(true);

    const handleLoadedTickets = (tickets: SupportTicket[]) => {
      let current = tickets.find((t) => t.id === initialTicketId);
      if (!current && tickets.length > 0) {
        current = tickets[0];
      }
      if (current) {
        setTicket(current);
        setMessages(current.messages || []);
        markChatAsReadByStudent(student.id, student.username);
      }
      setIsLoading(false);
    };

    // 1. Initial live fetch
    fetchStudentTickets(student.id, student.username).then((tickets) => {
      handleLoadedTickets(tickets);
    });

    // 2. Real-time subscription via Supabase & local bus
    const unsubscribe = subscribeStudentTickets(student.id, student.username, (liveTickets) => {
      handleLoadedTickets(liveTickets);
    });

    return () => {
      unsubscribe();
    };
  }, [student?.id, student?.username, initialTicketId]);

  // Handle Photo selection and compression
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('Please select a valid image file (JPG, PNG, WebP).');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setErrorMessage('Image is too large. Please select an image under 10MB.');
      return;
    }

    setSelectedPhotoName(file.name);
    setErrorMessage('');

    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        const maxDim = 1280;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
          setSelectedPhoto(dataUrl);
        } else {
          setSelectedPhoto(reader.result as string);
        }
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Send message (Text and/or Photo)
  const handleSendMessage = async (e?: React.FormEvent, retryData?: { text: string; photo: string | null }) => {
    if (e) e.preventDefault();
    const textToSend = retryData ? retryData.text : inputText.trim();
    const photoToSend = retryData ? retryData.photo : selectedPhoto;

    if (!textToSend && !photoToSend) return;
    if (!student?.id) {
      setErrorMessage('Student session not identified. Please re-login.');
      return;
    }

    setIsSending(true);
    setErrorMessage('');
    setFailedMessageData(null);

    if (!retryData) {
      setInputText('');
      setSelectedPhoto(null);
      setSelectedPhotoName('');
    }

    const tempId = `msg_temp_${Date.now()}`;
    const optimisticMsg: SupportMessage = {
      id: tempId,
      sender: 'student',
      senderName: student.name || 'Student',
      senderUsername: student.username,
      text: textToSend || (photoToSend ? '📷 Photo' : ''),
      screenshotUrl: photoToSend,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, optimisticMsg]);
    setTimeout(() => scrollToBottom('smooth'), 50);

    try {
      if (ticket?.id) {
        const res = await sendFollowUpMessage(ticket.id, {
          sender: 'student',
          senderName: student.name || 'Student',
          senderUsername: student.username,
          text: textToSend || '📷 Photo',
          screenshotUrl: photoToSend,
        });

        if (res.success && res.ticket) {
          setTicket(res.ticket);
          setMessages(res.ticket.messages);
        } else if (!res.success) {
          setErrorMessage(res.error || 'Failed to send message. Please retry.');
          setFailedMessageData({ text: textToSend, photo: photoToSend });
        }
      } else {
        const res = await submitSupportTicket({
          studentId: student.id,
          studentName: student.name || 'Student',
          studentUsername: student.username,
          subject: 'Direct Chat with Admin Jyotish',
          category: 'General Support',
          description: textToSend || '📷 Photo',
          screenshotUrl: photoToSend,
        });

        if (res.success && res.ticket) {
          setTicket(res.ticket);
          setMessages(res.ticket.messages);
        } else {
          setErrorMessage(res.error || 'Failed to start chat. Please retry.');
          setFailedMessageData({ text: textToSend, photo: photoToSend });
        }
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error sending message.';
      setErrorMessage(msg);
      setFailedMessageData({ text: textToSend, photo: photoToSend });
    } finally {
      setIsSending(false);
      setTimeout(() => scrollToBottom('smooth'), 100);
    }
  };

  const formatTime = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
      });
    } catch {
      return '';
    }
  };

  const formatDateHeader = (isoString: string) => {
    try {
      const d = new Date(isoString);
      const today = new Date();
      if (
        d.getDate() === today.getDate() &&
        d.getMonth() === today.getMonth() &&
        d.getFullYear() === today.getFullYear()
      ) {
        return 'TODAY';
      }
      return d.toLocaleDateString('en-US', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }).toUpperCase();
    } catch {
      return 'MESSAGES';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#070509] text-slate-100 overflow-hidden font-sans select-none animate-in fade-in duration-200">
      {/* 1. LUXURY RED-AND-WHITE THEMED TOP HEADER BAR */}
      <header
        className="sticky top-0 z-30 h-16 sm:h-[72px] px-3 sm:px-5 flex items-center justify-between border-b shrink-0 select-none backdrop-blur-xl"
        style={{
          backgroundColor: 'rgba(15, 8, 14, 0.94)',
          borderColor: 'rgba(255, 46, 77, 0.22)',
          boxShadow: '0 4px 20px -2px rgba(0, 0, 0, 0.7), 0 0 25px -10px rgba(255, 46, 77, 0.35)',
        }}
      >
        {/* Left: Back Arrow + Admin Avatar + Header Details */}
        <div className="flex items-center gap-2.5 sm:gap-3.5 min-w-0">
          <button
            onClick={onClose}
            type="button"
            className="p-2 -ml-1 rounded-2xl text-slate-300 hover:text-white hover:bg-white/10 active:scale-90 transition-all cursor-pointer shadow-sm border border-transparent hover:border-white/10"
            aria-label="Back to Campus Portal"
            title="Back to portal"
          >
            <ArrowLeft className="w-5 h-5 sm:w-5.5 sm:h-5.5" />
          </button>

          {/* Admin Jyotish Avatar with Ruby Radial Glow and Online Badge */}
          <div className="relative shrink-0">
            <div
              className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center text-white font-black text-sm tracking-wide shadow-lg border border-white/25 transition-transform duration-300 hover:scale-105"
              style={{
                background: `linear-gradient(135deg, ${themeColor} 0%, #8b001a 100%)`,
                boxShadow: `0 0 18px -2px ${themeColor}88, inset 0 1px 1px rgba(255, 255, 255, 0.4)`,
              }}
            >
              <span>AJ</span>
            </div>
            {/* Glowing Online Beacon */}
            <span
              className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-[#22c55e] border-2 border-[#0f080e] shadow-[0_0_10px_#22c55e]"
              title="Admin Jyotish is Online"
            />
          </div>

          {/* Header Title & Subtitle */}
          <div className="flex flex-col min-w-0 text-left">
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm sm:text-base font-black text-white font-display tracking-tight truncate leading-tight uppercase">
                CHAT WITH ADMIN JYOTISH
              </h1>
              <ShieldCheck className="w-4 h-4 text-rose-400 shrink-0 drop-shadow" />
            </div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#22c55e] animate-pulse" />
              <span className="text-[11px] sm:text-xs text-emerald-400 font-bold tracking-wide">
                Online
              </span>
              <span className="text-[11px] text-slate-400 hidden sm:inline">
                • Free Study Campus Helpdesk
              </span>
            </div>
          </div>
        </div>

        {/* Right: Cloud Sync Badge & Close Button */}
        <div className="flex items-center gap-2">
          <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-xl bg-white/[0.04] border border-white/10 text-[11px] font-medium text-slate-300 shadow-inner">
            <Sparkles className="w-3.5 h-3.5" style={{ color: themeColor }} />
            <span>Supabase Cloud Sync</span>
          </div>

          <button
            onClick={onClose}
            type="button"
            className="p-2 sm:p-2.5 rounded-2xl bg-white/[0.04] hover:bg-white/[0.12] border border-white/10 text-slate-300 hover:text-white transition-all active:scale-95 cursor-pointer shadow-sm"
            title="Close Chat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* 2. CHAT MESSAGES CANVAS */}
      <div
        ref={chatScrollContainerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto px-3 sm:px-6 py-4 flex flex-col gap-3 relative scrollbar-thin scrollbar-thumb-white/10"
        style={{
          backgroundColor: '#070509',
          backgroundImage: `radial-gradient(circle at 50% 0%, ${themeColor}12 0%, transparent 65%), radial-gradient(circle at 80% 80%, rgba(255, 255, 255, 0.02) 0%, transparent 50%)`,
        }}
      >
        {/* Date Divider Chip */}
        <div className="flex justify-center my-1 select-none sticky top-1 z-10">
          <div
            className="px-4 py-1 rounded-xl border text-[10.5px] font-black text-slate-200 tracking-wider shadow-md uppercase backdrop-blur-md"
            style={{
              backgroundColor: 'rgba(23, 14, 22, 0.92)',
              borderColor: 'rgba(255, 255, 255, 0.12)',
            }}
          >
            {messages.length > 0
              ? formatDateHeader(messages[messages.length - 1].createdAt)
              : 'TODAY'}
          </div>
        </div>

        {/* Welcome Notice Card */}
        <div
          className="mx-auto max-w-lg w-full my-2 p-3.5 sm:p-4 rounded-3xl border text-center flex flex-col items-center gap-2 shadow-xl backdrop-blur-xl transition-all"
          style={{
            backgroundColor: 'rgba(18, 10, 16, 0.88)',
            borderColor: `${themeColor}28`,
            boxShadow: `0 10px 30px -5px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.08)`,
          }}
        >
          <div className="flex items-center gap-2 text-xs font-bold text-white">
            <span
              className="w-2 h-2 rounded-full shadow-[0_0_8px_#ff2e4d]"
              style={{ backgroundColor: themeColor }}
            />
            <span className="uppercase tracking-wider">Official Student Direct Desk</span>
          </div>
          <p className="text-[12px] sm:text-[12.5px] text-slate-300 leading-relaxed text-balance">
            Welcome, <strong className="text-white font-semibold">{student?.name || student?.username}</strong>! You are connected directly to <strong>Admin Jyotish</strong>. Send your text questions or upload photos of payment slips, notes, or lecture queries.
          </p>

          {/* Quick Starter Suggestions (Click to autofill) */}
          {messages.length === 0 && !isLoading && (
            <div className="flex flex-wrap items-center justify-center gap-2 mt-1">
              {[
                'Batch unlock request',
                'Payment verification slip',
                'Notes downloading issue',
                'Device login query',
              ].map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => {
                    setInputText(suggestion);
                    inputRef.current?.focus();
                  }}
                  className="px-3 py-1.5 rounded-xl text-[11px] font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 hover:border-rose-500/40 transition-all cursor-pointer shadow-sm active:scale-95"
                >
                  + {suggestion}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Loading Skeletons */}
        {isLoading && (
          <div className="py-6 flex flex-col gap-3 max-w-md w-full mx-auto animate-pulse">
            <div className="w-3/4 p-3 rounded-2xl bg-white/5 border border-white/5 self-start">
              <div className="h-3 bg-white/10 rounded w-1/3 mb-2" />
              <div className="h-3 bg-white/10 rounded w-full mb-1" />
              <div className="h-3 bg-white/10 rounded w-2/3" />
            </div>
            <div className="w-2/3 p-3 rounded-2xl bg-rose-950/20 border border-rose-500/10 self-end">
              <div className="h-3 bg-white/15 rounded w-full mb-1" />
              <div className="h-3 bg-white/15 rounded w-1/2" />
            </div>
            <div className="w-4/5 p-3 rounded-2xl bg-white/5 border border-white/5 self-start">
              <div className="h-3 bg-white/10 rounded w-1/4 mb-2" />
              <div className="h-3 bg-white/10 rounded w-5/6" />
            </div>
          </div>
        )}

        {/* Messages List */}
        {!isLoading &&
          messages.map((msg) => {
            const isStudent = msg.sender === 'student';

            return (
              <div
                key={msg.id}
                className={`flex flex-col max-w-[88%] sm:max-w-[72%] ${
                  isStudent ? 'self-end items-end' : 'self-start items-start'
                } animate-in fade-in duration-150`}
              >
                {/* Bubble Container */}
                <div
                  className={`relative p-3 sm:p-3.5 rounded-3xl shadow-lg transition-all text-sm leading-relaxed ${
                    isStudent
                      ? 'text-white rounded-br-xs'
                      : 'text-slate-100 rounded-bl-xs border border-white/10'
                  }`}
                  style={{
                    background: isStudent
                      ? `linear-gradient(135deg, ${themeColor} 0%, #aa0020 100%)`
                      : 'rgba(23, 16, 25, 0.94)',
                    boxShadow: isStudent
                      ? `0 6px 20px -3px ${themeColor}55, inset 0 1px 1px rgba(255, 255, 255, 0.35)`
                      : '0 6px 20px -3px rgba(0, 0, 0, 0.7), inset 0 1px 0 rgba(255, 255, 255, 0.08)',
                  }}
                >
                  {/* Sender Header for Received Admin Messages */}
                  {!isStudent && (
                    <div className="flex items-center gap-1.5 mb-1.5 select-none">
                      <span className="text-[11px] font-black text-rose-400 uppercase tracking-wider">
                        Admin Jyotish
                      </span>
                      <span className="px-1.5 py-0.5 rounded-md text-[9px] font-black uppercase bg-rose-950/80 text-rose-300 border border-rose-500/30">
                        Admin
                      </span>
                    </div>
                  )}

                  {/* Attached Photo inside Bubble */}
                  {msg.screenshotUrl && (
                    <div className="mb-2 relative rounded-2xl overflow-hidden bg-black/50 border border-white/15 group cursor-pointer max-w-sm">
                      <img
                        src={msg.screenshotUrl}
                        alt="Shared in conversation"
                        loading="lazy"
                        onClick={() => setZoomedImage(msg.screenshotUrl!)}
                        className="w-full max-h-72 object-cover transition-transform duration-200 group-hover:scale-102"
                      />
                      <button
                        type="button"
                        onClick={() => setZoomedImage(msg.screenshotUrl!)}
                        className="absolute bottom-2 right-2 p-1.5 rounded-xl bg-black/75 text-white hover:bg-black transition-all backdrop-blur-md"
                        title="View photo full size"
                      >
                        <Maximize2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* Text Message */}
                  {msg.text && (!msg.screenshotUrl || msg.text !== '📷 Photo') && (
                    <p className="whitespace-pre-wrap break-words text-[13.5px] sm:text-[14.5px] leading-relaxed pr-12 pb-1 font-normal">
                      {msg.text}
                    </p>
                  )}

                  {/* Timestamp & Status Icon Row */}
                  <div className="flex items-center justify-end gap-1.5 text-[10px] select-none float-right -mt-2 ml-4">
                    <span className={isStudent ? 'text-white/80' : 'text-slate-400'}>
                      {formatTime(msg.createdAt)}
                    </span>
                    {isStudent && (
                      <span title="Delivered to Admin">
                        {msg.id.startsWith('msg_temp_') ? (
                          <Clock className="w-3.5 h-3.5 text-white/70 animate-spin" />
                        ) : (
                          <CheckCheck className="w-3.5 h-3.5 text-cyan-200" />
                        )}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

        <div ref={messagesEndRef} className="h-1" />
      </div>

      {/* Floating Scroll to Bottom Button */}
      {showScrollBottom && (
        <button
          onClick={() => scrollToBottom('smooth')}
          type="button"
          aria-label="Scroll to newest messages"
          className="absolute right-4 bottom-24 z-30 p-2.5 rounded-full text-white bg-black/80 hover:bg-black border border-white/20 shadow-xl backdrop-blur-md transition-all active:scale-90"
        >
          <ChevronDown className="w-5 h-5 text-rose-400" />
        </button>
      )}

      {/* 3. PHOTO PREVIEW DRAWER (When student selects a photo to send) */}
      {selectedPhoto && (
        <div className="bg-[#150d18] border-t border-rose-500/20 px-4 py-3 flex items-center justify-between gap-3 animate-in slide-in-from-bottom-2 duration-150 shadow-2xl">
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative w-12 h-12 rounded-2xl overflow-hidden border border-rose-500/40 bg-black shrink-0 shadow-md">
              <img
                src={selectedPhoto}
                alt="Selected preview"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-bold text-white truncate">
                Photo staged for Admin Jyotish
              </span>
              <span className="text-[11px] text-rose-400 font-medium truncate">
                {selectedPhotoName || 'Optimized for fast sending'}
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              setSelectedPhoto(null);
              setSelectedPhotoName('');
            }}
            type="button"
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Remove photo"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Error Notice with Retry Option */}
      {errorMessage && (
        <div className="bg-rose-950/90 border-t border-rose-500/40 text-rose-100 text-xs px-4 py-2.5 flex items-center justify-between gap-2 shadow-lg">
          <div className="flex items-center gap-2 min-w-0">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span className="truncate">{errorMessage}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {failedMessageData && (
              <button
                onClick={() => handleSendMessage(undefined, failedMessageData)}
                type="button"
                className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-1 transition-colors cursor-pointer text-[11px]"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Retry</span>
              </button>
            )}
            <button
              onClick={() => {
                setErrorMessage('');
                setFailedMessageData(null);
              }}
              type="button"
              className="p-1 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* 4. RED-AND-WHITE PREMIUM BOTTOM INPUT BAR */}
      <footer className="bg-[#100813] border-t border-white/10 px-3 py-2.5 sm:px-5 sm:py-3.5 flex items-center gap-2.5 shrink-0 pb-[calc(0.75rem+env(safe-area-inset-bottom,0px))] shadow-2xl">
        {/* Hidden File Input for Gallery / Photo Attachment */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handlePhotoSelect}
          className="hidden"
        />

        {/* Gallery / Photo Attachment Button */}
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          aria-label="Attach Photo"
          title="Attach photo from gallery or camera"
          className={`p-2.5 sm:p-3 rounded-2xl border transition-all cursor-pointer shrink-0 active:scale-90 shadow-sm ${
            selectedPhoto
              ? 'text-white border-rose-500 bg-rose-600/30 ring-2 ring-rose-500/40'
              : 'text-slate-300 hover:text-white bg-white/[0.05] hover:bg-white/[0.1] border-white/10'
          }`}
        >
          <ImageIcon className="w-5 h-5" />
        </button>

        {/* Message Input Box Form */}
        <form
          onSubmit={(e) => handleSendMessage(e)}
          className="flex-1 flex items-center gap-2 min-w-0"
        >
          <input
            ref={inputRef}
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              selectedPhoto ? 'Add a photo caption...' : 'Type a message to Admin Jyotish...'
            }
            className="w-full py-2.5 sm:py-3 px-4 rounded-2xl bg-white/[0.06] border border-white/10 focus:border-rose-500/60 text-white placeholder-slate-400 text-sm sm:text-[14.5px] transition-all focus:outline-none shadow-inner"
          />

          {/* Send Button */}
          <button
            type="submit"
            disabled={isSending || (!inputText.trim() && !selectedPhoto)}
            aria-label="Send Message"
            title="Send Message"
            className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl flex items-center justify-center text-white cursor-pointer transition-all duration-200 active:scale-90 disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shrink-0"
            style={{
              background: `linear-gradient(135deg, ${themeColor} 0%, #aa0020 100%)`,
              boxShadow: `0 4px 14px ${themeColor}55`,
            }}
          >
            {isSending ? (
              <RefreshCw className="w-4 h-4 sm:w-5 sm:h-5 animate-spin text-white" />
            ) : (
              <Send className="w-4 h-4 sm:w-5 sm:h-5 fill-white ml-0.5 text-white" />
            )}
          </button>
        </form>
      </footer>

      {/* 5. FULL-SCREEN PHOTO LIGHTBOX MODAL */}
      {zoomedImage && (
        <div
          className="fixed inset-0 z-60 bg-black/95 flex flex-col items-center justify-center p-3 animate-in fade-in duration-200 backdrop-blur-md"
          onClick={() => setZoomedImage(null)}
        >
          <div className="absolute top-4 right-4 z-10 flex items-center gap-2">
            <button
              onClick={() => setZoomedImage(null)}
              type="button"
              className="p-2.5 rounded-2xl bg-white/15 hover:bg-white/25 text-white transition-all cursor-pointer shadow-lg"
              title="Close full-screen"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <img
            src={zoomedImage}
            alt="Full size preview"
            className="max-w-full max-h-[90vh] object-contain rounded-2xl shadow-2xl select-none"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
};
