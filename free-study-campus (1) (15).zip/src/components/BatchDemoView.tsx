import React, { useState, useEffect, useMemo } from 'react';
import {
  Video,
  Play,
  ArrowLeft,
  Search,
  X,
  Sparkles,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { BatchDemo, subscribeBatchDemos } from '../services/batchDemoService';
import { BatchDemoPlayerModal } from './BatchDemoPlayerModal';

interface BatchDemoViewProps {
  onBack?: () => void;
  backLabel?: string;
}

export const BatchDemoView: React.FC<BatchDemoViewProps> = ({ onBack, backLabel = 'Back to Login' }) => {
  const { config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';

  const [demos, setDemos] = useState<BatchDemo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedDemo, setSelectedDemo] = useState<BatchDemo | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState<string>('all');

  // Real-time synchronization: disabled or deleted demos are automatically hidden
  useEffect(() => {
    setIsLoading(true);
    const unsubscribe = subscribeBatchDemos((activeDemos) => {
      setDemos(activeDemos);
      setIsLoading(false);
    }, false); // Only enabled demos for students

    return () => {
      unsubscribe();
    };
  }, []);

  // Distinct platform filter chips
  const platformList = useMemo(() => {
    const set = new Set<string>();
    demos.forEach((d) => {
      if (d.platformName) set.add(d.platformName);
    });
    return Array.from(set);
  }, [demos]);

  // Filtered demos based on search query and platform filter
  const filteredDemos = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return demos.filter((d) => {
      if (selectedPlatform !== 'all' && d.platformName !== selectedPlatform) {
        return false;
      }
      if (!q) return true;
      return (
        d.title.toLowerCase().includes(q) ||
        d.platformName.toLowerCase().includes(q) ||
        (d.description && d.description.toLowerCase().includes(q))
      );
    });
  }, [demos, searchQuery, selectedPlatform]);

  return (
    <div className="w-full pb-24 flex flex-col gap-5 sm:gap-6 max-w-5xl mx-auto animate-in fade-in duration-200">
      {/* 1. TOP HEADER & BREADCRUMB */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/15 text-xs font-bold text-white transition-all active:scale-95 cursor-pointer shadow-sm"
              title={backLabel}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{backLabel}</span>
            </button>
          )}

          <div>
            <div className="flex items-center gap-2">
              <span
                className="w-2.5 h-2.5 rounded-full animate-pulse"
                style={{ backgroundColor: themeColor }}
              />
              <h1 className="text-lg sm:text-2xl font-black text-white font-display tracking-tight flex items-center gap-2">
                <span>OFFICIAL BATCH DEMOS</span>
              </h1>
              <span
                className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider text-white border"
                style={{
                  backgroundColor: `${themeColor}25`,
                  borderColor: `${themeColor}50`,
                }}
              >
                {demos.length} Live
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Watch real teaching methodology, concept walkthroughs & sample lectures from top platforms.
            </p>
          </div>
        </div>

        {/* Verified Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-300 text-[11px] font-bold self-start sm:self-auto">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Unlisted HD Demos</span>
        </div>
      </div>

      {/* 2. SEARCH BAR & PLATFORM FILTER CHIPS */}
      <div className="flex flex-col gap-3">
        {/* Search input */}
        <div className="relative flex items-center">
          <div className="absolute left-4 pointer-events-none text-slate-400">
            <Search className="w-4 h-4" style={{ color: themeColor }} />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search demo by platform or title (e.g. Physics Wallah, Unacademy, Target Board)..."
            className="w-full pl-11 pr-10 py-3 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-white/20 focus:border-red-500/50 text-white placeholder-slate-400 text-xs sm:text-sm transition-all focus:outline-none focus:ring-1 focus:ring-red-500/30 shadow-[0_4px_16px_rgba(0,0,0,0.4)]"
            style={{
              borderColor: searchQuery ? `${themeColor}60` : undefined,
            }}
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 p-1 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Platform Filter Chips */}
        {platformList.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            <button
              type="button"
              onClick={() => setSelectedPlatform('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
                selectedPlatform === 'all'
                  ? 'bg-white/15 text-white border-white/30 shadow-sm'
                  : 'bg-white/[0.03] text-slate-400 border-white/5 hover:text-white'
              }`}
            >
              All Platforms ({demos.length})
            </button>
            {platformList.map((plat) => {
              const isSelected = selectedPlatform === plat;
              const count = demos.filter((d) => d.platformName === plat).length;
              return (
                <button
                  key={plat}
                  type="button"
                  onClick={() => setSelectedPlatform(plat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border flex items-center gap-1.5 ${
                    isSelected
                      ? 'text-white shadow-sm'
                      : 'bg-white/[0.03] text-slate-400 border-white/5 hover:text-white'
                  }`}
                  style={{
                    backgroundColor: isSelected ? `${themeColor}25` : undefined,
                    borderColor: isSelected ? `${themeColor}55` : undefined,
                  }}
                >
                  <span>{plat}</span>
                  <span className="text-[10px] opacity-75 font-mono">({count})</span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 3. DEMOS GRID */}
      {isLoading ? (
        <div className="py-20 flex flex-col items-center justify-center gap-2 text-slate-400 text-xs">
          <RefreshCw className="w-6 h-6 animate-spin" style={{ color: themeColor }} />
          <span>Loading official batch demos...</span>
        </div>
      ) : filteredDemos.length === 0 ? (
        <div className="p-10 rounded-3xl glass-panel border border-white/10 flex flex-col items-center justify-center text-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-center text-slate-400">
            <Video className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">No Batch Demos Found</h3>
            <p className="text-xs text-slate-400 max-w-sm mt-1">
              {searchQuery
                ? `No demos matching "${searchQuery}". Try a different keyword or reset filters.`
                : 'Demo options will appear here as soon as they are added by the administrator.'}
            </p>
          </div>
          {searchQuery && (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedPlatform('all');
              }}
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-bold text-white transition-all cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredDemos.map((demo) => {
            const thumbUrl = demo.videoId
              ? `https://img.youtube.com/vi/${demo.videoId}/hqdefault.jpg`
              : null;

            return (
              <div
                key={demo.id}
                onClick={() => setSelectedDemo(demo)}
                className="group rounded-3xl glass-panel border border-white/10 hover:border-red-500/50 p-4 transition-all duration-300 flex flex-col justify-between gap-3 relative overflow-hidden shadow-lg hover:shadow-2xl cursor-pointer hover:-translate-y-1"
                style={{
                  boxShadow: '0 8px 24px -4px rgba(0, 0, 0, 0.7)',
                }}
              >
                {/* Ambient glow behind card on hover */}
                <div
                  className="absolute -top-10 -right-10 w-28 h-28 rounded-full blur-2xl pointer-events-none opacity-0 group-hover:opacity-25 transition-opacity duration-500"
                  style={{ backgroundColor: themeColor }}
                />

                {/* 16:9 Thumbnail with Overlay Play Button */}
                <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-black/60 border border-white/10 shadow-inner flex items-center justify-center">
                  {thumbUrl ? (
                    <img
                      src={thumbUrl}
                      alt={demo.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-zinc-900">
                      <Video className="w-8 h-8 text-zinc-600" />
                    </div>
                  )}

                  {/* Gradient shadow overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                  {/* Central Glowing Red Play Button */}
                  <div
                    className="relative z-10 w-12 h-12 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 group-hover:scale-115"
                    style={{
                      backgroundColor: themeColor,
                      boxShadow: `0 0 20px ${themeColor}88`,
                    }}
                  >
                    <Play className="w-5 h-5 text-white fill-white ml-0.5" />
                  </div>

                  {/* Platform pill in bottom-left */}
                  <div className="absolute bottom-2.5 left-2.5 z-10 flex items-center gap-1.5">
                    <span
                      className="px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider text-white shadow-md backdrop-blur-md"
                      style={{ backgroundColor: `${themeColor}ee` }}
                    >
                      {demo.platformName}
                    </span>
                  </div>

                  {/* HD Badge in top-right */}
                  <div className="absolute top-2.5 right-2.5 z-10">
                    <span className="px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-widest text-white bg-black/75 border border-white/20 backdrop-blur-md">
                      HD DEMO
                    </span>
                  </div>
                </div>

                {/* Card Title & Content */}
                <div className="flex flex-col gap-1.5 flex-1 justify-between">
                  <div>
                    <h3 className="text-sm sm:text-base font-extrabold text-white font-display group-hover:text-red-400 transition-colors line-clamp-2 leading-snug">
                      {demo.title}
                    </h3>
                    {demo.description && (
                      <p className="text-xs text-slate-300 mt-1 line-clamp-2 leading-relaxed">
                        {demo.description}
                      </p>
                    )}
                  </div>

                  {/* Watch Button Callout */}
                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs font-bold">
                    <span className="text-slate-400 text-[11px] flex items-center gap-1">
                      <Sparkles className="w-3 h-3" style={{ color: themeColor }} />
                      <span>Sample Lecture</span>
                    </span>

                    <span
                      className="flex items-center gap-1 group-hover:translate-x-1 transition-transform"
                      style={{ color: themeColor }}
                    >
                      <span>Watch Demo</span>
                      <Play className="w-3 h-3 fill-current" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Video Player Modal */}
      <BatchDemoPlayerModal
        demo={selectedDemo}
        isOpen={Boolean(selectedDemo)}
        onClose={() => setSelectedDemo(null)}
      />
    </div>
  );
};
