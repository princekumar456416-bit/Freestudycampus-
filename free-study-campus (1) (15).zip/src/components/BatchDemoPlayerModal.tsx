import React, { useState } from 'react';
import { X, Play, ExternalLink, AlertTriangle, ShieldCheck, Video } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { BatchDemo, parseYouTubeVideo } from '../services/batchDemoService';

interface BatchDemoPlayerModalProps {
  demo: BatchDemo | null;
  isOpen: boolean;
  onClose: () => void;
}

export const BatchDemoPlayerModal: React.FC<BatchDemoPlayerModalProps> = ({
  demo,
  isOpen,
  onClose,
}) => {
  const { config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';
  const [hasPlaybackError, setHasPlaybackError] = useState(false);

  if (!isOpen || !demo) return null;

  const parsed = parseYouTubeVideo(demo.videoUrl);
  const videoId = demo.videoId || parsed.videoId;
  const isVideoValid = Boolean(videoId);

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 select-none"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-3xl rounded-3xl bg-[#0a070e]/95 border border-white/15 p-4 sm:p-6 shadow-[0_25px_60px_rgba(0,0,0,0.9)] backdrop-blur-2xl flex flex-col gap-4 max-h-[92vh] overflow-y-auto"
        style={{
          boxShadow: `0 0 35px -5px ${themeColor}33`,
        }}
      >
        {/* Top Highlight Accent */}
        <div
          className="absolute -top-12 -right-12 w-48 h-48 rounded-full blur-3xl pointer-events-none opacity-20"
          style={{ backgroundColor: themeColor }}
        />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 relative z-10">
          <div className="flex items-center gap-3 min-w-0 pr-2">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-md border"
              style={{
                backgroundColor: `${themeColor}22`,
                borderColor: `${themeColor}44`,
              }}
            >
              <Video className="w-5 h-5" style={{ color: themeColor }} />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span
                  className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider text-white"
                  style={{ backgroundColor: themeColor }}
                >
                  {demo.platformName}
                </span>
                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  <span>Verified Demo</span>
                </span>
              </div>
              <h3 className="text-sm sm:text-base font-extrabold text-white font-display truncate mt-0.5">
                {demo.title}
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer shrink-0"
            title="Close Video Player"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Video Player 16:9 Frame */}
        <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-black border border-white/10 shadow-2xl flex items-center justify-center">
          {isVideoValid && !hasPlaybackError ? (
            <iframe
              src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1&playsinline=1`}
              title={demo.title}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              onError={() => setHasPlaybackError(true)}
            />
          ) : (
            <div className="flex flex-col items-center justify-center text-center p-6 gap-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">Video Playback Unavailable</p>
                <p className="text-xs text-slate-400 max-w-sm mt-1">
                  This YouTube video link might be invalid, deleted, or marked private by the creator.
                </p>
              </div>
              {demo.videoUrl && (
                <a
                  href={demo.videoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white bg-white/10 hover:bg-white/15 transition-all"
                >
                  <span>Try Opening on YouTube</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          )}
        </div>

        {/* Video Meta & Description */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-white/5">
          <div className="text-xs text-slate-300">
            {demo.description ? (
              <p className="line-clamp-2 leading-relaxed">{demo.description}</p>
            ) : (
              <p className="text-slate-400">
                Official batch teaching demonstration, curriculum walkthrough, and methodology sample.
              </p>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {demo.videoUrl && (
              <a
                href={demo.videoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all cursor-pointer"
                title="Open directly in YouTube App"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Open YouTube</span>
              </a>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl text-xs font-bold text-white transition-all cursor-pointer shadow-md"
              style={{
                backgroundColor: themeColor,
              }}
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
