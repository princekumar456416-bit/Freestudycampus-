import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useTheme } from '../context/ThemeContext';
import { PlatformCard, PlatformDisplayItem } from './PlatformCard';
import { SearchBar } from './SearchBar';
import { ShieldCheck, Layers, WifiOff, RefreshCw, Sparkles, BookOpen, ExternalLink } from 'lucide-react';
import { api, safeDataCache, ConnectionStatusInfo, subscribeAnnouncements } from '../services/api';
import { AnnouncementRecord, BatchRecord } from '../../server/db';
import { CampusLogo } from './CampusLogo';
import { HomeParticles } from './HomeParticles';
import { AnimatedLogoBorder } from './AnimatedLogoBorder';
import { AnnouncementCarousel } from './AnnouncementCarousel';

interface HomeViewProps {
  platforms: PlatformDisplayItem[];
  logoUrl?: string;
  onOpenDemos?: () => void;
}

export const HomeView: React.FC<HomeViewProps> = React.memo(({ platforms, logoUrl }) => {
  const { currentThemeColor, config } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState('');
  const [announcements, setAnnouncements] = useState<AnnouncementRecord[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatusInfo>(safeDataCache.getStatus());

  const handleSearchChange = useCallback((q: string) => {
    setSearchQuery(q);
  }, []);

  const handleTagChange = useCallback((t: string) => {
    setSelectedTag(t);
  }, []);

  const handleClearFilters = useCallback(() => {
    setSearchQuery('');
    setSelectedTag('');
  }, []);

  useEffect(() => {
    return safeDataCache.subscribeStatus((st) => setConnectionStatus(st));
  }, []);

  useEffect(() => {
    const unsubscribe = subscribeAnnouncements((data) => {
      setAnnouncements(data);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  // Filter platforms by search query or quick tag with fast case normalization
  const filteredPlatforms = useMemo(() => {
    if (!platforms || platforms.length === 0) return [];
    const q = searchQuery.trim().toLowerCase();
    const tag = selectedTag.trim().toLowerCase();

    if (!q && !tag) return platforms;

    return platforms.filter((p) => {
      const name = p.name.toLowerCase();
      if (q && !name.includes(q)) return false;
      if (tag && !name.includes(tag)) return false;
      return true;
    });
  }, [platforms, searchQuery, selectedTag]);

  return (
    <div
      className="w-full pb-24 flex flex-col gap-5 sm:gap-6 max-w-4xl mx-auto relative select-none"
      style={{
        transform: 'translateZ(0)',
        WebkitTransform: 'translateZ(0)',
        contain: 'layout style',
      }}
    >
      {/* Lightweight GPU-accelerated atmospheric background with zero scrolling lag */}
      <HomeParticles themeColor={themeColor} />

      {/* 1. LUXURY HERO / BRAND PRESENTATION */}
      <section className="relative text-center pt-1 sm:pt-3 pb-1 flex flex-col items-center">
        {/* Soft, High-Contrast Red Ambient Glow */}
        <div
          className="absolute -top-10 left-1/2 -translate-x-1/2 w-72 sm:w-[28rem] h-36 rounded-full pointer-events-none opacity-20 transition-all duration-700"
          style={{
            background: `radial-gradient(ellipse 70% 50% at 50% 25%, ${themeColor}66 0%, transparent 70%)`,
            transform: 'translateZ(0)',
          }}
        />

        {/* Hero Main Logo: Jewel Pedestal with Luminous Animated Outline */}
        <div className="relative mb-3 group flex items-center justify-center">
          <AnimatedLogoBorder shape="circle" accentColor={themeColor}>
            {/* Crisp Circular Pedestal Frame: Deep Obsidian Surface & Specular Rim */}
            <div
              className="relative z-10 w-20 h-20 sm:w-24 sm:h-24 rounded-full p-2.5 sm:p-3 flex items-center justify-center transition-transform duration-300 overflow-hidden group-hover:scale-105"
              style={{
                backgroundColor: '#090508',
                border: `1.5px solid ${themeColor}55`,
                boxShadow: `0 12px 32px -6px rgba(0, 0, 0, 0.85), 0 0 16px -2px ${themeColor}30, inset 0 1px 1px rgba(255, 255, 255, 0.25)`,
              }}
            >
              {/* Specular Inner Glare */}
              <div className="absolute inset-0 bg-gradient-to-b from-white/[0.12] to-transparent pointer-events-none rounded-full" />

              <CampusLogo
                logoUrl={logoUrl}
                className="relative z-10 w-full h-full object-contain aspect-square drop-shadow-md select-none pointer-events-none"
                alt="Free Study Campus Logo"
              />
            </div>
          </AnimatedLogoBorder>
        </div>

        {/* Clean, Premium FREE STUDY CAMPUS Typography */}
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white font-display tracking-tight leading-tight drop-shadow-sm">
          FREE STUDY <span style={{ color: themeColor }}>CAMPUS</span>
        </h1>

        {/* Executive "By Jyotish Kumar" Branding Signature */}
        <div className="inline-flex items-center gap-1.5 sm:gap-2 mt-2 px-3.5 py-1 rounded-full bg-white/[0.04] border border-white/10 text-xs shadow-sm backdrop-blur-md">
          <span className="text-slate-400 font-medium">Curated &amp; Directed by</span>
          <span className="text-white font-bold tracking-wide">Jyotish Kumar</span>
          <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: themeColor }} />
        </div>

        {/* Professional Subtitle */}
        <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-md font-normal leading-relaxed text-balance">
          Your verified gateway to authorized study portals and premium batches.
        </p>
      </section>

      {/* 2. CAMPUS ANNOUNCEMENT SECTION & CAROUSEL */}
      <section className="w-full">
        <AnnouncementCarousel
          announcements={announcements}
          themeColor={themeColor}
        />
      </section>

      {/* 3. SEARCH BAR & FILTERS */}
      <section className="w-full">
        <SearchBar
          searchQuery={searchQuery}
          onSearchChange={handleSearchChange}
          selectedTag={selectedTag}
          onSelectTag={handleTagChange}
          placeholder="Search study batches and platforms..."
        />
      </section>

      {/* 4. LUXURY BATCH CARDS SECTION */}
      <section className="flex flex-col gap-3 sm:gap-4">
        {/* Section Heading with Verified Status */}
        <div className="flex items-center justify-between gap-3 pt-1">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white font-display tracking-tight">
              Study Batches &amp; Portals
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Tap any batch to launch its authorized external portal directly
            </p>
          </div>

          <div
            className="flex items-center gap-1.5 text-[11px] font-semibold px-2.5 sm:px-3 py-1 rounded-xl border backdrop-blur-md shadow-sm shrink-0 select-none"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.04)',
              borderColor: `${themeColor}35`,
              boxShadow: `0 2px 8px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.08)`,
            }}
          >
            <ShieldCheck className="w-3.5 h-3.5" style={{ color: themeColor }} />
            <span className="text-slate-200">{filteredPlatforms.length} Active</span>
          </div>
        </div>

        {/* BATCH CARDS GRID */}
        {filteredPlatforms.length === 0 ? (
          <div className="rounded-3xl p-8 sm:p-10 text-center glass-panel border border-white/10 flex flex-col items-center justify-center gap-3">
            {searchQuery.trim() || selectedTag ? (
              <>
                <Layers className="w-8 h-8 text-slate-500" />
                <p className="text-sm font-semibold text-white">No matching batches found</p>
                <p className="text-xs text-slate-400">Try searching for &ldquo;Physics Wallah&rdquo; or &ldquo;Target Board&rdquo;.</p>
                <button
                  type="button"
                  onClick={handleClearFilters}
                  className="btn-primary-red mt-1 px-4 py-1.5 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Clear Filters
                </button>
              </>
            ) : connectionStatus.isUnavailable ? (
              <>
                <WifiOff className="w-9 h-9 text-amber-400" />
                <h3 className="text-sm sm:text-base font-bold text-white">Connection Temporarily Unavailable</h3>
                <p className="text-xs text-slate-400 max-w-sm">
                  Unable to reach the campus directory right now. Showing saved data where available.
                </p>
                <button
                  type="button"
                  onClick={() => window.location.reload()}
                  className="btn-primary-red mt-1 inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold cursor-pointer shadow-md"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Retry Connection</span>
                </button>
              </>
            ) : (
              <>
                <Layers className="w-8 h-8 text-slate-500" />
                <p className="text-sm font-semibold text-white">No batches available</p>
                <p className="text-xs text-slate-400">All newly published batches will appear here.</p>
              </>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            {filteredPlatforms.map((platform) => (
              <PlatformCard key={platform.id} platform={platform} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
});

HomeView.displayName = 'HomeView';
