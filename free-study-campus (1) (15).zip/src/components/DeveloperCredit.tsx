import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { Sparkles, Code2 } from 'lucide-react';

interface DeveloperCreditProps {
  className?: string;
}

export const DeveloperCredit: React.FC<DeveloperCreditProps> = ({ className = '' }) => {
  const { config } = useTheme();

  return (
    <div
      className={`w-full flex items-center justify-center my-6 sm:my-8 pointer-events-auto select-none ${className}`}
      aria-label="Developer Attribution"
    >
      <div
        className="group relative inline-flex items-center gap-2 px-4 sm:px-5 py-2 sm:py-2.5 rounded-full border backdrop-blur-xl transition-all duration-500 hover:scale-[1.02]"
        style={{
          backgroundColor: config.cardBg,
          borderColor: config.borderColor,
          boxShadow: `0 4px 24px -4px ${config.accentGlow}`,
        }}
      >
        {/* Continuous Soft Ambient Shimmer / Pulse Glow */}
        <div
          className="absolute -inset-1 rounded-full blur-md opacity-40 pointer-events-none transition-opacity duration-700 animate-developer-glow"
          style={{
            backgroundColor: config.primaryColor,
          }}
        />

        {/* Inner subtle glow ring */}
        <div
          className="absolute inset-0 rounded-full opacity-20 pointer-events-none"
          style={{
            boxShadow: `inset 0 0 12px ${config.primaryColor}`,
          }}
        />

        {/* Small subtle tech icon */}
        <div
          className="relative z-10 w-4 h-4 rounded-full flex items-center justify-center shrink-0"
          style={{ color: config.primaryColor }}
        >
          <Code2 className="w-3.5 h-3.5" />
        </div>

        {/* Developed by Jyotish Kumar with dynamic soft animated glow */}
        <div className="relative z-10 flex items-center gap-1.5 text-xs sm:text-sm font-semibold tracking-wide">
          <span className="text-slate-400 font-medium">Developed by</span>
          <span
            className="font-bold font-display tracking-tight animate-developer-text-glow transition-colors"
            style={{
              color: '#ffffff',
              textShadow: `0 0 12px ${config.accentGlow}, 0 0 20px ${config.primaryColor}`,
            }}
          >
            Jyotish Kumar
          </span>
          <Sparkles
            className="w-3 h-3 shrink-0 ml-0.5 animate-pulse"
            style={{ color: config.primaryColor }}
          />
        </div>
      </div>
    </div>
  );
};
