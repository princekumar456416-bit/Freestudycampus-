import React, { useState, useEffect, useMemo } from 'react';
import { NavView } from '../types';
import { LayoutDashboard, Globe, Bell, User } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface BottomNavProps {
  currentView?: NavView;
  activeTab?: NavView;
  onSelectView?: (view: NavView) => void;
  setActiveTab?: (view: NavView) => void;
  studentAvatarUrl?: string | null;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentView,
  activeTab,
  onSelectView,
  setActiveTab,
  studentAvatarUrl,
}) => {
  const { currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || '#ff2e4d';
  const current = activeTab || currentView || 'HOME';
  const handleSelect = setActiveTab || onSelectView || (() => {});
  const [avatarError, setAvatarError] = useState(false);

  // Live reset of avatar error if studentAvatarUrl updates
  useEffect(() => {
    if (studentAvatarUrl) {
      setAvatarError(false);
    }
  }, [studentAvatarUrl]);

  const navItems: { id: NavView; label: string; icon: React.ElementType }[] = useMemo(
    () => [
      { id: 'HOME', label: 'Home', icon: LayoutDashboard },
      { id: 'PLATFORMS', label: 'Batches', icon: Globe },
      { id: 'UPCOMING', label: 'Upcoming', icon: Bell },
      { id: 'PROFILE', label: 'Profile', icon: User },
    ],
    []
  );

  // Calculate active index (0 to 3) for smooth sliding pill
  const activeIndex = useMemo(() => {
    const idx = navItems.findIndex((item) => item.id === current);
    return idx >= 0 ? idx : 0;
  }, [navItems, current]);

  return (
    <nav
      className="fixed z-40 left-1/2 -translate-x-1/2 bottom-[max(0.65rem,env(safe-area-inset-bottom,0px))] sm:bottom-4 w-[calc(100%-1.25rem)] max-w-sm sm:max-w-md select-none print:hidden pointer-events-auto transition-all duration-300"
      aria-label="Bottom Navigation"
      role="tablist"
    >
      {/* 1. Ambient Background Glow Aura behind Floating Capsule */}
      <div
        className="absolute -inset-2 rounded-full blur-xl pointer-events-none opacity-45 transition-all duration-700"
        style={{
          background: `radial-gradient(ellipse at 50% 50%, ${themeColor}66 0%, transparent 75%)`,
        }}
      />

      {/* 2. Floating Pill Capsule Shell with Red-and-White Glassmorphism */}
      <div
        className="relative rounded-full border p-1.5 flex items-center justify-between backdrop-blur-2xl transition-all shadow-[0_16px_40px_-8px_rgba(0,0,0,0.85)]"
        style={{
          backgroundColor: 'rgba(12, 7, 14, 0.92)',
          borderColor: 'rgba(255, 255, 255, 0.14)',
          boxShadow: `0 16px 40px -8px rgba(0, 0, 0, 0.9), 0 0 24px -4px ${themeColor}38, inset 0 1px 1px rgba(255, 255, 255, 0.22)`,
        }}
      >
        {/* Specular Inner Glare for Premium Glass Lustre */}
        <div className="absolute inset-x-6 top-0 h-1/2 rounded-t-full bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />

        {/* 3. Smooth Sliding Active Pill Indicator */}
        <div
          className="absolute top-1.5 bottom-1.5 left-0 w-1/4 px-1 pointer-events-none will-change-transform"
          style={{
            transform: `translate3d(${activeIndex * 100}%, 0, 0)`,
            transition: 'transform 360ms cubic-bezier(0.34, 1.35, 0.64, 1)',
          }}
        >
          {/* Active Highlighted Pill Body */}
          <div
            className="w-full h-full rounded-full relative overflow-hidden transition-all duration-300"
            style={{
              background: `linear-gradient(135deg, ${themeColor}33 0%, ${themeColor}1a 100%)`,
              border: `1.5px solid ${themeColor}66`,
              boxShadow: `0 0 18px -1px ${themeColor}55, inset 0 1px 1px rgba(255, 255, 255, 0.45)`,
            }}
          >
            {/* Top Micro-Highlight Glaze */}
            <div className="absolute inset-x-3 top-0 h-px bg-gradient-to-r from-transparent via-white/50 to-transparent" />

            {/* Core Radial Glow Accent */}
            <div
              className="absolute inset-0 opacity-70"
              style={{
                background: `radial-gradient(circle at 50% 50%, ${themeColor}55 0%, transparent 70%)`,
              }}
            />
          </div>
        </div>

        {/* 4. Four Interactive Navigation Tabs */}
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = current === item.id;
          const isProfileWithAvatar =
            item.id === 'PROFILE' && Boolean(studentAvatarUrl && !avatarError);

          return (
            <button
              key={item.id}
              onClick={() => handleSelect(item.id)}
              type="button"
              className="relative z-10 flex flex-col items-center justify-center flex-1 h-12 sm:h-13 min-h-[46px] rounded-full cursor-pointer transition-all duration-200 active:scale-92 focus:outline-none group"
              aria-selected={isActive}
              role="tab"
              title={item.label}
            >
              {/* Profile Avatar Mode */}
              {isProfileWithAvatar ? (
                <div
                  className={`relative flex items-center justify-center transition-transform duration-300 ${
                    isActive ? 'scale-110 -translate-y-0.5' : 'scale-100 group-hover:scale-105'
                  }`}
                >
                  {/* Subtle breathing ambient glow when active */}
                  {isActive && (
                    <div
                      className="absolute -inset-1 rounded-full blur-sm pointer-events-none animate-pulse"
                      style={{
                        background: `radial-gradient(circle, ${themeColor}88 0%, transparent 70%)`,
                      }}
                    />
                  )}
                  <div
                    className="relative z-10 w-6.5 h-6.5 sm:w-7 sm:h-7 rounded-full overflow-hidden transition-all duration-200 aspect-square border"
                    style={{
                      borderColor: isActive ? '#ffffff' : 'rgba(255, 255, 255, 0.25)',
                      boxShadow: isActive
                        ? `0 0 12px ${themeColor}88, inset 0 1px 1px rgba(255, 255, 255, 0.4)`
                        : '0 2px 6px rgba(0,0,0,0.5)',
                    }}
                  >
                    <img
                      src={studentAvatarUrl!}
                      alt="Student Profile"
                      className="w-full h-full object-cover rounded-full aspect-square select-none pointer-events-none"
                      onError={() => setAvatarError(true)}
                    />
                  </div>
                </div>
              ) : (
                /* Icon Mode */
                <div
                  className={`flex items-center justify-center transition-all duration-300 ${
                    isActive
                      ? 'scale-115 -translate-y-0.5 text-white'
                      : 'scale-100 text-zinc-400 group-hover:text-zinc-200 group-hover:scale-105'
                  }`}
                  style={{
                    filter: isActive ? `drop-shadow(0 0 8px ${themeColor}bb)` : 'none',
                  }}
                >
                  <Icon className="w-5 h-5 sm:w-5.5 sm:h-5.5 transition-transform" />
                </div>
              )}

              {/* Text Label with Fading and Scaling Animation */}
              <span
                className={`text-[10px] sm:text-[10.5px] mt-0.5 tracking-tight transition-all duration-200 ${
                  isActive
                    ? 'font-black text-white scale-105'
                    : 'font-medium text-zinc-400 group-hover:text-zinc-200'
                }`}
                style={{
                  textShadow: isActive ? `0 0 10px ${themeColor}88` : 'none',
                }}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
