import React, { useMemo } from 'react';

interface HomeParticlesProps {
  themeColor?: string;
}

// 10 lightweight, gracefully positioned ambient micro-orbs using only transform: translate3d
const LIGHT_PARTICLES = [
  { x: 8, y: 12, size: 2, anim: 'A', duration: 16, delay: -4, opacity: 0.4 },
  { x: 22, y: 28, size: 1.5, anim: 'B', duration: 22, delay: -10, opacity: 0.35 },
  { x: 38, y: 15, size: 2.5, anim: 'C', duration: 18, delay: -6, opacity: 0.5 },
  { x: 55, y: 24, size: 2, anim: 'D', duration: 20, delay: -12, opacity: 0.45 },
  { x: 72, y: 10, size: 3, anim: 'A', duration: 24, delay: -8, opacity: 0.5 },
  { x: 88, y: 32, size: 1.5, anim: 'B', duration: 19, delay: -14, opacity: 0.35 },
  { x: 15, y: 65, size: 2, anim: 'C', duration: 21, delay: -5, opacity: 0.4 },
  { x: 42, y: 75, size: 2.5, anim: 'D', duration: 23, delay: -11, opacity: 0.45 },
  { x: 68, y: 82, size: 1.5, anim: 'A', duration: 17, delay: -7, opacity: 0.35 },
  { x: 85, y: 68, size: 2, anim: 'B', duration: 25, delay: -15, opacity: 0.4 },
];

export const HomeParticles: React.FC<HomeParticlesProps> = React.memo(({ themeColor = '#ff2e4d' }) => {
  const particles = useMemo(() => {
    return LIGHT_PARTICLES.map((p, index) => {
      const style: React.CSSProperties = {
        left: `${p.x}%`,
        top: `${p.y}%`,
        width: `${p.size}px`,
        height: `${p.size}px`,
        backgroundColor: index % 2 === 0 ? themeColor : '#ffffff',
        animationName: `particleFloat${p.anim}`,
        animationDuration: `${p.duration}s`,
        animationDelay: `${p.delay}s`,
        animationTimingFunction: 'ease-in-out',
        animationIterationCount: 'infinite',
        animationDirection: 'alternate',
        opacity: p.opacity,
      };

      return {
        id: index,
        style,
      };
    });
  }, [themeColor]);

  return (
    <div
      className="fixed inset-0 pointer-events-none select-none overflow-hidden z-0"
      style={{
        contain: 'strict',
        transform: 'translateZ(0)',
      }}
      aria-hidden="true"
    >
      {/* Soft atmospheric gradient mesh (GPU composited) */}
      <div
        className="absolute inset-0 pointer-events-none opacity-25"
        style={{
          background: `radial-gradient(circle at 50% 0%, ${themeColor}22 0%, transparent 60%), radial-gradient(circle at 85% 30%, ${themeColor}12 0%, transparent 50%)`,
        }}
      />
      {particles.map((p) => (
        <span key={p.id} className="home-particle" style={p.style} />
      ))}
    </div>
  );
});

HomeParticles.displayName = 'HomeParticles';

