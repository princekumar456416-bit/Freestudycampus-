import React, { useState } from 'react';
import { ArrowLeft, Shield, Palette, X, Check, Sparkles, Bell } from 'lucide-react';
import { NavView, ThemeType } from '../types';
import { useTheme, THEMES, ACCENT_PRESETS } from '../context/ThemeContext';
import { CampusLogo } from './CampusLogo';
import { AnimatedLogoBorder } from './AnimatedLogoBorder';

interface HeaderProps {
  currentView?: NavView;
  activeTab?: NavView;
  onSelectView?: (view: NavView) => void;
  setActiveTab?: (view: NavView) => void;
  onOpenDrawer?: () => void;
  onBack?: () => void;
  showBack?: boolean;
  onOpenProfile?: () => void;
  onOpenAdmin?: () => void;
  onOpenNotifications?: () => void;
  unreadNotificationCount?: number;
  logoUrl?: string;
}

/**
 * Luxury Premium Header / Toolbar — Free Study Campus
 * 
 * - Executive branding presentation with Free Study Campus emblem & "By Jyotish Kumar"
 * - 100% Dynamic Theme Color integration (derived directly from active settings)
 * - Modern Theme Change Jewel Control with dual-color palette indicator
 * - Sleek obsidian glass surface with specular top edge line and subtle depth
 * - Compact, mobile-first responsive layout with zero overflow on Android screens
 */
export const Header: React.FC<HeaderProps> = React.memo(({
  activeTab,
  setActiveTab,
  onBack,
  showBack,
  onOpenAdmin,
  onOpenNotifications,
  unreadNotificationCount,
  logoUrl,
}) => {
  const { theme, setTheme, accent, setAccent, config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';
  const [isColorModalOpen, setIsColorModalOpen] = useState(false);

  const availableThemes: ThemeType[] = [
    'rose',
    'obsidian',
    'monochrome',
    'cyber',
    'emerald',
    'violet',
    'amber',
  ];

  return (
    <>
      <header
        className="sticky top-0 z-40 w-full backdrop-blur-2xl border-b border-white/[0.08] transition-colors duration-300 select-none"
        style={{
          backgroundColor: 'rgba(9, 6, 11, 0.94)',
          boxShadow: '0 8px 30px -4px rgba(0, 0, 0, 0.85)',
          contain: 'layout style',
        }}
      >
        {/* 1. Precision Specular Top Rim Line - Gives header a luxury chamfered glass finish */}
        <div
          className="absolute top-0 inset-x-0 h-[1.5px] pointer-events-none opacity-50 transition-opacity duration-300"
          style={{
            background: `linear-gradient(90deg, transparent 0%, ${themeColor}66 25%, #ffffffcc 50%, ${themeColor}66 75%, transparent 100%)`,
          }}
        />

        {/* 2. Soft Ambient Header Glow behind controls */}
        <div
          className="absolute -top-10 right-10 w-44 h-24 rounded-full pointer-events-none opacity-20"
          style={{
            background: `radial-gradient(circle, ${themeColor}77 0%, transparent 70%)`,
          }}
        />

        <div className="max-w-4xl mx-auto px-3 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-2 sm:gap-4 relative z-10">
          {/* ======================================================== */}
          {/* LEFT: BRAND / BACK BUTTON                                */}
          {/* ======================================================== */}
          <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
            {showBack && onBack ? (
              <button
                onClick={onBack}
                type="button"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/15 text-xs font-bold text-white transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
            ) : (
              <div className="flex items-center gap-2.5 sm:gap-3 group min-w-0">
                {/* Logo Frame with Luminous Animated Outline */}
                <div className="relative shrink-0 flex items-center justify-center">
                  <AnimatedLogoBorder shape="rounded-rect" borderRadius={12} accentColor={themeColor}>
                    <div
                      className="relative z-10 w-8.5 h-8.5 sm:w-9.5 sm:h-9.5 rounded-xl p-1 flex items-center justify-center shadow-[0_4px_14px_rgba(0,0,0,0.7),inset_0_1px_0_rgba(255,255,255,0.18)] border border-white/15 overflow-hidden transition-all duration-300 group-hover:scale-105"
                      style={{
                        backgroundColor: '#0d070b',
                      }}
                    >
                      <CampusLogo
                        logoUrl={logoUrl}
                        withGlow={false}
                        className="w-full h-full object-contain aspect-square drop-shadow-sm pointer-events-none"
                      />
                    </div>
                  </AnimatedLogoBorder>
                </div>

                {/* Brand Title Lockup with "By Jyotish Kumar" */}
                <div className="flex flex-col min-w-0 justify-center">
                  <div className="flex items-baseline gap-1 sm:gap-1.5 truncate leading-tight">
                    <span className="text-[13px] sm:text-[15px] md:text-base font-extrabold text-white font-display tracking-tight whitespace-nowrap drop-shadow-sm">
                      FREE STUDY
                    </span>
                    <span
                      className="text-[13px] sm:text-[15px] md:text-base font-black font-display tracking-tight whitespace-nowrap drop-shadow-sm transition-colors duration-300"
                      style={{ color: themeColor }}
                    >
                      CAMPUS
                    </span>
                  </div>

                  {/* Curated By Jyotish Kumar Signature */}
                  <span className="text-[9px] sm:text-[10px] text-slate-400 font-medium tracking-wide truncate -mt-0.5 select-none">
                    By <span className="text-slate-200 font-semibold">Jyotish Kumar</span>
                  </span>
                </div>

                {/* Live Campus Indicator Pill (Hidden on narrow screens to prevent crowding) */}
                <div
                  className="hidden md:inline-flex items-center gap-1 text-[9px] uppercase font-mono px-2 py-0.5 rounded-full border tracking-widest font-bold shadow-sm ml-1"
                  style={{
                    backgroundColor: `${themeColor}15`,
                    borderColor: `${themeColor}35`,
                    color: themeColor,
                  }}
                >
                  <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: themeColor }} />
                  <span>Live</span>
                </div>
              </div>
            )}
          </div>

          {/* ======================================================== */}
          {/* RIGHT: THEME CONTROL, ADMIN PORTAL, NOTIFICATION BELL    */}
          {/* ======================================================== */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0 z-10">
            {/* 1. Redesigned Luxury Theme-Change Button */}
            <button
              onClick={() => setIsColorModalOpen(true)}
              type="button"
              aria-label="Change Theme Atmosphere"
              className="group relative flex items-center gap-1.5 h-9 sm:h-10 px-2.5 sm:px-3 rounded-xl bg-white/[0.04] hover:bg-white/[0.09] border border-white/12 hover:border-white/25 text-slate-200 hover:text-white transition-all duration-200 active:scale-95 cursor-pointer shadow-sm shrink-0"
              style={{
                boxShadow: `0 2px 8px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.08)`,
              }}
              title={`Active Atmosphere: ${config.name}`}
            >
              <Palette
                className="w-3.5 h-3.5 sm:w-4 sm:h-4 transition-transform duration-300 group-hover:rotate-12"
                style={{ color: themeColor }}
              />

              {/* Theme Name (Visible on tablet & desktop) */}
              <span className="hidden sm:inline text-xs font-semibold tracking-tight text-slate-300 group-hover:text-white">
                {config.name.split(' ')[0]}
              </span>

              {/* Dynamic Theme Color Gem Indicator with Ambient Halo */}
              <div className="relative flex items-center justify-center ml-0.5">
                <span
                  className="w-2.5 h-2.5 rounded-full border border-black/80 shadow-[0_0_8px_currentColor] transition-colors duration-300"
                  style={{ backgroundColor: themeColor, color: themeColor }}
                />
              </div>
            </button>

            {/* 2. Admin Portal Shortcut Button */}
            {onOpenAdmin && (
              <button
                onClick={onOpenAdmin}
                type="button"
                className="flex items-center justify-center gap-1.5 h-9 sm:h-10 px-2.5 sm:px-3 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 hover:border-white/20 text-xs font-semibold text-slate-300 hover:text-white transition-all duration-200 active:scale-95 cursor-pointer shadow-sm shrink-0"
                title="Open Admin Control Panel"
              >
                <Shield className="w-3.5 h-3.5 text-slate-400 group-hover:text-white transition-colors" />
                <span className="hidden sm:inline">Admin</span>
              </button>
            )}

            {/* 3. Student Notification Bell Button */}
            <button
              onClick={(e) => {
                e.preventDefault();
                if (onOpenNotifications) {
                  onOpenNotifications();
                } else if (setActiveTab) {
                  setActiveTab('UPCOMING');
                }
              }}
              type="button"
              aria-label="Student Notifications"
              className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-white/[0.04] hover:bg-white/[0.09] border border-white/12 hover:border-white/25 flex items-center justify-center text-slate-200 hover:text-white transition-all duration-200 active:scale-95 cursor-pointer shadow-sm shrink-0"
              title={
                unreadNotificationCount && unreadNotificationCount > 0
                  ? `${unreadNotificationCount} New Notifications`
                  : 'Student Notifications'
              }
            >
              <Bell
                className="w-4 h-4 transition-transform duration-300 hover:rotate-12"
                style={{
                  color: unreadNotificationCount && unreadNotificationCount > 0 ? themeColor : undefined,
                }}
              />

              {unreadNotificationCount && unreadNotificationCount > 0 ? (
                <span
                  className="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 flex items-center justify-center rounded-full text-[9px] font-black text-white shadow-md animate-pulse pointer-events-none z-10"
                  style={{ backgroundColor: themeColor }}
                >
                  {unreadNotificationCount > 99 ? '99+' : unreadNotificationCount}
                </span>
              ) : null}
            </button>
          </div>
        </div>
      </header>

      {/* ======================================================== */}
      {/* LUXURY THEME & COLOR ATMOSPHERE MODAL                     */}
      {/* ======================================================== */}
      {isColorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div
            className="relative w-full max-w-md rounded-3xl p-5 sm:p-6 border border-white/[0.08] shadow-2xl overflow-hidden transition-all duration-300"
            style={{
              backgroundColor: '#0a060a',
              boxShadow: `0 16px 44px -8px rgba(0, 0, 0, 0.95), 0 0 24px -4px ${config.accentGlow}`,
            }}
          >
            {/* Modal Specular Top Line */}
            <div
              className="absolute top-0 inset-x-0 h-[1.5px] pointer-events-none opacity-60"
              style={{
                background: `linear-gradient(90deg, transparent 0%, ${themeColor}66 30%, #ffffff88 50%, ${themeColor}66 70%, transparent 100%)`,
              }}
            />

            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <div
                  className="w-8.5 h-8.5 rounded-xl flex items-center justify-center shadow-md border border-white/10"
                  style={{ backgroundColor: `${themeColor}20`, color: themeColor }}
                >
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-display">
                    Theme &amp; Color Atmosphere
                  </h3>
                  <p className="text-xs text-slate-400">
                    Choose your favorite campus study palette
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsColorModalOpen(false)}
                type="button"
                className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
                aria-label="Close Theme Modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Theme Presets Grid */}
            <div className="mt-4 space-y-4 max-h-[60vh] overflow-y-auto pr-1">
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2.5">
                  Select Theme Palette
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {availableThemes.map((tKey) => {
                    const tConfig = THEMES[tKey];
                    if (!tConfig) return null;
                    const isActive = theme === tKey;

                    return (
                      <button
                        key={tKey}
                        onClick={() => setTheme(tKey)}
                        type="button"
                        className={`flex items-center gap-3 p-3 rounded-2xl border text-left transition-all duration-200 cursor-pointer ${
                          isActive
                            ? 'bg-white/[0.08] ring-1 scale-[1.02]'
                            : 'bg-white/[0.02] hover:bg-white/[0.06] border-white/10 opacity-75 hover:opacity-100'
                        }`}
                        style={{
                          borderColor: isActive ? tConfig.primaryColor : 'rgba(255, 255, 255, 0.1)',
                          boxShadow: isActive ? `0 0 12px ${tConfig.accentGlow}` : 'none',
                        }}
                      >
                        {/* Dual-color preview gem */}
                        <div
                          className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 shadow-md"
                          style={{
                            background: `linear-gradient(135deg, ${tConfig.previewColors[0]}, ${tConfig.previewColors[2]})`,
                            border: `2px solid ${tConfig.primaryColor}`,
                          }}
                        >
                          {isActive && <Check className="w-3 h-3 text-white drop-shadow" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-bold text-white truncate">
                            {tConfig.name}
                          </p>
                          <p className="text-[10px] text-slate-400 truncate">
                            {tConfig.label.split('&')[1]?.trim() || tConfig.label}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Accent Color Swatches */}
              <div className="pt-3 border-t border-white/10">
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2.5">
                  Quick Accent Color
                </label>
                <div className="flex flex-wrap items-center gap-2.5">
                  {ACCENT_PRESETS.map((p) => {
                    const isSelected = accent === p.id;
                    return (
                      <button
                        key={p.id}
                        onClick={() => setAccent(p.id)}
                        type="button"
                        title={p.name}
                        className={`relative w-8 h-8 rounded-full transition-all duration-200 cursor-pointer flex items-center justify-center ${
                          isSelected
                            ? 'scale-110 ring-2 ring-white ring-offset-2 ring-offset-black shadow-lg'
                            : 'hover:scale-105 opacity-80 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: p.hex }}
                      >
                        {isSelected && (
                          <Check className="w-3.5 h-3.5 text-black drop-shadow font-bold" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="mt-5 pt-4 border-t border-white/10 flex justify-end">
              <button
                onClick={() => setIsColorModalOpen(false)}
                type="button"
                className="btn-primary-red px-5 py-2 rounded-xl text-xs font-bold cursor-pointer shadow-lg"
                style={{
                  backgroundColor: config.primaryColor,
                  boxShadow: `0 0 14px ${config.accentGlow}`,
                }}
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
});

Header.displayName = 'Header';
