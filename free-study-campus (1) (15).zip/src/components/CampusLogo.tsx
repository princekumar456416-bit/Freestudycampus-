import React, { useState, useEffect } from 'react';
import { DEFAULT_FALLBACK_LOGO } from '../utils/logoHelper';
import { useTheme } from '../context/ThemeContext';

interface CampusLogoProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  logoUrl?: string | null;
  className?: string;
  alt?: string;
  withGlow?: boolean;
  ambientGlow?: boolean;
}

/**
 * Universal Centralized CampusLogo Component:
 * Guarantees that the logo is NEVER blank, undefined, or broken.
 * Features clean dynamic theme-colored outline, soft ambient glow, zero distortion,
 * breathing glow pulse, and tactile hover/tap enhancement.
 */
export const CampusLogo: React.FC<CampusLogoProps> = ({
  logoUrl,
  className = '',
  alt = 'Free Study Campus Logo',
  withGlow = false,
  ambientGlow = false,
  ...rest
}) => {
  const { currentThemeColor, config } = useTheme();
  const themeColor = currentThemeColor || config?.primaryColor || '#ff2e4d';

  const getInitialSrc = (url?: string | null) => {
    if (url && typeof url === 'string') {
      const trimmed = url.trim();
      if (trimmed && trimmed !== 'null' && trimmed !== 'undefined') {
        return trimmed;
      }
    }
    return DEFAULT_FALLBACK_LOGO;
  };

  const [imgSrc, setImgSrc] = useState<string>(() => getInitialSrc(logoUrl));
  const [hasFailed, setHasFailed] = useState<boolean>(false);

  useEffect(() => {
    const nextSrc = getInitialSrc(logoUrl);
    setImgSrc(nextSrc);
    setHasFailed(false);
  }, [logoUrl]);

  const handleError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    if (!hasFailed) {
      setHasFailed(true);
      if (imgSrc !== DEFAULT_FALLBACK_LOGO) {
        setImgSrc(DEFAULT_FALLBACK_LOGO);
      } else {
        setImgSrc('/logo.svg');
      }
    } else if (imgSrc !== '/logo.svg') {
      setImgSrc('/logo.svg');
    }
    rest.onError?.(e);
  };

  const imageElement = (
    <img
      src={imgSrc}
      alt={alt}
      className={`object-contain aspect-square select-none transition-transform duration-300 ${className}`}
      onError={handleError}
      loading="eager"
      decoding="async"
      {...rest}
    />
  );

  if (withGlow || ambientGlow) {
    return (
      <div className="relative inline-flex items-center justify-center select-none group/logo">
        {/* Soft, gentle breathing theme-colored ambient glow (NO thick red ring, NO random colors) */}
        <div
          className="absolute -inset-1.5 rounded-full pointer-events-none transition-all duration-500 opacity-40 group-hover/logo:opacity-75 blur-md"
          style={{
            background: `radial-gradient(circle, ${themeColor}44 0%, transparent 70%)`,
            animation: 'heroLogoBreathing 6s ease-in-out infinite',
          }}
        />
        {/* Clean, thin single border matching the selected theme color */}
        <div
          className="relative z-10 rounded-full p-1 flex items-center justify-center transition-all duration-300 backdrop-blur-md"
          style={{
            border: `1px solid ${themeColor}66`,
            boxShadow: `0 4px 16px -2px rgba(0, 0, 0, 0.6), 0 0 12px -2px ${themeColor}33`,
            backgroundColor: 'rgba(12, 10, 15, 0.85)',
          }}
        >
          {imageElement}
        </div>
      </div>
    );
  }

  return imageElement;
};
