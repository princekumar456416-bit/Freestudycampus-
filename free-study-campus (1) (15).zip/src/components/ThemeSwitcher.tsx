import React from 'react';
import { useTheme, THEMES } from '../context/ThemeContext';
import { ThemeType } from '../types';

interface ThemeSwitcherProps {
  variant?: 'compact' | 'expanded';
  showLabel?: boolean;
}

export const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({
  variant = 'compact',
  showLabel = false,
}) => {
  const { theme, setTheme, config } = useTheme();

  const themeList: ThemeType[] = ['rose', 'cyber', 'emerald', 'violet', 'amber', 'obsidian', 'monochrome'];

  return (
    <div className="flex flex-col gap-1.5">
      {showLabel && (
        <div className="flex items-center justify-between text-xs font-medium text-slate-300 px-1">
          <span>Active Atmosphere</span>
          <span className="text-[11px] font-mono capitalize" style={{ color: config.primaryColor }}>
            {config.label}
          </span>
        </div>
      )}

      {/* The 4 Theme Buttons */}
      <div
        className={`flex items-center gap-2 p-1.5 rounded-2xl glass-panel ${
          variant === 'expanded' ? 'justify-between w-full' : ''
        }`}
        role="group"
        aria-label="Theme Color Switcher"
      >
        {themeList.map((tKey) => {
          const tConfig = THEMES[tKey];
          const isActive = theme === tKey;

          return (
            <button
              key={tKey}
              onClick={() => setTheme(tKey)}
              type="button"
              title={tConfig.label}
              aria-label={`Select ${tConfig.label} theme`}
              aria-pressed={isActive}
              className={`relative flex items-center justify-center rounded-xl transition-all duration-300 cursor-pointer ${
                variant === 'compact'
                  ? 'h-8 w-8 min-w-[32px]'
                  : 'h-11 flex-1 px-2.5 py-1.5 gap-2'
              } ${
                isActive
                  ? 'scale-105 ring-2 ring-offset-1 ring-offset-black/40'
                  : 'opacity-70 hover:opacity-100 hover:scale-100'
              }`}
              style={{
                backgroundColor: isActive ? 'rgba(255, 255, 255, 0.08)' : 'rgba(255, 255, 255, 0.02)',
                boxShadow: isActive ? `0 0 16px ${tConfig.accentGlow}` : 'none',
                borderColor: isActive ? tConfig.primaryColor : 'transparent',
              }}
            >
              {/* Dual-color glowing preview dot/pill */}
              <div
                className="w-4 h-4 rounded-full transition-transform duration-300 flex-shrink-0"
                style={{
                  background: `linear-gradient(135deg, ${tConfig.previewColors[0]}, ${tConfig.previewColors[1]})`,
                  boxShadow: isActive ? `0 0 10px ${tConfig.previewColors[0]}` : 'none',
                }}
              />

              {variant === 'expanded' && (
                <span
                  className={`text-xs font-medium tracking-tight truncate ${
                    isActive ? 'text-white font-semibold' : 'text-slate-400'
                  }`}
                >
                  {tConfig.name.split(' ')[1] || tConfig.name}
                </span>
              )}

              {/* Active Indicator Pip */}
              {isActive && (
                <span
                  className="absolute -top-1 -right-1 w-2 h-2 rounded-full border border-black/80"
                  style={{
                    backgroundColor: tConfig.primaryColor,
                    boxShadow: `0 0 6px ${tConfig.primaryColor}`,
                  }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
