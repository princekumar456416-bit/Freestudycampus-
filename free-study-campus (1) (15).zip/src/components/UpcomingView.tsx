import React, { useState, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';
import { UpcomingRecord } from '../../server/db';
import { api } from '../services/api';
import { Sparkles, Compass, Rocket, Calendar, ExternalLink } from 'lucide-react';

export const UpcomingView: React.FC = () => {
  const { config } = useTheme();
  const [upcomingBatches, setUpcomingBatches] = useState<UpcomingRecord[]>([]);

  useEffect(() => {
    api.getUpcoming().then((data) => {
      if (data && data.length > 0) {
        setUpcomingBatches(data);
      }
    });
  }, []);

  const roadmapItems = [
    {
      title: 'Integrated Mock Test Engine',
      desc: 'Full-length timed computer based tests with instant answer analysis and percentile breakdown.',
      eta: 'In Testing',
    },
    {
      title: 'Interactive Mindmap Explorer',
      desc: 'Zoomable high-resolution formula mindmaps with one-tap concept flashcards.',
      eta: 'Next Release',
    },
    {
      title: 'Peer Campus Study Rooms',
      desc: 'Collaborative silent study timers and live doubt clearing circles with verified scholars.',
      eta: 'Upcoming',
    },
  ];

  return (
    <div className="animate-page-enter w-full pb-24 flex flex-col gap-6 max-w-3xl mx-auto">
      {/* Premium Empty State */}
      <div
        className="rounded-3xl p-8 sm:p-14 text-center glass-panel border relative overflow-hidden flex flex-col items-center justify-center my-4"
        style={{
          borderColor: config.borderColor,
          boxShadow: `0 10px 40px -10px ${config.accentGlow}`,
        }}
      >
        {/* Soft floating background glow */}
        <div
          className="absolute w-72 h-72 rounded-full blur-[100px] pointer-events-none opacity-30 animate-pulse-subtle"
          style={{ backgroundColor: config.primaryColor }}
        />

        {/* Animated Central Emblem */}
        <div className="relative mb-6">
          <div
            className="w-20 h-20 rounded-3xl flex items-center justify-center border shadow-2xl transition-transform hover:scale-105"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.06)',
              borderColor: config.borderColor,
              boxShadow: `0 0 30px ${config.accentGlow}`,
            }}
          >
            <Rocket
              className="w-10 h-10 transition-transform duration-700 animate-bounce"
              style={{ color: config.primaryColor }}
            />
          </div>

          <div
            className="absolute -top-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center border text-xs"
            style={{
              backgroundColor: config.primaryColor,
              borderColor: '#030712',
              color: '#030712',
            }}
          >
            <Sparkles className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Required Headings */}
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display tracking-tight mb-2">
          Coming Soon
        </h1>
        <p className="text-sm sm:text-base font-medium text-slate-300 max-w-md mx-auto leading-relaxed">
          New learning resources are being added.
        </p>

        <p className="text-xs text-slate-400 mt-2 max-w-sm">
          Our curriculum team is digitizing new open lectures, formula compendiums, and solved question sets.
        </p>
      </div>

      {/* Dynamic Upcoming Batches Managed by Admin */}
      {upcomingBatches.length > 0 && (
        <div className="flex flex-col gap-3">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1 flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5" style={{ color: config.primaryColor }} />
            Scheduled Batches & Courses ({upcomingBatches.length})
          </h2>

          <div className="grid grid-cols-1 gap-3">
            {upcomingBatches.map((item) => (
              <div
                key={item.id}
                className="p-4 sm:p-5 rounded-3xl glass-panel border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all hover:border-white/20"
                style={{ borderColor: config.borderColor }}
              >
                <div className="flex items-center gap-3.5">
                  <img
                    src={item.thumbnail}
                    alt={item.batchName}
                    className="w-14 h-14 rounded-2xl object-cover border border-white/10 shrink-0"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider"
                        style={{
                          backgroundColor: config.badgeBg,
                          color: config.primaryColor,
                        }}
                      >
                        {item.platform}
                      </span>
                      <span className="text-[10px] font-semibold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-md border border-amber-400/20">
                        {item.status}
                      </span>
                    </div>

                    <h3 className="text-sm sm:text-base font-bold text-white mt-1">
                      {item.batchName}
                    </h3>
                    <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">
                      {item.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-end sm:self-center shrink-0">
                  <span className="text-xs font-mono text-slate-400">
                    {item.expectedDate}
                  </span>
                  {item.externalUrl && (
                    <a
                      href={item.externalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-xl border border-white/10 text-cyan-300 hover:text-white hover:bg-white/10 transition-colors"
                      title="Preview Resource"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Campus Expansion Roadmap Preview */}
      <div className="flex flex-col gap-3">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1 flex items-center gap-2">
          <Compass className="w-3.5 h-3.5" style={{ color: config.primaryColor }} />
          Campus Feature Roadmap
        </h2>

        <div className="grid grid-cols-1 gap-3">
          {roadmapItems.map((item, idx) => (
            <div
              key={idx}
              className="p-4 sm:p-5 rounded-2xl glass-panel border flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              style={{ borderColor: 'rgba(255, 255, 255, 0.08)' }}
            >
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm sm:text-base font-semibold text-white">
                    {item.title}
                  </h3>
                </div>
                <p className="text-xs text-slate-400 max-w-lg">
                  {item.desc}
                </p>
              </div>

              <span
                className="px-3 py-1 rounded-full text-[11px] font-mono font-medium tracking-wide border self-start sm:self-center"
                style={{
                  backgroundColor: config.badgeBg,
                  borderColor: config.borderColor,
                  color: config.primaryColor,
                }}
              >
                {item.eta}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
