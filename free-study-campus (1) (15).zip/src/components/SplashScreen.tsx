import React, { useEffect, useState, useMemo } from 'react';
import { CampusLogo } from './CampusLogo';
import { AnimatedLogoBorder } from './AnimatedLogoBorder';
import { HomeParticles } from './HomeParticles';
import { ChevronRight, Sparkles, ShieldCheck } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface SplashScreenProps {
  onComplete: () => void;
  logoUrl?: string;
}

/**
 * Cinematic Premium Splash Screen — Free Study Campus
 * Inspired by the dynamic volumetric lighting, anamorphic streaks, and elegant motion
 * of high-end cinematic universe intros (e.g., Bat Universe reference).
 * 
 * - 100% Dynamic Theme Color: derived directly from active settings / theme context
 * - Cinematic scale-in, specular light sweep, and traveling luminous outline
 * - Staggered letter-by-letter text elevation for "FREE STUDY CAMPUS"
 * - Sophisticated "BY JYOTISH KUMAR" and "LEARN MORE · GROW MORE" reveal
 * - Hardware-accelerated GPU transforms with zero lag on Android mobile & desktop
 */
export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete, logoUrl }) => {
  const { currentThemeColor, config } = useTheme();
  // Derived strictly from the user's active theme or settings — never hardcoded
  const themeColor = currentThemeColor || config?.primaryColor || '#ff2e4d';

  // Coordinated cinematic intro phases
  // 0. void: deep obsidian void with atmospheric anamorphic light streak
  // 1. emblem: logo smoothly scales in with subtle specular rim
  // 2. sweep: luminous border loop begins and light sweep glides diagonally
  // 3. title: "FREE STUDY CAMPUS" letters elevate into position
  // 4. author: "BY JYOTISH KUMAR" + tagline fade in
  // 5. ready: laser progress bar finishes and settles into final stable state
  const [phase, setPhase] = useState<'void' | 'emblem' | 'sweep' | 'title' | 'author' | 'ready'>('void');
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase('emblem'), 120);
    const t2 = setTimeout(() => setPhase('sweep'), 420);
    const t3 = setTimeout(() => setPhase('title'), 720);
    const t4 = setTimeout(() => setPhase('author'), 1150);
    const t5 = setTimeout(() => setPhase('ready'), 1750);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      clearTimeout(t5);
    };
  }, []);

  // Smooth cinematic progress bar
  useEffect(() => {
    const startTime = Date.now();
    const duration = 2300; // 2.3s cinematic pace

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);

      if (pct >= 100) {
        clearInterval(interval);
        // Short stable beat for visual completion, then elegant cinematic dissolve
        setTimeout(() => {
          setIsFadingOut(true);
          setTimeout(() => {
            onComplete();
          }, 380);
        }, 150);
      }
    }, 24);

    return () => clearInterval(interval);
  }, [onComplete]);

  const handleSkip = () => {
    setIsFadingOut(true);
    setTimeout(onComplete, 160);
  };

  const isEmblemVisible = ['emblem', 'sweep', 'title', 'author', 'ready'].includes(phase);
  const isSweepActive = ['sweep', 'title', 'author', 'ready'].includes(phase);
  const isTitleVisible = ['title', 'author', 'ready'].includes(phase);
  const isAuthorVisible = ['author', 'ready'].includes(phase);

  // Staggered letters for cinematic title reveal
  const freeStudyLetters = useMemo(() => 'FREE STUDY'.split(''), []);
  const campusLetters = useMemo(() => 'CAMPUS'.split(''), []);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-between py-6 sm:py-8 px-4 overflow-hidden bg-[#070509] select-none transition-all duration-500 ease-out ${
        isFadingOut
          ? 'opacity-0 pointer-events-none scale-102 blur-[1.5px]'
          : 'opacity-100 scale-100'
      }`}
      style={{
        transform: 'translateZ(0)',
        WebkitTransform: 'translateZ(0)',
        contain: 'layout style paint',
      }}
      aria-label="Free Study Campus Splash Screen"
    >
      {/* ======================================================== */}
      {/* 1. CINEMATIC ATMOSPHERE & ANAMORPHIC VOLUMETRIC LIGHTING */}
      {/* ======================================================== */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {/* Hardware-accelerated micro-stardust particles matching dynamic theme color */}
        <HomeParticles themeColor={themeColor} />

        {/* Central Anamorphic Optical Flare Streak (Cinematic studio aesthetic) */}
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[85vw] max-w-2xl h-[2px] pointer-events-none opacity-50 animate-anamorphic-flare"
          style={{
            background: `linear-gradient(90deg, transparent 0%, ${themeColor}33 20%, #ffffff 50%, ${themeColor}33 80%, transparent 100%)`,
            boxShadow: `0 0 16px ${themeColor}88, 0 0 32px ${themeColor}44`,
          }}
        />

        {/* Core Volumetric Radial Ambient Aura */}
        <div
          className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[320px] sm:w-[540px] h-[320px] sm:h-[540px] rounded-full pointer-events-none transition-all duration-1000 ${
            isSweepActive ? 'opacity-30 scale-105' : 'opacity-15 scale-90'
          }`}
          style={{
            background: `radial-gradient(circle, ${themeColor}55 0%, rgba(255, 255, 255, 0.08) 35%, transparent 70%)`,
            transform: 'translateZ(0)',
          }}
        />

        {/* High-tech Micro-Grid Overlay */}
        <div
          className="absolute inset-0 opacity-[0.03] pointer-events-none"
          style={{
            backgroundImage:
              'linear-gradient(rgba(255,255,255,0.18) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.18) 1px, transparent 1px)',
            backgroundSize: '36px 36px',
          }}
        />
      </div>

      {/* ======================================================== */}
      {/* TOP SECURITY KICKER BADGE                                */}
      {/* ======================================================== */}
      <div
        className={`relative z-10 transition-all duration-700 ease-out pt-2 ${
          isEmblemVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-3'
        }`}
      >
        <div
          className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full border backdrop-blur-md shadow-sm"
          style={{
            backgroundColor: 'rgba(255, 255, 255, 0.04)',
            borderColor: `${themeColor}33`,
            boxShadow: `0 2px 10px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.1)`,
          }}
        >
          <ShieldCheck className="w-3.5 h-3.5" style={{ color: themeColor }} />
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-300">
            OFFICIAL STUDY PORTAL
          </span>
          <span
            className="w-1.5 h-1.5 rounded-full ml-0.5 animate-pulse"
            style={{ backgroundColor: themeColor }}
          />
        </div>
      </div>

      {/* ======================================================== */}
      {/* CENTERPIECE: LOGO WITH SPECULAR SWEEP & CINEMATIC TEXT   */}
      {/* ======================================================== */}
      <div className="relative z-10 flex flex-col items-center px-4 max-w-md w-full text-center my-auto">
        {/* LOGO PEDESTAL WITH LUMINOUS OUTLINE & SPECULAR GLARE */}
        <div
          className={`relative mb-6 transition-all duration-800 ease-out ${
            isEmblemVisible ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-90 translate-y-4'
          }`}
        >
          {/* Breathing Ambient Halo behind Logo */}
          <div
            className={`absolute -inset-4 rounded-full pointer-events-none transition-opacity duration-1000 ${
              isSweepActive ? 'opacity-55 scale-105' : 'opacity-0 scale-90'
            }`}
            style={{
              background: `radial-gradient(circle, ${themeColor}66 0%, transparent 70%)`,
              animation: 'heroLogoBreathing 5s ease-in-out infinite',
            }}
          />

          {/* Precision Luminous Animated Outline Tracing Around Border */}
          <AnimatedLogoBorder shape="circle" accentColor={themeColor}>
            {/* Logo Inner Pedestal Frame */}
            <div
              className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full flex items-center justify-center p-3.5 bg-[#0a0509] backdrop-blur-2xl overflow-hidden shadow-2xl transition-transform duration-500"
              style={{
                boxShadow: isSweepActive
                  ? `0 16px 44px -6px rgba(0,0,0,0.95), 0 0 28px -4px ${themeColor}44, inset 0 0 16px ${themeColor}20`
                  : '0 8px 24px rgba(0,0,0,0.85)',
              }}
            >
              {/* Diagonal Specular Light Ray Sweep (Bat Universe cinematic shine) */}
              {isSweepActive && (
                <div
                  className="cinematic-sweep-beam absolute -inset-y-4 -inset-x-8 w-1/3 pointer-events-none z-20"
                  style={{
                    background:
                      'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.4) 50%, transparent 100%)',
                  }}
                />
              )}

              {/* Authentic Free Study Campus Logo */}
              <CampusLogo
                logoUrl={logoUrl}
                className="w-full h-full object-contain aspect-square select-none pointer-events-none relative z-10 drop-shadow-md"
                alt="Free Study Campus Logo"
              />
            </div>
          </AnimatedLogoBorder>
        </div>

        {/* CINEMATIC TITLE: LETTER-BY-LETTER SEQUENCED REVEAL */}
        <div className="flex flex-col items-center">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight font-display drop-shadow-[0_2px_16px_rgba(0,0,0,0.95)] flex items-center justify-center gap-2 overflow-hidden py-1">
            {/* "FREE STUDY" (Crisp Pure White Letters) */}
            <span className="flex items-center text-white">
              {freeStudyLetters.map((char, index) => (
                <span
                  key={`fs-${index}`}
                  className={`inline-block ${isTitleVisible ? 'letter-reveal-node' : 'opacity-0'}`}
                  style={{
                    animationDelay: `${index * 32}ms`,
                    whiteSpace: char === ' ' ? 'pre' : 'normal',
                  }}
                >
                  {char}
                </span>
              ))}
            </span>

            {/* "CAMPUS" (Dynamic Theme Color Letters with Specular Glow) */}
            <span className="flex items-center" style={{ color: themeColor }}>
              {campusLetters.map((char, index) => (
                <span
                  key={`cp-${index}`}
                  className={`inline-block font-black ${isTitleVisible ? 'letter-reveal-node' : 'opacity-0'}`}
                  style={{
                    animationDelay: `${(freeStudyLetters.length + index) * 32}ms`,
                    textShadow: `0 0 20px ${themeColor}88, 0 0 40px ${themeColor}44`,
                  }}
                >
                  {char}
                </span>
              ))}
            </span>
          </h1>

          {/* Tagline: "LEARN MORE · GROW MORE" */}
          <p
            className={`text-[10px] sm:text-[11px] font-bold uppercase tracking-[0.24em] text-slate-300 mt-2 flex items-center gap-2 transition-all duration-700 ease-out ${
              isAuthorVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
            }`}
          >
            <span>Learn More</span>
            <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: themeColor }} />
            <span>Grow More</span>
          </p>
        </div>

        {/* "BY JYOTISH KUMAR" LUXURY CREATOR BADGE */}
        <div
          className={`mt-4 transition-all duration-600 ease-out ${
            isAuthorVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
          }`}
        >
          <div
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full backdrop-blur-xl shadow-lg"
            style={{
              border: `1px solid ${themeColor}40`,
              backgroundColor: `${themeColor}15`,
              boxShadow: `0 4px 18px -4px rgba(0,0,0,0.6), inset 0 0 12px ${themeColor}12`,
            }}
          >
            <span
              className="w-1.5 h-1.5 rounded-full animate-ping"
              style={{ backgroundColor: themeColor }}
            />
            <span className="text-[10px] sm:text-[11px] font-semibold tracking-wider text-slate-200">
              BY <span className="text-white font-black tracking-widest">JYOTISH KUMAR</span>
            </span>
            <Sparkles className="w-3.5 h-3.5 ml-0.5 opacity-90" style={{ color: themeColor }} />
          </div>
        </div>

        {/* MINIMAL HIGH-TECH LASER PROGRESS GAUGE */}
        <div
          className={`w-48 sm:w-56 mt-7 flex flex-col items-center gap-2 transition-all duration-500 ${
            isAuthorVisible ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div className="w-full h-1 bg-white/[0.08] rounded-full overflow-hidden p-0.5 backdrop-blur-sm border border-white/[0.05]">
            <div
              className="h-full rounded-full transition-all duration-75 ease-out"
              style={{
                width: `${progress}%`,
                background: `linear-gradient(90deg, ${themeColor} 0%, #ffffff 85%, ${themeColor} 100%)`,
                boxShadow: `0 0 12px ${themeColor}aa`,
              }}
            />
          </div>

          <div className="w-full flex items-center justify-between text-[10px] font-mono tracking-widest text-slate-400 px-0.5">
            <span className="text-[9px] uppercase tracking-wider text-slate-400 font-sans">
              Initializing Gateway
            </span>
            <span style={{ color: themeColor }} className="font-bold">
              {progress}%
            </span>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* BOTTOM ACTION: SKIP / INSTANT ENTER                      */}
      {/* ======================================================== */}
      <div className="relative z-10 pb-2">
        <button
          onClick={handleSkip}
          type="button"
          className="text-[11px] text-slate-400 hover:text-white px-4 py-1.5 rounded-full border border-white/10 hover:border-white/25 bg-white/[0.04] hover:bg-white/[0.08] backdrop-blur-md flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer shadow-sm"
          title="Enter Campus Immediately"
        >
          <span className="font-medium tracking-wide">Enter Campus</span>
          <ChevronRight className="w-3.5 h-3.5" style={{ color: themeColor }} />
        </button>
      </div>
    </div>
  );
};
