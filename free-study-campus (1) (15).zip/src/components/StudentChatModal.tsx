import React from 'react';
import { StudentUser } from '../services/studentUserService';
import { StudentWhatsAppChat } from './StudentWhatsAppChat';

interface StudentChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentUser | null;
  initialSelectedTicketId?: string | null;
}

export const StudentChatModal: React.FC<StudentChatModalProps> = ({
  isOpen,
  onClose,
  student,
  initialSelectedTicketId,
}) => {
  if (!isOpen) return null;

  return (
    <StudentWhatsAppChat
      student={student}
      onClose={onClose}
      initialTicketId={initialSelectedTicketId}
    />
  );
};
