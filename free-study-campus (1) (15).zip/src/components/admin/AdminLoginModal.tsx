import React, { useState } from 'react';
import { api } from '../../services/api';
import { CampusLogo } from '../CampusLogo';
import { Shield, Lock, Eye, EyeOff, X, AlertTriangle } from 'lucide-react';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: () => void;
  noticeMessage?: string;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  noticeMessage,
}) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      setErrorMessage('Incorrect Password');
      return;
    }

    setErrorMessage('');

    const result = await api.login(password.trim());
    if (result.success) {
      setPassword('');
      setErrorMessage('');
      onLoginSuccess();
    } else {
      setErrorMessage(result.error || 'Incorrect Password');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
      <div
        className="w-full max-w-sm rounded-3xl p-6 sm:p-7 bg-[#0c080b]/95 border border-red-500/25 relative overflow-hidden shadow-[0_24px_64px_-12px_rgba(0,0,0,0.9),0_0_36px_-6px_rgba(220,38,38,0.3)] backdrop-blur-2xl animate-modal-enter"
      >
        {/* Top Specular Line */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-red-500 to-transparent opacity-85" />

        {/* Soft background ambient glow */}
        <div
          className="absolute -top-20 -right-20 w-44 h-44 rounded-full blur-3xl pointer-events-none opacity-30 bg-red-600"
        />

        {/* Close Button */}
        <button
          onClick={onClose}
          type="button"
          aria-label="Close modal"
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with Campus Logo Emblem */}
        <div className="flex flex-col items-center text-center mb-5">
          <div className="relative mb-3 group">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center border border-red-500/30 bg-[#070608] shadow-[0_0_20px_rgba(220,38,38,0.4)] p-2">
              <CampusLogo withGlow={true} className="w-full h-full object-contain" />
            </div>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[10px] font-black tracking-widest uppercase mb-1.5 border border-red-500/30 bg-red-950/30 text-red-300">
            <Shield className="w-3 h-3 text-red-400" />
            <span>CONTROL CENTER</span>
          </div>

          <h2 className="text-xl font-extrabold text-white font-display tracking-tight">
            Admin Access
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Enter administrator password to manage campus
          </p>
        </div>

        {/* Forced Session Invalidation / Notice Alert */}
        {noticeMessage && (
          <div className="mb-4 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2.5 text-amber-200 text-xs animate-in slide-in-from-top-1">
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
            <span className="font-medium leading-relaxed">{noticeMessage}</span>
          </div>
        )}

        {/* Error Alert */}
        {errorMessage && (
          <div className="mb-4 p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center gap-2.5 text-rose-300 text-xs animate-in slide-in-from-top-1">
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
            <span className="font-semibold">{errorMessage}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-red-400" />
                Admin Password
              </span>
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onFocus={() => setIsFocused(true)}
                onBlur={() => setIsFocused(false)}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errorMessage) setErrorMessage('');
                }}
                placeholder="Enter password"
                className={`w-full bg-black/60 border rounded-2xl px-4 py-3 pr-11 text-sm text-white placeholder-slate-500 focus:outline-none transition-all font-mono ${
                  isFocused
                    ? 'border-red-500 shadow-[0_0_16px_rgba(220,38,38,0.35)]'
                    : 'border-white/10 hover:border-white/20'
                }`}
                autoFocus
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition-colors cursor-pointer"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Button: "Unlock Admin Panel" */}
          <button
            type="submit"
            className="btn-primary-red w-full mt-1 py-3.5 px-6 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-lg cursor-pointer"
          >
            <span>Unlock Admin Panel</span>
          </button>
        </form>
      </div>
    </div>
  );
};
