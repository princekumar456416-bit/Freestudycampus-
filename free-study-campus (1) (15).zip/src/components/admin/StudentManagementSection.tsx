import React, { useState, useEffect, useMemo } from 'react';
import { useTheme } from '../../context/ThemeContext';
import {
  StudentUser,
  subscribeStudentUsers,
  createStudentUser,
  updateStudentUsername,
  updateStudentPassword,
  updateStudentStatus,
  deleteStudentUser,
  forceLogoutStudent,
  ensureInitialStudent1Exists,
  searchStudentsFromSupabase,
} from '../../services/studentUserService';
import { useToast } from './Toast';
import {
  User,
  UserPlus,
  KeyRound,
  ShieldCheck,
  ShieldAlert,
  Trash2,
  Eye,
  EyeOff,
  X,
  Loader2,
  CheckCircle2,
  LogOut,
  Smartphone,
  ChevronRight,
  Settings2,
  AtSign,
  Radio,
  Search,
} from 'lucide-react';

export const StudentManagementSection: React.FC = () => {
  const { config } = useTheme();
  const { showToast } = useToast();

  const [students, setStudents] = useState<StudentUser[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<StudentUser | null>(null);

  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'logged_out' | 'disabled'>('all');
  const [isSearchingSupabase, setIsSearchingSupabase] = useState(false);

  // Per-student inline action loading state
  const [actionLoadingKey, setActionLoadingKey] = useState<string | null>(null);

  // Add Student Modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newStudentUsername, setNewStudentUsername] = useState('');
  const [newStudentPassword, setNewStudentPassword] = useState('');
  const [showNewStudentPassword, setShowNewStudentPassword] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const [addError, setAddError] = useState('');

  // Selected Student Settings Form
  const [editUsername, setEditUsername] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [showEditPassword, setShowEditPassword] = useState(false);
  const [isSavingUsername, setIsSavingUsername] = useState(false);
  const [isSavingPassword, setIsSavingPassword] = useState(false);
  const [settingsError, setSettingsError] = useState('');

  // Subscribe to real-time student list from Supabase
  useEffect(() => {
    ensureInitialStudent1Exists();
    const unsubscribe = subscribeStudentUsers((liveList) => {
      setStudents(liveList);
      // Keep selected student synced if modal is open
      if (selectedStudent) {
        const found = liveList.find((s) => s.id === selectedStudent.id);
        if (found) setSelectedStudent(found);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [selectedStudent?.id]);

  const cleanQuery = searchQuery.trim().toLowerCase().replace(/^@/, '');

  // Background Supabase query on search input to ensure all records in DB are caught
  useEffect(() => {
    if (!cleanQuery) return;

    let isMounted = true;
    const timer = setTimeout(async () => {
      setIsSearchingSupabase(true);
      try {
        await searchStudentsFromSupabase(cleanQuery);
      } finally {
        if (isMounted) setIsSearchingSupabase(false);
      }
    }, 250);

    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [cleanQuery]);

  // Filter students based on search query (exact or partial username/name, case-insensitive) and status filter
  const filteredStudents = useMemo(() => {
    const list = Array.isArray(students) ? students : [];
    return list.filter((student) => {
      const matchesSearch =
        !cleanQuery ||
        student.username.toLowerCase().includes(cleanQuery) ||
        (student.name && student.name.toLowerCase().includes(cleanQuery));

      if (!matchesSearch) return false;

      if (statusFilter === 'active') {
        return Boolean(student.activeSessionId) && student.status === 'active';
      }
      if (statusFilter === 'logged_out') {
        return !student.activeSessionId && student.status === 'active';
      }
      if (statusFilter === 'disabled') {
        return student.status === 'disabled';
      }
      return true;
    });
  }, [students, cleanQuery, statusFilter]);

  const activeOnlineCount = useMemo(
    () => (Array.isArray(students) ? students.filter((s) => Boolean(s.activeSessionId) && s.status === 'active').length : 0),
    [students]
  );
  const loggedOutCount = useMemo(
    () => (Array.isArray(students) ? students.filter((s) => !s.activeSessionId && s.status === 'active').length : 0),
    [students]
  );
  const disabledCount = useMemo(
    () => (Array.isArray(students) ? students.filter((s) => s.status === 'disabled').length : 0),
    [students]
  );

  // Handle open student settings
  const handleOpenStudentSettings = (student: StudentUser) => {
    setSelectedStudent(student);
    setEditUsername(student.username);
    setEditPassword('');
    setShowEditPassword(false);
    setSettingsError('');
  };

  // Handle Save Username
  const handleSaveUsername = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) return;
    const clean = editUsername.trim().toLowerCase();
    if (!clean || clean.length < 3) {
      setSettingsError('Username must be at least 3 characters');
      return;
    }

    setIsSavingUsername(true);
    setSettingsError('');

    try {
      await updateStudentUsername(selectedStudent.id, clean);
      showToast(`Username updated to "${clean}" for ${selectedStudent.name}!`, 'success');
      setSelectedStudent((prev) => (prev ? { ...prev, username: clean } : null));
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to update username';
      setSettingsError(msg);
      showToast(msg, 'error');
    } finally {
      setIsSavingUsername(false);
    }
  };

  // Handle Save Password
  const handleSavePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) return;
    const clean = editPassword.trim();
    if (!clean || clean.length < 4) {
      setSettingsError('Password must be at least 4 characters');
      return;
    }

    setIsSavingPassword(true);
    setSettingsError('');

    try {
      await updateStudentPassword(selectedStudent.id, clean);
      showToast(
        `New password saved! ${selectedStudent.name} was automatically logged out and must login with new password.`,
        'success'
      );
      setEditPassword('');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to update password';
      setSettingsError(msg);
      showToast(msg, 'error');
    } finally {
      setIsSavingPassword(false);
    }
  };

  // Handle Toggle Status (Active <-> Disabled)
  const handleToggleStudentStatus = async (student: StudentUser, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const nextStatus = student.status === 'active' ? 'disabled' : 'active';
    const key = `${student.id}_status`;
    setActionLoadingKey(key);

    try {
      await updateStudentStatus(student.id, nextStatus);
      if (nextStatus === 'disabled') {
        showToast(
          `${student.name} is now DISABLED. Active session was terminated and student status is Logged Out.`,
          'info'
        );
      } else {
        showToast(`${student.name} is now ENABLED. Student can now log in.`, 'success');
      }

      if (selectedStudent && selectedStudent.id === student.id) {
        setSelectedStudent((prev) => (prev ? { ...prev, status: nextStatus } : null));
      }
    } catch {
      showToast('Failed to update student status', 'error');
    } finally {
      setActionLoadingKey(null);
    }
  };

  // Handle Force Logout
  const handleForceLogoutStudent = async (student: StudentUser, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!student.activeSessionId) return;

    const key = `${student.id}_logout`;
    setActionLoadingKey(key);

    try {
      await forceLogoutStudent(student.id);
      showToast(
        `Force logged out ${student.name}! Session Status is now LOGGED OUT.`,
        'success'
      );

      if (selectedStudent && selectedStudent.id === student.id) {
        setSelectedStudent((prev) =>
          prev ? { ...prev, activeSessionId: null, activeDeviceInfo: null } : null
        );
      }
    } catch {
      showToast('Failed to force logout student', 'error');
    } finally {
      setActionLoadingKey(null);
    }
  };

  // Handle Delete Student
  const handleDeleteStudent = async () => {
    if (!selectedStudent) return;
    const confirm = window.confirm(
      `Are you sure you want to permanently delete "${selectedStudent.name}" (@${selectedStudent.username})?\nAny active phone session will be logged out immediately and credentials will stop working.`
    );
    if (!confirm) return;

    try {
      await deleteStudentUser(selectedStudent.id);
      showToast(`Student "${selectedStudent.name}" deleted permanently`, 'success');
      setSelectedStudent(null);
    } catch {
      showToast('Failed to delete student', 'error');
    }
  };

  // Handle Add Student Submit
  const handleAddStudentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUser = newStudentUsername.trim().toLowerCase();
    const cleanPass = newStudentPassword.trim();

    if (!cleanUser || cleanUser.length < 3) {
      setAddError('Username must be at least 3 characters');
      return;
    }
    if (!cleanPass || cleanPass.length < 4) {
      setAddError('Password must be at least 4 characters');
      return;
    }

    setIsAdding(true);
    setAddError('');

    try {
      const nextNum = (Array.isArray(students) ? students.length : 0) + 1;
      const created = await createStudentUser(cleanUser, cleanPass, `Student ${nextNum}`);
      showToast(`Created "${created.name}" (@${created.username}) successfully!`, 'success');
      setIsAddModalOpen(false);
      setNewStudentUsername('');
      setNewStudentPassword('');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to add student';
      setAddError(msg);
      showToast(msg, 'error');
    } finally {
      setIsAdding(false);
    }
  };

  const isDarkText = ['cyber', 'monochrome', 'amber'].includes(config.id);
  const btnTextColor = isDarkText ? '#09090b' : '#ffffff';

  return (
    <div className="flex flex-col gap-6 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">👨🎓</span>
            <h3 className="text-lg sm:text-xl font-bold text-white font-display tracking-tight">
              Student Management
            </h3>
            <span
              className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border"
              style={{
                backgroundColor: config.badgeBg,
                color: config.primaryColor,
                borderColor: config.borderColor,
              }}
            >
              Admin Portal
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time Session Status (Active / Logged Out), Enable/Disable accounts, and Force Logout control.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setNewStudentUsername('');
            setNewStudentPassword('');
            setShowNewStudentPassword(false);
            setAddError('');
            setIsAddModalOpen(true);
          }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all active:scale-95 cursor-pointer shadow-lg hover:brightness-110 self-start sm:self-auto shrink-0"
          style={{
            backgroundColor: config.primaryColor,
            color: btnTextColor,
            boxShadow: `0 0 15px ${config.accentGlow}`,
          }}
        >
          <UserPlus className="w-4 h-4" />
          <span>+ Add Student</span>
        </button>
      </div>

      {/* ======================================================== */}
      {/* 1. STUDENT SEARCH BAR & STATUS FILTER CONTROLS           */}
      {/* ======================================================== */}
      <div className="flex flex-col gap-3">
        {/* Search Input Box */}
        <div className="relative flex items-center">
          <div className="absolute left-4 pointer-events-none text-slate-400">
            {isSearchingSupabase ? (
              <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
            ) : (
              <Search className="w-4 h-4" style={{ color: config.primaryColor }} />
            )}
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search students by exact or partial username (e.g. @priyanshu, student1)..."
            className="w-full pl-11 pr-10 py-3.5 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-white/20 focus:border-cyan-500/60 text-white placeholder-slate-400 text-xs sm:text-sm transition-all focus:outline-none focus:ring-1 focus:ring-cyan-500/30 shadow-[0_4px_16px_rgba(0,0,0,0.4)]"
            style={{
              borderColor: searchQuery ? `${config.primaryColor}70` : undefined,
            }}
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 p-1 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter Chips & Counter Row */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 pt-0.5">
          {/* Quick Status Filter Tabs */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
                statusFilter === 'all'
                  ? 'bg-white/15 text-white border-white/30 shadow-sm'
                  : 'bg-white/[0.02] text-slate-400 border-white/5 hover:text-white hover:bg-white/5'
              }`}
            >
              All ({Array.isArray(students) ? students.length : 0})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('active')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer border flex items-center gap-1.5 ${
                statusFilter === 'active'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                  : 'bg-white/[0.02] text-slate-400 border-white/5 hover:text-emerald-300 hover:bg-emerald-500/5'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Active ({activeOnlineCount})</span>
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('logged_out')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
                statusFilter === 'logged_out'
                  ? 'bg-zinc-700/50 text-zinc-200 border-zinc-600 shadow-sm'
                  : 'bg-white/[0.02] text-slate-400 border-white/5 hover:text-white hover:bg-white/5'
              }`}
            >
              Logged Out ({loggedOutCount})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('disabled')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
                statusFilter === 'disabled'
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 shadow-sm'
                  : 'bg-white/[0.02] text-slate-400 border-white/5 hover:text-rose-300 hover:bg-rose-500/5'
              }`}
            >
              Disabled ({disabledCount})
            </button>
          </div>

          {/* Results Counter / Match Status */}
          <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1.5">
            {cleanQuery ? (
              <span className="text-cyan-300">
                Found <span className="font-bold text-white">{filteredStudents.length}</span> of {students.length} matching "{searchQuery}"
              </span>
            ) : (
              <span>Showing {filteredStudents.length} registered students</span>
            )}
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 2. STUDENT CARDS GRID & EMPTY RESULTS STATE              */}
      {/* ======================================================== */}
      {filteredStudents.length === 0 ? (
        <div className="p-8 sm:p-12 rounded-3xl glass-panel border border-white/10 flex flex-col items-center justify-center text-center gap-3 animate-in fade-in">
          <div className="w-14 h-14 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-center shadow-lg">
            <Search className="w-6 h-6 text-slate-400" />
          </div>
          <div>
            <h4 className="text-base font-bold text-white font-display">
              No students found matching "{searchQuery}"
            </h4>
            <p className="text-xs text-slate-400 max-w-sm mt-1">
              Check for typing errors, or try searching with a partial username or name.
            </p>
          </div>
          <div className="flex items-center gap-2 mt-2">
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setStatusFilter('all');
              }}
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-bold text-white transition-all cursor-pointer"
            >
              Clear Search
            </button>
            <button
              type="button"
              onClick={() => {
                setNewStudentUsername(cleanQuery);
                setNewStudentPassword('');
                setShowNewStudentPassword(false);
                setAddError('');
                setIsAddModalOpen(true);
              }}
              className="px-4 py-2 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-md"
              style={{
                backgroundColor: config.primaryColor,
                color: btnTextColor,
              }}
            >
              + Create @{cleanQuery}
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredStudents.map((student) => {
            const isActive = student.status === 'active';
            const isOnline = Boolean(student.activeSessionId);
            const isStatusLoading = actionLoadingKey === `${student.id}_status`;
            const isLogoutLoading = actionLoadingKey === `${student.id}_logout`;

            return (
              <div
                key={student.id}
                className={`p-5 rounded-3xl glass-panel border transition-all duration-200 flex flex-col justify-between gap-4 relative overflow-hidden shadow-lg ${
                  isActive
                    ? isOnline
                      ? 'border-emerald-500/30 hover:border-emerald-500/50 shadow-emerald-950/20'
                      : 'border-white/10 hover:border-cyan-500/40'
                    : 'border-rose-500/20 bg-rose-500/[0.02]'
                }`}
              >
                {/* Top Row: Avatar & Dual Badges */}
                <div className="flex items-start justify-between gap-3">
                  <div
                    onClick={() => handleOpenStudentSettings(student)}
                    className="flex items-center gap-3 cursor-pointer group flex-1 min-w-0"
                  >
                    <div
                      className={`w-11 h-11 rounded-2xl flex items-center justify-center font-display font-black text-sm uppercase shrink-0 border overflow-hidden ${
                        isOnline
                          ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.2)]'
                          : 'bg-zinc-800/80 border-zinc-700/80 text-zinc-400'
                      }`}
                    >
                      {student.avatarUrl ? (
                        <img
                          src={student.avatarUrl}
                          alt={student.name}
                          className="w-full h-full object-cover rounded-2xl"
                        />
                      ) : (
                        <User className="w-5 h-5" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <h4 className="text-base font-bold text-white font-display group-hover:text-cyan-300 transition-colors truncate">
                        {student.name || 'Student'}
                      </h4>
                      <span className="text-xs font-mono text-cyan-400 block truncate">
                        @{student.username}
                      </span>
                    </div>
                  </div>

                  {/* Session Status & Account Status Pill Stack */}
                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    {/* Session Status: Active / Logged Out */}
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        isOnline
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-[0_0_10px_rgba(16,185,129,0.25)]'
                          : 'bg-zinc-800/90 text-zinc-400 border border-zinc-700/70'
                      }`}
                      title={isOnline ? 'Session is currently Active' : 'Student is currently Logged Out'}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-zinc-500'
                        }`}
                      />
                      <span>{isOnline ? 'Active' : 'Logged Out'}</span>
                    </span>

                    {/* Account Status Pill */}
                    <span
                      className={`text-[9px] font-semibold px-2 py-0.5 rounded-md ${
                        isActive
                          ? 'text-cyan-400 bg-cyan-500/10 border border-cyan-500/20'
                          : 'text-rose-400 bg-rose-500/10 border border-rose-500/20'
                      }`}
                    >
                      {isActive ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                </div>

                {/* Middle Row: Session Status & Device Details */}
                <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex flex-col gap-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 font-medium">Session Status:</span>
                    <span
                      className={`font-bold flex items-center gap-1.5 ${
                        isOnline ? 'text-emerald-400' : 'text-slate-400'
                      }`}
                    >
                      <span
                        className={`w-2 h-2 rounded-full ${
                          isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-zinc-500'
                        }`}
                      />
                      <span>{isOnline ? 'Active' : 'Logged Out'}</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-white/5 pt-1.5">
                    <div className="flex items-center gap-1.5">
                      <Smartphone className="w-3 h-3 text-slate-500 shrink-0" />
                      <span>Device:</span>
                    </div>
                    <span className="truncate max-w-[170px] text-slate-300 font-mono">
                      {isOnline ? student.activeDeviceInfo || 'Active Phone' : 'None (Logged Out)'}
                    </span>
                  </div>
                </div>

                {/* Action Buttons Row: Enable/Disable + Force Logout + Settings */}
                <div className="pt-2 border-t border-white/5 flex items-center gap-2">
                  {/* 1. Enable / Disable Button */}
                  <button
                    type="button"
                    disabled={isStatusLoading}
                    onClick={(e) => handleToggleStudentStatus(student, e)}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl text-[11px] font-bold transition-all active:scale-95 cursor-pointer disabled:opacity-50 ${
                      isActive
                        ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30'
                        : 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30'
                    }`}
                    title={isActive ? 'Disable student access' : 'Enable student access'}
                  >
                    {isStatusLoading ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : isActive ? (
                      <ShieldAlert className="w-3.5 h-3.5" />
                    ) : (
                      <ShieldCheck className="w-3.5 h-3.5" />
                    )}
                    <span>{isActive ? 'Disable' : 'Enable'}</span>
                  </button>

                  {/* 2. Force Logout Button */}
                  <button
                    type="button"
                    disabled={!isOnline || isLogoutLoading}
                    onClick={(e) => handleForceLogoutStudent(student, e)}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl text-[11px] font-bold transition-all active:scale-95 cursor-pointer ${
                      isOnline
                        ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30'
                        : 'bg-white/[0.03] text-slate-600 border border-white/5 cursor-not-allowed'
                    }`}
                    title={isOnline ? 'Force logout from current phone' : 'Student is already Logged Out'}
                  >
                    {isLogoutLoading ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : (
                      <LogOut className="w-3.5 h-3.5" />
                    )}
                    <span>{isOnline ? 'Force Logout' : 'Logged Out'}</span>
                  </button>

                  {/* 3. Settings Button */}
                  <button
                    type="button"
                    onClick={() => handleOpenStudentSettings(student)}
                    className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-all cursor-pointer shrink-0"
                    title="Configure Username & Password"
                  >
                    <Settings2 className="w-3.5 h-3.5 text-cyan-400" />
                  </button>
                </div>
              </div>
            );
          })}

          {/* Add Student Card Button */}
          <button
            type="button"
            onClick={() => {
              setNewStudentUsername('');
              setNewStudentPassword('');
              setShowNewStudentPassword(false);
              setAddError('');
              setIsAddModalOpen(true);
            }}
            className="p-6 rounded-3xl border-2 border-dashed border-white/10 hover:border-cyan-500/50 bg-white/[0.02] hover:bg-cyan-500/[0.04] transition-all flex flex-col items-center justify-center gap-3 cursor-pointer group min-h-[190px]"
          >
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
              <UserPlus className="w-6 h-6" />
            </div>
            <div className="text-center">
              <span className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors block">
                + Add Student
              </span>
              <span className="text-[11px] text-slate-400 mt-0.5 block">
                Create another student account
              </span>
            </div>
          </button>
        </div>
      )}

      {/* ======================================================== */}
      {/* 2. STUDENT SETTINGS MODAL (Tap Student → Settings)       */}
      {/* ======================================================== */}
      {selectedStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
          <div
            className="relative w-full max-w-lg rounded-3xl p-6 sm:p-7 border shadow-2xl overflow-hidden flex flex-col gap-5 max-h-[90vh] overflow-y-auto"
            style={{
              backgroundColor: '#0c101a',
              borderColor: config.borderColor,
              boxShadow: `0 0 35px -5px ${config.accentGlow}`,
            }}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div
                  className="w-11 h-11 rounded-2xl flex items-center justify-center text-xl shadow-md border overflow-hidden"
                  style={{
                    backgroundColor: 'rgba(6, 182, 212, 0.15)',
                    borderColor: 'rgba(6, 182, 212, 0.3)',
                  }}
                >
                  {selectedStudent.avatarUrl ? (
                    <img
                      src={selectedStudent.avatarUrl}
                      alt={selectedStudent.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span>👨🎓</span>
                  )}
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white font-display">
                    {selectedStudent.name} Settings
                  </h3>
                  <p className="text-xs text-slate-400">
                    Manage Username, Password, Session, and Account Status
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedStudent(null)}
                className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Error Banner */}
            {settingsError && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300">
                {settingsError}
              </div>
            )}

            {/* Section 1: Username (Create / Change) */}
            <form onSubmit={handleSaveUsername} className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 flex flex-col gap-3">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <AtSign className="w-3.5 h-3.5 text-red-400" />
                <span>Username (Create / Change)</span>
              </label>

              <div className="flex gap-2">
                <input
                  type="text"
                  required
                  value={editUsername}
                  onChange={(e) => setEditUsername(e.target.value.toLowerCase().replace(/\s+/g, ''))}
                  placeholder="e.g. student01"
                  className="flex-1 px-3.5 py-2.5 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] font-mono transition-all"
                />
                <button
                  type="submit"
                  disabled={isSavingUsername || editUsername.trim() === selectedStudent.username}
                  className="btn-primary-red px-4 py-2.5 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-md disabled:opacity-40"
                >
                  {isSavingUsername ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Save'}
                </button>
              </div>
              <span className="text-[10px] text-slate-400">
                Must be unique. Changing username updates login credentials instantly.
              </span>
            </form>

            {/* Section 2: Password (Create / Change) */}
            <form onSubmit={handleSavePassword} className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 flex flex-col gap-3">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <KeyRound className="w-3.5 h-3.5 text-red-400" />
                <span>Password (Create / Change)</span>
              </label>

              <div className="flex gap-2 relative">
                <div className="relative flex-1">
                  <input
                    type={showEditPassword ? 'text' : 'password'}
                    value={editPassword}
                    onChange={(e) => setEditPassword(e.target.value)}
                    placeholder="Enter new password (min 4 chars)"
                    className="w-full pl-3.5 pr-10 py-2.5 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] transition-all font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowEditPassword(!showEditPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                  >
                    {showEditPassword ? <EyeOff className="w-3.5 h-3.5 text-red-400" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={isSavingPassword || !editPassword.trim()}
                  className="btn-primary-red px-4 py-2.5 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer shadow-md disabled:opacity-40"
                >
                  {isSavingPassword ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Update Password'}
                </button>
              </div>
              <span className="text-[10px] text-slate-400">
                Changing password immediately invalidates current phone session and forces re-login.
              </span>
            </form>

            {/* Section 3: Status & 1-Device Control */}
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 flex flex-col gap-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 block">
                Session &amp; Access Controls
              </span>

              {/* Session Status Display Box */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/5">
                <div>
                  <span className="text-xs font-bold text-white block flex items-center gap-1.5">
                    <Radio className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Session Status</span>
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {selectedStudent.activeSessionId
                      ? `Active on ${selectedStudent.activeDeviceInfo || 'Device'}`
                      : 'Logged Out (No active phone/device session)'}
                  </span>
                </div>

                <span
                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                    selectedStudent.activeSessionId
                      ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                      : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      selectedStudent.activeSessionId ? 'bg-emerald-400 animate-pulse' : 'bg-zinc-500'
                    }`}
                  />
                  <span>{selectedStudent.activeSessionId ? 'Active' : 'Logged Out'}</span>
                </span>
              </div>

              {/* Force Logout Option */}
              <div className="flex items-center justify-between border-t border-white/5 pt-3">
                <div>
                  <span className="text-xs font-bold text-white block">Force Session Logout</span>
                  <span className="text-[11px] text-slate-400">
                    {selectedStudent.activeSessionId
                      ? 'Disconnect student from current phone immediately'
                      : 'Student is currently Logged Out'}
                  </span>
                </div>

                <button
                  type="button"
                  disabled={
                    !selectedStudent.activeSessionId ||
                    actionLoadingKey === `${selectedStudent.id}_logout`
                  }
                  onClick={() => handleForceLogoutStudent(selectedStudent)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-rose-500/15 text-rose-300 border border-rose-500/30 hover:bg-rose-500/25 transition-all cursor-pointer disabled:opacity-40 disabled:pointer-events-none"
                >
                  {actionLoadingKey === `${selectedStudent.id}_logout` ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <LogOut className="w-3.5 h-3.5" />
                  )}
                  <span>Force Logout</span>
                </button>
              </div>

              {/* Account Status Toggle (Enable / Disable) */}
              <div className="flex items-center justify-between border-t border-white/5 pt-3">
                <div>
                  <span className="text-xs font-bold text-white block">Account Access Status</span>
                  <span className="text-[11px] text-slate-400">
                    Currently{' '}
                    <strong
                      className={
                        selectedStudent.status === 'active' ? 'text-emerald-400' : 'text-rose-400'
                      }
                    >
                      {selectedStudent.status.toUpperCase()}
                    </strong>
                  </span>
                </div>

                <button
                  type="button"
                  disabled={actionLoadingKey === `${selectedStudent.id}_status`}
                  onClick={() => handleToggleStudentStatus(selectedStudent)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer disabled:opacity-50 ${
                    selectedStudent.status === 'active'
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 hover:bg-amber-500/25'
                      : 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/25'
                  }`}
                >
                  {actionLoadingKey === `${selectedStudent.id}_status` ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : selectedStudent.status === 'active' ? (
                    <>
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>Disable Account</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Enable Account</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Section 4: Delete Student Option */}
            <div className="pt-2 border-t border-white/10 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-rose-400 block">Delete Student</span>
                <span className="text-[10px] text-slate-400">Permanently removes this account</span>
              </div>

              <button
                type="button"
                onClick={handleDeleteStudent}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 transition-all cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 3. ADD STUDENT MODAL                                     */}
      {/* ======================================================== */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-in fade-in duration-150">
          <div
            className="relative w-full max-w-md rounded-3xl p-6 bg-[#0c080b]/95 border border-red-500/25 shadow-[0_24px_64px_-12px_rgba(0,0,0,0.9),0_0_36px_-6px_rgba(220,38,38,0.3)] overflow-hidden flex flex-col gap-4 backdrop-blur-2xl"
          >
            {/* Top Specular Line */}
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-red-500 to-transparent opacity-85" />

            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center shadow-md border border-red-500/30 bg-red-950/30 text-red-400"
                >
                  <UserPlus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-display">
                    Add New Student Account
                  </h3>
                  <p className="text-xs text-slate-400">
                    Set unique Username and Password
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {addError && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300">
                {addError}
              </div>
            )}

            <form onSubmit={handleAddStudentSubmit} className="flex flex-col gap-3.5">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Username *
                </label>
                <input
                  type="text"
                  required
                  value={newStudentUsername}
                  onChange={(e) =>
                    setNewStudentUsername(e.target.value.toLowerCase().replace(/\s+/g, ''))
                  }
                  placeholder="e.g. student02"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] font-mono transition-all"
                />
                <span className="text-[10px] text-slate-400">
                  Unique identifier used by student to log in.
                </span>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Password *
                </label>
                <div className="relative">
                  <input
                    type={showNewStudentPassword ? 'text' : 'password'}
                    required
                    value={newStudentPassword}
                    onChange={(e) => setNewStudentPassword(e.target.value)}
                    placeholder="Create a strong password (min 4 chars)"
                    className="w-full pl-3.5 pr-10 py-2.5 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] transition-all font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewStudentPassword(!showNewStudentPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                  >
                    {showNewStudentPassword ? (
                      <EyeOff className="w-3.5 h-3.5 text-red-400" />
                    ) : (
                      <Eye className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
                <span className="text-[10px] text-slate-400">
                  Password will be hashed with SHA-256 before storage.
                </span>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isAdding}
                  className="btn-primary-red flex items-center gap-2 px-5 py-2 rounded-xl font-bold text-xs transition-all active:scale-95 cursor-pointer shadow-md disabled:opacity-50"
                >
                  {isAdding ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  )}
                  <span>Create Account</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
