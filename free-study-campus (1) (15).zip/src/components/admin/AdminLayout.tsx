import React, { useState, useEffect, useCallback } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { api, safeDataCache, subscribePlatforms, subscribeSettings } from '../../services/api';
import { PlatformRecord, AnnouncementRecord, SettingsRecord } from '../../../server/db';
import { getWebsiteLogo } from '../../utils/logoHelper';
import { AdminHeader } from './AdminHeader';
import { AdminDashboard } from './AdminDashboard';
import { AdminPlatforms } from './AdminPlatforms';
import { AdminAnnouncements } from './AdminAnnouncements';
import { AdminSettings } from './AdminSettings';
import { AdminBatchDemos } from './AdminBatchDemos';
import { StudentManagementSection } from './StudentManagementSection';
import { PaymentSettingsSection } from './PaymentSettingsSection';
import { AdminChatInbox } from './AdminChatInbox';
import { AdminNotificationCenter } from './AdminNotificationCenter';
import { subscribeAdminNotifications, AppNotification } from '../../services/notificationService';
import { ToastProvider, useToast } from './Toast';
import {
  Layers,
  LayoutDashboard,
  Bell,
  Settings,
  Loader2,
  RefreshCw,
  Users,
  QrCode,
  MessageSquare,
  Video,
} from 'lucide-react';

export type AdminTab = 'platforms' | 'dashboard' | 'demos' | 'students' | 'support' | 'announcements' | 'payment' | 'settings';

interface AdminLayoutProps {
  onLogout: () => void;
  onExitAdmin: () => void;
  onDataChanged?: () => void;
}

const AdminContent: React.FC<AdminLayoutProps> = ({ onLogout, onExitAdmin, onDataChanged }) => {
  const { config } = useTheme();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<AdminTab>('platforms');
  const [selectedSupportTicketId, setSelectedSupportTicketId] = useState<string | null>(null);

  // Admin Notification Drawer state
  const [isAdminNotifOpen, setIsAdminNotifOpen] = useState(false);
  const [adminNotifs, setAdminNotifs] = useState<AppNotification[]>([]);

  // Data states
  const [isLoading, setIsLoading] = useState(true);
  const [platforms, setPlatforms] = useState<PlatformRecord[]>(() => safeDataCache.getPlatforms());
  const [announcements, setAnnouncements] = useState<AnnouncementRecord[]>([]);
  const [settings, setSettings] = useState<SettingsRecord>(() => {
    const cached = safeDataCache.getSettings();
    return {
      websiteName: cached?.websiteName || 'FREE STUDY CAMPUS',
      tagline: cached?.tagline || 'Learn More. Grow More.',
      logo: cached?.logo || '/logo.png',
      defaultTheme: cached?.defaultTheme || 'cyan',
      maintenanceMode: cached?.maintenanceMode ?? false,
      announcementBanner: cached?.announcementBanner || 'Free and authorized study resources for competitive exam aspirants.',
      contactLink: cached?.contactLink || 'https://t.me/freestudycampus',
      updatedAt: cached?.updatedAt,
    };
  });

  // Real-time synchronization for batches/platforms, settings & admin notifications
  useEffect(() => {
    const unsubscribeNotifs = subscribeAdminNotifications((list) => {
      setAdminNotifs(list);
    });
    const unsubscribePlatforms = subscribePlatforms((livePlatforms) => {
      setPlatforms(livePlatforms);
      setIsLoading(false);
    });

    const unsubscribeSettings = subscribeSettings((liveSettings) => {
      setSettings(liveSettings);
    });

    // Also load announcements
    api.getAnnouncements().then((data) => {
      if (Array.isArray(data) && data.length > 0) {
        setAnnouncements(data);
      }
    });

    return () => {
      unsubscribeNotifs();
      unsubscribePlatforms();
      unsubscribeSettings();
    };
  }, []);

  const loadAllData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [fetchedPlatforms, fetchedAnn, fetchedSet] =
        await Promise.all([
          api.getAdminPlatforms().catch(() => safeDataCache.getPlatforms()),
          api.getAnnouncements().catch(() => safeDataCache.getAnnouncements()),
          api.getSettings().catch(() => safeDataCache.getSettings()),
        ]);

      if (Array.isArray(fetchedPlatforms)) {
        setPlatforms(fetchedPlatforms);
      }

      if (Array.isArray(fetchedAnn) && fetchedAnn.length > 0) {
        setAnnouncements(fetchedAnn);
      }

      if (fetchedSet) setSettings(fetchedSet);
    } catch {
      showToast('Connection temporarily unavailable. Showing saved data.', 'info');
    } finally {
      setIsLoading(false);
    }
  }, [showToast]);

  // Platform / Batch Handlers
  const handleAddPlatform = async (data: Partial<PlatformRecord>) => {
    try {
      await api.addPlatform(data);
      onDataChanged?.();
    } catch (err: unknown) {
      onDataChanged?.();
      throw err; // Re-throw so modal/toast displays actual error message
    }
  };

  const handleUpdatePlatform = async (id: string, data: Partial<PlatformRecord>) => {
    try {
      await api.updatePlatform(id, data);
      onDataChanged?.();
    } catch (err: unknown) {
      onDataChanged?.();
      throw err;
    }
  };

  const handleDeletePlatform = async (id: string) => {
    try {
      await api.deletePlatform(id);
      onDataChanged?.();
    } catch (err: unknown) {
      onDataChanged?.();
      throw err;
    }
  };

  const handleReorderPlatform = async (id: string, direction: 'up' | 'down') => {
    const reordered = await api.reorderPlatform(id, direction);
    setPlatforms(reordered);
    onDataChanged?.();
  };

  // Announcement Handlers
  const handleAddAnnouncement = async (data: Partial<AnnouncementRecord>) => {
    const newAnn = await api.addAnnouncement(data);
    setAnnouncements((prev) => [...prev, newAnn]);
    loadAllData();
  };

  const handleDeleteAnnouncement = async (id: string) => {
    await api.deleteAnnouncement(id);
    setAnnouncements((prev) => prev.filter((a) => a.id !== id));
    loadAllData();
  };

  const handleToggleActiveAnn = async (id: string, current: boolean) => {
    await api.updateAnnouncement(id, { isActive: !current });
    loadAllData();
  };

  // Settings Handlers
  const handleUpdateSettings = async (data: Partial<SettingsRecord>) => {
    const updated = await api.updateSettings(data);
    setSettings(updated);
  };

  const unreadAlertsCount = adminNotifs.filter((n) => !n.read).length;

  const navTabs = [
    { id: 'platforms', label: 'Batches Directory', icon: Layers },
    { id: 'demos', label: 'Manage Batch Demos', icon: Video },
    { id: 'dashboard', label: 'Dashboard Overview', icon: LayoutDashboard },
    { id: 'students', label: 'Student Management', icon: Users },
    { id: 'support', label: 'Student Chats & Inbox', icon: MessageSquare },
    { id: 'announcements', label: 'Notices & Alerts', icon: Bell },
    { id: 'payment', label: 'Scanner & Telegram', icon: QrCode },
    { id: 'settings', label: 'Campus Settings', icon: Settings },
  ] as const;

  const isDarkActiveText = ['cyber', 'monochrome', 'amber'].includes(config.id);
  const activeTabTextColor = isDarkActiveText ? '#09090b' : '#ffffff';

  return (
    <div
      className="min-h-screen flex flex-col relative text-slate-100"
      style={{ backgroundColor: config.bgHex }}
    >
      <AdminHeader
        onLogout={onLogout}
        onExitAdmin={onExitAdmin}
        onOpenChangePassword={() => setActiveTab('settings')}
        onOpenNotifications={() => setIsAdminNotifOpen(true)}
        unreadNotificationCount={unreadAlertsCount}
        announcementCount={announcements.filter((a) => a.isActive).length}
        logoUrl={getWebsiteLogo(settings?.logo, settings?.updatedAt)}
      />

      <div className="flex-1 flex max-w-7xl w-full mx-auto px-4 sm:px-8 pt-6 pb-24 lg:pb-12 gap-8">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex flex-col w-60 shrink-0 gap-2">
          <div className="p-2 rounded-2xl glass-panel border border-white/10 flex flex-col gap-1">
            {navTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  type="button"
                  className={`flex items-center gap-3 px-3.5 py-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isActive ? 'shadow-md' : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                  style={{
                    backgroundColor: isActive ? config.primaryColor : 'transparent',
                    color: isActive ? activeTabTextColor : undefined,
                    boxShadow: isActive ? `0 0 15px ${config.accentGlow}` : 'none',
                  }}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Quick Refresh */}
          <button
            onClick={() => loadAllData()}
            type="button"
            className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-white/[0.03] border border-white/5 text-xs text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer mt-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Sync Database</span>
          </button>
        </aside>

        {/* Main Admin View Content */}
        <main className="flex-1 min-w-0 animate-page-enter">
          {isLoading && platforms.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-24 gap-3">
              <Loader2 className="w-8 h-8 animate-spin" style={{ color: config.primaryColor }} />
              <span className="text-xs text-slate-400">Loading campus database...</span>
            </div>
          ) : (
            <>
              {activeTab === 'platforms' && (
                <AdminPlatforms
                  platforms={platforms}
                  onAddPlatform={handleAddPlatform}
                  onUpdatePlatform={handleUpdatePlatform}
                  onDeletePlatform={handleDeletePlatform}
                  onReorderPlatform={handleReorderPlatform}
                />
              )}

              {activeTab === 'demos' && (
                <AdminBatchDemos />
              )}

              {activeTab === 'dashboard' && (
                <AdminDashboard
                  platforms={platforms}
                  onNavigateTab={(tab) => setActiveTab(tab)}
                  onOpenAddPlatform={() => setActiveTab('platforms')}
                />
              )}

              {activeTab === 'students' && (
                <StudentManagementSection />
              )}

              {activeTab === 'support' && (
                <AdminChatInbox initialSelectedTicketId={selectedSupportTicketId} />
              )}

              {activeTab === 'announcements' && (
                <AdminAnnouncements
                  announcements={announcements}
                  onAddAnnouncement={handleAddAnnouncement}
                  onDeleteAnnouncement={handleDeleteAnnouncement}
                  onToggleActive={handleToggleActiveAnn}
                />
              )}

              {activeTab === 'payment' && (
                <PaymentSettingsSection />
              )}

              {activeTab === 'settings' && (
                <AdminSettings
                  settings={settings}
                  onUpdateSettings={handleUpdateSettings}
                  onLogout={onLogout}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Admin Notification Center Modal */}
      <AdminNotificationCenter
        isOpen={isAdminNotifOpen}
        onClose={() => setIsAdminNotifOpen(false)}
        onOpenTicket={(ticketId) => {
          setSelectedSupportTicketId(ticketId);
          setActiveTab('support');
          setIsAdminNotifOpen(false);
        }}
      />

      {/* Mobile Sticky Tab Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-black/90 backdrop-blur-xl border-t border-white/10 px-2 py-2 flex items-center justify-around">
        {navTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              type="button"
              className={`flex flex-col items-center gap-1 p-2 rounded-xl text-[10px] font-bold transition-all ${
                isActive ? 'text-white' : 'text-slate-500'
              }`}
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{
                  backgroundColor: isActive ? config.badgeBg : 'transparent',
                  color: isActive ? config.primaryColor : 'inherit',
                }}
              >
                <Icon className="w-4 h-4" />
              </div>
              <span className="truncate max-w-[65px]">{tab.label.split(' ')[0]}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export const AdminLayout: React.FC<AdminLayoutProps> = (props) => (
  <ToastProvider>
    <AdminContent {...props} />
  </ToastProvider>
);
