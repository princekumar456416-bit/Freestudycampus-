import React, { useState, useEffect, useRef } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { SettingsRecord } from '../../../server/db';
import {
  Save,
  Sliders,
  Shield,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  LogOut,
  Upload,
  Loader2,
  Sparkles,
  Trash2,
  Users,
  QrCode,
} from 'lucide-react';
import { useToast } from './Toast';
import { api } from '../../services/api';
import { compressOfficialWebLogo } from '../../utils/imageUtils';
import { verifyImageUrl, DEFAULT_FALLBACK_LOGO } from '../../utils/logoHelper';
import { CampusLogo } from '../CampusLogo';
import { StudentManagementSection } from './StudentManagementSection';
import { PaymentSettingsSection } from './PaymentSettingsSection';

export type SettingsSubTab = 'general' | 'students' | 'payment' | 'password';

interface AdminSettingsProps {
  settings: SettingsRecord;
  onUpdateSettings: (data: Partial<SettingsRecord>) => Promise<void>;
  onLogout?: () => void;
  initialSubTab?: SettingsSubTab;
}

export const AdminSettings: React.FC<AdminSettingsProps> = ({
  settings,
  onUpdateSettings,
  onLogout,
  initialSubTab = 'general',
}) => {
  const { config } = useTheme();
  const { showToast } = useToast();

  const [activeSubTab, setActiveSubTab] = useState<SettingsSubTab>(initialSubTab);

  // General website settings
  const [websiteName, setWebsiteName] = useState(settings.websiteName || 'FREE STUDY CAMPUS');
  const [tagline, setTagline] = useState(settings.tagline || 'Learn More. Grow More.');
  const [logo, setLogo] = useState(settings.logo || '');
  const [telegramUrl, setTelegramUrl] = useState(settings.telegramChannelUrl || settings.contactLink || 'https://t.me/freestudycampus');
  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);
  const logoFileInputRef = useRef<HTMLInputElement>(null);

  // Admin Change Password state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');

  // Sync settings when updated externally
  useEffect(() => {
    if (settings && !isSaving) {
      if (settings.websiteName !== undefined) setWebsiteName(settings.websiteName);
      if (settings.tagline !== undefined) setTagline(settings.tagline);
      if (settings.logo !== undefined) setLogo(settings.logo);
      if (settings.telegramChannelUrl !== undefined) setTelegramUrl(settings.telegramChannelUrl);
    }
  }, [settings, isSaving]);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingLogo(true);
    try {
      // 1. Client-side compress specifically for Web Logo & PWA (512x512, transparent, ~30-50KB)
      const compressedDataUrl = await compressOfficialWebLogo(file);

      // 2. Verify that the image is valid and renderable
      const isValid = await verifyImageUrl(compressedDataUrl);
      if (!isValid) {
        throw new Error('Selected image could not be decoded. Please try another image file.');
      }

      // 3. Set instant preview so admin sees the uploaded logo immediately
      setLogo(compressedDataUrl);

      // 4. Upload & update globally across Supabase and server
      const res = await api.uploadOfficialLogo(compressedDataUrl);
      if (res.success && res.logoUrl) {
        setLogo(res.logoUrl);
        showToast('Web Logo updated successfully across website and PWA icons!', 'success');
      } else {
        showToast(res.error || 'Failed to update logo', 'error');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error uploading logo';
      showToast(msg, 'error');
    } finally {
      setIsUploadingLogo(false);
      if (logoFileInputRef.current) {
        logoFileInputRef.current.value = '';
      }
    }
  };

  const handleResetLogo = async () => {
    setIsUploadingLogo(true);
    try {
      await api.uploadOfficialLogo('');
      setLogo(DEFAULT_FALLBACK_LOGO);
      showToast('Logo reset to default Free Study Campus brand icon', 'info');
    } catch {
      showToast('Failed to reset logo', 'error');
    } finally {
      setIsUploadingLogo(false);
    }
  };

  const handleSaveGeneral = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const finalLogo = logo && logo.trim() && logo.trim() !== 'null' && logo.trim() !== 'undefined'
        ? logo.trim()
        : DEFAULT_FALLBACK_LOGO;

      await onUpdateSettings({
        websiteName: websiteName.trim(),
        tagline: tagline.trim(),
        logo: finalLogo,
        telegramChannelUrl: telegramUrl.trim(),
        contactLink: telegramUrl.trim(),
      });
      showToast('Website settings saved successfully!', 'success');
    } catch {
      showToast('Failed to save settings', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (!currentPassword || !newPassword || !confirmPassword) {
      setPasswordError('Please fill in all password fields');
      return;
    }

    if (newPassword.length < 6) {
      setPasswordError('New password must be at least 6 characters');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError('New passwords do not match');
      return;
    }

    setIsUpdatingPassword(true);
    try {
      const res = await api.changePassword(currentPassword, newPassword);
      if (res.success) {
        setPasswordSuccess('Admin password changed successfully! All sessions have been logged out.');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
        showToast('Admin password changed successfully! All sessions logged out.', 'success');
        setTimeout(() => {
          if (onLogout) {
            onLogout();
          }
        }, 800);
      } else {
        setPasswordError(res.error || 'Current password incorrect');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to change password';
      setPasswordError(msg);
    } finally {
      setIsUpdatingPassword(false);
    }
  };

  const isDarkText = ['cyber', 'monochrome', 'amber'].includes(config.id);
  const btnTextColor = isDarkText ? '#09090b' : '#ffffff';

  return (
    <div className="flex flex-col gap-6">
      {/* Settings Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl glass-panel border border-white/10 w-fit">
        <button
          onClick={() => setActiveSubTab('general')}
          type="button"
          className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'general' ? 'shadow-md' : 'text-slate-400 hover:text-white'
          }`}
          style={{
            backgroundColor: activeSubTab === 'general' ? config.primaryColor : 'transparent',
            color: activeSubTab === 'general' ? btnTextColor : undefined,
          }}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>General & Web Logo</span>
        </button>

        <button
          onClick={() => setActiveSubTab('students')}
          type="button"
          className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'students' ? 'shadow-md' : 'text-slate-400 hover:text-white'
          }`}
          style={{
            backgroundColor: activeSubTab === 'students' ? config.primaryColor : 'transparent',
            color: activeSubTab === 'students' ? btnTextColor : undefined,
          }}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Student Management</span>
        </button>

        <button
          onClick={() => setActiveSubTab('payment')}
          type="button"
          className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'payment' ? 'shadow-md' : 'text-slate-400 hover:text-white'
          }`}
          style={{
            backgroundColor: activeSubTab === 'payment' ? config.primaryColor : 'transparent',
            color: activeSubTab === 'payment' ? btnTextColor : undefined,
          }}
        >
          <QrCode className="w-3.5 h-3.5" />
          <span>Scanner & Telegram</span>
        </button>

        <button
          onClick={() => setActiveSubTab('password')}
          type="button"
          className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'password' ? 'shadow-md' : 'text-slate-400 hover:text-white'
          }`}
          style={{
            backgroundColor: activeSubTab === 'password' ? config.primaryColor : 'transparent',
            color: activeSubTab === 'password' ? btnTextColor : undefined,
          }}
        >
          <Shield className="w-3.5 h-3.5" />
          <span>Admin Security</span>
        </button>
      </div>

      {/* 1. GENERAL SETTINGS & WEB LOGO */}
      {activeSubTab === 'general' && (
        <form onSubmit={handleSaveGeneral} className="flex flex-col gap-6 max-w-2xl">
          <div
            className="p-6 rounded-3xl glass-panel border flex flex-col gap-5"
            style={{ borderColor: config.borderColor }}
          >
            <div className="flex items-center gap-2.5 pb-2 border-b border-white/10">
              <Sliders className="w-4 h-4" style={{ color: config.primaryColor }} />
              <h2 className="text-base font-bold text-white font-display">Website Branding</h2>
            </div>

            {/* Web Logo Upload */}
            <div className="flex flex-col sm:flex-row items-center gap-5 p-4 rounded-2xl bg-white/[0.02] border border-white/5">
              <div className="w-20 h-20 rounded-2xl border-2 border-dashed border-white/20 flex items-center justify-center p-2 overflow-hidden bg-black/40 shrink-0">
                <CampusLogo
                  logoUrl={logo}
                  withGlow={true}
                  className="w-full h-full object-contain"
                  alt="Web Logo Preview"
                />
              </div>
              <div className="flex-1 flex flex-col gap-2 text-center sm:text-left">
                <span className="text-xs font-bold text-white">Web Logo</span>
                <p className="text-[11px] text-zinc-400">
                  Upload official website logo (PNG, JPG, or WEBP). It will be centrally used across header, splash screen, and PWA icons.
                </p>
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="file"
                    ref={logoFileInputRef}
                    onChange={handleLogoUpload}
                    accept="image/*,image/png,image/jpeg,image/webp"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => logoFileInputRef.current?.click()}
                    disabled={isUploadingLogo}
                    className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white transition-all cursor-pointer active:scale-95"
                  >
                    {isUploadingLogo ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Optimizing & Uploading...</span>
                      </>
                    ) : (
                      <>
                        <Upload className="w-3.5 h-3.5" />
                        <span>{logo ? 'Change Web Logo' : 'Upload Web Logo'}</span>
                      </>
                    )}
                  </button>

                  {logo && (
                    <button
                      type="button"
                      onClick={handleResetLogo}
                      disabled={isUploadingLogo}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-xs font-semibold text-rose-300 transition-all cursor-pointer active:scale-95 border border-rose-500/20"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Reset to Default</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">Website Name</label>
              <input
                type="text"
                value={websiteName}
                onChange={(e) => setWebsiteName(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] transition-all"
                required
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">Tagline</label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] transition-all"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">Telegram Channel Link</label>
              <input
                type="url"
                value={telegramUrl}
                onChange={(e) => setTelegramUrl(e.target.value)}
                placeholder="https://t.me/freestudycampus"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] transition-all font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={isSaving}
              className="btn-primary-red flex items-center justify-center gap-2 w-full py-3.5 rounded-xl text-sm font-bold transition-all active:scale-98 cursor-pointer mt-2"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 text-white" />
                  <span>Save Branding Settings</span>
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* 2. ADMIN PASSWORD CHANGE */}
      {activeSubTab === 'password' && (
        <form onSubmit={handleChangePassword} className="flex flex-col gap-4 max-w-md">
          <div
            className="p-6 rounded-3xl glass-panel border flex flex-col gap-4"
            style={{ borderColor: config.borderColor }}
          >
            <div className="flex items-center gap-2.5 pb-2 border-b border-white/10">
              <KeyRound className="w-4 h-4" style={{ color: config.primaryColor }} />
              <div>
                <h2 className="text-base font-bold text-white font-display">Change Admin Password</h2>
                <p className="text-[11px] text-zinc-400">Protects the Admin Panel and Batch Management</p>
              </div>
            </div>

            {passwordError && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-300">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{passwordError}</span>
              </div>
            )}

            {passwordSuccess && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{passwordSuccess}</span>
              </div>
            )}

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">Current Password</label>
              <div className="relative">
                <input
                  type={showCurrentPassword ? 'text' : 'password'}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white pr-10 focus:outline-none"
                  placeholder="Enter current password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">New Password</label>
              <div className="relative">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white pr-10 focus:outline-none"
                  placeholder="Enter new password (min. 6 characters)"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">Confirm New Password</label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white pr-10 focus:outline-none"
                  placeholder="Confirm new password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isUpdatingPassword}
              className="btn-primary-red flex items-center justify-center gap-2 w-full py-3.5 rounded-xl text-sm font-bold transition-all active:scale-98 cursor-pointer mt-2"
            >
              {isUpdatingPassword ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>Updating Password...</span>
                </>
              ) : (
                <>
                  <KeyRound className="w-4 h-4 text-white" />
                  <span>Update Admin Password</span>
                </>
              )}
            </button>
          </div>

          {onLogout && (
            <button
              type="button"
              onClick={onLogout}
              className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs font-bold hover:bg-rose-500/20 transition-all cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout of Admin Mode</span>
            </button>
          )}
        </form>
      )}

      {/* 2. STUDENT MANAGEMENT (ACCOUNTS, USERNAMES, PASSWORDS, 1-DEVICE LOCK) */}
      {activeSubTab === 'students' && (
        <div className="w-full">
          <StudentManagementSection />
        </div>
      )}

      {/* 3. SCANNER & TELEGRAM (UPI QR, TELEGRAM BOT, ENROLLMENT FEES) */}
      {activeSubTab === 'payment' && (
        <div className="w-full">
          <PaymentSettingsSection />
        </div>
      )}
    </div>
  );
};
