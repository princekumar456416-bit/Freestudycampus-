import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { UpcomingRecord } from '../../../server/db';
import { Plus, Trash2, Calendar, Sparkles, ExternalLink } from 'lucide-react';
import { useToast } from './Toast';

interface AdminUpcomingProps {
  upcomingList: UpcomingRecord[];
  onAddUpcoming: (data: Partial<UpcomingRecord>) => Promise<void>;
  onDeleteUpcoming: (id: string) => Promise<void>;
}

export const AdminUpcoming: React.FC<AdminUpcomingProps> = ({
  upcomingList,
  onAddUpcoming,
  onDeleteUpcoming,
}) => {
  const { config } = useTheme();
  const { showToast } = useToast();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [batchName, setBatchName] = useState('');
  const [platform, setPlatform] = useState('Physics Wallah');
  const [description, setDescription] = useState('');
  const [thumbnail, setThumbnail] = useState('');
  const [expectedDate, setExpectedDate] = useState('');
  const [externalUrl, setExternalUrl] = useState('https://pwthor.live/study/batches');
  const [status, setStatus] = useState<'Upcoming' | 'In Preparation'>('Upcoming');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!batchName.trim()) {
      showToast('Batch Name is required', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      await onAddUpcoming({
        batchName: batchName.trim(),
        platform: platform.trim(),
        description: description.trim(),
        thumbnail: thumbnail.trim(),
        expectedDate: expectedDate.trim() || 'Coming Soon',
        externalUrl: externalUrl.trim(),
        status,
      });
      showToast('Upcoming batch added to public schedule');
      setIsModalOpen(false);
      setBatchName('');
      setDescription('');
      setExpectedDate('');
    } catch {
      showToast('Failed to add upcoming batch', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await onDeleteUpcoming(id);
      showToast('Upcoming batch removed');
    } catch {
      showToast('Failed to delete upcoming batch', 'error');
    }
  };

  return (
    <div className="flex flex-col gap-6 pb-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white font-display">
            Upcoming Batches Manager
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Publish roadmap announcements displayed on the public Upcoming section.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          type="button"
          className="flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-black text-xs transition-all active:scale-95 shadow-lg cursor-pointer self-start sm:self-auto"
          style={{
            backgroundColor: config.primaryColor,
            boxShadow: `0 0 15px ${config.accentGlow}`,
          }}
        >
          <Plus className="w-4 h-4 text-black" />
          <span>Add Upcoming Batch</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {upcomingList.map((item) => (
          <div
            key={item.id}
            className="rounded-3xl p-5 glass-panel border flex flex-col justify-between gap-4"
            style={{ borderColor: config.borderColor }}
          >
            <div className="flex items-start gap-3.5">
              <img
                src={item.thumbnail}
                alt={item.batchName}
                className="w-16 h-16 rounded-2xl object-cover border border-white/10 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span
                    className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider"
                    style={{
                      backgroundColor: config.badgeBg,
                      color: config.primaryColor,
                    }}
                  >
                    {item.platform}
                  </span>
                  <span className="text-[10px] font-semibold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-md border border-amber-400/20">
                    {item.status}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white mt-1 truncate">
                  {item.batchName}
                </h3>
                <p className="text-xs text-slate-300 line-clamp-2 mt-0.5 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" style={{ color: config.primaryColor }} />
                <span>Expected: {item.expectedDate}</span>
              </div>

              <button
                onClick={() => handleDelete(item.id)}
                type="button"
                className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors"
                title="Delete from Upcoming"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div
            className="w-full max-w-lg rounded-3xl p-6 sm:p-8 glass-panel border relative shadow-2xl"
            style={{
              backgroundColor: config.cardBg,
              borderColor: config.borderColor,
            }}
          >
            <h3 className="text-lg font-bold text-white mb-4">Add Upcoming Batch</h3>
            <form onSubmit={handleSave} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-slate-300">Batch Name *</label>
                <input
                  type="text"
                  required
                  value={batchName}
                  onChange={(e) => setBatchName(e.target.value)}
                  placeholder="e.g. Arjuna JEE 2027 Comprehensive Foundation"
                  className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                  style={{ borderColor: config.borderColor }}
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-slate-300">Platform</label>
                <input
                  type="text"
                  value={platform}
                  onChange={(e) => setPlatform(e.target.value)}
                  placeholder="Physics Wallah"
                  className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                  style={{ borderColor: config.borderColor }}
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-slate-300">Description</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Syllabus scope and faculty overview..."
                  className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none resize-none"
                  style={{ borderColor: config.borderColor }}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-slate-300">Expected Date</label>
                  <input
                    type="text"
                    value={expectedDate}
                    onChange={(e) => setExpectedDate(e.target.value)}
                    placeholder="e.g. October 15, 2026"
                    className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                    style={{ borderColor: config.borderColor }}
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-slate-300">Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as 'Upcoming' | 'In Preparation')}
                    className="w-full bg-black/60 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                    style={{ borderColor: config.borderColor }}
                  >
                    <option value="Upcoming">Upcoming</option>
                    <option value="In Preparation">In Preparation</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-slate-300">Optional External URL</label>
                <input
                  type="url"
                  value={externalUrl}
                  onChange={(e) => setExternalUrl(e.target.value)}
                  placeholder="https://pwthor.live/study/batches"
                  className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none font-mono"
                  style={{ borderColor: config.borderColor }}
                />
              </div>

              <div className="flex items-center justify-end gap-3 mt-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl text-xs font-bold text-black"
                  style={{ backgroundColor: config.primaryColor }}
                >
                  {isSubmitting ? 'Saving...' : 'Save Upcoming Batch'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
