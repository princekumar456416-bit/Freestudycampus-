import React, { useState, useRef } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { PlatformRecord } from '../../../server/db';
import {
  Plus,
  Edit2,
  Trash2,
  ArrowUp,
  ArrowDown,
  ExternalLink,
  Layers,
  AlertTriangle,
  X,
  Check,
  Globe,
  Sparkles,
  Upload,
  Image as ImageIcon,
  Loader2,
  Eye,
  EyeOff,
} from 'lucide-react';
import { useToast } from './Toast';
import {
  compressAndCropBatchLogo,
  isImageSource,
  getBatchInitials,
} from '../../utils/imageUtils';

interface AdminPlatformsProps {
  platforms: PlatformRecord[];
  onAddPlatform: (data: Partial<PlatformRecord>) => Promise<void>;
  onUpdatePlatform: (id: string, data: Partial<PlatformRecord>) => Promise<void>;
  onDeletePlatform: (id: string) => Promise<void>;
  onReorderPlatform: (id: string, direction: 'up' | 'down') => Promise<void>;
}

export const AdminPlatforms: React.FC<AdminPlatformsProps> = ({
  platforms,
  onAddPlatform,
  onUpdatePlatform,
  onDeletePlatform,
  onReorderPlatform,
}) => {
  const { config } = useTheme();
  const { showToast } = useToast();

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPlatform, setEditingPlatform] = useState<PlatformRecord | null>(null);
  const [deleteConfirmPlatform, setDeleteConfirmPlatform] = useState<PlatformRecord | null>(null);

  // Form fields as requested
  // 1. Batch Name
  const [platformName, setPlatformName] = useState('');
  // 2. Batch Link
  const [externalLink, setExternalLink] = useState('');
  // 3. Batch Logo
  const [logoIcon, setLogoIcon] = useState('');
  // Status (Active / Inactive)
  const [statusActive, setStatusActive] = useState(true);

  // File picker state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isProcessingLogo, setIsProcessingLogo] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Open Add Batch Form
  const handleOpenAdd = () => {
    setEditingPlatform(null);
    setPlatformName('');
    setExternalLink('');
    setLogoIcon('');
    setStatusActive(true);
    setIsModalOpen(true);
  };

  // Open Edit Batch Form
  const handleOpenEdit = (p: PlatformRecord) => {
    setEditingPlatform(p);
    setPlatformName(p.name);
    setExternalLink(p.externalUrl);
    setLogoIcon(p.logo || '');
    setStatusActive(p.isAvailable);
    setIsModalOpen(true);
  };

  // Handle phone / desktop file picker selection
  const handleLogoFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingLogo(true);
    try {
      const compressedDataUrl = await compressAndCropBatchLogo(file, 280, 0.85);
      setLogoIcon(compressedDataUrl);
      showToast('Batch Logo uploaded and optimized');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to process logo';
      showToast(msg, 'error');
    } finally {
      setIsProcessingLogo(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Remove uploaded logo and revert to placeholder
  const handleRemoveLogo = () => {
    setLogoIcon('');
    showToast('Batch logo removed. Default placeholder will be used.');
  };

  // Submit Save Batch
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!platformName.trim()) {
      showToast('Please enter Batch Name', 'error');
      return;
    }
    if (!externalLink.trim()) {
      showToast('Please enter Batch Link', 'error');
      return;
    }

    // Ensure link has http:// or https://
    let formattedLink = externalLink.trim();
    if (!/^https?:\/\//i.test(formattedLink)) {
      formattedLink = `https://${formattedLink}`;
    }

    const finalLogo = logoIcon.trim() || platformName.trim().slice(0, 2).toUpperCase();

    setIsSubmitting(true);
    try {
      if (editingPlatform) {
        await onUpdatePlatform(editingPlatform.id, {
          name: platformName.trim(),
          externalUrl: formattedLink,
          logo: finalLogo,
          isAvailable: statusActive,
        });
        showToast(`Batch "${platformName}" updated successfully`);
      } else {
        await onAddPlatform({
          name: platformName.trim(),
          externalUrl: formattedLink,
          logo: finalLogo,
          isAvailable: statusActive,
        });
        showToast(`Batch "${platformName}" saved to database`);
      }
      setIsModalOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Operation failed';
      showToast(msg, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Toggle status immediately from list
  const handleToggleStatus = async (platform: PlatformRecord) => {
    const nextStatus = !platform.isAvailable;
    try {
      await onUpdatePlatform(platform.id, { isAvailable: nextStatus });
      showToast(
        `"${platform.name}" is now ${nextStatus ? 'ACTIVE (visible on public site)' : 'INACTIVE (hidden)'}`
      );
    } catch {
      showToast('Failed to change status', 'error');
    }
  };

  // Reordering
  const handleReorder = async (platformId: string, direction: 'up' | 'down') => {
    try {
      await onReorderPlatform(platformId, direction);
      showToast('Batch display order updated');
    } catch {
      showToast('Failed to reorder batch', 'error');
    }
  };

  // Confirm delete
  const handleDelete = async () => {
    if (!deleteConfirmPlatform) return;
    try {
      await onDeletePlatform(deleteConfirmPlatform.id);
      showToast(`Batch "${deleteConfirmPlatform.name}" deleted successfully`);
      setDeleteConfirmPlatform(null);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to delete batch';
      showToast(msg, 'error');
    }
  };

  return (
    <div className="flex flex-col gap-6 pb-20">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white font-display tracking-tight flex items-center gap-2.5">
            <span>Batch Management</span>
            <span
              className="text-xs px-2.5 py-0.5 rounded-full font-mono border"
              style={{
                backgroundColor: config.badgeBg,
                borderColor: config.borderColor,
                color: config.primaryColor,
              }}
            >
              {platforms.length} Batches
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Manage batches, upload custom logos from phone, and configure external study links.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          type="button"
          className="btn-primary-red flex items-center gap-2 px-5 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 shadow-lg cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-white" />
          <span>Add New Batch</span>
        </button>
      </div>

      {/* Info notice */}
      <div className="p-3.5 rounded-2xl bg-white/[0.02] border border-white/5 flex items-center justify-between text-xs text-slate-400">
        <span className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 shrink-0" style={{ color: config.primaryColor }} />
          <span>Only <strong>ACTIVE</strong> batches appear on the public student website. Tapping a card opens its configured Batch Link directly.</span>
        </span>
      </div>

      {/* BATCHES LIST */}
      {platforms.length === 0 ? (
        <div className="rounded-3xl p-12 text-center glass-panel border border-white/10 flex flex-col items-center justify-center gap-3">
          <Layers className="w-10 h-10 text-slate-500" />
          <h3 className="text-base font-bold text-white">No Batches Added Yet</h3>
          <p className="text-xs text-slate-400 max-w-sm">
            Click &ldquo;Add New Batch&rdquo; above to register study batches with custom logos and direct external links.
          </p>
          <button
            onClick={handleOpenAdd}
            type="button"
            className="btn-primary-red mt-2 px-4 py-2 rounded-xl text-xs font-bold text-white cursor-pointer shadow-lg"
          >
            Add First Batch
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {platforms.map((platform, idx) => {
            const isFirst = idx === 0;
            const isLast = idx === platforms.length - 1;
            const hasCustomImage = isImageSource(platform.logo);

            return (
              <div
                key={platform.id}
                className="p-4 sm:p-5 rounded-3xl glass-panel border flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all duration-300 hover:border-white/20 relative overflow-hidden"
                style={{
                  borderColor: platform.isAvailable ? config.borderColor : 'rgba(255, 255, 255, 0.08)',
                  boxShadow: platform.isAvailable ? `0 4px 20px -2px ${config.accentGlow}` : 'none',
                  opacity: platform.isAvailable ? 1 : 0.65,
                }}
              >
                {/* Left side: Logo & Batch Name */}
                <div className="flex items-center gap-3.5 min-w-0 flex-1">
                  {/* Batch Logo */}
                  <div
                    className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center border shrink-0 overflow-hidden font-black text-sm bg-black/50 shadow-md"
                    style={{
                      borderColor: config.borderColor,
                      color: config.primaryColor,
                    }}
                  >
                    {hasCustomImage ? (
                      <img
                        src={platform.logo}
                        alt={platform.name}
                        className="w-full h-full object-contain p-1"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : (
                      <span className="uppercase select-none">
                        {platform.logo && !isImageSource(platform.logo)
                          ? platform.logo
                          : getBatchInitials(platform.name)}
                      </span>
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white tracking-tight truncate">
                        {platform.name}
                      </h3>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider ${
                          platform.isAvailable
                            ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/40'
                            : 'bg-slate-900 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {platform.isAvailable ? 'ON' : 'OFF'}
                      </span>
                    </div>

                    <a
                      href={platform.externalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-slate-400 hover:text-cyan-300 transition-colors flex items-center gap-1.5 mt-0.5 truncate max-w-sm sm:max-w-md font-mono"
                    >
                      <Globe className="w-3 h-3 shrink-0" />
                      <span className="truncate">{platform.externalUrl}</span>
                      <ExternalLink className="w-3 h-3 shrink-0 opacity-60" />
                    </a>
                  </div>
                </div>

                {/* Right side: Active/Inactive Toggle, Reorder, Edit, Delete */}
                <div className="flex items-center justify-between sm:justify-end gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-white/5 shrink-0">
                  {/* Status Switch (ON / OFF) */}
                  <button
                    onClick={() => handleToggleStatus(platform)}
                    type="button"
                    title={platform.isAvailable ? 'Click to make INACTIVE' : 'Click to make ACTIVE'}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                      platform.isAvailable
                        ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/25'
                        : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    {platform.isAvailable ? (
                      <Eye className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <EyeOff className="w-3.5 h-3.5 text-slate-500" />
                    )}
                    <span>{platform.isAvailable ? 'Active' : 'Inactive'}</span>
                  </button>

                  {/* Move Up / Move Down */}
                  <div className="flex items-center rounded-xl bg-white/5 border border-white/10 overflow-hidden">
                    <button
                      onClick={() => handleReorder(platform.id, 'up')}
                      disabled={isFirst}
                      type="button"
                      aria-label="Move Up"
                      title="Move Up"
                      className={`p-2 transition-colors ${
                        isFirst
                          ? 'opacity-25 cursor-not-allowed text-slate-600'
                          : 'text-slate-300 hover:text-white hover:bg-white/10 cursor-pointer'
                      }`}
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <div className="w-[1px] h-4 bg-white/10" />
                    <button
                      onClick={() => handleReorder(platform.id, 'down')}
                      disabled={isLast}
                      type="button"
                      aria-label="Move Down"
                      title="Move Down"
                      className={`p-2 transition-colors ${
                        isLast
                          ? 'opacity-25 cursor-not-allowed text-slate-600'
                          : 'text-slate-300 hover:text-white hover:bg-white/10 cursor-pointer'
                      }`}
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Edit */}
                  <button
                    onClick={() => handleOpenEdit(platform)}
                    type="button"
                    title="Edit Batch"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-white/10 text-xs font-semibold text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>

                  {/* Delete */}
                  <button
                    onClick={() => setDeleteConfirmPlatform(platform)}
                    type="button"
                    title="Delete Batch"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-rose-500/20 text-xs font-semibold text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ======================================================= */}
      {/* ADD / EDIT BATCH MODAL (Name, Link, Logo)               */}
      {/* ======================================================= */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
          <div
            className="w-full max-w-lg rounded-3xl p-6 sm:p-7 glass-panel border relative flex flex-col gap-5 shadow-2xl animate-in zoom-in-95 duration-200 my-8"
            style={{
              borderColor: config.borderColor,
              boxShadow: `0 20px 60px -10px ${config.accentGlow}`,
            }}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h3 className="text-lg font-extrabold text-white font-display">
                  {editingPlatform ? 'Edit Batch' : 'Add New Batch'}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Set Batch Name, Batch Link, and upload custom Batch Logo.
                </p>
              </div>

              <button
                onClick={() => setIsModalOpen(false)}
                type="button"
                className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              {/* Field 1: Batch Name */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  1. Batch Name <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={platformName}
                  onChange={(e) => setPlatformName(e.target.value)}
                  placeholder="e.g. Lakshya JEE 2027, Target Board, or Vidyakul"
                  className="w-full bg-black/40 border rounded-2xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 transition-all"
                  style={{ borderColor: config.borderColor }}
                />
              </div>

              {/* Field 2: Batch Link */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  2. Batch Link <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={externalLink}
                  onChange={(e) => setExternalLink(e.target.value)}
                  placeholder="https://pwthor.live/study/batches"
                  className="w-full bg-black/40 border rounded-2xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 font-mono transition-all text-xs"
                  style={{ borderColor: config.borderColor }}
                />
                <span className="text-[11px] text-slate-400">
                  Direct destination URL launched when a student taps this batch card on the Home Page.
                </span>
              </div>

              {/* Field 3: Batch Logo Upload & Preview */}
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <ImageIcon className="w-3.5 h-3.5" style={{ color: config.primaryColor }} />
                    <span>3. Batch Logo</span>
                  </label>
                  {isImageSource(logoIcon) && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                      Logo Uploaded
                    </span>
                  )}
                </div>

                {/* Hidden native file input for mobile & desktop */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,image/png,image/jpeg,image/jpg,image/webp"
                  onChange={handleLogoFileChange}
                  className="hidden"
                />

                {/* Logo Preview & Action Box */}
                <div
                  className="p-3.5 sm:p-4 rounded-2xl border flex flex-col sm:flex-row items-center gap-4 bg-black/40 backdrop-blur-md"
                  style={{ borderColor: config.borderColor }}
                >
                  {/* Visual Logo Preview */}
                  <div
                    className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl border flex items-center justify-center shrink-0 overflow-hidden shadow-lg bg-black/70"
                    style={{
                      borderColor: config.borderColor,
                      boxShadow: `0 0 16px ${config.accentGlow}`,
                    }}
                  >
                    {isProcessingLogo ? (
                      <div className="flex flex-col items-center justify-center gap-1 text-slate-400 text-[10px] p-2 text-center">
                        <Loader2 className="w-5 h-5 animate-spin" style={{ color: config.primaryColor }} />
                        <span>Optimizing...</span>
                      </div>
                    ) : isImageSource(logoIcon) ? (
                      <img
                        src={logoIcon}
                        alt={platformName || 'Batch Logo Preview'}
                        className="w-full h-full object-contain p-1.5"
                      />
                    ) : (
                      <div className="flex flex-col items-center justify-center text-center p-2">
                        <span
                          className="text-xl sm:text-2xl font-black font-display uppercase tracking-wider select-none"
                          style={{ color: config.primaryColor }}
                        >
                          {logoIcon && !isImageSource(logoIcon)
                            ? logoIcon
                            : getBatchInitials(platformName)}
                        </span>
                        <span className="text-[8px] sm:text-[9px] text-slate-500 uppercase mt-0.5 tracking-tight font-semibold">
                          Default Logo
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Buttons & Helpers */}
                  <div className="flex-1 flex flex-col gap-2 w-full text-center sm:text-left">
                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                      {/* Upload / Change Logo Button */}
                      <button
                        type="button"
                        disabled={isProcessingLogo}
                        onClick={() => fileInputRef.current?.click()}
                        className="btn-primary-red flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all active:scale-95 shadow-md cursor-pointer disabled:opacity-50"
                      >
                        <Upload className="w-3.5 h-3.5 text-white" />
                        <span>{isImageSource(logoIcon) ? 'Change Logo' : 'Upload Batch Logo'}</span>
                      </button>

                      {/* Remove Logo Button */}
                      {isImageSource(logoIcon) && (
                        <button
                          type="button"
                          onClick={handleRemoveLogo}
                          className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl border border-rose-500/30 text-rose-400 hover:bg-rose-500/10 text-xs font-semibold transition-all cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove Logo</span>
                        </button>
                      )}
                    </div>

                    <p className="text-[11px] text-slate-400">
                      Supports <strong>PNG, JPG, JPEG, WEBP</strong>. Tap to select from phone gallery or take photo. Image is automatically resized, compressed, and previewed.
                    </p>

                    {/* Optional URL accordion */}
                    <details className="mt-1 text-left">
                      <summary className="text-[10px] text-slate-500 hover:text-slate-300 cursor-pointer transition-colors">
                        Advanced: paste image link or custom 2-letter badge
                      </summary>
                      <div className="mt-1.5">
                        <input
                          type="text"
                          value={logoIcon}
                          onChange={(e) => setLogoIcon(e.target.value)}
                          placeholder="https://... or 2-letter emblem"
                          className="w-full bg-black/60 border rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:outline-none font-mono"
                          style={{ borderColor: config.borderColor }}
                        />
                      </div>
                    </details>
                  </div>
                </div>
              </div>

              {/* Status: Active / Inactive */}
              <div className="flex flex-col gap-1.5 pt-1">
                <label className="text-xs font-semibold text-slate-300">
                  Batch Status
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setStatusActive(true)}
                    className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl border text-xs font-bold transition-all cursor-pointer ${
                      statusActive
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-md'
                        : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Active (Public)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setStatusActive(false)}
                    className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl border text-xs font-bold transition-all cursor-pointer ${
                      !statusActive
                        ? 'bg-slate-800 text-slate-200 border-slate-600 shadow-md'
                        : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-slate-500" />
                    <span>Inactive (Hidden)</span>
                  </button>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-2xl border border-white/10 text-xs font-bold text-slate-300 hover:text-white hover:bg-white/5 transition-all cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSubmitting || isProcessingLogo}
                  className="btn-primary-red flex items-center justify-center gap-2 px-6 py-2.5 rounded-2xl font-bold text-white text-xs transition-all active:scale-95 shadow-lg cursor-pointer disabled:opacity-50"
                >
                  <Check className="w-4 h-4 text-white" />
                  <span>
                    {isSubmitting
                      ? 'Saving Batch...'
                      : editingPlatform
                      ? 'SAVE BATCH CHANGES'
                      : 'SAVE BATCH'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ======================================================= */}
      {/* DELETE CONFIRMATION MODAL                               */}
      {/* ======================================================= */}
      {deleteConfirmPlatform && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
          <div
            className="w-full max-w-md rounded-3xl p-6 glass-panel border border-rose-500/30 flex flex-col gap-4 shadow-2xl animate-in zoom-in-95 duration-150"
            style={{
              boxShadow: '0 20px 50px -10px rgba(244, 63, 94, 0.3)',
            }}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-rose-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Delete Batch</h3>
                <p className="text-xs text-slate-400">This action cannot be undone.</p>
              </div>
            </div>

            <p className="text-sm text-slate-200">
              Are you sure you want to delete this batch from the directory?
            </p>

            <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 overflow-hidden bg-black/50"
                style={{ borderColor: config.borderColor, color: config.primaryColor }}
              >
                {isImageSource(deleteConfirmPlatform.logo) ? (
                  <img
                    src={deleteConfirmPlatform.logo}
                    alt={deleteConfirmPlatform.name}
                    className="w-full h-full object-contain p-0.5"
                  />
                ) : (
                  <span>
                    {deleteConfirmPlatform.logo || getBatchInitials(deleteConfirmPlatform.name)}
                  </span>
                )}
              </div>
              <div className="truncate">
                <span className="text-xs font-bold text-white block truncate">
                  {deleteConfirmPlatform.name}
                </span>
                <span className="text-[11px] text-slate-400 block truncate font-mono">
                  {deleteConfirmPlatform.externalUrl}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmPlatform(null)}
                className="px-4 py-2.5 rounded-2xl border border-white/10 text-xs font-bold text-slate-300 hover:text-white hover:bg-white/5 transition-all cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleDelete}
                className="px-5 py-2.5 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold transition-all active:scale-95 shadow-lg shadow-rose-500/25 cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
