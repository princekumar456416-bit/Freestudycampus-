import React, { useState, useMemo } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { BatchRecord, PlatformRecord } from '../../../server/db';
import {
  Plus,
  Search,
  Filter,
  ArrowUp,
  ArrowDown,
  Star,
  Eye,
  EyeOff,
  Edit3,
  Trash2,
  ExternalLink,
  AlertTriangle,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';
import { useToast } from './Toast';

interface AdminBatchesProps {
  batches: BatchRecord[];
  platforms: PlatformRecord[];
  selectedPlatformId: string;
  onSelectPlatformId: (id: string) => void;
  onAddBatch: (data: Partial<BatchRecord>) => Promise<void>;
  onUpdateBatch: (id: string, data: Partial<BatchRecord>) => Promise<void>;
  onDeleteBatch: (id: string) => Promise<void>;
  onReorderBatch: (id: string, direction: 'up' | 'down') => Promise<void>;
  onToggleFeature: (id: string) => Promise<void>;
  onToggleStatus: (id: string) => Promise<void>;
  isAddModalOpen?: boolean;
  onCloseAddModal?: () => void;
}

export const AdminBatches: React.FC<AdminBatchesProps> = ({
  batches,
  platforms,
  selectedPlatformId,
  onSelectPlatformId,
  onAddBatch,
  onUpdateBatch,
  onDeleteBatch,
  onReorderBatch,
  onToggleFeature,
  onToggleStatus,
  isAddModalOpen = false,
  onCloseAddModal,
}) => {
  const { config } = useTheme();
  const { showToast } = useToast();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Upcoming' | 'Completed'>('All');
  const [internalModalOpen, setInternalModalOpen] = useState(false);
  const [editingBatch, setEditingBatch] = useState<BatchRecord | null>(null);
  const [isDeletingId, setIsDeletingId] = useState<string | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [thumbnail, setThumbnail] = useState('');
  const [teacherName, setTeacherName] = useState('');
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState('JEE');
  const [batchUrl, setBatchUrl] = useState('https://pwthor.live/study/batches');
  const [startDate, setStartDate] = useState('');
  const [status, setStatus] = useState<'Active' | 'Upcoming' | 'Completed'>('Active');
  const [displayOrder, setDisplayOrder] = useState(1);
  const [isFeatured, setIsFeatured] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const modalOpen = isAddModalOpen || internalModalOpen;

  const openAddModal = () => {
    setEditingBatch(null);
    setTitle('');
    setShortDescription('');
    setThumbnail('https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=600&auto=format&fit=crop&q=80');
    setTeacherName('Physics Wallah Academic Mentors');
    setSubject('Physics');
    setCategory('JEE');
    setBatchUrl('https://pwthor.live/study/batches');
    setStartDate(new Date().toISOString().slice(0, 10));
    setStatus('Active');
    setDisplayOrder(batches.length + 1);
    setIsFeatured(false);
    setInternalModalOpen(true);
  };

  const openEditModal = (batch: BatchRecord) => {
    setEditingBatch(batch);
    setTitle(batch.title);
    setShortDescription(batch.shortDescription);
    setThumbnail(batch.thumbnail);
    setTeacherName(batch.teacherName);
    setSubject(batch.subject);
    setCategory(batch.category);
    setBatchUrl(batch.batchUrl);
    setStartDate(batch.startDate);
    setStatus(batch.status);
    setDisplayOrder(batch.displayOrder);
    setIsFeatured(batch.isFeatured);
    setInternalModalOpen(true);
  };

  const closeModal = () => {
    setInternalModalOpen(false);
    if (onCloseAddModal) onCloseAddModal();
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !batchUrl.trim()) {
      showToast('Batch Title and Batch URL are required', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload: Partial<BatchRecord> = {
        platformId: selectedPlatformId || 'physics-wallah',
        title: title.trim(),
        shortDescription: shortDescription.trim(),
        thumbnail: thumbnail.trim(),
        teacherName: teacherName.trim(),
        subject: subject.trim(),
        category: category.trim().toUpperCase(),
        batchUrl: batchUrl.trim(),
        startDate,
        status,
        displayOrder: Number(displayOrder),
        isFeatured,
      };

      if (editingBatch) {
        await onUpdateBatch(editingBatch.id, payload);
        showToast('Batch updated successfully');
      } else {
        await onAddBatch(payload);
        showToast('New batch created and live on website');
      }
      closeModal();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save batch';
      showToast(msg, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!isDeletingId) return;
    try {
      await onDeleteBatch(isDeletingId);
      showToast('Batch removed from curriculum');
      setIsDeletingId(null);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to delete batch';
      showToast(msg, 'error');
    }
  };

  // Filtered Batches
  const filteredBatches = useMemo(() => {
    return batches
      .filter((b) => {
        if (selectedPlatformId && b.platformId !== selectedPlatformId) return false;
        if (statusFilter !== 'All' && b.status !== statusFilter) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const match =
            b.title.toLowerCase().includes(q) ||
            b.shortDescription.toLowerCase().includes(q) ||
            b.teacherName.toLowerCase().includes(q) ||
            b.subject.toLowerCase().includes(q) ||
            b.category.toLowerCase().includes(q);
          if (!match) return false;
        }
        return true;
      })
      .sort((a, b) => a.displayOrder - b.displayOrder);
  }, [batches, selectedPlatformId, statusFilter, searchQuery]);

  return (
    <div className="flex flex-col gap-6 pb-16">
      {/* Top Header & Platform Selector */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white font-display">
            Batch Management
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Publish, edit, and organize curricula under educational partner platforms.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Platform Tab Selector */}
          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-black/40 border border-white/10">
            {platforms.map((p) => {
              const isActive = p.id === selectedPlatformId;
              return (
                <button
                  key={p.id}
                  onClick={() => onSelectPlatformId(p.id)}
                  type="button"
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isActive ? 'text-white shadow-md' : 'text-slate-400 hover:text-white'
                  }`}
                  style={{
                    backgroundColor: isActive ? config.primaryColor : 'transparent',
                  }}
                >
                  {p.name}
                </button>
              );
            })}
          </div>

          <button
            onClick={openAddModal}
            type="button"
            className="btn-primary-red flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 shadow-lg cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4 text-white" />
            <span>Add New Batch</span>
          </button>
        </div>
      </div>

      {/* Search & Status Filters */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        {/* Search Bar */}
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search batches by title, educator, subject..."
            className="w-full bg-black/40 border rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-all"
            style={{ borderColor: config.borderColor }}
          />
        </div>

        {/* Status Filters */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {(['All', 'Active', 'Upcoming', 'Completed'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              type="button"
              className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                statusFilter === st
                  ? 'border-transparent text-white font-bold shadow-md'
                  : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
              }`}
              style={{
                backgroundColor: statusFilter === st ? config.primaryColor : undefined,
              }}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Batches Table / Grid */}
      {filteredBatches.length === 0 ? (
        <div
          className="rounded-3xl p-12 text-center glass-panel border flex flex-col items-center justify-center gap-3"
          style={{ borderColor: 'rgba(255, 255, 255, 0.08)' }}
        >
          <Layers className="w-10 h-10 text-slate-500" />
          <h3 className="text-base font-bold text-white">No batches found</h3>
          <p className="text-xs text-slate-400 max-w-sm">
            {searchQuery
              ? `No matches for "${searchQuery}". Clear your search or filter.`
              : 'No batches have been created under this platform yet. Click "+ Add New Batch".'}
          </p>
          <button
            onClick={openAddModal}
            type="button"
            className="mt-2 px-4 py-2 rounded-xl text-xs font-bold text-black"
            style={{ backgroundColor: config.primaryColor }}
          >
            Create First Batch
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {filteredBatches.map((batch, index) => (
            <div
              key={batch.id}
              className="rounded-3xl p-4 sm:p-5 glass-panel border flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-all duration-300 hover:border-white/20"
              style={{
                borderColor: batch.isAvailable ? config.borderColor : 'rgba(255, 255, 255, 0.08)',
                opacity: batch.isAvailable ? 1 : 0.65,
              }}
            >
              {/* Left: Thumbnail & Details */}
              <div className="flex items-start sm:items-center gap-3.5 min-w-0 flex-1">
                <div className="relative shrink-0">
                  <img
                    src={batch.thumbnail}
                    alt={batch.title}
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border border-white/10 shadow-md"
                  />
                  {batch.isFeatured && (
                    <div
                      className="absolute -top-1.5 -left-1.5 p-1 rounded-full text-black"
                      style={{ backgroundColor: config.primaryColor }}
                      title="Featured Batch"
                    >
                      <Star className="w-3 h-3 fill-current" />
                    </div>
                  )}
                </div>

                <div className="flex flex-col gap-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider"
                      style={{
                        backgroundColor: config.badgeBg,
                        color: config.primaryColor,
                      }}
                    >
                      {batch.category}
                    </span>

                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-semibold border ${
                        batch.status === 'Active'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : batch.status === 'Upcoming'
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                          : 'bg-slate-500/10 text-slate-400 border-slate-500/30'
                      }`}
                    >
                      {batch.status}
                    </span>

                    <span className="text-[10px] text-slate-500 font-mono">
                      Order: #{batch.displayOrder}
                    </span>
                  </div>

                  <h3 className="text-sm sm:text-base font-bold text-white truncate">
                    {batch.title}
                  </h3>

                  <p className="text-xs text-slate-300 line-clamp-1">
                    {batch.teacherName} · {batch.subject} · {batch.shortDescription}
                  </p>

                  <div className="flex items-center gap-2 text-[11px] font-mono text-cyan-300">
                    <ExternalLink className="w-3 h-3 shrink-0" />
                    <a
                      href={batch.batchUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:underline truncate max-w-xs sm:max-w-md"
                    >
                      {batch.batchUrl}
                    </a>
                  </div>
                </div>
              </div>

              {/* Right: Actions */}
              <div className="flex items-center gap-1.5 shrink-0 self-end md:self-center pt-2 md:pt-0 border-t md:border-t-0 border-white/10 w-full md:w-auto justify-end">
                {/* Reorder Buttons */}
                <div className="flex items-center bg-white/5 rounded-xl border border-white/10 p-0.5">
                  <button
                    onClick={() => onReorderBatch(batch.id, 'up')}
                    disabled={index === 0}
                    type="button"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 disabled:opacity-30 disabled:hover:bg-transparent"
                    title="Move Up"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onReorderBatch(batch.id, 'down')}
                    disabled={index === filteredBatches.length - 1}
                    type="button"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 disabled:opacity-30 disabled:hover:bg-transparent"
                    title="Move Down"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Feature Toggle */}
                <button
                  onClick={() => onToggleFeature(batch.id)}
                  type="button"
                  className={`p-2 rounded-xl transition-all ${
                    batch.isFeatured
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'text-slate-400 hover:text-white hover:bg-white/10'
                  }`}
                  title={batch.isFeatured ? 'Remove Featured Status' : 'Mark as Featured'}
                >
                  <Star className={`w-4 h-4 ${batch.isFeatured ? 'fill-current' : ''}`} />
                </button>

                {/* Status Toggle (Enable/Disable) */}
                <button
                  onClick={() => onToggleStatus(batch.id)}
                  type="button"
                  className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                  title={batch.isAvailable ? 'Disable Batch' : 'Enable Batch'}
                >
                  {batch.isAvailable ? <Eye className="w-4 h-4 text-emerald-400" /> : <EyeOff className="w-4 h-4 text-slate-500" />}
                </button>

                {/* Edit */}
                <button
                  onClick={() => openEditModal(batch)}
                  type="button"
                  className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                  title="Edit Batch"
                >
                  <Edit3 className="w-4 h-4" />
                </button>

                {/* Delete */}
                <button
                  onClick={() => setIsDeletingId(batch.id)}
                  type="button"
                  className="p-2 rounded-xl text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors"
                  title="Delete Batch"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Batch Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
          <div
            className="w-full max-w-2xl rounded-3xl p-6 sm:p-8 glass-panel border relative my-8"
            style={{
              backgroundColor: config.cardBg,
              borderColor: config.borderColor,
              boxShadow: `0 20px 50px -10px ${config.accentGlow}`,
            }}
          >
            <div className="flex items-center justify-between mb-2">
              <div>
                <h3 className="text-xl font-bold text-white font-display">
                  {editingBatch ? 'Edit Batch' : '+ Add New Batch'}
                </h3>
                <p className="text-xs text-slate-400">
                  Configure batch syllabus, thumbnail, teacher mentors, and direct link.
                </p>
              </div>
              <span
                className="px-2.5 py-1 rounded-full text-xs font-bold uppercase"
                style={{
                  backgroundColor: config.badgeBg,
                  color: config.primaryColor,
                }}
              >
                Physics Wallah
              </span>
            </div>

            <form onSubmit={handleSave} className="flex flex-col gap-4 mt-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5 sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-300">Batch Name *</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Lakshya JEE (Class 12) - High-Yield Series"
                    className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                    style={{ borderColor: config.borderColor }}
                  />
                </div>

                <div className="flex flex-col gap-1.5 sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-300">Short Description</label>
                  <textarea
                    rows={2}
                    value={shortDescription}
                    onChange={(e) => setShortDescription(e.target.value)}
                    placeholder="Brief description of chapters covered, syllabus focus..."
                    className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none resize-none"
                    style={{ borderColor: config.borderColor }}
                  />
                </div>

                <div className="flex flex-col gap-1.5 sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-300">Batch Thumbnail / Image URL</label>
                  <input
                    type="url"
                    value={thumbnail}
                    onChange={(e) => setThumbnail(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none font-mono"
                    style={{ borderColor: config.borderColor }}
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-300">Teacher / Faculty Name</label>
                  <input
                    type="text"
                    value={teacherName}
                    onChange={(e) => setTeacherName(e.target.value)}
                    placeholder="e.g. Alakh Pandey Sir & Rajwant Sir"
                    className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                    style={{ borderColor: config.borderColor }}
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-300">Subject</label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="e.g. Physics, Chemistry, Math"
                    className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                    style={{ borderColor: config.borderColor }}
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-300">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-black/60 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                    style={{ borderColor: config.borderColor }}
                  >
                    <option value="JEE">JEE (Mains & Advanced)</option>
                    <option value="NEET">NEET (UG Medical)</option>
                    <option value="BOARDS">Boards (Class 10/12)</option>
                    <option value="FOUNDATION">Foundation (Class 9/10)</option>
                    <option value="NOTES">PDF Notes & Mindmaps</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-300">Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as 'Active' | 'Upcoming' | 'Completed')}
                    className="w-full bg-black/60 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                    style={{ borderColor: config.borderColor }}
                  >
                    <option value="Active">Active</option>
                    <option value="Upcoming">Upcoming</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1.5 sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-300">Batch URL (Destination) *</label>
                  <input
                    type="url"
                    required
                    value={batchUrl}
                    onChange={(e) => setBatchUrl(e.target.value)}
                    placeholder="https://pwthor.live/study/batches"
                    className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none font-mono"
                    style={{ borderColor: config.borderColor }}
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-300">Start Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                    style={{ borderColor: config.borderColor }}
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-300">Display Order</label>
                  <input
                    type="number"
                    min={1}
                    value={displayOrder}
                    onChange={(e) => setDisplayOrder(parseInt(e.target.value) || 1)}
                    className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                    style={{ borderColor: config.borderColor }}
                  />
                </div>
              </div>

              {/* Toggles */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <label className="flex items-center gap-2 p-2.5 rounded-xl bg-white/5 border border-white/10 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isFeatured}
                    onChange={(e) => setIsFeatured(e.target.checked)}
                    className="rounded accent-cyan-400"
                  />
                  <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                    <Star className="w-3.5 h-3.5 text-amber-400" />
                    Featured Batch ON
                  </span>
                </label>
              </div>

              {/* Form Actions */}
              <div className="flex items-center justify-end gap-3 mt-4 pt-4 border-t border-white/10">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="btn-primary-red px-5 py-2.5 rounded-xl text-xs font-bold text-white transition-all active:scale-95 shadow-md cursor-pointer"
                >
                  {isSubmitting ? 'Saving Batch...' : editingBatch ? 'Update Batch' : 'Save Batch'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      {isDeletingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div
            className="w-full max-w-sm rounded-3xl p-6 glass-panel border relative shadow-2xl text-center"
            style={{
              backgroundColor: config.cardBg,
              borderColor: '#f43f5e',
            }}
          >
            <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center mx-auto mb-3">
              <AlertTriangle className="w-6 h-6 text-rose-400" />
            </div>

            <h3 className="text-lg font-bold text-white mb-2">
              Are you sure you want to delete this batch?
            </h3>
            <p className="text-xs text-slate-300 mb-6">
              This batch will be permanently removed from the public Physics Wallah section.
            </p>

            <div className="flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => setIsDeletingId(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-white/10"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 transition-colors cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
