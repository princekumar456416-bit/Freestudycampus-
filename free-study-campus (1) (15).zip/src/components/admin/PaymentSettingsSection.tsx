import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { useTheme } from '../../context/ThemeContext';
import {
  getCachedAuthConfig,
  subscribeAuthConfig,
  getLatestAuthConfig,
  setSupabasePaymentSettings,
} from '../../services/authConfigService';
import { SAVED_PAYMENT_CONFIG } from '../../services/savedPaymentFallback';
import { compressAndCropBatchLogo } from '../../utils/imageUtils';
import { useToast } from './Toast';
import {
  QrCode,
  Upload,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Save,
  Loader2,
  Send,
  HelpCircle,
  IndianRupee,
  AtSign,
  FileText,
} from 'lucide-react';

export const PaymentSettingsSection: React.FC = () => {
  const { config } = useTheme();
  const { showToast } = useToast();

  // State initialized from local cache & saved payment config to prevent default value flickering
  const [feeText, setFeeText] = useState(() => getCachedAuthConfig().feeText || SAVED_PAYMENT_CONFIG.feeText);
  const [feeAmount, setFeeAmount] = useState<number>(() => getCachedAuthConfig().feeAmount || SAVED_PAYMENT_CONFIG.feeAmount);
  const [upiId, setUpiId] = useState(() => getCachedAuthConfig().upiId || SAVED_PAYMENT_CONFIG.upiId);
  const [qrImageUrl, setQrImageUrl] = useState(() => getCachedAuthConfig().qrImageUrl || SAVED_PAYMENT_CONFIG.qrImageUrl);
  const [paymentInstructions, setPaymentInstructions] = useState(
    () =>
      getCachedAuthConfig().paymentInstructions ||
      'Scan QR code, pay the verification fee, and send screenshot to our Telegram Bot to receive your account credentials instantly.'
  );
  const [telegramBotUrl, setTelegramBotUrl] = useState(
    () => getCachedAuthConfig().telegramBotUrl || 'https://t.me/Freestudycampusbot'
  );
  const [telegramBotHandle, setTelegramBotHandle] = useState(
    () => getCachedAuthConfig().telegramBotHandle || '@Freestudycampusbot'
  );

  // Dynamic preview for generated QR when custom QR is not uploaded
  const [previewGeneratedQr, setPreviewGeneratedQr] = useState<string>('');

  // UI state
  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingQr, setIsUploadingQr] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState('');
  const [saveError, setSaveError] = useState('');
  const qrFileInputRef = useRef<HTMLInputElement>(null);

  // Initial direct Supabase sync on mount
  useEffect(() => {
    getLatestAuthConfig()
      .then((live) => {
        if (live) {
          if (live.feeText !== undefined) setFeeText(live.feeText);
          if (typeof live.feeAmount === 'number') setFeeAmount(live.feeAmount);
          if (live.upiId !== undefined) setUpiId(live.upiId);
          if (live.qrImageUrl !== undefined) setQrImageUrl(live.qrImageUrl);
          if (live.paymentInstructions !== undefined) {
            setPaymentInstructions(live.paymentInstructions);
          }
          if (live.telegramBotUrl !== undefined) setTelegramBotUrl(live.telegramBotUrl);
          if (live.telegramBotHandle !== undefined) {
            setTelegramBotHandle(live.telegramBotHandle);
          }
        }
      })
      .catch((err) => {
        console.warn('Initial payment config fetch notice:', err);
      });
  }, []);

  // Real-time listener for central Supabase payment settings
  useEffect(() => {
    const unsubscribe = subscribeAuthConfig((liveData) => {
      if (liveData && !isSaving) {
        if (liveData.feeText !== undefined) setFeeText(liveData.feeText);
        if (typeof liveData.feeAmount === 'number') setFeeAmount(liveData.feeAmount);
        if (liveData.upiId !== undefined) setUpiId(liveData.upiId);
        if (liveData.qrImageUrl !== undefined) setQrImageUrl(liveData.qrImageUrl);
        if (liveData.paymentInstructions !== undefined) {
          setPaymentInstructions(liveData.paymentInstructions);
        }
        if (liveData.telegramBotUrl !== undefined) setTelegramBotUrl(liveData.telegramBotUrl);
        if (liveData.telegramBotHandle !== undefined) {
          setTelegramBotHandle(liveData.telegramBotHandle);
        }
      }
    });

    return () => {
      unsubscribe();
    };
  }, [isSaving]);

  // Generate dynamic QR preview if custom QR is not uploaded
  useEffect(() => {
    if (qrImageUrl) {
      setPreviewGeneratedQr(qrImageUrl);
      return;
    }

    const cleanUpi = upiId.trim() || '77630159@ybl';
    const numAmount =
      typeof feeAmount === 'number' && !isNaN(feeAmount)
        ? feeAmount
        : parseFloat(String(feeText).replace(/[^\d.]/g, '')) || 49;

    const upiUrl = `upi://pay?pa=${encodeURIComponent(cleanUpi)}&pn=${encodeURIComponent(
      'FREE STUDY CAMPUS'
    )}&am=${encodeURIComponent(numAmount.toFixed(2))}&cu=INR&tn=${encodeURIComponent(
      'Student Access'
    )}`;

    QRCode.toDataURL(upiUrl, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 320,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    })
      .then((url) => {
        setPreviewGeneratedQr(url);
      })
      .catch((err) => {
        console.warn('QR preview error:', err);
      });
  }, [qrImageUrl, upiId, feeAmount, feeText]);

  // Handle QR upload with immediate Supabase persistence
  const handleQrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingQr(true);
    setSaveError('');
    try {
      const compressedDataUrl = await compressAndCropBatchLogo(file, 400, 0.88);
      setQrImageUrl(compressedDataUrl);

      // Auto-save uploaded QR directly to Supabase so it persists permanently
      await setSupabasePaymentSettings({ qrImageUrl: compressedDataUrl });
      showToast('Payment QR Code uploaded and saved to Supabase permanently!', 'success');
      setSaveSuccess('Payment QR Code uploaded and saved successfully!');
      setTimeout(() => setSaveSuccess(''), 4000);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to process QR image';
      setSaveError(msg);
      showToast(msg, 'error');
    } finally {
      setIsUploadingQr(false);
      if (qrFileInputRef.current) {
        qrFileInputRef.current.value = '';
      }
    }
  };

  // Handle Reset to Default UPI QR
  const handleResetToDefaultQr = async () => {
    setQrImageUrl('');
    try {
      await setSupabasePaymentSettings({ qrImageUrl: '' });
      showToast('Reset to auto-generated UPI QR code and saved to Supabase.', 'info');
      setSaveSuccess('Reset to auto-generated UPI QR code successfully!');
      setTimeout(() => setSaveSuccess(''), 4000);
    } catch {
      showToast('Failed to reset QR code', 'error');
    }
  };

  // Handle Save All Payment Settings
  const handleSavePaymentSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveSuccess('');
    setSaveError('');

    const cleanFeeText = feeText.trim() || '₹49';
    const cleanUpi = upiId.trim() || '77630159@ybl';
    const cleanBotUrl = telegramBotUrl.trim() || 'https://t.me/Freestudycampusbot';
    const cleanBotHandle = telegramBotHandle.trim() || '@Freestudycampusbot';
    const cleanInstructions = paymentInstructions.trim();

    const parsedNum = parseFloat(cleanFeeText.replace(/[^\d.]/g, '')) || feeAmount || 49;

    try {
      const res = await setSupabasePaymentSettings({
        feeText: cleanFeeText,
        feeAmount: parsedNum,
        upiId: cleanUpi,
        qrImageUrl,
        paymentInstructions: cleanInstructions,
        telegramBotUrl: cleanBotUrl,
        telegramBotHandle: cleanBotHandle,
      });

      if (res.success) {
        setSaveSuccess('Payment settings saved and published to student screens successfully!');
        showToast('Payment settings updated and persisted successfully!', 'success');
      } else {
        setSaveError(res.error || 'Failed to update payment settings.');
        showToast(res.error || 'Save failed', 'error');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Database error while saving payment settings';
      setSaveError(msg);
      showToast(msg, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <form onSubmit={handleSavePaymentSettings} className="flex flex-col gap-6 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">💳</span>
            <h3 className="text-lg sm:text-xl font-bold text-white font-display tracking-tight">
              Payment Settings
            </h3>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
              Gateway &amp; UPI
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Configure student payment QR code, UPI ID, fee amount, instructions, and Telegram verification contact.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="text-xs text-slate-400">Current Fee:</span>
          <span className="text-xs font-black text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/20 font-mono">
            {feeText || `₹${feeAmount}`}
          </span>
        </div>
      </div>

      {/* Success Notification */}
      {saveSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-start gap-3 text-emerald-300 text-xs animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400 mt-0.5" />
          <div className="flex flex-col gap-0.5">
            <span className="font-bold text-emerald-200">Settings Persisted</span>
            <span>{saveSuccess}</span>
          </div>
        </div>
      )}

      {/* Error Notification */}
      {saveError && (
        <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-start gap-3 text-rose-300 text-xs animate-in fade-in">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-400 mt-0.5" />
          <div className="flex flex-col gap-0.5">
            <span className="font-bold text-rose-200">Save Error</span>
            <span>{saveError}</span>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 1. PAYMENT QR CODE CONFIGURATION                         */}
      {/* ======================================================== */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white/[0.03] border border-white/10 flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <QrCode className="w-4 h-4 text-cyan-400" />
          <h4 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider">
            1. Payment QR Code
          </h4>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-6 pt-1">
          {/* QR Preview Box */}
          <div className="p-3 bg-white rounded-2xl shadow-xl border border-slate-200 flex flex-col items-center justify-center shrink-0">
            {previewGeneratedQr ? (
              <img
                src={previewGeneratedQr}
                alt="Payment QR Preview"
                className="w-40 h-40 object-contain rounded-lg"
              />
            ) : (
              <div className="w-40 h-40 flex items-center justify-center bg-slate-100 rounded-lg">
                <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
              </div>
            )}
            <span className="text-[10px] font-bold text-slate-700 mt-2 font-mono">
              {qrImageUrl ? 'Custom Uploaded QR' : 'Auto-Generated UPI QR'}
            </span>
          </div>

          {/* QR Controls */}
          <div className="flex-1 flex flex-col gap-3 text-xs">
            <p className="text-slate-300 leading-relaxed">
              Students scan this QR code on the login page to pay their verification fee. You can upload your own custom merchant/PhonePe/GPay QR code image or use the auto-generated UPI QR code.
            </p>

            <div className="flex flex-wrap items-center gap-2.5 pt-1">
              <input
                type="file"
                ref={qrFileInputRef}
                onChange={handleQrUpload}
                accept="image/png, image/jpeg, image/webp"
                className="hidden"
              />

              <button
                type="button"
                disabled={isUploadingQr}
                onClick={() => qrFileInputRef.current?.click()}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs text-white cursor-pointer shadow-md hover:brightness-110 transition-all disabled:opacity-50"
                style={{ backgroundColor: config.primaryColor }}
              >
                {isUploadingQr ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                ) : (
                  <Upload className="w-3.5 h-3.5 text-white" />
                )}
                <span>Upload New QR Image</span>
              </button>

              {qrImageUrl && (
                <button
                  type="button"
                  onClick={handleResetToDefaultQr}
                  className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset to Auto-Generated QR</span>
                </button>
              )}
            </div>

            <span className="text-[11px] text-slate-400">
              {qrImageUrl
                ? 'A custom uploaded QR image is currently saved.'
                : `Currently generating dynamic high-resolution QR for UPI ID "${upiId}" and amount "${feeText}".`}
            </span>
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 2 & 3. UPI ID & PAYMENT AMOUNT                           */}
      {/* ======================================================== */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* UPI ID */}
        <div className="p-5 rounded-3xl bg-white/[0.03] border border-white/10 flex flex-col gap-2.5">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <AtSign className="w-3.5 h-3.5 text-red-400" />
            <span>2. Payment UPI ID (VPA) *</span>
          </label>
          <input
            type="text"
            required
            value={upiId}
            onChange={(e) => setUpiId(e.target.value.trim())}
            placeholder="e.g. 77630159@ybl"
            className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] font-mono transition-all"
          />
          <span className="text-[10px] text-slate-400">
            UPI ID students will see beneath the QR scanner.
          </span>
        </div>

        {/* Amount */}
        <div className="p-5 rounded-3xl bg-white/[0.03] border border-white/10 flex flex-col gap-2.5">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <IndianRupee className="w-3.5 h-3.5 text-red-400" />
            <span>3. Payment Amount / Fee *</span>
          </label>
          <input
            type="text"
            required
            value={feeText}
            onChange={(e) => {
              setFeeText(e.target.value);
              const num = parseFloat(e.target.value.replace(/[^\d.]/g, ''));
              if (!isNaN(num)) setFeeAmount(num);
            }}
            placeholder="e.g. ₹49"
            className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] font-mono font-bold transition-all"
          />
          <span className="text-[10px] text-slate-400">
            Amount shown to students and embedded in the QR code.
          </span>
        </div>
      </div>

      {/* ======================================================== */}
      {/* 4. PAYMENT INSTRUCTIONS                                  */}
      {/* ======================================================== */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white/[0.03] border border-white/10 flex flex-col gap-2.5">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
          <FileText className="w-3.5 h-3.5 text-red-400" />
          <span>4. Payment Instructions for Students</span>
        </label>
        <textarea
          rows={3}
          value={paymentInstructions}
          onChange={(e) => setPaymentInstructions(e.target.value)}
          placeholder="Enter instructions for students (e.g. Scan QR code, pay fee, and send screenshot to our Telegram Bot...)"
          className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] leading-relaxed transition-all resize-none font-sans"
        />
        <span className="text-[10px] text-slate-400">
          Displayed above the payment QR on the student login screen.
        </span>
      </div>

      {/* ======================================================== */}
      {/* 5. TELEGRAM CONTACT & VERIFICATION BOT                   */}
      {/* ======================================================== */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white/[0.03] border border-white/10 flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <Send className="w-4 h-4 text-red-400" />
          <h4 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider">
            5. Payment Contact / Telegram Bot
          </h4>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs text-slate-300 font-semibold">Telegram Bot Handle</label>
            <input
              type="text"
              value={telegramBotHandle}
              onChange={(e) => setTelegramBotHandle(e.target.value.trim())}
              placeholder="e.g. @Freestudycampusbot"
              className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] font-mono transition-all"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs text-slate-300 font-semibold">Telegram Bot Direct Link (URL)</label>
            <input
              type="url"
              value={telegramBotUrl}
              onChange={(e) => setTelegramBotUrl(e.target.value.trim())}
              placeholder="e.g. https://t.me/Freestudycampusbot"
              className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500 focus:shadow-[0_0_14px_rgba(220,38,38,0.35)] font-mono transition-all"
            />
          </div>
        </div>
      </div>

      {/* ======================================================== */}
      {/* SAVE BUTTON                                              */}
      {/* ======================================================== */}
      <div className="pt-2 flex items-center justify-between gap-4">
        <span className="text-xs text-slate-400">
          Changes will persist to Supabase and update immediately on student screens.
        </span>

        <button
          type="submit"
          disabled={isSaving}
          className="btn-primary-red flex items-center justify-center gap-2 py-3.5 px-8 rounded-2xl font-bold text-white text-xs sm:text-sm transition-all active:scale-95 shadow-xl cursor-pointer shrink-0 disabled:opacity-50"
        >
          {isSaving ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span>Saving Settings...</span>
            </>
          ) : (
            <>
              <Save className="w-4 h-4 text-white" />
              <span>Save / Update Payment Settings</span>
            </>
          )}
        </button>
      </div>
    </form>
  );
};
