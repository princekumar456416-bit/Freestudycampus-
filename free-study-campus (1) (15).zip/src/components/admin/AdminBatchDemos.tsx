import React, { useState, useEffect } from 'react';
import {
  Video,
  Plus,
  ArrowUp,
  ArrowDown,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Play,
  X,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  RefreshCw,
  Search,
  Sparkles,
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useToast } from './Toast';
import {
  BatchDemo,
  parseYouTubeVideo,
  createBatchDemo,
  updateBatchDemo,
  deleteBatchDemo,
  reorderBatchDemos,
  subscribeBatchDemos,
} from '../../services/batchDemoService';
import { BatchDemoPlayerModal } from '../BatchDemoPlayerModal';

const PLATFORM_PRESETS = [
  'Physics Wallah',
  'Target Board',
  'Unacademy',
  'NextToppers',
  'Vidyakul',
  'Allen Career Institute',
  'Khan Academy',
  'Other Platform',
];

export const AdminBatchDemos: React.FC = () => {
  const { config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';
  const { showToast } = useToast();

  const [demos, setDemos] = useState<BatchDemo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  // Add / Edit Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDemo, setEditingDemo] = useState<BatchDemo | null>(null);
  const [title, setTitle] = useState('');
  const [platformName, setPlatformName] = useState(PLATFORM_PRESETS[0]);
  const [customPlatform, setCustomPlatform] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [description, setDescription] = useState('');
  const [isAvailable, setIsAvailable] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  // Delete confirmation
  const [demoToDelete, setDemoToDelete] = useState<BatchDemo | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Preview Playback Modal
  const [previewDemo, setPreviewDemo] = useState<BatchDemo | null>(null);

  useEffect(() => {
    setIsLoading(true);
    const unsubscribe = subscribeBatchDemos((allDemos) => {
      setDemos(allDemos);
      setIsLoading(false);
    }, true); // include disabled in Admin

    return () => {
      unsubscribe();
    };
  }, []);

  const openAddModal = () => {
    setEditingDemo(null);
    setTitle('');
    setPlatformName(PLATFORM_PRESETS[0]);
    setCustomPlatform('');
    setVideoUrl('');
    setDescription('');
    setIsAvailable(true);
    setFormError('');
    setIsModalOpen(true);
  };

  const openEditModal = (demo: BatchDemo) => {
    setEditingDemo(demo);
    setTitle(demo.title);
    if (PLATFORM_PRESETS.includes(demo.platformName)) {
      setPlatformName(demo.platformName);
      setCustomPlatform('');
    } else {
      setPlatformName('Other Platform');
      setCustomPlatform(demo.platformName);
    }
    setVideoUrl(demo.videoUrl);
    setDescription(demo.description || '');
    setIsAvailable(demo.isAvailable);
    setFormError('');
    setIsModalOpen(true);
  };

  // Video URL live preview parse
  const parsedPreview = parseYouTubeVideo(videoUrl);

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setFormError('Please enter a demo title (e.g. PHYSICS WALLAH DEMO).');
      return;
    }
    if (!videoUrl.trim()) {
      setFormError('Please enter a valid YouTube video URL.');
      return;
    }
    if (!parsedPreview.isValid) {
      setFormError(parsedPreview.error || 'Invalid YouTube video URL format.');
      return;
    }

    const finalPlatform =
      platformName === 'Other Platform'
        ? customPlatform.trim() || 'Free Study Campus'
        : platformName;

    setIsSubmitting(true);
    setFormError('');

    try {
      if (editingDemo) {
        await updateBatchDemo(editingDemo.id, {
          title: title.trim(),
          platformName: finalPlatform,
          videoUrl: videoUrl.trim(),
          description: description.trim(),
          isAvailable,
        });
        showToast(`Demo "${title.trim()}" updated successfully!`, 'success');
      } else {
        await createBatchDemo({
          title: title.trim(),
          platformName: finalPlatform,
          videoUrl: videoUrl.trim(),
          description: description.trim(),
          isAvailable,
        });
        showToast(`Demo "${title.trim()}" created and synced!`, 'success');
      }
      setIsModalOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error saving batch demo';
      setFormError(msg);
      showToast(msg, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleStatus = async (demo: BatchDemo) => {
    try {
      await updateBatchDemo(demo.id, { isAvailable: !demo.isAvailable });
      showToast(
        `Demo "${demo.title}" is now ${!demo.isAvailable ? 'Enabled' : 'Disabled'}`,
        'success'
      );
    } catch {
      showToast('Failed to update status', 'error');
    }
  };

  const handleMove = async (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= demos.length) return;

    const reordered = [...demos];
    const temp = reordered[index];
    reordered[index] = reordered[targetIdx];
    reordered[targetIdx] = temp;

    const orderedIds = reordered.map((d) => d.id);
    try {
      await reorderBatchDemos(orderedIds);
      showToast('Demo order updated successfully', 'success');
    } catch {
      showToast('Failed to reorder demos', 'error');
    }
  };

  const confirmDelete = async () => {
    if (!demoToDelete) return;
    setIsDeleting(true);
    try {
      await deleteBatchDemo(demoToDelete.id);
      showToast(`Demo "${demoToDelete.title}" deleted permanently`, 'success');
      setDemoToDelete(null);
    } catch {
      showToast('Failed to delete demo', 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredDemos = demos.filter((d) => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      d.title.toLowerCase().includes(q) ||
      d.platformName.toLowerCase().includes(q) ||
      (d.description && d.description.toLowerCase().includes(q))
    );
  });

  return (
    <div className="flex flex-col gap-6 animate-in fade-in duration-200">
      {/* 1. SECTION HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">🎬</span>
            <h2 className="text-lg sm:text-xl font-bold text-white font-display tracking-tight">
              Manage Batch Demos
            </h2>
            <span
              className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border"
              style={{
                backgroundColor: config.badgeBg,
                color: themeColor,
                borderColor: config.borderColor,
              }}
            >
              Student Demos
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Publish YouTube Unlisted demo videos for students. Changes synchronize automatically to all devices.
          </p>
        </div>

        <button
          type="button"
          onClick={openAddModal}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all active:scale-95 cursor-pointer shadow-lg hover:brightness-110 self-start sm:self-auto shrink-0"
          style={{
            backgroundColor: themeColor,
            color: '#ffffff',
            boxShadow: `0 0 15px ${config.accentGlow}`,
          }}
        >
          <Plus className="w-4 h-4" />
          <span>+ Add Demo Option</span>
        </button>
      </div>

      {/* 2. SEARCH & STATS BAR */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search demos by title or platform..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-red-500/50"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-0.5 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="font-mono">{demos.length} Total Demos</span>
          <span>•</span>
          <span className="text-emerald-400 font-bold">
            {demos.filter((d) => d.isAvailable).length} Active
          </span>
          <span>•</span>
          <span className="text-rose-400 font-bold">
            {demos.filter((d) => !d.isAvailable).length} Disabled
          </span>
        </div>
      </div>

      {/* 3. DEMOS LIST */}
      {isLoading ? (
        <div className="py-20 flex flex-col items-center justify-center gap-2 text-slate-400 text-xs">
          <RefreshCw className="w-6 h-6 animate-spin" style={{ color: themeColor }} />
          <span>Loading batch demos from Supabase...</span>
        </div>
      ) : filteredDemos.length === 0 ? (
        <div className="p-10 rounded-3xl glass-panel border border-white/10 flex flex-col items-center justify-center text-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-center text-slate-500">
            <Video className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-white">No Batch Demos Found</h3>
          <p className="text-xs text-slate-400 max-w-sm">
            {searchQuery
              ? `No demos matched "${searchQuery}". Clear your search query.`
              : 'Add your first batch demo (e.g. Physics Wallah Demo, Target Board Demo).'}
          </p>
          {!searchQuery && (
            <button
              type="button"
              onClick={openAddModal}
              className="mt-2 px-4 py-2 rounded-xl text-xs font-bold text-white transition-all cursor-pointer shadow-md"
              style={{ backgroundColor: themeColor }}
            >
              + Create First Demo
            </button>
          )}
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {filteredDemos.map((demo, index) => {
            const thumbUrl = demo.videoId
              ? `https://img.youtube.com/vi/${demo.videoId}/hqdefault.jpg`
              : null;

            return (
              <div
                key={demo.id}
                className={`p-4 sm:p-5 rounded-3xl glass-panel border transition-all duration-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                  demo.isAvailable
                    ? 'border-white/10 hover:border-red-500/40 bg-white/[0.02]'
                    : 'border-rose-500/20 bg-rose-500/[0.02] opacity-75'
                }`}
              >
                {/* Left: Reorder Arrows & Thumbnail & Title */}
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  {/* Reorder Buttons */}
                  <div className="flex flex-col gap-1 shrink-0">
                    <button
                      type="button"
                      disabled={index === 0}
                      onClick={() => handleMove(index, 'up')}
                      className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                      title="Move Up"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={index === demos.length - 1}
                      onClick={() => handleMove(index, 'down')}
                      className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
                      title="Move Down"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Thumbnail / Play Preview Trigger */}
                  <div
                    onClick={() => setPreviewDemo(demo)}
                    className="relative w-24 h-16 sm:w-28 sm:h-18 rounded-2xl overflow-hidden bg-black/80 border border-white/15 shrink-0 group cursor-pointer shadow-md"
                    title="Click to Preview Playback"
                  >
                    {thumbUrl ? (
                      <img
                        src={thumbUrl}
                        alt={demo.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-zinc-600">
                        <Video className="w-5 h-5" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 flex items-center justify-center transition-colors">
                      <div
                        className="w-7 h-7 rounded-full flex items-center justify-center shadow-lg"
                        style={{ backgroundColor: themeColor }}
                      >
                        <Play className="w-3 h-3 text-white fill-white ml-0.5" />
                      </div>
                    </div>
                  </div>

                  {/* Details */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className="px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider text-white"
                        style={{ backgroundColor: themeColor }}
                      >
                        {demo.platformName}
                      </span>
                      <span
                        className={`text-[9px] font-bold px-2 py-0.5 rounded-md ${
                          demo.isAvailable
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}
                      >
                        {demo.isAvailable ? 'Live for Students' : 'Disabled (Hidden)'}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white truncate mt-1">{demo.title}</h3>

                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5 truncate font-mono">
                      <span className="truncate max-w-xs">{demo.videoUrl}</span>
                    </div>
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  {/* Test Playback button */}
                  <button
                    type="button"
                    onClick={() => setPreviewDemo(demo)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-xs font-semibold transition-all cursor-pointer"
                    title="Test Video Playback"
                  >
                    <Play className="w-3 h-3 text-red-400" />
                    <span>Test Video</span>
                  </button>

                  {/* Enable / Disable toggle */}
                  <button
                    type="button"
                    onClick={() => handleToggleStatus(demo)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
                      demo.isAvailable
                        ? 'bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border-amber-500/30'
                        : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    }`}
                    title={demo.isAvailable ? 'Disable Demo for Students' : 'Enable Demo for Students'}
                  >
                    {demo.isAvailable ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{demo.isAvailable ? 'Disable' : 'Enable'}</span>
                  </button>

                  {/* Edit button */}
                  <button
                    type="button"
                    onClick={() => openEditModal(demo)}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer"
                    title="Edit Demo"
                  >
                    <Edit2 className="w-3.5 h-3.5 text-cyan-400" />
                  </button>

                  {/* Delete button */}
                  <button
                    type="button"
                    onClick={() => setDemoToDelete(demo)}
                    className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 transition-all cursor-pointer"
                    title="Delete Demo Option"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 4. ADD / EDIT DEMO MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div
            className="relative w-full max-w-lg rounded-3xl p-6 sm:p-7 border shadow-2xl overflow-hidden flex flex-col gap-4 max-h-[90vh] overflow-y-auto"
            style={{
              backgroundColor: '#0c101a',
              borderColor: config.borderColor,
              boxShadow: `0 0 35px -5px ${config.accentGlow}`,
            }}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <div
                  className="w-10 h-10 rounded-2xl flex items-center justify-center shadow-lg"
                  style={{ backgroundColor: `${themeColor}22` }}
                >
                  <Video className="w-5 h-5" style={{ color: themeColor }} />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-display">
                    {editingDemo ? 'Edit Batch Demo Option' : 'Add New Batch Demo'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Paste YouTube Unlisted or public video URL for student demo playback
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmitForm} className="flex flex-col gap-4">
              {/* Demo Title */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5">
                  Demo Title <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. PHYSICS WALLAH DEMO, UNACADEMY DEMO..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500/50"
                />
              </div>

              {/* Platform Selector */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5">
                  Platform Name <span className="text-red-400">*</span>
                </label>
                <select
                  value={platformName}
                  onChange={(e) => setPlatformName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#121622] border border-white/10 text-xs text-white focus:outline-none focus:border-red-500/50"
                >
                  {PLATFORM_PRESETS.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
                {platformName === 'Other Platform' && (
                  <input
                    type="text"
                    required
                    value={customPlatform}
                    onChange={(e) => setCustomPlatform(e.target.value)}
                    placeholder="Enter custom platform name..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500/50 mt-2"
                  />
                )}
              </div>

              {/* YouTube Video URL */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5 flex items-center justify-between">
                  <span>YouTube Video URL (Unlisted / Public) <span className="text-red-400">*</span></span>
                  {parsedPreview.isValid && (
                    <span className="text-emerald-400 text-[10px] flex items-center gap-1 font-bold">
                      <CheckCircle2 className="w-3 h-3" /> Valid YouTube Link
                    </span>
                  )}
                </label>
                <input
                  type="text"
                  required
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  placeholder="https://youtu.be/... or https://www.youtube.com/watch?v=..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500/50 font-mono"
                />

                {/* Instant Video Preview Box */}
                {parsedPreview.isValid && parsedPreview.thumbnailUrl && (
                  <div className="mt-2.5 p-3 rounded-2xl bg-black/40 border border-white/10 flex items-center gap-3">
                    <img
                      src={parsedPreview.thumbnailUrl}
                      alt="Thumbnail Preview"
                      className="w-20 h-12 object-cover rounded-xl border border-white/10"
                    />
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] text-emerald-400 font-bold block">
                        Video ID: {parsedPreview.videoId}
                      </span>
                      <span className="text-xs text-slate-300 truncate block mt-0.5">
                        Ready for embedded player streaming
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Description */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5">
                  Optional Description / Notes
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Complete chapter overview, faculty introduction, and handwritten formula tour."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500/50 resize-none"
                />
              </div>

              {/* Enabled / Disabled Toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.03] border border-white/5">
                <div>
                  <span className="text-xs font-bold text-white block">Status for Students</span>
                  <span className="text-[11px] text-slate-400">
                    {isAvailable ? 'Visible to all students on Demo page' : 'Hidden from students'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAvailable(!isAvailable)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                    isAvailable
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                  }`}
                >
                  {isAvailable ? 'Enabled' : 'Disabled'}
                </button>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl text-xs font-bold text-white transition-all active:scale-95 cursor-pointer shadow-lg disabled:opacity-50 flex items-center gap-2"
                  style={{ backgroundColor: themeColor }}
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <span>{editingDemo ? 'Update Demo' : 'Create & Publish Demo'}</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 5. DELETE CONFIRMATION MODAL */}
      {demoToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl bg-[#0c101a] border border-rose-500/30 p-6 shadow-2xl flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Delete Batch Demo?</h3>
                <p className="text-xs text-slate-400">This action cannot be undone.</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to permanently delete <span className="font-bold text-white">"{demoToDelete.title}"</span>?
              It will immediately stop appearing on the Student Demo page across all devices.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDemoToDelete(null)}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={confirmDelete}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all cursor-pointer shadow-lg shadow-rose-900/30 disabled:opacity-50"
              >
                {isDeleting ? 'Deleting...' : 'Delete Permanently'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. PREVIEW PLAYBACK MODAL */}
      <BatchDemoPlayerModal
        demo={previewDemo}
        isOpen={Boolean(previewDemo)}
        onClose={() => setPreviewDemo(null)}
      />
    </div>
  );
};
