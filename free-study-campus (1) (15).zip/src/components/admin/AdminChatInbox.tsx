import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Search,
  MessageSquare,
  Send,
  Image as ImageIcon,
  CheckCheck,
  X,
  Maximize2,
  RefreshCw,
  ChevronLeft,
  Sparkles,
  AlertCircle,
  Trash2,
  Info,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useToast } from './Toast';
import {
  StudentUser,
  subscribeStudentUsers,
} from '../../services/studentUserService';
import {
  SupportTicket,
  SupportMessage,
  subscribeAdminTickets,
  fetchAllTicketsAdmin,
  sendAdminMessageToStudent,
  markChatAsReadByAdmin,
  getAdminUnreadCount,
  deleteSupportTicketAdmin,
} from '../../services/supportService';

interface AdminChatInboxProps {
  initialSelectedTicketId?: string | null;
  initialSelectedStudentId?: string | null;
}

interface StudentChatItem {
  student: StudentUser;
  ticket: SupportTicket | null;
  latestMessage: SupportMessage | null;
  lastActivityAt: string;
  unreadCount: number;
}

/**
 * Deterministic Telegram-style avatar gradients based on username/id
 */
function getTelegramAvatarStyle(seed: string): { background: string; color: string } {
  const gradients = [
    { background: 'linear-gradient(135deg, #e11d48 0%, #9f1239 100%)', color: '#ffffff' },
    { background: 'linear-gradient(135deg, #f97316 0%, #c2410c 100%)', color: '#ffffff' },
    { background: 'linear-gradient(135deg, #10b981 0%, #047857 100%)', color: '#ffffff' },
    { background: 'linear-gradient(135deg, #06b6d4 0%, #0e7490 100%)', color: '#ffffff' },
    { background: 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)', color: '#ffffff' },
    { background: 'linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%)', color: '#ffffff' },
    { background: 'linear-gradient(135deg, #ec4899 0%, #be185d 100%)', color: '#ffffff' },
    { background: 'linear-gradient(135deg, #6366f1 0%, #4338ca 100%)', color: '#ffffff' },
  ];
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  const index = Math.abs(hash) % gradients.length;
  return gradients[index];
}

function getInitials(name: string, username?: string): string {
  const target = (name || username || 'Student').trim();
  const parts = target.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return target.substring(0, 2).toUpperCase();
}

function formatTelegramTime(isoString: string): string {
  try {
    const d = new Date(isoString);
    const now = new Date();
    const isToday =
      d.getDate() === now.getDate() &&
      d.getMonth() === now.getMonth() &&
      d.getFullYear() === now.getFullYear();

    if (isToday) {
      return d.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
      });
    }

    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    const isYesterday =
      d.getDate() === yesterday.getDate() &&
      d.getMonth() === yesterday.getMonth() &&
      d.getFullYear() === yesterday.getFullYear();

    if (isYesterday) return 'Yesterday';

    return d.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
    });
  } catch {
    return '';
  }
}

export const AdminChatInbox: React.FC<AdminChatInboxProps> = ({
  initialSelectedTicketId,
  initialSelectedStudentId,
}) => {
  const { config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';
  const { showToast } = useToast();

  const [students, setStudents] = useState<StudentUser[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Active selected student for conversation view
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'unread'>('all');

  // Conversation input state
  const [inputText, setInputText] = useState('');
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const [selectedPhotoName, setSelectedPhotoName] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Modals & UI toggles
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);
  const [showStudentInfo, setShowStudentInfo] = useState(false);
  const [ticketToDelete, setTicketToDelete] = useState<SupportTicket | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Quick preset replies for fast Admin response
  const quickReplies = [
    'Fee slip verified! Access unlocked.',
    'Please share your registered email/phone.',
    'Checking with the campus team now.',
    'Please refresh your app to view the batch.',
  ];

  // Subscribe to all registered students in real-time
  useEffect(() => {
    const unsubStudents = subscribeStudentUsers((list) => {
      setStudents(list);
    });

    const unsubTickets = subscribeAdminTickets((allTickets) => {
      setTickets(allTickets);
      setIsLoading(false);
    });

    return () => {
      unsubStudents();
      unsubTickets();
    };
  }, []);

  // Merge students and tickets into unified Telegram chat list items
  const chatItems: StudentChatItem[] = useMemo(() => {
    return students.map((student) => {
      const ticket =
        tickets.find(
          (t) =>
            t.studentId === student.id ||
            t.studentUsername.toLowerCase() === student.username.toLowerCase()
        ) || null;

      const latestMessage =
        ticket && Array.isArray(ticket.messages) && ticket.messages.length > 0
          ? ticket.messages[ticket.messages.length - 1]
          : null;

      const lastActivityAt =
        latestMessage?.createdAt ||
        ticket?.updatedAt ||
        student.lastLoginAt ||
        student.createdAt ||
        new Date().toISOString();

      const unreadCount = ticket ? getAdminUnreadCount(ticket) : 0;

      return {
        student,
        ticket,
        latestMessage,
        lastActivityAt,
        unreadCount,
      };
    }).sort((a, b) => {
      if (a.unreadCount > 0 && b.unreadCount === 0) return -1;
      if (b.unreadCount > 0 && a.unreadCount === 0) return 1;
      return new Date(b.lastActivityAt).getTime() - new Date(a.lastActivityAt).getTime();
    });
  }, [students, tickets]);

  // Auto-select student if initial params provided
  useEffect(() => {
    if (initialSelectedStudentId) {
      setSelectedStudentId(initialSelectedStudentId);
    } else if (initialSelectedTicketId && tickets.length > 0) {
      const match = tickets.find((t) => t.id === initialSelectedTicketId);
      if (match?.studentId) {
        setSelectedStudentId(match.studentId);
      }
    }
  }, [initialSelectedTicketId, initialSelectedStudentId, tickets]);

  // Selected item object
  const activeChatItem = useMemo(() => {
    if (!selectedStudentId) return null;
    return chatItems.find((item) => item.student.id === selectedStudentId) || null;
  }, [selectedStudentId, chatItems]);

  // When opening a chat, mark it as read by Admin
  useEffect(() => {
    if (activeChatItem?.ticket?.id) {
      markChatAsReadByAdmin(activeChatItem.ticket.id);
    }
  }, [activeChatItem?.ticket?.id, activeChatItem?.latestMessage?.id]);

  // Scroll messages to bottom on conversation change or new message
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    if (activeChatItem) {
      scrollToBottom('auto');
    }
  }, [activeChatItem?.student.id, activeChatItem?.ticket?.messages?.length]);

  // Filtered chat items based on search query and unread toggle
  const filteredChatItems = useMemo(() => {
    return chatItems.filter((item) => {
      if (activeFilter === 'unread' && item.unreadCount === 0) {
        return false;
      }
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().replace(/^@/, '');
      const nameMatch = item.student.name.toLowerCase().includes(q);
      const userMatch = item.student.username.toLowerCase().includes(q);
      const textMatch = item.latestMessage?.text?.toLowerCase().includes(q);
      return nameMatch || userMatch || textMatch;
    });
  }, [chatItems, searchQuery, activeFilter]);

  const totalUnreadCount = useMemo(() => {
    return chatItems.reduce((acc, curr) => acc + curr.unreadCount, 0);
  }, [chatItems]);

  // Photo Selection & Compression for Admin
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file (JPG, PNG, WebP)', 'error');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      showToast('Image is too large. Please select an image under 10MB', 'error');
      return;
    }

    setSelectedPhotoName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        const maxDim = 1280;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          setSelectedPhoto(canvas.toDataURL('image/jpeg', 0.82));
        } else {
          setSelectedPhoto(reader.result as string);
        }
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Send Admin message or photo to the currently selected student
  const handleSendMessage = async (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    if (!activeChatItem) return;

    const textToSend = (customText !== undefined ? customText : inputText).trim();
    const photoToSend = selectedPhoto;

    if (!textToSend && !photoToSend) return;

    setIsSending(true);
    setErrorMessage('');
    setInputText('');
    setSelectedPhoto(null);
    setSelectedPhotoName('');

    try {
      const res = await sendAdminMessageToStudent(
        {
          id: activeChatItem.student.id,
          name: activeChatItem.student.name,
          username: activeChatItem.student.username,
          avatarUrl: activeChatItem.student.avatarUrl,
        },
        textToSend,
        photoToSend
      );

      if (res.success) {
        setTimeout(() => scrollToBottom('smooth'), 50);
      } else {
        setErrorMessage(res.error || 'Failed to send message.');
        showToast(res.error || 'Failed to send message', 'error');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error sending message';
      setErrorMessage(msg);
      showToast(msg, 'error');
    } finally {
      setIsSending(false);
      setTimeout(() => scrollToBottom('smooth'), 100);
    }
  };

  // Delete chat thread
  const handleConfirmDelete = async () => {
    if (!ticketToDelete) return;
    try {
      await deleteSupportTicketAdmin(ticketToDelete.id);
      showToast('Chat conversation cleared successfully', 'success');
      setTicketToDelete(null);
    } catch {
      showToast('Error deleting conversation', 'error');
    }
  };

  return (
    <div className="w-full flex flex-col gap-4 animate-in fade-in duration-200">
      {/* Top Banner / Stats Header */}
      <div
        className="p-4 sm:p-5 rounded-3xl border flex flex-wrap items-center justify-between gap-4 shadow-xl backdrop-blur-xl"
        style={{
          backgroundColor: 'rgba(15, 9, 14, 0.94)',
          borderColor: 'rgba(255, 46, 77, 0.22)',
          boxShadow: '0 8px 30px -4px rgba(0, 0, 0, 0.7), 0 0 25px -10px rgba(255, 46, 77, 0.25)',
        }}
      >
        <div className="flex items-center gap-3.5">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg border border-white/20"
            style={{
              background: `linear-gradient(135deg, ${themeColor} 0%, #8b001a 100%)`,
              boxShadow: `0 0 20px ${themeColor}66`,
            }}
          >
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-white font-display tracking-tight uppercase">
                STUDENT CHATS &amp; INBOX
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black tracking-wide uppercase bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>LIVE SYNC</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Direct student support &amp; ticket desk for all {students.length} registered students
            </p>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-2.5">
          {totalUnreadCount > 0 && (
            <div className="px-3.5 py-1.5 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center gap-2 shadow-lg animate-pulse">
              <span className="w-2 h-2 rounded-full bg-rose-500" />
              <span>{totalUnreadCount} Unread Message{totalUnreadCount > 1 ? 's' : ''}</span>
            </div>
          )}

          <button
            onClick={() => {
              setIsLoading(true);
              fetchAllTicketsAdmin().then((t) => {
                setTickets(t);
                setIsLoading(false);
                showToast('Chats refreshed successfully', 'success');
              });
            }}
            type="button"
            className="p-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.12] border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer shadow-sm active:scale-95"
            title="Refresh All Chats"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-rose-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Telegram-Style Split View */}
      <div
        className="h-[740px] rounded-3xl overflow-hidden border flex shadow-2xl relative"
        style={{
          backgroundColor: '#070509',
          borderColor: 'rgba(255, 255, 255, 0.1)',
        }}
      >
        {/* ========================================================================= */}
        {/* LEFT PANE: STUDENT CHAT LIST                                              */}
        {/* ========================================================================= */}
        <div
          className={`w-full lg:w-96 flex flex-col border-r border-white/10 bg-[#0e0710] shrink-0 transition-all ${
            selectedStudentId ? 'hidden lg:flex' : 'flex'
          }`}
        >
          {/* Top Search & Filter Bar */}
          <div className="p-3.5 border-b border-white/10 flex flex-col gap-2.5 bg-[#140b17]">
            {/* Search Input */}
            <div className="relative flex items-center">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search students by name or @username..."
                className="w-full pl-9 pr-8 py-2.5 rounded-2xl bg-white/[0.06] border border-transparent focus:border-rose-500/50 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none transition-all shadow-inner"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  type="button"
                  className="absolute right-2.5 p-1 text-slate-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Filter Buttons */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeFilter === 'all'
                    ? 'bg-white/15 text-white shadow-sm border border-white/10'
                    : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                }`}
              >
                All Students ({students.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveFilter('unread')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeFilter === 'unread'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                }`}
              >
                <span>Unread</span>
                {totalUnreadCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[10px] font-black">
                    {totalUnreadCount}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Student Chat List Items */}
          <div className="flex-1 overflow-y-auto divide-y divide-white/[0.04] scrollbar-thin scrollbar-thumb-white/10">
            {filteredChatItems.length === 0 ? (
              <div className="py-16 px-4 text-center flex flex-col items-center justify-center gap-2 text-slate-400">
                <MessageSquare className="w-8 h-8 text-slate-500/60" />
                <p className="text-xs font-medium">
                  {searchQuery ? 'No student matches your search.' : 'No students found.'}
                </p>
              </div>
            ) : (
              filteredChatItems.map((item) => {
                const isSelected = selectedStudentId === item.student.id;
                const avatarStyle = getTelegramAvatarStyle(item.student.username);
                const initials = getInitials(item.student.name, item.student.username);
                const isLastMsgAdmin = item.latestMessage?.sender === 'admin';

                return (
                  <button
                    key={item.student.id}
                    onClick={() => {
                      setSelectedStudentId(item.student.id);
                      if (item.ticket?.id) {
                        markChatAsReadByAdmin(item.ticket.id);
                      }
                    }}
                    type="button"
                    className={`w-full px-3.5 py-3 flex items-center gap-3 transition-all cursor-pointer text-left select-none relative group ${
                      isSelected
                        ? 'bg-white/[0.08] shadow-inner'
                        : 'hover:bg-white/[0.04]'
                    }`}
                  >
                    {/* Active Accent Indicator */}
                    {isSelected && (
                      <span
                        className="absolute left-0 top-2 bottom-2 w-1.5 rounded-r-full shadow-[0_0_10px_#ff2e4d]"
                        style={{ backgroundColor: themeColor }}
                      />
                    )}

                    {/* Student Avatar (Photo or Luxury Gradient Monogram) */}
                    <div className="relative shrink-0 ml-1">
                      {item.student.avatarUrl ? (
                        <img
                          src={item.student.avatarUrl}
                          alt={item.student.name}
                          className="w-12 h-12 rounded-2xl object-cover border border-white/20 shadow-md"
                        />
                      ) : (
                        <div
                          className="w-12 h-12 rounded-2xl flex items-center justify-center font-black text-sm tracking-wider shadow-md border border-white/20"
                          style={avatarStyle}
                        >
                          <span>{initials}</span>
                        </div>
                      )}

                      {/* Online/Active status indicator */}
                      <span
                        className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#0e0710] ${
                          item.student.status === 'active'
                            ? 'bg-[#22c55e] shadow-[0_0_8px_#22c55e]'
                            : 'bg-zinc-500'
                        }`}
                        title={item.student.status === 'active' ? 'Active Account' : 'Inactive'}
                      />
                    </div>

                    {/* Chat Content Preview */}
                    <div className="flex-1 min-w-0 flex flex-col gap-0.5">
                      {/* Top Row: Name + Time */}
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-xs sm:text-[13.5px] font-black text-white truncate">
                          {item.student.name}
                        </span>
                        {item.latestMessage && (
                          <span
                            className={`text-[10px] font-medium shrink-0 ${
                              item.unreadCount > 0 ? 'text-rose-400 font-bold' : 'text-slate-400'
                            }`}
                          >
                            {formatTelegramTime(item.latestMessage.createdAt)}
                          </span>
                        )}
                      </div>

                      {/* Username Row */}
                      <span className="text-[11px] text-rose-300/80 font-mono -mt-0.5 truncate">
                        @{item.student.username}
                      </span>

                      {/* Bottom Row: Message snippet + Unread Badge */}
                      <div className="flex items-center justify-between gap-2 mt-0.5">
                        <p className="text-[11.5px] text-slate-300 truncate leading-snug">
                          {item.latestMessage ? (
                            <>
                              {isLastMsgAdmin && (
                                <span className="text-rose-400 font-bold mr-1">You:</span>
                              )}
                              {item.latestMessage.screenshotUrl && !item.latestMessage.text && (
                                <span>📷 Photo</span>
                              )}
                              {item.latestMessage.screenshotUrl && item.latestMessage.text && (
                                <span>📷 {item.latestMessage.text}</span>
                              )}
                              {!item.latestMessage.screenshotUrl && (
                                <span>{item.latestMessage.text}</span>
                              )}
                            </>
                          ) : (
                            <span className="text-slate-500 italic">No messages yet • Tap to chat</span>
                          )}
                        </p>

                        {/* Unread Message Count Badge or Sent Checkmarks */}
                        {item.unreadCount > 0 ? (
                          <span
                            className="px-2 py-0.5 min-w-[20px] h-[20px] rounded-full text-[10px] font-black text-white flex items-center justify-center shrink-0 shadow-md animate-pulse"
                            style={{ backgroundColor: '#22c55e' }}
                          >
                            {item.unreadCount}
                          </span>
                        ) : isLastMsgAdmin ? (
                          <CheckCheck className="w-3.5 h-3.5 text-cyan-300 shrink-0 opacity-80" />
                        ) : null}
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* ========================================================================= */}
        {/* RIGHT PANE: ACTIVE CONVERSATION                                           */}
        {/* ========================================================================= */}
        <div
          className={`flex-1 flex flex-col bg-[#070509] transition-all min-w-0 ${
            selectedStudentId ? 'flex' : 'hidden lg:flex'
          }`}
        >
          {activeChatItem ? (
            <>
              {/* 1. CONVERSATION TOP BAR */}
              <header className="h-16 px-4 bg-[#140b17] border-b border-white/10 flex items-center justify-between shrink-0 shadow-md select-none">
                <div className="flex items-center gap-3 min-w-0">
                  {/* Mobile Back Button to list */}
                  <button
                    onClick={() => setSelectedStudentId(null)}
                    type="button"
                    className="lg:hidden p-2 -ml-2 rounded-2xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                    title="Back to chat list"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>

                  {/* Student Avatar */}
                  <div className="relative shrink-0">
                    {activeChatItem.student.avatarUrl ? (
                      <img
                        src={activeChatItem.student.avatarUrl}
                        alt={activeChatItem.student.name}
                        className="w-11 h-11 rounded-2xl object-cover border border-white/20 shadow-md"
                      />
                    ) : (
                      <div
                        className="w-11 h-11 rounded-2xl flex items-center justify-center font-black text-xs tracking-wider shadow-md border border-white/20"
                        style={getTelegramAvatarStyle(activeChatItem.student.username)}
                      >
                        <span>{getInitials(activeChatItem.student.name, activeChatItem.student.username)}</span>
                      </div>
                    )}
                    <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-[#22c55e] border-2 border-[#140b17]" />
                  </div>

                  {/* Student Details */}
                  <div className="flex flex-col min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-sm font-black text-white truncate">
                        {activeChatItem.student.name}
                      </h3>
                      <span className="text-[11px] font-mono text-rose-300 truncate">
                        (@{activeChatItem.student.username})
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#22c55e]" />
                      <span className="text-emerald-400 font-semibold">Registered Student</span>
                      {activeChatItem.student.activeDeviceInfo && (
                        <span className="hidden sm:inline text-slate-400">
                          • {activeChatItem.student.activeDeviceInfo}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right Actions */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowStudentInfo((prev) => !prev)}
                    type="button"
                    className="p-2 rounded-2xl bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-slate-300 hover:text-white transition-all cursor-pointer"
                    title="Student Information"
                  >
                    <Info className="w-4 h-4" />
                  </button>

                  {activeChatItem.ticket && (
                    <button
                      onClick={() => setTicketToDelete(activeChatItem.ticket)}
                      type="button"
                      className="p-2 rounded-2xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 transition-all cursor-pointer"
                      title="Clear Conversation History"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </header>

              {/* Student Profile Info Drawer (Toggled) */}
              {showStudentInfo && (
                <div className="p-4 bg-[#180e1b] border-b border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs animate-in slide-in-from-top-2 duration-150 shadow-md">
                  <div className="flex flex-wrap items-center gap-6">
                    <div>
                      <span className="text-slate-400 text-[10px] block uppercase font-bold">Student ID</span>
                      <span className="font-mono text-white text-xs">{activeChatItem.student.id}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] block uppercase font-bold">Device Lock Status</span>
                      <span className="text-emerald-400 font-semibold">
                        {activeChatItem.student.activeDeviceId ? 'Locked (1 Device Active)' : 'Not Bound'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] block uppercase font-bold">Joined</span>
                      <span className="text-slate-300">
                        {new Date(activeChatItem.student.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowStudentInfo(false)}
                    className="text-xs text-rose-400 hover:text-rose-300 font-bold cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              )}

              {/* 2. CHAT CANVAS */}
              <div
                className="flex-1 overflow-y-auto px-4 sm:px-6 py-4 flex flex-col gap-3 relative scrollbar-thin scrollbar-thumb-white/10"
                style={{
                  backgroundColor: '#070509',
                  backgroundImage: `radial-gradient(circle at 50% 0%, ${themeColor}10 0%, transparent 65%)`,
                }}
              >
                {/* Date Divider Chip */}
                <div className="flex justify-center my-1 select-none sticky top-1 z-10">
                  <div className="px-4 py-1 rounded-xl bg-[#1a0f1e]/90 border border-white/10 text-[10.5px] font-black text-slate-300 tracking-wider shadow-md uppercase backdrop-blur-md">
                    CONVERSATION WITH {activeChatItem.student.name.toUpperCase()}
                  </div>
                </div>

                {/* Empty State */}
                {(!activeChatItem.ticket?.messages || activeChatItem.ticket.messages.length === 0) && (
                  <div className="my-auto text-center py-12 flex flex-col items-center justify-center gap-2 text-slate-400">
                    <div className="w-14 h-14 rounded-3xl bg-white/[0.04] border border-white/10 flex items-center justify-center text-rose-400 shadow-md">
                      <Send className="w-6 h-6" />
                    </div>
                    <p className="text-sm font-bold text-white">
                      No messages with {activeChatItem.student.name} yet.
                    </p>
                    <p className="text-xs text-slate-400 max-w-xs">
                      Send a message or select a quick preset reply below to initiate conversation with this student.
                    </p>
                  </div>
                )}

                {/* Messages Bubble List */}
                {activeChatItem.ticket?.messages?.map((msg) => {
                  const isAdmin = msg.sender === 'admin';
                  const time = formatTelegramTime(msg.createdAt);

                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col max-w-[88%] sm:max-w-[72%] ${
                        isAdmin ? 'self-end items-end' : 'self-start items-start'
                      } animate-in fade-in duration-150`}
                    >
                      <div
                        className={`relative p-3 sm:p-3.5 rounded-3xl shadow-lg text-sm leading-relaxed ${
                          isAdmin
                            ? 'text-white rounded-br-xs'
                            : 'text-slate-100 rounded-bl-xs border border-white/10'
                        }`}
                        style={{
                          background: isAdmin
                            ? `linear-gradient(135deg, ${themeColor} 0%, #aa0020 100%)`
                            : 'rgba(23, 16, 25, 0.94)',
                          boxShadow: isAdmin
                            ? `0 6px 20px -3px ${themeColor}55, inset 0 1px 1px rgba(255, 255, 255, 0.35)`
                            : '0 6px 20px -3px rgba(0, 0, 0, 0.7), inset 0 1px 0 rgba(255, 255, 255, 0.08)',
                        }}
                      >
                        {/* Sender Label */}
                        <div className="flex items-center gap-1.5 mb-1.5 select-none">
                          <span
                            className={`text-[10.5px] font-black uppercase tracking-wider ${
                              isAdmin ? 'text-white/90' : 'text-rose-400'
                            }`}
                          >
                            {isAdmin ? 'Admin Jyotish (You)' : msg.senderName}
                          </span>
                        </div>

                        {/* Photo attachment */}
                        {msg.screenshotUrl && (
                          <div className="mb-2 relative rounded-2xl overflow-hidden bg-black/50 border border-white/15 group cursor-pointer max-w-sm">
                            <img
                              src={msg.screenshotUrl}
                              alt="Attached in conversation"
                              loading="lazy"
                              onClick={() => setZoomedImage(msg.screenshotUrl!)}
                              className="w-full max-h-72 object-cover transition-transform duration-200 group-hover:scale-102"
                            />
                            <button
                              type="button"
                              onClick={() => setZoomedImage(msg.screenshotUrl!)}
                              className="absolute bottom-2 right-2 p-1.5 rounded-xl bg-black/75 text-white hover:bg-black transition-all backdrop-blur-md"
                              title="View photo full size"
                            >
                              <Maximize2 className="w-4 h-4" />
                            </button>
                          </div>
                        )}

                        {/* Text Message */}
                        {msg.text && (!msg.screenshotUrl || msg.text !== '📷 Photo') && (
                          <p className="whitespace-pre-wrap break-words text-[13.5px] sm:text-[14px] leading-relaxed pr-12 pb-1 font-normal">
                            {msg.text}
                          </p>
                        )}

                        {/* Timestamp & Delivery Check */}
                        <div className="flex items-center justify-end gap-1.5 text-[10px] select-none float-right -mt-1 ml-4">
                          <span className={isAdmin ? 'text-white/80' : 'text-slate-400'}>
                            {time}
                          </span>
                          {isAdmin && (
                            <span title="Delivered to student">
                              <CheckCheck className="w-3.5 h-3.5 text-cyan-200" />
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                <div ref={messagesEndRef} className="h-1" />
              </div>

              {/* 3. PHOTO PREVIEW DRAWER (When Admin attaches a photo) */}
              {selectedPhoto && (
                <div className="bg-[#150d18] border-t border-rose-500/20 px-4 py-2.5 flex items-center justify-between gap-3 animate-in slide-in-from-bottom-2 duration-150 shadow-2xl">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="relative w-12 h-12 rounded-2xl overflow-hidden border border-rose-500/40 bg-black shrink-0 shadow-md">
                      <img
                        src={selectedPhoto}
                        alt="Photo attachment"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="text-xs font-bold text-white truncate">
                        Photo ready to send to {activeChatItem.student.name}
                      </span>
                      <span className="text-[11px] text-rose-400 font-medium truncate">
                        {selectedPhotoName || 'Optimized for student display'}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setSelectedPhoto(null);
                      setSelectedPhotoName('');
                    }}
                    type="button"
                    className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
                    title="Remove photo"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Error Alert */}
              {errorMessage && (
                <div className="bg-rose-950/90 border-t border-rose-500/40 text-rose-100 text-xs px-4 py-2.5 flex items-center justify-between gap-2 shadow-lg">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{errorMessage}</span>
                  </div>
                  <button onClick={() => setErrorMessage('')} className="p-1 text-slate-400 hover:text-white">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Quick Reply Preset Buttons */}
              <div className="px-4 py-2 bg-[#120814] border-t border-white/5 flex items-center gap-2 overflow-x-auto scrollbar-none select-none">
                <span className="text-[10px] uppercase font-bold text-slate-400 shrink-0">Quick Reply:</span>
                {quickReplies.map((reply) => (
                  <button
                    key={reply}
                    type="button"
                    onClick={() => handleSendMessage(undefined, reply)}
                    className="px-3 py-1 rounded-xl bg-white/[0.05] hover:bg-rose-600/20 hover:border-rose-500/40 border border-white/10 text-[11px] text-slate-300 hover:text-white whitespace-nowrap transition-all cursor-pointer active:scale-95 shrink-0 shadow-sm"
                  >
                    {reply}
                  </button>
                ))}
              </div>

              {/* 4. BOTTOM INPUT BAR */}
              <footer className="bg-[#100813] border-t border-white/10 px-4 py-3 flex items-center gap-2.5 shrink-0 shadow-2xl">
                {/* Hidden File Input */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoSelect}
                  className="hidden"
                />

                {/* Attach Photo Button */}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  aria-label="Attach Photo"
                  title="Attach photo from gallery or computer"
                  className={`p-2.5 sm:p-3 rounded-2xl border transition-all cursor-pointer shrink-0 active:scale-90 shadow-sm ${
                    selectedPhoto
                      ? 'text-white border-rose-500 bg-rose-600/30 ring-2 ring-rose-500/40'
                      : 'text-slate-300 hover:text-white bg-white/[0.05] hover:bg-white/[0.1] border-white/10'
                  }`}
                >
                  <ImageIcon className="w-5 h-5" />
                </button>

                {/* Form Input Box */}
                <form onSubmit={handleSendMessage} className="flex-1 flex items-center gap-2 min-w-0">
                  <input
                    ref={inputRef}
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder={
                      selectedPhoto
                        ? 'Add a caption...'
                        : `Type a message to ${activeChatItem.student.name}...`
                    }
                    className="w-full py-2.5 px-4 rounded-2xl bg-white/[0.06] border border-white/10 focus:border-rose-500/60 text-white placeholder-slate-400 text-sm transition-all focus:outline-none shadow-inner"
                  />

                  <button
                    type="submit"
                    disabled={isSending || (!inputText.trim() && !selectedPhoto)}
                    aria-label="Send Message"
                    title="Send Message"
                    className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl flex items-center justify-center text-white cursor-pointer transition-all duration-200 active:scale-90 disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shrink-0"
                    style={{
                      background: `linear-gradient(135deg, ${themeColor} 0%, #aa0020 100%)`,
                      boxShadow: `0 4px 14px ${themeColor}55`,
                    }}
                  >
                    {isSending ? (
                      <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    ) : (
                      <Send className="w-4 h-4 fill-white ml-0.5 text-white" />
                    )}
                  </button>
                </form>
              </footer>
            </>
          ) : (
            /* Desktop Empty Placeholder when no chat selected */
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center gap-4 text-slate-400 select-none">
              <div
                className="w-20 h-20 rounded-3xl flex items-center justify-center text-white shadow-2xl border border-white/20"
                style={{
                  background: `linear-gradient(135deg, ${themeColor} 0%, #8b0018 100%)`,
                  boxShadow: `0 0 30px ${themeColor}40`,
                }}
              >
                <MessageSquare className="w-10 h-10" />
              </div>
              <div className="max-w-sm flex flex-col gap-1.5">
                <h3 className="text-base font-bold text-white">
                  Select a Student Conversation
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Choose any student from the left panel to review chat history, view shared photos, and send instant replies.
                </p>
              </div>

              <div className="flex items-center gap-3 text-xs font-semibold text-slate-400 bg-white/5 px-4 py-2 rounded-2xl border border-white/10 mt-2">
                <span>{students.length} Registered Students</span>
                <span>•</span>
                <span>{chatItems.filter((c) => c.ticket).length} Active Conversations</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {ticketToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl p-6 bg-[#0c080b] border border-rose-500/30 shadow-2xl flex flex-col gap-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Clear Chat Conversation?</h3>
              <p className="text-xs text-slate-400 mt-1">
                Are you sure you want to clear chat messages for{' '}
                <span className="text-white font-bold">{ticketToDelete.studentName}</span>?
              </p>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setTicketToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white cursor-pointer shadow-lg"
              >
                Clear Conversation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Photo Lightbox Modal */}
      {zoomedImage && (
        <div
          className="fixed inset-0 z-60 bg-black/95 flex flex-col items-center justify-center p-3 animate-in fade-in duration-200 backdrop-blur-md"
          onClick={() => setZoomedImage(null)}
        >
          <div className="absolute top-4 right-4 z-10 flex items-center gap-2">
            <button
              onClick={() => setZoomedImage(null)}
              type="button"
              className="p-2.5 rounded-2xl bg-white/15 hover:bg-white/25 text-white transition-all cursor-pointer shadow-lg"
              title="Close full-screen"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <img
            src={zoomedImage}
            alt="Full size view"
            className="max-w-full max-h-[90vh] object-contain rounded-2xl shadow-2xl select-none"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
};
