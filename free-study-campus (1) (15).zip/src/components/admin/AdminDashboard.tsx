import React from 'react';
import { useTheme } from '../../context/ThemeContext';
import { Layers, Globe, Plus, ExternalLink, Sparkles, CheckCircle2, Eye, EyeOff, Video } from 'lucide-react';
import { PlatformRecord } from '../../../server/db';
import { isImageSource, getBatchInitials } from '../../utils/imageUtils';

interface AdminDashboardProps {
  platforms: PlatformRecord[];
  onNavigateTab: (tab: 'platforms' | 'dashboard' | 'demos' | 'students' | 'announcements' | 'payment' | 'settings') => void;
  onOpenAddPlatform: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  platforms,
  onNavigateTab,
  onOpenAddPlatform,
}) => {
  const { config } = useTheme();

  const isDarkText = ['cyber', 'monochrome', 'amber'].includes(config.id);
  const btnTextColor = isDarkText ? '#09090b' : '#ffffff';

  const totalPlatforms = platforms.length;
  const activePlatforms = platforms.filter((p) => p.isAvailable).length;
  const inactivePlatforms = platforms.filter((p) => !p.isAvailable).length;

  const statCards = [
    {
      title: 'Total Platforms',
      value: totalPlatforms,
      subtitle: 'Configured partner entries',
      icon: Layers,
      tab: 'platforms' as const,
    },
    {
      title: 'Active (Live)',
      value: activePlatforms,
      subtitle: 'Visible on public campus',
      icon: CheckCircle2,
      tab: 'platforms' as const,
    },
    {
      title: 'Inactive (Hidden)',
      value: inactivePlatforms,
      subtitle: 'Staged or offline portals',
      icon: EyeOff,
      tab: 'platforms' as const,
    },
  ];

  return (
    <div className="flex flex-col gap-8 pb-16">
      {/* Welcome Banner */}
      <div
        className="rounded-3xl p-6 sm:p-8 glass-panel border relative overflow-hidden"
        style={{
          borderColor: config.borderColor,
          boxShadow: `0 10px 40px -10px ${config.accentGlow}`,
        }}
      >
        <div
          className="absolute -right-16 -top-16 w-56 h-56 rounded-full blur-3xl pointer-events-none opacity-30"
          style={{ backgroundColor: config.primaryColor }}
        />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center gap-2">
              <span
                className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold uppercase tracking-wider border"
                style={{
                  backgroundColor: config.badgeBg,
                  borderColor: config.borderColor,
                  color: config.primaryColor,
                }}
              >
                Control Center
              </span>
              <span className="text-xs text-slate-400">Platform Link Directory</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white font-display">
              Administrator Dashboard
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Control the educational platform cards shown on the public FREE STUDY CAMPUS website. Each entry consists solely of a Name, optional Logo, and direct External Link.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigateTab('demos')}
              type="button"
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-xs bg-white/10 hover:bg-white/15 border border-white/15 text-white transition-all active:scale-95 shadow-md cursor-pointer"
            >
              <Video className="w-4 h-4 text-red-400" />
              <span>Manage Batch Demos</span>
            </button>
            <button
              onClick={onOpenAddPlatform}
              type="button"
              className="btn-primary-red flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 shadow-lg cursor-pointer"
            >
              <Plus className="w-4 h-4 text-white" />
              <span>Add Platform</span>
            </button>
          </div>
        </div>
      </div>

      {/* STAT CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div
              key={i}
              onClick={() => onNavigateTab(card.tab)}
              className="rounded-3xl p-5 glass-panel border transition-all duration-300 hover:border-white/20 cursor-pointer flex flex-col justify-between gap-3 group"
              style={{ borderColor: config.borderColor }}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400">{card.title}</span>
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center border transition-all duration-300 group-hover:scale-110"
                  style={{
                    backgroundColor: config.badgeBg,
                    borderColor: config.borderColor,
                    color: config.primaryColor,
                  }}
                >
                  <Icon className="w-4 h-4" />
                </div>
              </div>

              <div>
                <span className="text-3xl font-extrabold text-white font-display tracking-tight">
                  {card.value}
                </span>
                <p className="text-xs text-slate-400 mt-0.5">{card.subtitle}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* QUICK PREVIEW OF CONFIGURED PLATFORMS */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-white font-display">
              Configured Platforms Directory
            </h3>
            <p className="text-xs text-slate-400">
              Active entries are currently visible on the public website.
            </p>
          </div>

          <button
            onClick={() => onNavigateTab('platforms')}
            type="button"
            className="text-xs font-semibold hover:underline flex items-center gap-1 cursor-pointer"
            style={{ color: config.primaryColor }}
          >
            <span>Manage All Platforms</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {platforms.map((p) => (
            <div
              key={p.id}
              className="p-4 rounded-2xl glass-panel border flex items-center justify-between gap-3"
              style={{
                borderColor: p.isAvailable ? config.borderColor : 'rgba(255, 255, 255, 0.08)',
                opacity: p.isAvailable ? 1 : 0.6,
              }}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 border overflow-hidden bg-black/40"
                  style={{
                    borderColor: config.borderColor,
                    color: config.primaryColor,
                  }}
                >
                  {isImageSource(p.logo) ? (
                    <img
                      src={p.logo}
                      alt={p.name}
                      className="w-full h-full object-contain p-0.5"
                    />
                  ) : (
                    <span>{p.logo && !isImageSource(p.logo) ? p.logo : getBatchInitials(p.name)}</span>
                  )}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white truncate block">
                      {p.name}
                    </span>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                        p.isAvailable
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {p.isAvailable ? 'ON' : 'OFF'}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono truncate block max-w-[200px]">
                    {p.externalUrl}
                  </span>
                </div>
              </div>

              <a
                href={p.externalUrl}
                target="_blank"
                rel="noopener noreferrer"
                title="Test external link"
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors shrink-0"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
