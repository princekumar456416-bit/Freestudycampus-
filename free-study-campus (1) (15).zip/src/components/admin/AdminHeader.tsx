import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { ThemeSwitcher } from '../ThemeSwitcher';
import { ShieldCheck, LogOut, ArrowLeft, Bell, KeyRound } from 'lucide-react';
import { CampusLogo } from '../CampusLogo';

interface AdminHeaderProps {
  onLogout: () => void;
  onExitAdmin: () => void;
  onOpenChangePassword?: () => void;
  onOpenNotifications?: () => void;
  unreadNotificationCount?: number;
  announcementCount?: number;
  logoUrl?: string;
}

export const AdminHeader: React.FC<AdminHeaderProps> = ({
  onLogout,
  onExitAdmin,
  onOpenChangePassword,
  onOpenNotifications,
  unreadNotificationCount = 0,
  announcementCount = 0,
  logoUrl,
}) => {
  const { config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';

  return (
    <header
      className="sticky top-0 z-40 w-full backdrop-blur-2xl border-b transition-all duration-300 px-4 sm:px-8 py-3.5"
      style={{
        backgroundColor: config.cardBg,
        borderColor: config.borderColor,
        boxShadow: `0 4px 20px -2px ${config.accentGlow}`,
      }}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Left: Branding & Back to site */}
        <div className="flex items-center gap-3">
          <button
            onClick={onExitAdmin}
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-white/10 text-xs font-semibold text-slate-300 hover:text-white hover:bg-white/5 transition-all cursor-pointer"
            title="View Public Campus Website"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Public Campus</span>
          </button>

          <div className="h-4 w-px bg-white/15" />

          <div className="flex items-center gap-2.5">
            <CampusLogo
              logoUrl={logoUrl}
              withGlow={true}
              className="w-8 h-8 rounded-xl object-contain drop-shadow-md"
            />
            <div>
              <h1 className="text-sm sm:text-base font-extrabold tracking-tight text-white font-display flex items-center gap-1.5">
                FREE STUDY CAMPUS <span className="text-red-500 font-black">ADMIN</span>
              </h1>
              <p className="text-[10px] text-slate-400 -mt-0.5">Control Panel · Campus Management</p>
            </div>
          </div>
        </div>

        {/* Right: Change Password quick button, Theme Switcher, Notifications, Admin Profile, Logout */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          {/* Quick Change Password Button in Header (inside Admin Panel) */}
          {onOpenChangePassword && (
            <button
              onClick={onOpenChangePassword}
              type="button"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-white/15 hover:border-white/30 text-slate-200 hover:text-white bg-white/5 hover:bg-white/10 text-xs font-semibold transition-all cursor-pointer"
              title="Change Admin Password"
            >
              <KeyRound className="w-3.5 h-3.5" style={{ color: config.primaryColor }} />
              <span className="hidden md:inline">Change Password</span>
            </button>
          )}

          {/* Theme switcher */}
          <div className="hidden md:flex items-center">
            <ThemeSwitcher />
          </div>

          {/* Admin Notifications Button */}
          <button
            type="button"
            onClick={onOpenNotifications}
            className="relative p-2 rounded-xl border border-white/10 text-slate-300 bg-white/5 hover:bg-white/10 hover:text-white transition-all cursor-pointer"
            title={unreadNotificationCount > 0 ? `${unreadNotificationCount} New Student Queries` : 'Admin Alerts'}
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationCount > 0 ? (
              <span
                className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full text-[9px] font-black text-white shadow-md animate-pulse"
                style={{ backgroundColor: themeColor }}
              >
                {unreadNotificationCount}
              </span>
            ) : announcementCount > 0 ? (
              <span
                className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full"
                style={{ backgroundColor: themeColor }}
              />
            ) : null}
          </button>

          {/* Admin Profile Pill */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl border border-white/10 bg-white/5">
            <ShieldCheck className="w-4 h-4" style={{ color: config.primaryColor }} />
            <span className="text-xs font-semibold text-slate-200">Super Admin</span>
          </div>

          {/* Logout / Lock Session */}
          <button
            onClick={onLogout}
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 hover:text-rose-200 text-xs font-semibold transition-all cursor-pointer"
            title="Lock Admin Session & Logout"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Lock / Logout</span>
          </button>
        </div>
      </div>
    </header>
  );
};
