import React, { useState, useEffect } from 'react';
import {
  Bell,
  X,
  MessageSquare,
  CheckCircle2,
  RefreshCw,
  ExternalLink,
  CheckCheck,
  User,
} from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import {
  AppNotification,
  subscribeAdminNotifications,
  markAdminNotificationRead,
} from '../../services/notificationService';

interface AdminNotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenTicket: (ticketId: string) => void;
}

export const AdminNotificationCenter: React.FC<AdminNotificationCenterProps> = ({
  isOpen,
  onClose,
  onOpenTicket,
}) => {
  const { config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';

  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    setIsLoading(true);
    const unsubscribe = subscribeAdminNotifications((list) => {
      setNotifications(list);
      setIsLoading(false);
    });

    return () => {
      unsubscribe();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleNotificationClick = async (notif: AppNotification) => {
    if (!notif.read) {
      await markAdminNotificationRead(notif.id);
    }
    if (notif.ticketId) {
      onOpenTicket(notif.ticketId);
      onClose();
    }
  };

  const handleMarkAllRead = async () => {
    await markAdminNotificationRead(undefined, true);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg rounded-3xl bg-[#0e0910]/95 border border-white/15 p-5 sm:p-6 shadow-[0_20px_50px_rgba(0,0,0,0.85)] backdrop-blur-2xl flex flex-col gap-4 max-h-[85vh] overflow-hidden"
      >
        <div
          className="absolute -top-16 -right-16 w-40 h-40 rounded-full blur-3xl pointer-events-none opacity-20"
          style={{ backgroundColor: themeColor }}
        />

        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 relative z-10">
          <div className="flex items-center gap-2.5">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shadow-lg"
              style={{ backgroundColor: `${themeColor}22` }}
            >
              <Bell className="w-4 h-4" style={{ color: themeColor }} />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>Admin Alerts & Queries</span>
                {unreadCount > 0 && (
                  <span
                    className="px-2 py-0.5 rounded-full text-[10px] font-black text-white"
                    style={{ backgroundColor: themeColor }}
                  >
                    {unreadCount} New
                  </span>
                )}
              </h2>
              <p className="text-[11px] text-slate-400">Incoming student chat messages &amp; photo requests</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={handleMarkAllRead}
                className="text-[11px] font-bold text-slate-300 hover:text-white flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                title="Mark all as read"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Mark All Read</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 max-h-[60vh]">
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-2 text-slate-400 text-xs">
              <RefreshCw className="w-5 h-5 animate-spin" style={{ color: themeColor }} />
              <span>Loading alerts...</span>
            </div>
          ) : notifications.length === 0 ? (
            <div className="py-14 flex flex-col items-center justify-center gap-2 text-center text-slate-400 px-4">
              <div className="w-12 h-12 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-center">
                <Bell className="w-6 h-6 text-slate-500" />
              </div>
              <p className="text-sm font-bold text-white mt-2">No Active Alerts</p>
              <p className="text-xs text-slate-400 max-w-xs">
                Whenever students submit a complaint or ask a question, real-time alerts will appear right here.
              </p>
            </div>
          ) : (
            notifications.map((notif) => {
              const dateStr = new Date(notif.createdAt).toLocaleString('en-US', {
                month: 'short',
                day: 'numeric',
                hour: 'numeric',
                minute: '2-digit',
                hour12: true,
              });

              return (
                <div
                  key={notif.id}
                  onClick={() => handleNotificationClick(notif)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 relative ${
                    notif.read
                      ? 'bg-white/[0.02] border-white/5 text-slate-400 hover:bg-white/[0.04]'
                      : 'bg-white/[0.07] border-white/20 text-white shadow-md hover:bg-white/[0.1]'
                  }`}
                  style={{
                    borderColor: !notif.read ? `${themeColor}55` : undefined,
                  }}
                >
                  {!notif.read && (
                    <span
                      className="absolute top-3 right-3 w-2 h-2 rounded-full"
                      style={{ backgroundColor: themeColor }}
                    />
                  )}

                  <div className="w-8 h-8 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center shrink-0 mt-0.5">
                    <MessageSquare className="w-4 h-4 text-rose-400" />
                  </div>

                  <div className="flex-1 min-w-0 pr-4">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-xs font-bold text-white truncate">{notif.title}</h4>
                      <span className="text-[10px] text-slate-400 shrink-0">{dateStr}</span>
                    </div>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed line-clamp-2">
                      {notif.message}
                    </p>
                    {notif.ticketId && (
                      <div className="mt-2 flex items-center gap-1 text-[11px] font-bold" style={{ color: themeColor }}>
                        <span>Open & Reply Directly</span>
                        <ExternalLink className="w-3 h-3" />
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
