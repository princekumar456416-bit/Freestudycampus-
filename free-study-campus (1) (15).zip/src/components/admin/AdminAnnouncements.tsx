import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { AnnouncementRecord } from '../../../server/db';
import { Plus, Trash2, Bell, CheckCircle2, ExternalLink } from 'lucide-react';
import { useToast } from './Toast';

interface AdminAnnouncementsProps {
  announcements: AnnouncementRecord[];
  onAddAnnouncement: (data: Partial<AnnouncementRecord>) => Promise<void>;
  onDeleteAnnouncement: (id: string) => Promise<void>;
  onToggleActive: (id: string, current: boolean) => Promise<void>;
}

export const AdminAnnouncements: React.FC<AdminAnnouncementsProps> = ({
  announcements,
  onAddAnnouncement,
  onDeleteAnnouncement,
  onToggleActive,
}) => {
  const { config } = useTheme();
  const { showToast } = useToast();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [date, setDate] = useState('');
  const [link, setLink] = useState('https://pwthor.live/study/batches');
  const [isActive, setIsActive] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) {
      showToast('Title and Message are required', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      await onAddAnnouncement({
        title: title.trim(),
        message: message.trim(),
        date: date.trim() || new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
        link: link.trim(),
        isActive,
      });
      showToast('Announcement broadcasted');
      setIsModalOpen(false);
      setTitle('');
      setMessage('');
    } catch {
      showToast('Failed to create announcement', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col gap-6 pb-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white font-display">
            Campus Announcements
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Publish notices and schedule updates displayed as notification banners on the public homepage.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          type="button"
          className="btn-primary-red flex items-center gap-2 px-5 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-95 shadow-lg cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-white" />
          <span>Create Announcement</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {announcements.map((ann) => (
          <div
            key={ann.id}
            className="rounded-3xl p-5 glass-panel border flex flex-col justify-between gap-4"
            style={{
              borderColor: ann.isActive ? config.borderColor : 'rgba(255, 255, 255, 0.08)',
              opacity: ann.isActive ? 1 : 0.65,
            }}
          >
            <div className="flex flex-col gap-2">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-xl flex items-center justify-center border"
                    style={{
                      backgroundColor: config.badgeBg,
                      borderColor: config.borderColor,
                    }}
                  >
                    <Bell className="w-4 h-4" style={{ color: config.primaryColor }} />
                  </div>
                  <h3 className="text-sm font-bold text-white">{ann.title}</h3>
                </div>

                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
                    ann.isActive
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                      : 'bg-slate-500/10 text-slate-400 border-slate-500/30'
                  }`}
                >
                  {ann.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">{ann.message}</p>

              {ann.link && (
                <div className="flex items-center gap-1.5 text-[11px] font-mono text-cyan-300">
                  <ExternalLink className="w-3 h-3" />
                  <a href={ann.link} target="_blank" rel="noopener noreferrer" className="hover:underline truncate">
                    {ann.link}
                  </a>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
              <span>Broadcast Date: {ann.date}</span>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => onToggleActive(ann.id, ann.isActive)}
                  type="button"
                  className="px-2.5 py-1 rounded-lg text-xs font-semibold hover:bg-white/10 text-slate-300"
                >
                  {ann.isActive ? 'Deactivate' : 'Activate'}
                </button>
                <button
                  onClick={() => onDeleteAnnouncement(ann.id)}
                  type="button"
                  className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Announcement Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div
            className="w-full max-w-lg rounded-3xl p-6 sm:p-8 glass-panel border relative shadow-2xl"
            style={{
              backgroundColor: config.cardBg,
              borderColor: config.borderColor,
            }}
          >
            <h3 className="text-lg font-bold text-white mb-4">Create Campus Announcement</h3>
            <form onSubmit={handleSave} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-slate-300">Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. New Session Batches Live!"
                  className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                  style={{ borderColor: config.borderColor }}
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-slate-300">Message / Notification Text *</label>
                <textarea
                  rows={3}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Notice details for students..."
                  className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none resize-none"
                  style={{ borderColor: config.borderColor }}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-slate-300">Date</label>
                  <input
                    type="text"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    placeholder="e.g. Sep 2026"
                    className="w-full bg-black/40 border rounded-xl px-3 py-2 text-sm text-white focus:outline-none"
                    style={{ borderColor: config.borderColor }}
                  />
                </div>

                <div className="flex flex-col justify-end">
                  <label className="flex items-center gap-2 p-2 rounded-xl bg-white/5 border border-white/10 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isActive}
                      onChange={(e) => setIsActive(e.target.checked)}
                      className="rounded accent-red-500"
                    />
                    <span className="text-xs font-semibold text-slate-200">Active on Homepage</span>
                  </label>
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-slate-300">Resource Link</label>
                <input
                  type="url"
                  value={link}
                  onChange={(e) => setLink(e.target.value)}
                  placeholder="https://pwthor.live/study/batches"
                  className="w-full bg-black/40 border border-white/10 focus:border-red-500 rounded-xl px-3 py-2 text-sm text-white focus:outline-none font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-3 mt-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="btn-primary-red px-5 py-2.5 rounded-xl text-xs font-bold text-white shadow-md cursor-pointer"
                >
                  {isSubmitting ? 'Publishing...' : 'Broadcast'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
