import React, { useState, useEffect } from 'react';
import { ExternalLink, ShieldCheck } from 'lucide-react';
import { isImageSource, getBatchInitials } from '../utils/imageUtils';
import { useTheme } from '../context/ThemeContext';

export interface PlatformDisplayItem {
  id: string;
  name: string;
  externalUrl?: string;
  logo?: string;
  category?: string;
  status?: string;
  teacherName?: string;
}

interface PlatformCardProps {
  platform: PlatformDisplayItem;
}

/**
 * PlatformCard (Luxury Batch Card):
 * A world-class, compact, and luxurious card design for Free Study Campus.
 * - Distinct, properly sized platform logo pedestal with precision dual hairline border
 * - Prominent platform / batch title with verified authentication kicker
 * - High-contrast, attractive "OPEN BATCH" action button with thumb-friendly touch target
 * - Deep obsidian glass surface with subtle ruby red accent lighting and specular glare
 * - GPU hardware-accelerated transforms for ultra-smooth 60fps scrolling
 */
export const PlatformCard: React.FC<PlatformCardProps> = React.memo(({ platform }) => {
  const { config, accentHex } = useTheme();
  const themeAccent = accentHex || config.primaryColor || '#ff2e4d';
  const themeGlow = config.accentGlow || `${themeAccent}33`;

  const targetUrl = platform.externalUrl || '#';
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    setImageError(false);
  }, [platform.logo]);

  const hasImage = Boolean(platform.logo && isImageSource(platform.logo) && !imageError);

  return (
    <a
      href={targetUrl}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Open ${platform.name} batch`}
      style={
        {
          '--card-theme-accent': themeAccent,
          '--card-theme-glow': themeGlow,
        } as React.CSSProperties
      }
      className="platform-premium-card group relative flex items-center justify-between w-full rounded-2xl p-3 sm:p-4 cursor-pointer overflow-hidden border border-white/[0.08] select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2 focus-visible:ring-offset-[#08060a] touch-manipulation active:scale-[0.985] transition-all duration-200"
    >
      {/* 1. Precision Specular Top Rim Line - Gives cards a luxury chamfered glass finish */}
      <div
        className="absolute top-0 inset-x-0 h-[1.5px] pointer-events-none opacity-45 group-hover:opacity-100 transition-opacity duration-300"
        style={{
          background: `linear-gradient(90deg, transparent 0%, ${themeAccent}44 20%, #ffffffcc 50%, ${themeAccent}44 80%, transparent 100%)`,
        }}
      />

      {/* 2. Soft Ambient Corner Glow - Pure Native Radial Gradient (Zero Heavy Filter Blur for 60fps Scrolling) */}
      <div
        className="absolute -top-12 -right-12 w-36 h-36 rounded-full pointer-events-none opacity-20 group-hover:opacity-50 transition-opacity duration-300"
        style={{
          background: `radial-gradient(circle, ${themeGlow} 0%, transparent 70%)`,
        }}
      />

      {/* 3. Subtle Bottom Reflection Edge */}
      <div
        className="absolute bottom-0 inset-x-6 h-[1px] pointer-events-none opacity-10 group-hover:opacity-30 transition-opacity duration-300"
        style={{
          background: `linear-gradient(90deg, transparent 0%, ${themeAccent} 50%, transparent 100%)`,
        }}
      />

      {/* Left: Platform Logo Pedestal + Name & Verified Meta Details */}
      <div className="relative z-10 flex items-center gap-3 sm:gap-3.5 min-w-0 flex-1 mr-2 sm:mr-3">
        {/* Logo Container Pedestal with Ambient Backing Halo */}
        <div className="relative shrink-0">
          {/* Subtle Ambient Backing Halo */}
          <div
            className="absolute -inset-1 rounded-2xl pointer-events-none opacity-25 group-hover:opacity-60 transition-opacity duration-300"
            style={{
              background: `radial-gradient(circle, ${themeAccent}55 0%, transparent 70%)`,
            }}
          />

          {/* Luxury Logo Container: Deep obsidian surface, crisp dual border & inner specular gradient */}
          <div className="relative w-12 h-12 sm:w-13 sm:h-13 rounded-xl sm:rounded-2xl flex items-center justify-center border border-white/12 bg-[#090508]/95 shadow-[0_6px_18px_rgba(0,0,0,0.7),inset_0_1px_0_rgba(255,255,255,0.15)] overflow-hidden transition-all duration-300 group-hover:border-red-500/40 group-hover:shadow-[0_6px_22px_rgba(0,0,0,0.8),inset_0_1px_1px_rgba(255,255,255,0.22)]">
            {/* Top Specular Inner Glare */}
            <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/[0.1] to-transparent pointer-events-none" />

            {hasImage ? (
              <img
                src={platform.logo}
                alt={platform.name}
                loading="lazy"
                decoding="async"
                width={52}
                height={52}
                className="relative z-10 w-full h-full object-contain p-2 aspect-square transition-transform duration-300 group-hover:scale-105"
                onError={() => setImageError(true)}
              />
            ) : (
              <span
                className="relative z-10 text-sm sm:text-base font-black tracking-wider uppercase font-display select-none transition-colors"
                style={{ color: themeAccent }}
              >
                {platform.logo && !isImageSource(platform.logo)
                  ? platform.logo
                  : getBatchInitials(platform.name)}
              </span>
            )}
          </div>
        </div>

        {/* Platform Name and Unboxed Meta Separator */}
        <div className="min-w-0 flex-1">
          <h3 className="text-[14px] sm:text-[15px] font-bold text-white font-display tracking-tight leading-snug truncate group-hover:text-red-50 transition-colors drop-shadow-sm">
            {platform.name}
          </h3>

          {/* Clean Unboxed Metadata (Zero-Pill Discipline) */}
          <div className="flex items-center gap-1.5 mt-0.5 text-[11px] text-slate-400 font-medium tracking-normal truncate">
            <ShieldCheck className="w-3.5 h-3.5 shrink-0" style={{ color: themeAccent }} />
            <span className="truncate">Official Study Portal</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-slate-300 font-medium">Verified</span>
          </div>
        </div>
      </div>

      {/* Right: Attractive, High-Contrast "OPEN BATCH" Action Button */}
      <div
        className="btn-primary-red relative z-10 shrink-0 inline-flex items-center justify-center gap-1.5 px-3 sm:px-3.5 py-2 sm:py-2.5 rounded-xl text-[11px] sm:text-xs font-bold tracking-wider uppercase transition-all duration-200 group-hover:scale-105 active:scale-95 shadow-md cursor-pointer select-none"
        aria-hidden="true"
      >
        <span>OPEN BATCH</span>
        <ExternalLink className="w-3.5 h-3.5 shrink-0 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
      </div>
    </a>
  );
});

PlatformCard.displayName = 'PlatformCard';
