import React, { useState, useEffect } from 'react';
import { MessageSquare, X, Sparkles } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { StudentUser } from '../services/studentUserService';
import { subscribeStudentTickets, SupportTicket, getStudentUnreadCount } from '../services/supportService';

interface FloatingChatButtonProps {
  onClick: () => void;
  isOpen: boolean;
  student: StudentUser | null;
}

export const FloatingChatButton: React.FC<FloatingChatButtonProps> = ({
  onClick,
  isOpen,
  student,
}) => {
  const { config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';

  const [unreadCount, setUnreadCount] = useState(0);

  // Monitor student tickets for exact unread admin messages
  useEffect(() => {
    if (!student?.id) {
      setUnreadCount(0);
      return;
    }
    const cleanUser = (student.username || '').toLowerCase();
    const unsubscribe = subscribeStudentTickets(student.id, student.username, (tickets: SupportTicket[]) => {
      // Isolate strictly to this student's conversation
      const studentTickets = tickets.filter(
        (t) => t.studentId === student.id || (cleanUser && t.studentUsername === cleanUser)
      );
      const total = studentTickets.reduce((sum, t) => sum + getStudentUnreadCount(t), 0);
      setUnreadCount(total);
    });

    return () => {
      unsubscribe();
    };
  }, [student?.id, student?.username]);

  return (
    <div
      className="fixed z-40 right-3.5 sm:right-6 bottom-[calc(4.75rem+env(safe-area-inset-bottom,0px))] sm:bottom-6 pointer-events-auto select-none print:hidden transition-all duration-300"
    >
      {/* Outer Breathing Ambient Red Glow Ring */}
      <div
        className="absolute -inset-2.5 rounded-full blur-md pointer-events-none opacity-60 sm:opacity-75 transition-all duration-700"
        style={{
          background: `radial-gradient(circle, ${themeColor}99 0%, ${themeColor}22 65%, transparent 75%)`,
          animation: 'floatingGlowPulse 3s ease-in-out infinite',
        }}
      />

      {/* Main Circular Floating Button */}
      <button
        onClick={onClick}
        type="button"
        aria-label={isOpen ? 'Close Student Support Chat' : 'Open Live Student Support Chat'}
        title={isOpen ? 'Close Support Chat' : 'Live Student Help & Chat Support'}
        className="group relative w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center text-white cursor-pointer active:scale-90 hover:scale-105 transition-all duration-300 shadow-[0_8px_24px_rgba(0,0,0,0.65)] focus:outline-none focus-visible:ring-2 focus-visible:ring-white/80"
        style={{
          background: `linear-gradient(135deg, ${themeColor} 0%, #b30021 100%)`,
          border: '1.5px solid rgba(255, 255, 255, 0.4)',
          boxShadow: `0 0 24px -2px ${themeColor}88, 0 8px 24px rgba(0, 0, 0, 0.7), inset 0 1px 1px rgba(255, 255, 255, 0.45)`,
        }}
      >
        {/* Specular Inner Glare for Luxury Glass Aesthetic */}
        <div className="absolute inset-x-0 top-0 h-1/2 rounded-t-full bg-gradient-to-b from-white/35 to-transparent pointer-events-none" />

        {/* Dynamic Icon Transition: X when open, Chat Icon when closed */}
        <div className="relative z-10 transition-transform duration-300 group-hover:rotate-6">
          {isOpen ? (
            <X className="w-5 h-5 sm:w-6 sm:h-6 text-white drop-shadow" />
          ) : (
            <MessageSquare className="w-5 h-5 sm:w-6 sm:h-6 text-white fill-white/20 drop-shadow" />
          )}
        </div>

        {/* Exact Unread Messages Badge (Disappears when 0 or when chat is open) */}
        {!isOpen && unreadCount > 0 && (
          <span
            className="absolute -top-1.5 -right-1.5 min-w-[20px] h-[20px] px-1.5 rounded-full text-[10px] font-black text-white border-2 border-[#07090e] flex items-center justify-center shadow-[0_2px_10px_rgba(34,197,94,0.7)] animate-bounce z-20 pointer-events-none"
            style={{ backgroundColor: '#22c55e' }}
            title={`${unreadCount} unread message${unreadCount > 1 ? 's' : ''} from Admin Jyotish`}
          >
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      {/* Embedded Keyframe Animation for gentle floating breathing glow */}
      <style>{`
        @keyframes floatingGlowPulse {
          0%, 100% {
            transform: scale(1);
            opacity: 0.55;
          }
          50% {
            transform: scale(1.15);
            opacity: 0.9;
          }
        }
        @media (min-width: 640px) {
          .floating-chat-container {
            bottom: 1.5rem !important;
          }
        }
      `}</style>
    </div>
  );
};
