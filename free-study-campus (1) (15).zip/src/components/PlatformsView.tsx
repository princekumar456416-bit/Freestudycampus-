import React, { useState, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';
import { PlatformCard, PlatformDisplayItem } from './PlatformCard';
import { ShieldCheck, Layers, Sparkles, WifiOff, RefreshCw } from 'lucide-react';
import { safeDataCache, ConnectionStatusInfo } from '../services/api';
import { CampusLogo } from './CampusLogo';

interface PlatformsViewProps {
  platforms: PlatformDisplayItem[];
  logoUrl?: string;
}

export const PlatformsView: React.FC<PlatformsViewProps> = ({ platforms, logoUrl }) => {
  const { config } = useTheme();
  const [status, setStatus] = useState<ConnectionStatusInfo>(safeDataCache.getStatus());

  useEffect(() => {
    return safeDataCache.subscribeStatus((st) => setStatus(st));
  }, []);

  return (
    <div className="animate-page-enter w-full pb-24 flex flex-col gap-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center gap-2">
          <span
            className="px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase tracking-wider border backdrop-blur-md"
            style={{
              backgroundColor: config.badgeBg,
              borderColor: config.borderColor,
              color: config.primaryColor,
            }}
          >
            <Sparkles className="w-3 h-3 inline mr-1" />
            Educational Directory
          </span>
          <span className="text-xs text-slate-400">
            {platforms.length} Active {platforms.length === 1 ? 'Platform' : 'Platforms'}
          </span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-extrabold text-white font-display tracking-tight mt-1">
          Explore Study Platforms
        </h1>
        <p className="text-xs sm:text-sm text-slate-300">
          Tap any verified platform below to open its official study portal directly in your browser.
        </p>
      </div>

      {/* PLATFORM CARDS - ALL ACTIVE PLATFORMS */}
      {platforms.length === 0 ? (
        <div className="rounded-3xl p-12 text-center glass-panel border border-white/10 flex flex-col items-center justify-center gap-3">
          {status.isUnavailable ? (
            <>
              <WifiOff className="w-10 h-10 text-amber-400" />
              <h3 className="text-base font-bold text-white">Connection Temporarily Unavailable</h3>
              <p className="text-xs text-slate-400 max-w-sm">
                Unable to load study platforms right now due to a temporary network or database connection issue. Please check back in a moment.
              </p>
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="btn-primary-red mt-2 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold cursor-pointer shadow-md"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry Connection</span>
              </button>
            </>
          ) : (
            <>
              <CampusLogo
                logoUrl={logoUrl}
                withGlow={true}
                className="w-16 h-16 rounded-full object-contain mb-1"
                alt="Free Study Campus"
              />
              <h3 className="text-base font-bold text-white">No Active Platforms</h3>
              <p className="text-xs text-slate-400">
                Active platforms configured by administrators will appear here.
              </p>
            </>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          {platforms.map((platform) => (
            <PlatformCard key={platform.id} platform={platform} />
          ))}
        </div>
      )}

      {/* Trust & Verification Footer Note */}
      <div
        className="rounded-3xl p-5 sm:p-6 glass-panel border flex items-center justify-between gap-4 mt-2"
        style={{ borderColor: 'rgba(255, 255, 255, 0.08)' }}
      >
        <div className="flex items-center gap-3.5">
          <div
            className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 border"
            style={{
              backgroundColor: config.badgeBg,
              borderColor: config.borderColor,
            }}
          >
            <ShieldCheck className="w-5 h-5" style={{ color: config.primaryColor }} />
          </div>

          <div>
            <h3 className="text-sm font-bold text-white">Direct External Access</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              FREE STUDY CAMPUS does not host or re-upload content. All links redirect directly to authorized external portals.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
