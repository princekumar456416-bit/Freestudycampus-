import React, { useId } from 'react';

interface AnimatedLogoBorderProps {
  /**
   * Shape of the container to wrap
   * 'circle' for circular hero logo containers
   * 'rounded-rect' for rounded-square / rounded-rect containers (e.g., in header)
   */
  shape?: 'circle' | 'rounded-rect';
  /**
   * Border radius in px (used if shape is rounded-rect, defaults to 14)
   */
  borderRadius?: number;
  /**
   * Primary glowing stroke color (ruby red by default or reactive theme)
   */
  accentColor?: string;
  /**
   * Optional custom class for the outer wrapper
   */
  className?: string;
  /**
   * Child element (the original logo or container)
   */
  children: React.ReactNode;
}

/**
 * AnimatedLogoBorder:
 * High-performance, GPU hardware-accelerated animated luminous outline around
 * the Free Study Campus logo.
 * - Red-and-white / Theme reactive gradient with specular highlights.
 * - Zero heavy SVG blur filters to ensure ultra-smooth 60fps/120fps scrolling on mobile.
 * - Uses pure CSS stroke-dasharray animation on the compositor layer.
 */
export const AnimatedLogoBorder: React.FC<AnimatedLogoBorderProps> = React.memo(({
  shape = 'circle',
  borderRadius = 14,
  accentColor = '#ff2e4d',
  className = '',
  children,
}) => {
  const gradientId = useId();

  return (
    <div
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={{
        transform: 'translateZ(0)',
        contain: 'layout style',
      }}
    >
      {/* 1. Underlying Soft Ambient Glow (Pure CSS radial gradient on GPU, zero SVG filter blur) */}
      <div
        className={`absolute -inset-[3px] pointer-events-none transition-opacity duration-300 opacity-40 group-hover:opacity-70 ${
          shape === 'circle' ? 'rounded-full' : 'rounded-[16px]'
        }`}
        style={{
          background: `radial-gradient(circle, ${accentColor}55 0%, rgba(255, 255, 255, 0.15) 45%, transparent 70%)`,
          transform: 'translateZ(0)',
        }}
      />

      {/* 2. Static Base Precision Track Line (Thin hairline rim) */}
      <div
        className={`absolute inset-0 pointer-events-none z-10 transition-colors duration-300 ${
          shape === 'circle' ? 'rounded-full' : 'rounded-xl'
        }`}
        style={{
          borderRadius: shape === 'circle' ? '9999px' : `${borderRadius}px`,
          border: `1px solid ${accentColor}33`,
          boxShadow: `inset 0 0 6px ${accentColor}18, 0 0 8px ${accentColor}25`,
        }}
      />

      {/* 3. SVG Traveling Energy Beam (Exact border tracking, zero lag) */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none z-20 overflow-visible"
        aria-hidden="true"
      >
        <defs>
          {/* Multi-stop Red & Pure White Luxury Gradient */}
          <linearGradient id={`neon-beam-${gradientId}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={accentColor} stopOpacity="0.2" />
            <stop offset="35%" stopColor={accentColor} stopOpacity="0.9" />
            <stop offset="60%" stopColor="#ffffff" stopOpacity="1" />
            <stop offset="85%" stopColor="#ff4d6d" stopOpacity="0.9" />
            <stop offset="100%" stopColor={accentColor} stopOpacity="0.2" />
          </linearGradient>
        </defs>

        {shape === 'circle' ? (
          <rect
            x="1"
            y="1"
            width="calc(100% - 2px)"
            height="calc(100% - 2px)"
            rx="50%"
            ry="50%"
            fill="none"
            stroke={`url(#neon-beam-${gradientId})`}
            strokeWidth="1.8"
            strokeLinecap="round"
            className="logo-outline-circuit"
            pathLength="100"
          />
        ) : (
          <rect
            x="1"
            y="1"
            width="calc(100% - 2px)"
            height="calc(100% - 2px)"
            rx={borderRadius}
            ry={borderRadius}
            fill="none"
            stroke={`url(#neon-beam-${gradientId})`}
            strokeWidth="1.8"
            strokeLinecap="round"
            className="logo-outline-circuit"
            pathLength="100"
          />
        )}
      </svg>

      {/* 4. Center Content (Logo Container & image itself) */}
      <div className="relative z-10 w-full h-full flex items-center justify-center">
        {children}
      </div>
    </div>
  );
});

AnimatedLogoBorder.displayName = 'AnimatedLogoBorder';
