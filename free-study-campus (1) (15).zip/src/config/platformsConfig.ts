/**
 * =========================================================================
 * FREE STUDY CAMPUS - PLATFORM CONFIGURATION
 * =========================================================================
 * Configure external destination URLs for platforms in this single location.
 * When a user taps/clicks a platform card, this URL will open in the
 * device's default external browser in a new tab without an iframe,
 * keeping FREE STUDY CAMPUS active in the background.
 */
export const PHYSICS_WALLAH_URL = 'https://pwthor.live/study/batches';

export const PLATFORM_URLS = {
  PHYSICS_WALLAH: PHYSICS_WALLAH_URL,
} as const;

