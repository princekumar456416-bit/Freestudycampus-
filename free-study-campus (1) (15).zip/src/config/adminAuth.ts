/**
 * Admin Security Configuration
 * 
 * Authentication is strictly handled and verified server-side with cryptographic scrypt hashing.
 * Passwords are NEVER hardcoded in client source code.
 */

export const ADMIN_CONFIG = {
  // Session storage key used to store authentication token during active browser session
  SESSION_STORAGE_KEY: 'fsc_admin_unlocked',
} as const;
