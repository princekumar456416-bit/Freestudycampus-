import React, { useState, useEffect } from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { TabType, UserProfile } from './types';
import { SplashScreen } from './components/SplashScreen';
import { StudentAccessScreen } from './components/StudentAccessScreen';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeView } from './components/HomeView';
import { PlatformsView } from './components/PlatformsView';
import { UpcomingView } from './components/UpcomingView';
import { ProfileView } from './components/ProfileView';
import { StudentWhatsAppChat } from './components/StudentWhatsAppChat';
import { BatchDemoView } from './components/BatchDemoView';
import { StudentNotificationCenter } from './components/StudentNotificationCenter';
import { FloatingChatButton } from './components/FloatingChatButton';
import { StudentChatModal } from './components/StudentChatModal';
import { AdminLayout } from './components/admin/AdminLayout';
import { AdminLoginModal } from './components/admin/AdminLoginModal';
import { DeveloperCredit } from './components/DeveloperCredit';
import { TelegramChannelCard } from './components/TelegramChannelCard';
import { subscribeStudentNotifications, AppNotification } from './services/notificationService';
import {
  api,
  safeDataCache,
  subscribePlatforms,
  subscribeSettings,
  subscribeAdminSessionWatchdog,
  ConnectionStatusInfo,
} from './services/api';
import { PlatformRecord, SettingsRecord } from '../server/db';
import { getWebsiteLogo, updateDocumentFavicon } from './utils/logoHelper';
import {
  validateStoredSession,
  subscribeStudentSessionWatchdog,
  logoutStudentUser,
  updateStudentAvatar,
  StudentUser,
  getStoredSession,
} from './services/studentUserService';
import { WifiOff } from 'lucide-react';

const USER_STORAGE_KEY = 'free_study_campus_user';

const MainApp: React.FC = () => {
  const { config, currentThemeColor } = useTheme();
  const themeColor = currentThemeColor || config.primaryColor || '#ff2e4d';
  // 1. Splash Screen on initial launch
  const [showSplash, setShowSplash] = useState(true);
  const [activeTab, setActiveTab] = useState<TabType>('HOME');

  // Student Authentication State (Individual Username + Password, One Device per Account)
  const [isStudentAuthenticated, setIsStudentAuthenticated] = useState<boolean>(() => {
    return Boolean(getStoredSession());
  });
  const [activeStudent, setActiveStudent] = useState<StudentUser | null>(() => {
    const stored = getStoredSession();
    if (stored) {
      return {
        id: stored.studentId,
        username: stored.username,
        name: stored.username,
        passwordHash: '',
        status: 'active',
        activeSessionId: stored.sessionId,
        avatarUrl: stored.avatarUrl || null,
        createdAt: stored.loginAt,
        updatedAt: stored.loginAt,
      };
    }
    return null;
  });
  const [activeSessionId, setActiveSessionId] = useState<string | null>(() => {
    return getStoredSession()?.sessionId || null;
  });
  const [studentSessionTerminationNotice, setStudentSessionTerminationNotice] = useState<string | null>(null);
  const [showPublicDemos, setShowPublicDemos] = useState(false);

  // Student Notification Drawer & Ticket Navigation
  const [isStudentNotifOpen, setIsStudentNotifOpen] = useState(false);
  const [studentNotifs, setStudentNotifs] = useState<AppNotification[]>([]);
  const [selectedSupportTicketId, setSelectedSupportTicketId] = useState<string | null>(null);
  const [isSupportChatOpen, setIsSupportChatOpen] = useState(false);

  // Connection status from SafeDataCache (Quota / Network resilience)
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatusInfo>(safeDataCache.getStatus());

  useEffect(() => {
    return safeDataCache.subscribeStatus((status) => {
      setConnectionStatus(status);
    });
  }, []);

  // Validate persistent student session on boot / page refresh / reopen
  useEffect(() => {
    validateStoredSession().then((res) => {
      if (res.isValid) {
        setIsStudentAuthenticated(true);
        if (res.student) setActiveStudent(res.student);
        if (res.sessionId) setActiveSessionId(res.sessionId);
      } else {
        setIsStudentAuthenticated(false);
        setActiveStudent(null);
        setActiveSessionId(null);
        if (res.reason && res.reason !== 'No stored session found') {
          setStudentSessionTerminationNotice(res.reason);
        }
      }
    });
  }, []);

  // Real-time watchdog for active student session
  useEffect(() => {
    if (!isStudentAuthenticated || !activeStudent?.id || !activeSessionId) return;

    const unsubscribe = subscribeStudentSessionWatchdog(
      activeStudent.id,
      activeSessionId,
      (reason) => {
        setIsStudentAuthenticated(false);
        setActiveStudent(null);
        setActiveSessionId(null);
        setStudentSessionTerminationNotice(reason);
      },
      (updatedStudent) => {
        setActiveStudent(updatedStudent);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [isStudentAuthenticated, activeStudent?.id, activeSessionId]);

  // Real-time synchronization for student notifications
  useEffect(() => {
    const currentStudentId = activeStudent?.id || getStoredSession()?.studentId;
    if (!currentStudentId) {
      setStudentNotifs([]);
      return;
    }
    const unsubscribe = subscribeStudentNotifications(currentStudentId, (list) => {
      setStudentNotifs(list);
    });
    return () => {
      unsubscribe();
    };
  }, [activeStudent?.id]);

  // Dynamic public platforms and settings from database with safe initial cache
  const [publicPlatforms, setPublicPlatforms] = useState<PlatformRecord[]>(() =>
    safeDataCache.getPlatforms().filter((p) => p.isAvailable)
  );
  const [settings, setSettings] = useState<SettingsRecord | null>(() =>
    safeDataCache.getSettings()
  );

  // Admin state
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [adminNoticeMessage, setAdminNoticeMessage] = useState<string>('');

  // Subscribe to real-time central Supabase data across all devices
  useEffect(() => {
    api.verifyAuth().then((isValid) => {
      setIsAdminLoggedIn(isValid);
    });

    // Real-time admin session watchdog: immediately terminates sessions when password changes globally
    const unsubscribeAdminWatchdog = subscribeAdminSessionWatchdog((isValid, reason) => {
      if (!isValid) {
        setIsAdminLoggedIn(false);
        setIsAdminMode(false);
        setAdminNoticeMessage(
          reason || 'Admin password was changed globally. All sessions have been logged out. Please log in again.'
        );
        setIsLoginModalOpen(true);
      }
    });

    // Real-time listener for batches/platforms: Single Source of Truth
    const unsubscribePlatforms = subscribePlatforms((livePlatforms) => {
      setPublicPlatforms(livePlatforms.filter((p) => p.isAvailable));
    });

    // Real-time listener for global settings (Telegram URL, branding, banners)
    const unsubscribeSettings = subscribeSettings((liveSettings) => {
      setSettings(liveSettings);
    });

    return () => {
      unsubscribeAdminWatchdog();
      unsubscribePlatforms();
      unsubscribeSettings();
    };
  }, []);

  // Refresh platforms whenever exiting admin mode or returning to public view
  const handleExitAdmin = () => {
    setIsAdminMode(false);
    api.fetchLivePlatforms().then((live) => {
      setPublicPlatforms(live.filter((p) => p.isAvailable));
    }).catch(() => {});
  };

  // Student Profile / Preferences state (local to client)
  const [user, setUser] = useState<UserProfile>(() => {
    const defaultProfile: UserProfile = {
      name: 'Student',
      email: 'student@freestudycampus.in',
      avatarSeed: 'Felix',
      avatarUrl: undefined,
      gradeLevel: 'Class 12th',
      targetExam: 'NEET / JEE 2026',
      studyMinutes: 120,
      savedNotes: [],
      bookmarkedLectures: [],
      streakDays: 14,
    };

    try {
      const stored = localStorage.getItem(USER_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return {
          ...defaultProfile,
          ...parsed,
          avatarUrl: parsed.avatarUrl || (parsed.avatarSeed?.startsWith('data:') ? parsed.avatarSeed : undefined),
          savedNotes: Array.isArray(parsed?.savedNotes) ? parsed.savedNotes : [],
          bookmarkedLectures: Array.isArray(parsed?.bookmarkedLectures) ? parsed.bookmarkedLectures : [],
        };
      }
    } catch {
      // ignore
    }
    return defaultProfile;
  });

  const handleUpdateUser = (updated: Partial<UserProfile>) => {
    setUser((prev) => {
      const next = { ...prev, ...updated };
      try {
        localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  const handleTabChange = (tab: TabType) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenAdmin = () => {
    setAdminNoticeMessage('');
    if (isAdminLoggedIn) {
      setIsAdminMode(true);
    } else {
      setIsLoginModalOpen(true);
    }
  };

  const handleLoginSuccess = () => {
    setAdminNoticeMessage('');
    setIsAdminLoggedIn(true);
    setIsLoginModalOpen(false);
    setIsAdminMode(true);
  };

  const handleAdminLogout = async () => {
    await api.logout();
    setIsAdminLoggedIn(false);
    setIsAdminMode(false);
  };

  // Student Unlock Success Handler
  const handleStudentUnlockSuccess = (student?: StudentUser, sessionId?: string) => {
    setIsStudentAuthenticated(true);
    if (student) setActiveStudent(student);
    if (sessionId) setActiveSessionId(sessionId);
    setStudentSessionTerminationNotice(null);
  };

  // Student Logout Handler (Releases device lock)
  const handleStudentLogout = async () => {
    if (activeStudent?.id) {
      await logoutStudentUser(activeStudent.id, activeSessionId || undefined);
    } else {
      await logoutStudentUser();
    }
    setIsStudentAuthenticated(false);
    setActiveStudent(null);
    setActiveSessionId(null);
    setStudentSessionTerminationNotice('You have logged out. You can now log in on this or another device.');
  };

  const currentLogoUrl = getWebsiteLogo(settings?.logo, settings?.updatedAt);

  // Dynamically update document favicon and touch icons whenever global logo changes
  useEffect(() => {
    if (currentLogoUrl) {
      updateDocumentFavicon(currentLogoUrl);
    }
  }, [currentLogoUrl]);

  // 1. Splash Screen shows on initial app launch only
  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} logoUrl={currentLogoUrl} />;
  }

  // 2. If Admin Mode is active and logged in, show Admin Batch Management layout
  if (isAdminMode && isAdminLoggedIn) {
    return (
      <AdminLayout
        onLogout={handleAdminLogout}
        onExitAdmin={handleExitAdmin}
        onDataChanged={() => {
          api.fetchLivePlatforms().then((live) => {
            setPublicPlatforms(live.filter((p) => p.isAvailable));
          }).catch(() => {});
        }}
      />
    );
  }

  // 3. Student Login Screen or Public Batch Demo Screen (Works WITHOUT login or purchase)
  if (!isStudentAuthenticated) {
    if (showPublicDemos) {
      return (
        <div
          className="min-h-screen text-slate-100 flex flex-col relative px-4 py-5 sm:py-7 bg-[#06080d]"
          style={{
            backgroundColor: config.bgHex || '#07090e',
          }}
        >
          {/* Ambient Lighting */}
          <div
            className="fixed inset-0 pointer-events-none opacity-40"
            style={{
              background: `radial-gradient(ellipse 70% 45% at 50% -5%, ${themeColor}22 0%, transparent 65%), radial-gradient(circle at 95% 60%, ${config.secondaryColor}12 0%, transparent 50%)`,
              transform: 'translateZ(0)',
            }}
          />
          <main className="flex-1 w-full max-w-5xl mx-auto relative z-10 pt-2">
            <BatchDemoView
              onBack={() => setShowPublicDemos(false)}
              backLabel="Back to Login"
            />
          </main>
        </div>
      );
    }

    return (
      <>
        <StudentAccessScreen
          onUnlockSuccess={handleStudentUnlockSuccess}
          onOpenAdmin={handleOpenAdmin}
          onOpenDemos={() => setShowPublicDemos(true)}
          terminationNotice={studentSessionTerminationNotice}
          telegramChannelUrl={settings?.telegramChannelUrl || settings?.contactLink || 'https://t.me/freestudycampus'}
          logoUrl={currentLogoUrl}
        />
        <AdminLoginModal
          isOpen={isLoginModalOpen}
          onClose={() => {
            setIsLoginModalOpen(false);
            setAdminNoticeMessage('');
          }}
          onLoginSuccess={handleLoginSuccess}
          noticeMessage={adminNoticeMessage}
        />
      </>
    );
  }

  // 4. Authenticated Student Website
  return (
    <div
      className="min-h-screen text-slate-100 flex flex-col relative selection:bg-red-500/25 selection:text-red-100"
      style={{
        backgroundColor: config.bgHex || '#07090e',
        transition: 'background-color 0.45s ease',
      }}
    >
      {/* Cinematic Ambient Background Gradients - Native GPU Radial Gradients without costly blur filters */}
      <div
        className="fixed inset-0 pointer-events-none opacity-40 transition-opacity duration-700"
        style={{
          background: `radial-gradient(ellipse 70% 45% at 50% -5%, ${themeColor}22 0%, transparent 65%), radial-gradient(circle at 95% 60%, ${config.secondaryColor}12 0%, transparent 50%), radial-gradient(circle at 5% 40%, ${themeColor}10 0%, transparent 45%)`,
          transform: 'translateZ(0)',
          contain: 'strict',
        }}
      />

      {/* Non-blocking Connection Notice Banner */}
      {connectionStatus.isUsingSavedData && (
        <div className="bg-amber-500/10 border-b border-amber-500/20 text-amber-300 text-xs py-1.5 px-4 flex items-center justify-center gap-2 text-center sticky top-0 z-50 backdrop-blur-md animate-in fade-in">
          <WifiOff className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>Connection temporarily unavailable. Showing saved data.</span>
        </div>
      )}

      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        showBack={activeTab === 'SUPPORT'}
        onBack={() => handleTabChange('HOME')}
        onOpenProfile={() => handleTabChange('PROFILE')}
        onOpenAdmin={handleOpenAdmin}
        onOpenNotifications={() => setIsStudentNotifOpen(true)}
        unreadNotificationCount={studentNotifs.filter((n) => !n.read).length}
        logoUrl={currentLogoUrl}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-5xl mx-auto px-4 sm:px-6 pt-5 pb-20 relative z-10">
        {activeTab === 'HOME' && (
          <HomeView
            platforms={publicPlatforms}
            logoUrl={currentLogoUrl}
          />
        )}

        {activeTab === 'PLATFORMS' && (
          <PlatformsView platforms={publicPlatforms} logoUrl={currentLogoUrl} />
        )}

        {activeTab === 'UPCOMING' && <UpcomingView />}

        {activeTab === 'SUPPORT' && (
          <StudentWhatsAppChat
            student={activeStudent}
            onClose={() => setActiveTab('HOME')}
            initialTicketId={selectedSupportTicketId}
          />
        )}

        {activeTab === 'PROFILE' && (
          <ProfileView
            user={user}
            student={activeStudent}
            studentAvatarUrl={
              activeStudent?.avatarUrl ||
              user.avatarUrl ||
              (user.avatarSeed?.startsWith('data:') || user.avatarSeed?.startsWith('http') || user.avatarSeed?.startsWith('/')
                ? user.avatarSeed
                : null)
            }
            onUpdateAvatar={async (newAvatar) => {
              handleUpdateUser({ avatarUrl: newAvatar, avatarSeed: newAvatar });
              if (activeStudent?.id) {
                await updateStudentAvatar(activeStudent.id, newAvatar);
                setActiveStudent((prev) => (prev ? { ...prev, avatarUrl: newAvatar } : null));
              }
            }}
            onUpdateUser={handleUpdateUser}
            onReplaySplash={() => setShowSplash(true)}
            onOpenAdmin={handleOpenAdmin}
            onLogoutStudent={handleStudentLogout}
            onOpenSupport={() => setIsSupportChatOpen(true)}
          />
        )}

        {/* Telegram Channel Card */}
        <TelegramChannelCard channelUrl={settings?.telegramChannelUrl || settings?.contactLink || 'https://t.me/freestudycampus'} />

        {/* Developer Attribution with subtle continuous pulse & shimmer */}
        <DeveloperCredit />
      </main>

      {/* Fixed Bottom Navigation with Real-Time Profile Photo Sync */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        studentAvatarUrl={
          activeStudent?.avatarUrl ||
          user.avatarUrl ||
          (user.avatarSeed?.startsWith('data:') || user.avatarSeed?.startsWith('http') || user.avatarSeed?.startsWith('/')
            ? user.avatarSeed
            : null)
        }
      />

      {/* Admin Login Modal (For Admin Panel access) */}
      <AdminLoginModal
        isOpen={isLoginModalOpen}
        onClose={() => {
          setIsLoginModalOpen(false);
          setAdminNoticeMessage('');
        }}
        onLoginSuccess={handleLoginSuccess}
        noticeMessage={adminNoticeMessage}
      />
      {/* Student Notification Center Modal */}
      <StudentNotificationCenter
        studentId={activeStudent?.id || getStoredSession()?.studentId}
        isOpen={isStudentNotifOpen}
        onClose={() => setIsStudentNotifOpen(false)}
        onOpenTicket={(ticketId) => {
          setSelectedSupportTicketId(ticketId);
          setIsSupportChatOpen(true);
          setIsStudentNotifOpen(false);
        }}
      />

      {/* 5. Small Premium Circular Floating Chat Button at Bottom-Right Corner of ALL Student Pages */}
      <FloatingChatButton
        onClick={() => setIsSupportChatOpen((prev) => !prev)}
        isOpen={isSupportChatOpen}
        student={activeStudent}
      />

      {/* 6. Student Support & Admin Chat Center (Preserves message history and reply capability) */}
      <StudentChatModal
        isOpen={isSupportChatOpen}
        onClose={() => setIsSupportChatOpen(false)}
        student={activeStudent}
        initialSelectedTicketId={selectedSupportTicketId}
      />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <MainApp />
    </ThemeProvider>
  );
}
