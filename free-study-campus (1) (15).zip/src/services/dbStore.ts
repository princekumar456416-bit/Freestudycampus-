export interface PlatformRecord {
  id: string;
  name: string;
  tagline: string;
  description: string;
  accentColor: string;
  externalUrl: string;
  logo: string;
  displayOrder: number;
  isAvailable: boolean;
  totalBatches?: number;
  createdAt: string;
  updatedAt: string;
}

export interface BatchRecord {
  id: string;
  platformId: string;
  title: string;
  shortDescription: string;
  thumbnail: string;
  teacherName: string;
  subject: string;
  category: string;
  batchUrl: string;
  startDate: string;
  status: 'Active' | 'Upcoming' | 'Completed';
  displayOrder: number;
  isFeatured: boolean;
  isAvailable: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AnnouncementRecord {
  id: string;
  title: string;
  message: string;
  date: string;
  link?: string;
  isActive: boolean;
  createdAt: string;
}

export interface UpcomingRecord {
  id: string;
  batchName: string;
  platform: string;
  description: string;
  thumbnail: string;
  expectedDate: string;
  externalUrl?: string;
  status: 'Upcoming' | 'In Preparation';
  createdAt: string;
}

export interface SettingsRecord {
  websiteName: string;
  tagline: string;
  logo: string;
  defaultTheme: string;
  maintenanceMode: boolean;
  announcementBanner: string;
  contactLink: string;
  telegramChannelUrl?: string;
  telegramBotUrl?: string;
  telegramBotHandle?: string;
  upiId?: string;
  qrImageUrl?: string;
  feeText?: string;
  customSettings?: Record<string, string>;
  updatedAt?: string;
}

export interface CourseRecord {
  id: string;
  batchId?: string;
  title: string;
  description: string;
  educator: string;
  category: string;
  thumbnail: string;
  isAvailable: boolean;
  createdAt: string;
}

export interface SubjectRecord {
  id: string;
  batchId?: string;
  courseId?: string;
  name: string;
  code?: string;
  totalChapters?: number;
  totalLectures?: number;
  isAvailable: boolean;
}

export interface ChapterRecord {
  id: string;
  subjectId?: string;
  batchId?: string;
  title: string;
  chapterNumber: number;
  totalLessons?: number;
  isAvailable: boolean;
}

export interface LessonRecord {
  id: string;
  chapterId?: string;
  title: string;
  duration: string;
  videoUrl?: string;
  notesUrl?: string;
  isAvailable: boolean;
}

export interface CampusDatabase {
  platforms: PlatformRecord[];
  batches: BatchRecord[];
  courses: CourseRecord[];
  subjects: SubjectRecord[];
  chapters: ChapterRecord[];
  lessons: LessonRecord[];
  announcements: AnnouncementRecord[];
  upcoming: UpcomingRecord[];
  settings: SettingsRecord;
}

export const DEFAULT_CAMPUS_DB: CampusDatabase = {
  platforms: [
    {
      id: 'target-board',
      name: 'Target Board',
      tagline: 'Authorized Learning Partner',
      description: 'Comprehensive board exam preparation and study portal.',
      accentColor: '#00e5ff',
      externalUrl: 'https://targetboard.com.in',
      logo: 'TB',
      displayOrder: 1,
      isAvailable: true,
      totalBatches: 1,
      createdAt: '2026-09-23T16:40:00.000Z',
      updatedAt: '2026-09-23T16:40:00.000Z',
    },
    {
      id: 'learn-and-share',
      name: 'Learn and share',
      tagline: 'Authorized Learning Partner',
      description: 'Interactive concept videos and academic archives.',
      accentColor: '#00e5ff',
      externalUrl: 'https://Https. Pwthor. Com',
      logo: 'LS',
      displayOrder: 2,
      isAvailable: true,
      totalBatches: 0,
      createdAt: '2026-09-26T05:59:46.970Z',
      updatedAt: '2026-09-26T05:59:46.970Z',
    },
  ],
  batches: [
    {
      id: 'batch-pw-lakshya-jee',
      platformId: 'physics-wallah',
      title: 'Lakshya JEE 2027 Comprehensive Batch',
      shortDescription: 'Complete Class 12 & Dropper JEE Advanced program with chapter-wise modules and solved question banks.',
      thumbnail: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=600&auto=format&fit=crop&q=80',
      teacherName: 'Senior JEE Mentors',
      subject: 'Physics, Chemistry & Mathematics',
      category: 'JEE',
      batchUrl: 'https://pwthor.live/study/batches',
      startDate: '2026-09-01',
      status: 'Active',
      displayOrder: 1,
      isFeatured: true,
      isAvailable: true,
      createdAt: '2026-09-23T16:40:00.000Z',
      updatedAt: '2026-09-23T16:40:00.000Z',
    },
    {
      id: 'batch-pw-yakeen-neet',
      platformId: 'physics-wallah',
      title: 'Yakeen NEET 2027 Dropper Batch',
      shortDescription: 'High-yield NCERT diagram-based video lectures, formula notes, and daily practice test sheets.',
      thumbnail: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=600&auto=format&fit=crop&q=80',
      teacherName: 'Senior NEET Faculty',
      subject: 'Physics, Chemistry & Biology',
      category: 'NEET',
      batchUrl: 'https://pwthor.live/study/batches',
      startDate: '2026-09-15',
      status: 'Active',
      displayOrder: 2,
      isFeatured: true,
      isAvailable: true,
      createdAt: '2026-09-23T16:40:00.000Z',
      updatedAt: '2026-09-23T16:40:00.000Z',
    },
    {
      id: 'batch-tb-bihar-board-12',
      platformId: 'target-board',
      title: 'Target Board Class 12th State Board Super Batch',
      shortDescription: 'Dedicated Hindi and English medium syllabus coverage with model papers and question bank solutions.',
      thumbnail: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&auto=format&fit=crop&q=80',
      teacherName: 'Prince Sir & Team',
      subject: 'All Board Subjects',
      category: 'BOARD',
      batchUrl: 'https://targetboard.com.in',
      startDate: '2026-09-10',
      status: 'Active',
      displayOrder: 1,
      isFeatured: true,
      isAvailable: true,
      createdAt: '2026-09-23T16:40:00.000Z',
      updatedAt: '2026-09-23T16:40:00.000Z',
    },
  ],
  announcements: [
    {
      id: 'ann-1',
      title: 'New Session 2026-2027 Batches Live!',
      message: 'Lakshya JEE and Yakeen NEET study batches have been updated with complete formula compendiums.',
      date: 'September 2026',
      link: 'https://pwthor.live/study/batches',
      isActive: true,
      createdAt: '2026-09-23T16:34:06.789Z',
    },
  ],
  upcoming: [
    {
      id: 'up-1',
      batchName: 'Target Board 2027 Comprehensive Foundation',
      platform: 'Target Board',
      description: 'Comprehensive 2-year integrated course with foundational syllabus and questions.',
      thumbnail: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&auto=format&fit=crop&q=80',
      expectedDate: 'October 15, 2026',
      externalUrl: 'https://targetboard.com.in',
      status: 'Upcoming',
      createdAt: '2026-09-23T16:34:06.789Z',
    },
  ],
  courses: [],
  subjects: [],
  chapters: [],
  lessons: [],
  settings: {
    websiteName: 'FREE STUDY CAMPUS',
    tagline: 'Learn More. Grow More.',
    logo: '/logo.png',
    defaultTheme: 'cyan',
    maintenanceMode: false,
    announcementBanner: 'Free and authorized study resources for competitive exam aspirants nationwide.',
    contactLink: 'https://t.me/freestudycampus',
    telegramChannelUrl: 'https://t.me/freestudycampus',
    telegramBotUrl: 'https://t.me/Freestudycampusbot',
    telegramBotHandle: '@Freestudycampusbot',
    upiId: '77630159@ybl',
    feeText: '₹49',
  },
};

const DB_STORAGE_KEY = 'fsc_campus_database_v3';

export const dbStore = {
  getDb(): CampusDatabase {
    if (typeof localStorage === 'undefined') {
      return { ...DEFAULT_CAMPUS_DB };
    }
    try {
      const raw = localStorage.getItem(DB_STORAGE_KEY);
      if (raw) {
        const parsed: CampusDatabase = JSON.parse(raw);
        const platforms = Array.isArray(parsed.platforms) && parsed.platforms.length > 0 ? parsed.platforms : DEFAULT_CAMPUS_DB.platforms;
        const batches = Array.isArray(parsed.batches) && parsed.batches.length > 0 ? parsed.batches : DEFAULT_CAMPUS_DB.batches;
        const courses = Array.isArray(parsed.courses) ? parsed.courses : DEFAULT_CAMPUS_DB.courses;
        const subjects = Array.isArray(parsed.subjects) ? parsed.subjects : DEFAULT_CAMPUS_DB.subjects;
        const chapters = Array.isArray(parsed.chapters) ? parsed.chapters : DEFAULT_CAMPUS_DB.chapters;
        const lessons = Array.isArray(parsed.lessons) ? parsed.lessons : DEFAULT_CAMPUS_DB.lessons;
        const announcements = Array.isArray(parsed.announcements) ? parsed.announcements : DEFAULT_CAMPUS_DB.announcements;
        const upcoming = Array.isArray(parsed.upcoming) ? parsed.upcoming : DEFAULT_CAMPUS_DB.upcoming;

        const settings = {
          ...DEFAULT_CAMPUS_DB.settings,
          ...(parsed.settings || {}),
        };

        return { platforms, batches, courses, subjects, chapters, lessons, announcements, upcoming, settings };
      }
    } catch (err) {
      console.warn('Error reading local persistent campus database:', err);
    }

    try {
      localStorage.setItem(DB_STORAGE_KEY, JSON.stringify(DEFAULT_CAMPUS_DB));
    } catch {
      // ignore
    }
    return DEFAULT_CAMPUS_DB;
  },

  setDb(db: CampusDatabase): void {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(DB_STORAGE_KEY, JSON.stringify(db));
    } catch (err) {
      console.error('Failed to write to persistent database:', err);
    }
  },

  // Sync server records into local store: NEVER overwrite good data with empty arrays on error
  syncServerPlatforms(serverPlatforms: PlatformRecord[], allowEmpty = false): PlatformRecord[] {
    if (!Array.isArray(serverPlatforms)) {
      return this.getPlatforms(true);
    }
    // Prevent replacing good cached data with an empty array if database query fails
    if (serverPlatforms.length === 0 && !allowEmpty) {
      const existing = this.getPlatforms(true);
      if (existing.length > 0) return existing;
    }
    const current = this.getDb();
    current.platforms = serverPlatforms;
    this.setDb(current);
    return serverPlatforms;
  },

  syncServerBatches(serverBatches: BatchRecord[], allowEmpty = false): BatchRecord[] {
    if (!Array.isArray(serverBatches)) {
      return this.getBatches();
    }
    // Prevent replacing good cached data with an empty array if database query fails
    if (serverBatches.length === 0 && !allowEmpty) {
      const existing = this.getBatches();
      if (existing.length > 0) return existing;
    }
    const current = this.getDb();
    current.batches = serverBatches;
    this.setDb(current);
    return serverBatches;
  },

  getPlatforms(includeInactive = false): PlatformRecord[] {
    const db = this.getDb();
    const sorted = [...db.platforms].sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
    return includeInactive ? sorted : sorted.filter((p) => p.isAvailable);
  },

  addPlatform(data: Partial<PlatformRecord>): PlatformRecord {
    const db = this.getDb();
    const id = data.id || `plat-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const index = db.platforms.findIndex((p) => p.id === id);

    if (index !== -1) {
      const existing = db.platforms[index];
      const updated: PlatformRecord = {
        ...existing,
        ...data,
        name: data.name !== undefined ? data.name.trim() : existing.name,
        externalUrl: data.externalUrl !== undefined ? data.externalUrl.trim() : existing.externalUrl,
        updatedAt: new Date().toISOString(),
      };
      db.platforms[index] = updated;
      this.setDb(db);
      return updated;
    }

    const newPlatform: PlatformRecord = {
      id,
      name: (data.name || '').trim(),
      tagline: data.tagline || 'Authorized Learning Partner',
      description: data.description || '',
      accentColor: data.accentColor || '#00e5ff',
      externalUrl: (data.externalUrl || '').trim(),
      logo: data.logo ? data.logo.trim() : (data.name?.slice(0, 2) || 'SC').toUpperCase(),
      displayOrder: data.displayOrder ?? (db.platforms.length + 1),
      isAvailable: data.isAvailable !== undefined ? data.isAvailable : true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.platforms.push(newPlatform);
    this.setDb(db);
    return newPlatform;
  },

  updatePlatform(id: string, data: Partial<PlatformRecord>): PlatformRecord {
    const db = this.getDb();
    const index = db.platforms.findIndex((p) => p.id === id);

    if (index === -1) {
      // If platform is not in dbStore yet, create it safely rather than throwing
      const newPlatform: PlatformRecord = {
        id,
        name: (data.name || '').trim(),
        tagline: data.tagline || 'Authorized Learning Partner',
        description: data.description || '',
        accentColor: data.accentColor || '#00e5ff',
        externalUrl: (data.externalUrl || '').trim(),
        logo: data.logo ? data.logo.trim() : (data.name?.slice(0, 2) || 'SC').toUpperCase(),
        displayOrder: data.displayOrder ?? (db.platforms.length + 1),
        isAvailable: data.isAvailable !== undefined ? data.isAvailable : true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      db.platforms.push(newPlatform);
      this.setDb(db);
      return newPlatform;
    }

    const updated: PlatformRecord = {
      ...db.platforms[index],
      ...data,
      name: data.name !== undefined ? data.name.trim() : db.platforms[index].name,
      externalUrl: data.externalUrl !== undefined ? data.externalUrl.trim() : db.platforms[index].externalUrl,
      updatedAt: new Date().toISOString(),
    };

    db.platforms[index] = updated;
    this.setDb(db);
    return updated;
  },

  deletePlatform(id: string): void {
    const db = this.getDb();
    db.platforms = db.platforms.filter((p) => p.id !== id);
    this.setDb(db);
  },

  reorderPlatforms(ids: string[]): PlatformRecord[] {
    const db = this.getDb();
    const map = new Map(db.platforms.map((p) => [p.id, p]));
    const reordered: PlatformRecord[] = [];

    ids.forEach((id, index) => {
      const p = map.get(id);
      if (p) {
        p.displayOrder = index + 1;
        reordered.push(p);
        map.delete(id);
      }
    });

    // Append any leftover
    map.forEach((p) => {
      p.displayOrder = reordered.length + 1;
      reordered.push(p);
    });

    db.platforms = reordered;
    this.setDb(db);
    return reordered;
  },

  // Batches
  getBatches(platformId?: string): BatchRecord[] {
    const db = this.getDb();
    let list = db.batches;
    if (platformId) {
      list = list.filter((b) => b.platformId === platformId);
    }
    return [...list].sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
  },

  addBatch(data: Partial<BatchRecord>): BatchRecord {
    const db = this.getDb();
    const id = data.id || `batch-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const newBatch: BatchRecord = {
      id,
      platformId: data.platformId || 'physics-wallah',
      title: (data.title || '').trim(),
      shortDescription: data.shortDescription || '',
      thumbnail: data.thumbnail || 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=600&auto=format&fit=crop&q=80',
      teacherName: data.teacherName || 'Faculty Mentor',
      subject: data.subject || 'All Subjects',
      category: data.category || 'GENERAL',
      batchUrl: (data.batchUrl || '').trim(),
      startDate: data.startDate || new Date().toISOString().split('T')[0],
      status: data.status || 'Active',
      displayOrder: data.displayOrder ?? (db.batches.length + 1),
      isFeatured: Boolean(data.isFeatured),
      isAvailable: data.isAvailable !== undefined ? data.isAvailable : true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.batches.push(newBatch);
    this.setDb(db);
    return newBatch;
  },

  updateBatch(id: string, data: Partial<BatchRecord>): BatchRecord {
    const db = this.getDb();
    const index = db.batches.findIndex((b) => b.id === id);
    if (index === -1) {
      throw new Error(`Batch with id "${id}" not found`);
    }

    const updated: BatchRecord = {
      ...db.batches[index],
      ...data,
      title: data.title !== undefined ? data.title.trim() : db.batches[index].title,
      batchUrl: data.batchUrl !== undefined ? data.batchUrl.trim() : db.batches[index].batchUrl,
      updatedAt: new Date().toISOString(),
    };

    db.batches[index] = updated;
    this.setDb(db);
    return updated;
  },

  deleteBatch(id: string): void {
    const db = this.getDb();
    db.batches = db.batches.filter((b) => b.id !== id);
    this.setDb(db);
  },

  // Announcements
  getAnnouncements(): AnnouncementRecord[] {
    const db = this.getDb();
    return db.announcements;
  },

  addAnnouncement(data: Partial<AnnouncementRecord>): AnnouncementRecord {
    const db = this.getDb();
    const id = data.id || `ann-${Date.now()}`;
    const newAnn: AnnouncementRecord = {
      id,
      title: (data.title || '').trim(),
      message: (data.message || '').trim(),
      date: data.date || 'Active Alert',
      link: data.link,
      isActive: data.isActive !== undefined ? data.isActive : true,
      createdAt: new Date().toISOString(),
    };

    db.announcements.unshift(newAnn);
    this.setDb(db);
    return newAnn;
  },

  updateAnnouncement(id: string, data: Partial<AnnouncementRecord>): AnnouncementRecord {
    const db = this.getDb();
    const index = db.announcements.findIndex((a) => a.id === id);
    if (index === -1) throw new Error('Announcement not found');

    const updated = { ...db.announcements[index], ...data };
    db.announcements[index] = updated;
    this.setDb(db);
    return updated;
  },

  deleteAnnouncement(id: string): void {
    const db = this.getDb();
    db.announcements = db.announcements.filter((a) => a.id !== id);
    this.setDb(db);
  },

  // Settings
  getSettings(): SettingsRecord {
    const db = this.getDb();
    return db.settings;
  },

  updateSettings(data: Partial<SettingsRecord>): SettingsRecord {
    const db = this.getDb();
    db.settings = { ...db.settings, ...data };
    this.setDb(db);
    return db.settings;
  },
};
