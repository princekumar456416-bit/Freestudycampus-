import { supabase } from './supabase';

export interface BatchDemo {
  id: string;
  title: string;
  platformName: string;
  platformLogo?: string;
  videoUrl: string;
  videoId: string;
  description?: string;
  displayOrder: number;
  isAvailable: boolean;
  createdAt: string;
  updatedAt: string;
}

const LOCAL_STORAGE_KEY = 'fsc_batch_demos_cache_v1';

/**
 * Extracts and validates YouTube video ID and returns standard embed URL.
 * Supports:
 * - https://www.youtube.com/watch?v=VIDEO_ID
 * - https://youtu.be/VIDEO_ID
 * - https://www.youtube.com/embed/VIDEO_ID
 * - https://youtube.com/shorts/VIDEO_ID
 * - Unlisted video URLs and direct 11-character video IDs.
 */
export function parseYouTubeVideo(url: string): {
  isValid: boolean;
  videoId: string | null;
  embedUrl: string | null;
  thumbnailUrl: string | null;
  error?: string;
} {
  if (!url || !url.trim()) {
    return {
      isValid: false,
      videoId: null,
      embedUrl: null,
      thumbnailUrl: null,
      error: 'Please enter a YouTube video URL',
    };
  }

  const clean = url.trim();
  const regExp =
    /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([^"&?\/\s]{11})/i;
  const match = clean.match(regExp);

  if (match && match[1]) {
    const videoId = match[1];
    return {
      isValid: true,
      videoId,
      embedUrl: `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1&playsinline=1`,
      thumbnailUrl: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
    };
  }

  // Direct 11-character video ID
  if (/^[a-zA-Z0-9_-]{11}$/.test(clean)) {
    return {
      isValid: true,
      videoId: clean,
      embedUrl: `https://www.youtube-nocookie.com/embed/${clean}?autoplay=1&rel=0&modestbranding=1&playsinline=1`,
      thumbnailUrl: `https://img.youtube.com/vi/${clean}/hqdefault.jpg`,
    };
  }

  return {
    isValid: false,
    videoId: null,
    embedUrl: null,
    thumbnailUrl: null,
    error: 'Invalid YouTube link. Please provide a standard watch, youtu.be, or unlisted video URL.',
  };
}

/**
 * Loads cached demos from local storage.
 * NOTE: Returns empty array if none found or if user deleted all demos.
 * Never restores deleted demos from hardcoded arrays.
 */
function loadLocalDemos(): BatchDemo[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore
  }
  return [];
}

function persistLocalDemos(demos: BatchDemo[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(demos));
    window.dispatchEvent(new CustomEvent('fsc_batch_demos_updated', { detail: demos }));
  } catch {
    // ignore
  }
}

let cachedDemos: BatchDemo[] = loadLocalDemos();
const demoListeners = new Set<(demos: BatchDemo[]) => void>();
let supabaseRealtimeChannel: any = null;

// Map Supabase announcement row with demo_ prefix to BatchDemo
function mapSupabaseRowToDemo(row: any): BatchDemo {
  let parsedMsg: any = {};
  try {
    if (typeof row.message === 'string' && row.message.startsWith('{')) {
      parsedMsg = JSON.parse(row.message);
    }
  } catch {
    // ignore
  }

  const videoUrl = row.link || parsedMsg.videoUrl || '';
  const parsedVid = parseYouTubeVideo(videoUrl);

  return {
    id: String(row.id),
    title: row.title || 'BATCH DEMO',
    platformName: parsedMsg.platformName || row.date || 'Free Study Campus',
    platformLogo: parsedMsg.platformLogo || '',
    videoUrl,
    videoId: parsedVid.videoId || parsedMsg.videoId || '',
    description: parsedMsg.description || '',
    displayOrder: typeof parsedMsg.displayOrder === 'number' ? parsedMsg.displayOrder : 100,
    isAvailable: row.is_active !== false,
    createdAt: row.created_at || new Date().toISOString(),
    updatedAt: parsedMsg.updatedAt || row.created_at || new Date().toISOString(),
  };
}

function mapDemoToSupabaseRow(d: BatchDemo): any {
  return {
    id: d.id,
    title: d.title,
    message: JSON.stringify({
      platformName: d.platformName,
      platformLogo: d.platformLogo || '',
      videoUrl: d.videoUrl,
      videoId: d.videoId,
      description: d.description || '',
      displayOrder: d.displayOrder,
      updatedAt: d.updatedAt,
    }),
    date: d.platformName,
    link: d.videoUrl,
    is_active: d.isAvailable,
  };
}

/**
 * Fetches all batch demos directly from the Supabase database.
 * Supabase is the SINGLE SOURCE OF TRUTH.
 * If 0 rows exist in the database, returns 0 demos.
 */
export async function fetchBatchDemos(includeDisabled = false): Promise<BatchDemo[]> {
  try {
    const { data, error } = await supabase
      .from('announcements')
      .select('*')
      .like('id', 'demo_%')
      .order('created_at', { ascending: true });

    if (!error && Array.isArray(data)) {
      const list = data.map(mapSupabaseRowToDemo).sort((a, b) => a.displayOrder - b.displayOrder);
      cachedDemos = list;
      persistLocalDemos(list);
      return includeDisabled ? list : list.filter((d) => d.isAvailable);
    } else if (error) {
      console.warn('Supabase fetchBatchDemos error:', error);
    }
  } catch (err) {
    console.warn('Supabase fetchBatchDemos notice:', err);
  }

  return includeDisabled ? cachedDemos : cachedDemos.filter((d) => d.isAvailable);
}

/**
 * Admin action: Creates a brand new batch demo option in Supabase.
 * Broadcasts immediately to all devices and students.
 */
export async function createBatchDemo(data: {
  title: string;
  platformName: string;
  platformLogo?: string;
  videoUrl: string;
  description?: string;
  isAvailable?: boolean;
}): Promise<BatchDemo> {
  const parsed = parseYouTubeVideo(data.videoUrl);
  if (!parsed.isValid || !parsed.videoId) {
    throw new Error(parsed.error || 'Invalid YouTube video URL');
  }

  const id = `demo_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();
  const maxOrder = cachedDemos.reduce((max, d) => Math.max(max, d.displayOrder || 0), 0);

  const newDemo: BatchDemo = {
    id,
    title: data.title.trim(),
    platformName: data.platformName.trim() || 'Free Study Campus',
    platformLogo: data.platformLogo?.trim() || '',
    videoUrl: data.videoUrl.trim(),
    videoId: parsed.videoId,
    description: data.description?.trim() || '',
    displayOrder: maxOrder + 1,
    isAvailable: data.isAvailable !== false,
    createdAt: now,
    updatedAt: now,
  };

  // 1. Sync to Supabase announcements table
  const row = mapDemoToSupabaseRow(newDemo);
  const { error } = await supabase.from('announcements').insert(row);
  if (error) {
    // Attempt upsert fallback if insert fails
    const { error: upsertErr } = await supabase.from('announcements').upsert(row);
    if (upsertErr) {
      throw new Error(`Failed to save demo in database: ${upsertErr.message}`);
    }
  }

  // 2. Update local state and notify listeners
  cachedDemos = [...cachedDemos, newDemo].sort((a, b) => a.displayOrder - b.displayOrder);
  persistLocalDemos(cachedDemos);
  demoListeners.forEach((fn) => fn(cachedDemos));

  return newDemo;
}

/**
 * Admin action: Updates an existing demo (title, videoUrl, isAvailable, etc.) in Supabase.
 */
export async function updateBatchDemo(
  id: string,
  patch: Partial<BatchDemo>
): Promise<BatchDemo> {
  const existing = cachedDemos.find((d) => d.id === id);
  if (!existing) {
    throw new Error('Batch demo not found');
  }

  let videoId = existing.videoId;
  if (patch.videoUrl && patch.videoUrl !== existing.videoUrl) {
    const parsed = parseYouTubeVideo(patch.videoUrl);
    if (!parsed.isValid || !parsed.videoId) {
      throw new Error(parsed.error || 'Invalid YouTube video URL');
    }
    videoId = parsed.videoId;
  }

  const updated: BatchDemo = {
    ...existing,
    ...patch,
    videoId,
    updatedAt: new Date().toISOString(),
  };

  // 1. Sync to Supabase
  const row = mapDemoToSupabaseRow(updated);
  const { error } = await supabase.from('announcements').update(row).eq('id', id);
  if (error) {
    // Attempt upsert fallback
    const { error: upsertErr } = await supabase.from('announcements').upsert(row);
    if (upsertErr) {
      throw new Error(`Failed to update demo in database: ${upsertErr.message}`);
    }
  }

  // 2. Update local state and notify listeners
  cachedDemos = cachedDemos
    .map((d) => (d.id === id ? updated : d))
    .sort((a, b) => a.displayOrder - b.displayOrder);
  persistLocalDemos(cachedDemos);
  demoListeners.forEach((fn) => fn(cachedDemos));

  return updated;
}

/**
 * Admin action: Deletes a batch demo permanently from Supabase.
 * The demo is removed from the database and will never reappear after refresh or app reopen.
 */
export async function deleteBatchDemo(id: string): Promise<boolean> {
  // 1. Remove from Supabase database
  const { error } = await supabase.from('announcements').delete().eq('id', id);
  if (error) {
    throw new Error(`Failed to delete demo from database: ${error.message}`);
  }

  // 2. Remove from cache and local store immediately
  cachedDemos = cachedDemos.filter((d) => d.id !== id);
  persistLocalDemos(cachedDemos);
  demoListeners.forEach((fn) => fn(cachedDemos));
  return true;
}

/**
 * Admin action: Reorders batch demos up / down and saves new order in Supabase.
 */
export async function reorderBatchDemos(orderedIds: string[]): Promise<BatchDemo[]> {
  const updated = cachedDemos.map((demo) => {
    const idx = orderedIds.indexOf(demo.id);
    return idx !== -1 ? { ...demo, displayOrder: idx + 1 } : demo;
  });

  updated.sort((a, b) => a.displayOrder - b.displayOrder);
  cachedDemos = updated;
  persistLocalDemos(updated);
  demoListeners.forEach((fn) => fn(updated));

  // Sync updated orders to Supabase
  for (const d of updated) {
    try {
      await supabase.from('announcements').update({
        message: JSON.stringify({
          platformName: d.platformName,
          platformLogo: d.platformLogo || '',
          videoUrl: d.videoUrl,
          videoId: d.videoId,
          description: d.description || '',
          displayOrder: d.displayOrder,
          updatedAt: d.updatedAt,
        }),
      }).eq('id', d.id);
    } catch (e) {
      console.warn('Notice reordering demo in Supabase:', e);
    }
  }

  return updated;
}

/**
 * Subscribes to real-time batch demo changes across all student devices.
 * Reads from Supabase database as the single source of truth.
 */
export function subscribeBatchDemos(
  callback: (demos: BatchDemo[]) => void,
  includeDisabled = false
): () => void {
  const listener = (allDemos: BatchDemo[]) => {
    callback(includeDisabled ? allDemos : allDemos.filter((d) => d.isAvailable));
  };

  demoListeners.add(listener);

  // 1. Provide cached data immediately for instant responsive rendering
  if (cachedDemos.length > 0) {
    listener(cachedDemos);
  }

  // 2. Always fetch authoritative fresh data from Supabase database
  fetchBatchDemos(true).then((fresh) => {
    listener(fresh);
  });

  // 3. Cross-tab & multi-window event listener
  const handleStorageUpdate = (e: any) => {
    if (e.detail && Array.isArray(e.detail)) {
      cachedDemos = e.detail;
      listener(cachedDemos);
    }
  };
  window.addEventListener('fsc_batch_demos_updated', handleStorageUpdate);

  // 4. Real-time PostgreSQL changes subscription via Supabase
  if (!supabaseRealtimeChannel) {
    try {
      supabaseRealtimeChannel = supabase
        .channel('public:batch_demos_realtime')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'announcements' },
          async (payload) => {
            const rowId = (payload.new as any)?.id || (payload.old as any)?.id;
            // When any demo is added, modified, or deleted:
            if (!rowId || String(rowId).startsWith('demo_')) {
              const fresh = await fetchBatchDemos(true);
              demoListeners.forEach((fn) => fn(fresh));
            }
          }
        )
        .subscribe();
    } catch (e) {
      console.warn('Realtime subscription notice for batch_demos:', e);
    }
  }

  return () => {
    demoListeners.delete(listener);
    window.removeEventListener('fsc_batch_demos_updated', handleStorageUpdate);
  };
}
