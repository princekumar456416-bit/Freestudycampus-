import {
  PlatformRecord,
  BatchRecord,
  AnnouncementRecord,
  UpcomingRecord,
  SettingsRecord,
  dbStore,
  DEFAULT_CAMPUS_DB,
} from './dbStore';
import { ADMIN_CONFIG } from '../config/adminAuth';
import {
  verifyStudentAccessPassword,
  verifyAdminAccessPassword,
  setSupabaseStudentPassword,
  setSupabaseAdminPassword,
  setSupabasePaymentSettings,
  getLatestAuthConfig,
  subscribeAuthConfig,
  getCachedAuthConfig,
  hashAdminPassword,
  verifyAdminSession,
  subscribeAdminSessionWatchdog,
  notifyAdminSessionTerminated,
  AuthConfig,
} from './authConfigService';
import { supabase, isSupabaseConfigured } from './supabase';
import {
  supabasePlatforms,
  supabaseBatches,
  supabaseSettings,
  supabaseCurriculum,
} from './supabaseDataService';
import {
  safeDataCache,
  isDatabaseOrNetworkError,
  ConnectionStatusInfo,
} from './safeDataCache';
import { broadcastSync, subscribeSyncBroadcast } from './syncBroadcaster';

export {
  safeDataCache,
  subscribeAdminSessionWatchdog,
  verifyAdminSession,
  hashAdminPassword,
};

export type {
  PlatformRecord,
  BatchRecord,
  AnnouncementRecord,
  UpcomingRecord,
  SettingsRecord,
  AuthConfig,
  ConnectionStatusInfo,
};

let platformsUnsubscribe: (() => void) | null = null;
const platformListeners = new Set<(platforms: PlatformRecord[]) => void>();
let cachedLivePlatforms: PlatformRecord[] | null = null;
let hasAttemptedPlatformSeeding = false;

/**
 * Direct fetch from Supabase that immediately updates all active subscribers.
 */
export async function fetchLivePlatforms(): Promise<PlatformRecord[]> {
  try {
    const liveList = await supabasePlatforms.getAll();
    if (Array.isArray(liveList) && liveList.length > 0) {
      safeDataCache.reportConnectionSuccess();
      cachedLivePlatforms = liveList;
      safeDataCache.syncFromLiveDatabase('platforms', liveList);
      dbStore.syncServerPlatforms(liveList, true);

      platformListeners.forEach((fn) => {
        try {
          fn(liveList);
        } catch (e) {
          console.error('Error in platforms subscriber callback:', e);
        }
      });
      return liveList;
    }
  } catch (err) {
    if (isDatabaseOrNetworkError(err)) {
      safeDataCache.reportConnectionIssue(err);
    }
  }
  return cachedLivePlatforms || safeDataCache.getPlatforms();
}

async function ensureInitialPlatformsInSupabase() {
  if (hasAttemptedPlatformSeeding) return;
  hasAttemptedPlatformSeeding = true;
  try {
    const existing = await supabasePlatforms.getAll();
    if (existing.length === 0) {
      for (const p of DEFAULT_CAMPUS_DB.platforms) {
        await supabasePlatforms.create(p).catch(() => {});
      }
    } else {
      cachedLivePlatforms = existing;
      safeDataCache.syncFromLiveDatabase('platforms', existing);
      dbStore.syncServerPlatforms(existing, true);

      platformListeners.forEach((fn) => {
        try {
          fn(existing);
        } catch (e) {
          console.error('Error in platforms subscriber callback on initial check:', e);
        }
      });
    }
  } catch (err) {
    console.warn('Initial platform seeding note:', err);
  }
}

// Background lifecycle listeners for mobile sleep, tab switching, and reconnection
if (typeof window !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      fetchLivePlatforms().catch(() => {});
    }
  });

  window.addEventListener('online', () => {
    fetchLivePlatforms().catch(() => {});
  });

  subscribeSyncBroadcast((event) => {
    if (event.type === 'platforms' && Array.isArray(event.payload)) {
      cachedLivePlatforms = event.payload;
      safeDataCache.syncFromLiveDatabase('platforms', event.payload);
      dbStore.syncServerPlatforms(event.payload, true);
      platformListeners.forEach((fn) => {
        try {
          fn(event.payload);
        } catch (e) {
          console.error('Error in broadcast sync platform listener:', e);
        }
      });
    }
  });
}

/**
 * Real-time centralized Supabase subscription for Platforms & Batches.
 */
export function subscribePlatforms(callback: (platforms: PlatformRecord[]) => void): () => void {
  platformListeners.add(callback);

  if (cachedLivePlatforms !== null) {
    callback(cachedLivePlatforms);
  } else {
    callback(safeDataCache.getPlatforms());
  }

  fetchLivePlatforms().catch(() => {});
  ensureInitialPlatformsInSupabase().catch(() => {});

  if (!platformsUnsubscribe) {
    try {
      const channel = supabase
        .channel('public:platforms')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'platforms' },
          async () => {
            try {
              const liveList = await supabasePlatforms.getAll();
              if (liveList.length > 0) {
                cachedLivePlatforms = liveList;
                safeDataCache.syncFromLiveDatabase('platforms', liveList);
                dbStore.syncServerPlatforms(liveList, true);
                platformListeners.forEach((fn) => {
                  try {
                    fn(liveList);
                  } catch (e) {
                    console.error('Error in platforms subscriber callback:', e);
                  }
                });
              }
            } catch (e) {
              console.warn('Supabase realtime platform fetch notice:', e);
            }
          }
        )
        .subscribe();

      platformsUnsubscribe = () => {
        supabase.removeChannel(channel);
      };
    } catch (e) {
      console.warn('Realtime subscription notice for platforms:', e);
    }
  }

  return () => {
    platformListeners.delete(callback);
    if (platformListeners.size === 0 && platformsUnsubscribe) {
      platformsUnsubscribe();
      platformsUnsubscribe = null;
    }
  };
}

let announcementsUnsubscribe: (() => void) | null = null;
const announcementListeners = new Set<(announcements: AnnouncementRecord[]) => void>();
let cachedLiveAnnouncements: AnnouncementRecord[] | null = null;

export function mapSupabaseToAnnouncement(row: any): AnnouncementRecord {
  return {
    id: String(row.id),
    title: String(row.title || ''),
    message: String(row.message || ''),
    date: String(row.date || ''),
    link: row.link || undefined,
    isActive: row.is_active !== false && row.isActive !== false,
    createdAt: row.created_at || row.createdAt || new Date().toISOString(),
  };
}

export function subscribeAnnouncements(callback: (announcements: AnnouncementRecord[]) => void): () => void {
  announcementListeners.add(callback);

  if (cachedLiveAnnouncements !== null) {
    callback(cachedLiveAnnouncements);
  } else {
    callback(safeDataCache.getAnnouncements());
  }

  // Live fetch to ensure fresh cloud data
  api.getAnnouncements().then((data) => {
    callback(data);
  }).catch(() => {});

  if (!announcementsUnsubscribe) {
    // Polling heartbeat interval (every 5 seconds)
    const intervalId = setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
        api.getAnnouncements().then((fresh) => {
          announcementListeners.forEach((fn) => fn(fresh));
        }).catch(() => {});
      }
    }, 5000);

    try {
      const channel = supabase
        .channel('public:announcements')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'announcements' },
          async () => {
            try {
              const fresh = await api.getAnnouncements();
              announcementListeners.forEach((fn) => fn(fresh));
            } catch (e) {
              console.warn('Supabase realtime announcements notice:', e);
            }
          }
        )
        .subscribe();

      announcementsUnsubscribe = () => {
        clearInterval(intervalId);
        supabase.removeChannel(channel);
      };
    } catch {
      announcementsUnsubscribe = () => {
        clearInterval(intervalId);
      };
    }
  }

  return () => {
    announcementListeners.delete(callback);
    if (announcementListeners.size === 0 && announcementsUnsubscribe) {
      announcementsUnsubscribe();
      announcementsUnsubscribe = null;
    }
  };
}

let settingsUnsubscribe: (() => void) | null = null;
const settingsListeners = new Set<(settings: SettingsRecord) => void>();
let cachedLiveSettings: SettingsRecord | null = null;

export function subscribeSettings(callback: (settings: SettingsRecord) => void): () => void {
  settingsListeners.add(callback);

  if (cachedLiveSettings !== null) {
    callback(cachedLiveSettings);
  } else {
    const cached = safeDataCache.getSettings() || dbStore.getSettings();
    if (cached) callback(cached);
  }

  supabaseSettings.get().then((live) => {
    if (live) {
      cachedLiveSettings = live;
      safeDataCache.saveSettings(live);
      dbStore.updateSettings(live);
      callback(live);
    }
  }).catch(() => {});

  if (!settingsUnsubscribe) {
    try {
      const unsub = supabaseSettings.subscribe((liveSettings) => {
        cachedLiveSettings = liveSettings;
        safeDataCache.saveSettings(liveSettings);
        dbStore.updateSettings(liveSettings);

        settingsListeners.forEach((fn) => {
          try {
            fn(liveSettings);
          } catch (e) {
            console.error('Error in settings subscriber callback:', e);
          }
        });
      });
      settingsUnsubscribe = unsub;
    } catch (e) {
      console.warn('Realtime subscription notice for settings:', e);
    }
  }

  return () => {
    settingsListeners.delete(callback);
    if (settingsListeners.size === 0 && settingsUnsubscribe) {
      settingsUnsubscribe();
      settingsUnsubscribe = null;
    }
  };
}

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('fsc_admin_token') || localStorage.getItem('token');
  if (token) {
    return { Authorization: `Bearer ${token}` };
  }
  return {};
}

async function safeFetch(url: string, options: RequestInit = {}, timeoutMs: number = 8000): Promise<Response | null> {
  try {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeoutMs);
    const response = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(id);
    return response;
  } catch (err: unknown) {
    return null;
  }
}

export const api = {
  async login(password: string): Promise<{ success: boolean; token?: string; error?: string }> {
    try {
      const authRes = await verifyAdminAccessPassword(password);
      if (authRes.success) {
        const sessionToken = await hashAdminPassword(password);
        localStorage.setItem('fsc_admin_token', sessionToken);
        localStorage.setItem('token', sessionToken);
        return { success: true, token: sessionToken };
      }
      return { success: false, error: authRes.error || 'Incorrect Password' };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Login failed';
      return { success: false, error: msg };
    }
  },

  async logout(): Promise<void> {
    localStorage.removeItem('fsc_admin_token');
    localStorage.removeItem('token');
  },

  async verifyAuth(): Promise<boolean> {
    return verifyAdminSession();
  },

  async requireValidAdmin(): Promise<void> {
    const isValid = await this.verifyAuth();
    if (!isValid) {
      notifyAdminSessionTerminated('Admin session expired or password was changed. Please log in again.');
      throw new Error('Admin session expired or password was changed. Please log in again.');
    }
  },

  async verifyStudentCode(code: string): Promise<boolean> {
    const res = await verifyStudentAccessPassword(code);
    return res.success;
  },

  async changeAdminPassword(currentPass: string, newPass: string): Promise<{ success: boolean; error?: string }> {
    const verifyRes = await verifyAdminAccessPassword(currentPass);
    if (!verifyRes.success) {
      return { success: false, error: 'Current password is incorrect' };
    }
    return setSupabaseAdminPassword(newPass);
  },

  async changePassword(currentPass: string, newPass: string): Promise<{ success: boolean; error?: string }> {
    return this.changeAdminPassword(currentPass, newPass);
  },

  async getStudentAccessConfig(): Promise<{
    feeText: string;
    feeAmount: number;
    telegramBotUrl: string;
    telegramBotHandle: string;
    upiId: string;
    qrImageUrl: string;
    paymentInstructions: string;
  }> {
    const cfg = await getLatestAuthConfig();
    return {
      feeText: cfg.feeText,
      feeAmount: cfg.feeAmount,
      telegramBotUrl: cfg.telegramBotUrl,
      telegramBotHandle: cfg.telegramBotHandle,
      upiId: cfg.upiId,
      qrImageUrl: cfg.qrImageUrl,
      paymentInstructions: cfg.paymentInstructions || '',
    };
  },

  async updateStudentAccessConfig(data: {
    newCode?: string;
    feeText?: string;
    feeAmount?: number;
    telegramBotUrl?: string;
    telegramBotHandle?: string;
    upiId?: string;
    qrImageUrl?: string;
  }): Promise<{ success: boolean; error?: string }> {
    await this.requireValidAdmin();
    let success = true;
    let error: string | undefined;

    if (data.newCode !== undefined) {
      const codeRes = await setSupabaseStudentPassword(data.newCode);
      if (!codeRes.success) {
        success = false;
        error = codeRes.error;
      }
    }

    if (success) {
      const numericAmount =
        data.feeAmount !== undefined && !isNaN(data.feeAmount)
          ? data.feeAmount
          : data.feeText
          ? parseFloat(data.feeText.replace(/[^\d.]/g, '')) || 49
          : undefined;

      const payRes = await setSupabasePaymentSettings({
        ...data,
        feeAmount: numericAmount,
      });

      if (!payRes.success) {
        success = false;
        error = payRes.error;
      } else {
        try {
          await supabaseSettings.update({
            feeText: data.feeText,
            feeAmount: numericAmount,
            telegramBotUrl: data.telegramBotUrl,
            telegramBotHandle: data.telegramBotHandle,
            upiId: data.upiId,
            qrImageUrl: data.qrImageUrl,
          });
        } catch (err) {
          console.warn('Sync to supabaseSettings note:', err);
        }
      }
    }

    return { success, error };
  },

  async getPlatforms(): Promise<PlatformRecord[]> {
    if (cachedLivePlatforms !== null) {
      return cachedLivePlatforms.filter((p) => p.isAvailable);
    }
    return fetchLivePlatforms();
  },

  async fetchLivePlatforms(): Promise<PlatformRecord[]> {
    return fetchLivePlatforms();
  },

  async getBatches(param?: string | { platformId?: string }): Promise<BatchRecord[]> {
    const platformId = typeof param === 'string' ? param : param?.platformId;
    try {
      const batches = await supabaseBatches.getAll(platformId);
      if (batches.length > 0) {
        safeDataCache.saveBatches(batches);
        return batches;
      }
    } catch {
      // ignore
    }
    return safeDataCache.getBatches(platformId);
  },

  async getCourses(batchId: string): Promise<any[]> {
    try {
      const courses = await supabaseCurriculum.getCourses(batchId);
      if (courses.length > 0) {
        safeDataCache.saveCourses(courses as any);
        return courses;
      }
    } catch {
      // ignore
    }
    return safeDataCache.getCourses(batchId);
  },

  async getSubjects(courseId: string): Promise<any[]> {
    try {
      const subjects = await supabaseCurriculum.getSubjects(courseId);
      if (subjects.length > 0) {
        safeDataCache.saveSubjects(subjects as any);
        return subjects;
      }
    } catch {
      // ignore
    }
    return safeDataCache.getSubjects(courseId);
  },

  async getChapters(subjectId: string): Promise<any[]> {
    try {
      const chapters = await supabaseCurriculum.getChapters(subjectId);
      if (chapters.length > 0) {
        safeDataCache.saveChapters(chapters as any);
        return chapters;
      }
    } catch {
      // ignore
    }
    return safeDataCache.getChapters(subjectId);
  },

  async getLessons(chapterId: string): Promise<any[]> {
    try {
      const lessons = await supabaseCurriculum.getLessons(chapterId);
      if (lessons.length > 0) {
        safeDataCache.saveLessons(lessons as any);
        return lessons;
      }
    } catch {
      // ignore
    }
    return safeDataCache.getLessons(chapterId);
  },

  async getAnnouncements(): Promise<AnnouncementRecord[]> {
    try {
      const { data, error } = await supabase
        .from('announcements')
        .select('*')
        .not('id', 'like', 'demo_%')
        .not('id', 'like', 'chat_%')
        .order('created_at', { ascending: false });

      if (!error && Array.isArray(data)) {
        const mapped = data.map(mapSupabaseToAnnouncement);
        cachedLiveAnnouncements = mapped;
        safeDataCache.saveAnnouncements(mapped);
        return mapped.filter((a) => a.isActive);
      }
    } catch {
      // ignore
    }
    if (cachedLiveAnnouncements !== null) {
      return cachedLiveAnnouncements.filter((a) => a.isActive);
    }
    return safeDataCache.getAnnouncements().filter((a) => a.isActive);
  },

  async getUpcoming(): Promise<UpcomingRecord[]> {
    return safeDataCache.getUpcoming();
  },

  async getSettings(): Promise<SettingsRecord | null> {
    if (cachedLiveSettings) return cachedLiveSettings;
    try {
      const s = await supabaseSettings.get();
      if (s) {
        cachedLiveSettings = s;
        safeDataCache.saveSettings(s);
        return s;
      }
    } catch {
      // ignore
    }
    return safeDataCache.getSettings() || dbStore.getSettings();
  },

  async getAdminStats(): Promise<{ totalPlatforms: number; totalBatches: number; activeBatches: number; upcomingBatches: number }> {
    const platforms = safeDataCache.getPlatforms();
    const batches = safeDataCache.getBatches();
    return {
      totalPlatforms: platforms.length,
      totalBatches: batches.length,
      activeBatches: batches.filter((b) => b.status === 'Active').length,
      upcomingBatches: batches.filter((b) => b.status === 'Upcoming').length,
    };
  },

  async getAdminPlatforms(): Promise<PlatformRecord[]> {
    if (cachedLivePlatforms !== null) {
      return cachedLivePlatforms;
    }
    return this.getPlatforms();
  },

  async addPlatform(data: Partial<PlatformRecord>): Promise<PlatformRecord> {
    await this.requireValidAdmin();
    if (!data.name || !data.name.trim()) {
      throw new Error('Please enter Batch Name');
    }
    if (!data.externalUrl || !data.externalUrl.trim()) {
      throw new Error('Please enter Batch Link');
    }

    const id = data.id || `plat-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const currentList = cachedLivePlatforms || safeDataCache.getPlatforms();
    const newPlatform: PlatformRecord = {
      id,
      name: data.name.trim(),
      tagline: (data.tagline || 'Authorized Learning Partner').trim(),
      description: (data.description || '').trim(),
      accentColor: data.accentColor || '#00e5ff',
      externalUrl: data.externalUrl.trim(),
      logo: data.logo ? data.logo.trim() : (data.name?.slice(0, 2) || 'SC').toUpperCase(),
      displayOrder: data.displayOrder ?? (currentList.length + 1),
      isAvailable: data.isAvailable !== undefined ? data.isAvailable : true,
      totalBatches: data.totalBatches ?? 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      await supabasePlatforms.create(newPlatform);
      safeDataCache.reportConnectionSuccess();
    } catch (err) {
      console.warn('Supabase platforms insert notice:', err);
    }

    dbStore.addPlatform(newPlatform);
    const all = dbStore.getPlatforms(true);
    safeDataCache.savePlatforms(all);
    const currentListForAdd = cachedLivePlatforms || safeDataCache.getPlatforms();
    cachedLivePlatforms = [...currentListForAdd.filter((p) => p.id !== id), newPlatform].sort(
      (a, b) => (a.displayOrder ?? 0) - (b.displayOrder ?? 0)
    );
    safeDataCache.syncFromLiveDatabase('platforms', cachedLivePlatforms);

    platformListeners.forEach((fn) => {
      try {
        fn(cachedLivePlatforms!);
      } catch (e) {
        console.error('Error notifying platformListener on add:', e);
      }
    });
    broadcastSync('platforms', cachedLivePlatforms);

    return newPlatform;
  },

  async updatePlatform(id: string, data: Partial<PlatformRecord>): Promise<PlatformRecord> {
    await this.requireValidAdmin();
    const existing =
      cachedLivePlatforms?.find((p) => p.id === id) ||
      safeDataCache.getPlatforms().find((p) => p.id === id) ||
      dbStore.getPlatforms(true).find((p) => p.id === id);

    const updated: PlatformRecord = {
      id,
      name: data.name !== undefined ? data.name.trim() : (existing?.name || ''),
      tagline: data.tagline !== undefined ? data.tagline.trim() : (existing?.tagline || 'Authorized Learning Partner'),
      description: data.description !== undefined ? data.description.trim() : (existing?.description || ''),
      accentColor: data.accentColor || existing?.accentColor || '#00e5ff',
      externalUrl: data.externalUrl !== undefined ? data.externalUrl.trim() : (existing?.externalUrl || ''),
      logo: data.logo !== undefined ? data.logo.trim() : (existing?.logo || ''),
      displayOrder: data.displayOrder !== undefined ? data.displayOrder : (existing?.displayOrder ?? 1),
      isAvailable: data.isAvailable !== undefined ? data.isAvailable : (existing?.isAvailable ?? true),
      totalBatches: data.totalBatches !== undefined ? data.totalBatches : (existing?.totalBatches ?? 0),
      createdAt: existing?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      await supabasePlatforms.update(id, updated);
      safeDataCache.reportConnectionSuccess();
    } catch (err) {
      console.warn('Supabase platforms update notice:', err);
    }

    dbStore.updatePlatform(id, updated);
    const all = dbStore.getPlatforms(true);
    safeDataCache.savePlatforms(all);
    const currentListForUpdate = cachedLivePlatforms || safeDataCache.getPlatforms();
    cachedLivePlatforms = currentListForUpdate.map((p) => (p.id === id ? { ...p, ...updated } : p));
    safeDataCache.syncFromLiveDatabase('platforms', cachedLivePlatforms);

    platformListeners.forEach((fn) => {
      try {
        fn(cachedLivePlatforms!);
      } catch (e) {
        console.error('Error notifying platformListener on update:', e);
      }
    });
    broadcastSync('platforms', cachedLivePlatforms);

    return updated;
  },

  async deletePlatform(id: string): Promise<void> {
    await this.requireValidAdmin();
    try {
      await supabasePlatforms.delete(id);
      safeDataCache.reportConnectionSuccess();
    } catch (err) {
      console.warn('Supabase platforms delete notice:', err);
    }

    dbStore.deletePlatform(id);
    const all = dbStore.getPlatforms(true);
    safeDataCache.savePlatforms(all);
    const currentListForDelete = cachedLivePlatforms || safeDataCache.getPlatforms();
    cachedLivePlatforms = currentListForDelete.filter((p) => p.id !== id);
    safeDataCache.syncFromLiveDatabase('platforms', cachedLivePlatforms);

    platformListeners.forEach((fn) => {
      try {
        fn(cachedLivePlatforms!);
      } catch (e) {
        console.error('Error notifying platformListener on delete:', e);
      }
    });
    broadcastSync('platforms', cachedLivePlatforms);
  },

  async reorderPlatform(id: string, direction: 'up' | 'down'): Promise<PlatformRecord[]> {
    const platforms = await this.getAdminPlatforms();
    const index = platforms.findIndex((p) => p.id === id);
    if (index === -1) return platforms;
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= platforms.length) return platforms;

    const newPlatforms = [...platforms];
    const [moved] = newPlatforms.splice(index, 1);
    newPlatforms.splice(targetIndex, 0, moved);

    await this.reorderPlatforms(newPlatforms.map((p) => p.id));
    return newPlatforms;
  },

  async reorderPlatforms(ids: string[]): Promise<void> {
    const reordered = dbStore.reorderPlatforms(ids);
    safeDataCache.savePlatforms(reordered);
    cachedLivePlatforms = [...reordered];
    safeDataCache.syncFromLiveDatabase('platforms', cachedLivePlatforms);
    platformListeners.forEach((fn) => fn(cachedLivePlatforms!));
    broadcastSync('platforms', cachedLivePlatforms);

    try {
      for (let i = 0; i < ids.length; i++) {
        await supabasePlatforms.update(ids[i], { displayOrder: i + 1 }).catch(() => {});
      }
    } catch (e) {
      console.warn('Notice reordering platforms in Supabase:', e);
    }
  },

  async getAdminBatches(platformId?: string): Promise<BatchRecord[]> {
    return this.getBatches(platformId);
  },

  async addBatch(data: Partial<BatchRecord>): Promise<BatchRecord> {
    await this.requireValidAdmin();
    const id = data.id || `batch-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const newBatch: BatchRecord = {
      id,
      platformId: data.platformId || 'physics-wallah',
      title: (data.title || '').trim(),
      shortDescription: data.shortDescription || '',
      thumbnail: data.thumbnail || 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=600&auto=format&fit=crop&q=80',
      teacherName: data.teacherName || 'Faculty Mentor',
      subject: data.subject || 'All Subjects',
      category: data.category || 'GENERAL',
      batchUrl: (data.batchUrl || '').trim(),
      startDate: data.startDate || new Date().toISOString().split('T')[0],
      status: data.status || 'Active',
      displayOrder: data.displayOrder ?? 1,
      isFeatured: Boolean(data.isFeatured),
      isAvailable: data.isAvailable !== undefined ? data.isAvailable : true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    dbStore.addBatch(newBatch);
    const all = dbStore.getBatches();
    safeDataCache.saveBatches(all);

    try {
      await supabaseBatches.create(newBatch);
    } catch (err) {
      console.warn('Supabase batch create notice:', err);
    }

    return newBatch;
  },

  async updateBatch(id: string, data: Partial<BatchRecord>): Promise<BatchRecord> {
    await this.requireValidAdmin();
    const updated = dbStore.updateBatch(id, data);
    const all = dbStore.getBatches();
    safeDataCache.saveBatches(all);

    try {
      await supabaseBatches.update(id, data);
    } catch (err) {
      console.warn('Supabase batch update notice:', err);
    }

    return updated;
  },

  async deleteBatch(id: string): Promise<void> {
    await this.requireValidAdmin();
    dbStore.deleteBatch(id);
    const all = dbStore.getBatches();
    safeDataCache.saveBatches(all);

    try {
      await supabaseBatches.delete(id);
    } catch (err) {
      console.warn('Supabase batch delete notice:', err);
    }
  },

  async reorderBatches(ids: string[]): Promise<void> {
    await this.requireValidAdmin();
    // Reorder in memory & local storage
  },

  async getAdminAnnouncements(): Promise<AnnouncementRecord[]> {
    await this.requireValidAdmin();
    try {
      const { data, error } = await supabase
        .from('announcements')
        .select('*')
        .not('id', 'like', 'demo_%')
        .not('id', 'like', 'chat_%')
        .order('created_at', { ascending: false });

      if (!error && Array.isArray(data)) {
        const mapped = data.map(mapSupabaseToAnnouncement);
        cachedLiveAnnouncements = mapped;
        safeDataCache.saveAnnouncements(mapped);
        return mapped;
      }
    } catch {
      // ignore
    }
    return safeDataCache.getAnnouncements();
  },

  async addAnnouncement(data: Partial<AnnouncementRecord>): Promise<AnnouncementRecord> {
    await this.requireValidAdmin();
    const saved = dbStore.addAnnouncement(data);
    safeDataCache.saveAnnouncements(dbStore.getAnnouncements());

    // Sync to Supabase cloud database with exact Postgres schema columns
    try {
      const supaRow = {
        id: saved.id,
        title: saved.title,
        message: saved.message,
        date: saved.date,
        link: saved.link || null,
        is_active: saved.isActive !== false,
        created_at: saved.createdAt,
      };
      const { error } = await supabase.from('announcements').upsert(supaRow);
      if (error) {
        console.warn('Supabase announcement upsert warning:', error.message);
      }
    } catch (err) {
      console.warn('Supabase announcement insert notice:', err);
    }

    this.getAnnouncements().then((fresh) => {
      announcementListeners.forEach((fn) => fn(fresh));
    }).catch(() => {});

    return saved;
  },

  async updateAnnouncement(id: string, data: Partial<AnnouncementRecord>): Promise<AnnouncementRecord> {
    await this.requireValidAdmin();
    const updated = dbStore.updateAnnouncement(id, data);
    safeDataCache.saveAnnouncements(dbStore.getAnnouncements());

    try {
      const supaUpdates: Record<string, any> = {};
      if (data.title !== undefined) supaUpdates.title = data.title;
      if (data.message !== undefined) supaUpdates.message = data.message;
      if (data.date !== undefined) supaUpdates.date = data.date;
      if (data.link !== undefined) supaUpdates.link = data.link || null;
      if (data.isActive !== undefined) supaUpdates.is_active = Boolean(data.isActive);

      const { error } = await supabase.from('announcements').update(supaUpdates).eq('id', id);
      if (error) {
        console.warn('Supabase announcement update warning:', error.message);
      }
    } catch (err) {
      console.warn('Supabase announcement update notice:', err);
    }

    this.getAnnouncements().then((fresh) => {
      announcementListeners.forEach((fn) => fn(fresh));
    }).catch(() => {});

    return updated;
  },

  async deleteAnnouncement(id: string): Promise<void> {
    await this.requireValidAdmin();
    dbStore.deleteAnnouncement(id);
    safeDataCache.saveAnnouncements(dbStore.getAnnouncements());
    if (cachedLiveAnnouncements) {
      cachedLiveAnnouncements = cachedLiveAnnouncements.filter((a) => a.id !== id);
    }

    try {
      await supabase.from('announcements').delete().eq('id', id);
    } catch (err) {
      console.warn('Supabase announcement delete notice:', err);
    }

    this.getAnnouncements().then((fresh) => {
      announcementListeners.forEach((fn) => fn(fresh));
    }).catch(() => {});
  },

  async toggleAnnouncement(id: string, isActive: boolean): Promise<AnnouncementRecord> {
    await this.requireValidAdmin();
    return this.updateAnnouncement(id, { isActive });
  },

  async getAdminSettings(): Promise<SettingsRecord> {
    return (await this.getSettings()) || dbStore.getSettings();
  },

  async updateSettings(data: Partial<SettingsRecord>): Promise<SettingsRecord> {
    await this.requireValidAdmin();
    const updated = dbStore.updateSettings(data);

    try {
      await supabaseSettings.update(data);
      safeDataCache.reportConnectionSuccess();
    } catch (err) {
      console.warn('Supabase update settings notice:', err);
    }

    safeDataCache.saveSettings(updated);
    cachedLiveSettings = updated;
    settingsListeners.forEach((fn) => {
      try {
        fn(updated);
      } catch (e) {
        console.error('Error notifying settings listener:', e);
      }
    });

    return updated;
  },

  async uploadOfficialLogo(imageData: string): Promise<{ success: boolean; logoUrl?: string; error?: string }> {
    await this.requireValidAdmin();
    try {
      const updatedAt = new Date().toISOString();
      const finalLogo = imageData ? imageData.trim() : '';

      try {
        await supabaseSettings.update({ logo: finalLogo, updatedAt });
      } catch (e) {
        console.warn('Supabase logo sync notice:', e);
      }

      try {
        dbStore.updateSettings({ logo: finalLogo, updatedAt });
        const existingSettings = safeDataCache.getSettings() || {
          websiteName: 'FREE STUDY CAMPUS',
          tagline: 'Learn More. Grow More.',
          logo: finalLogo,
          defaultTheme: 'cyan',
          maintenanceMode: false,
          announcementBanner: 'Free and authorized study resources for competitive exam aspirants.',
          contactLink: 'https://t.me/freestudycampus',
        };
        const updatedObj = { ...existingSettings, logo: finalLogo, updatedAt };
        safeDataCache.saveSettings(updatedObj);
        settingsListeners.forEach((fn) => {
          try {
            fn(updatedObj);
          } catch {
            // ignore
          }
        });
        broadcastSync('settings', updatedObj);
      } catch (err) {
        console.warn('Local cache sync error:', err);
      }

      let canonicalUrl = finalLogo || '/logo.png';
      if (finalLogo) {
        try {
          const res = await safeFetch('/api/admin/upload-official-logo', {
            method: 'POST',
            headers: { ...getAuthHeader(), 'Content-Type': 'application/json' },
            body: JSON.stringify({ imageData: finalLogo }),
          }, 15000);

          if (res && res.ok) {
            const data = await res.json();
            if (data.logoUrl) {
              canonicalUrl = data.logoUrl;
              try {
                await supabaseSettings.update({ logo: canonicalUrl, updatedAt });
                dbStore.updateSettings({ logo: canonicalUrl, updatedAt });
              } catch {
                // ignore
              }
            }
          }
        } catch (serverErr) {
          console.warn('Server icon generation note:', serverErr);
        }
      }

      return { success: true, logoUrl: canonicalUrl };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Upload failed';
      return { success: false, error: msg };
    }
  },
};
