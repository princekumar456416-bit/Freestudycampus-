import { supabase, isSupabaseConfigured } from './supabase';
import { PlatformRecord, BatchRecord, AnnouncementRecord, SettingsRecord } from '../../server/db';
import { StudentUser } from './studentUserService';

// ============================================================================
// SUPABASE DATA SERVICE LAYER (STEP 5)
// Source of truth for database operations: Supabase PostgreSQL
// ============================================================================

export interface CourseRecord {
  id: string;
  batchId: string;
  title: string;
  description: string;
  displayOrder: number;
  isAvailable: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SubjectRecord {
  id: string;
  courseId: string;
  title: string;
  displayOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface ChapterRecord {
  id: string;
  subjectId: string;
  title: string;
  displayOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface LessonRecord {
  id: string;
  chapterId: string;
  title: string;
  lessonType: 'video' | 'pdf' | 'notes';
  videoUrl?: string;
  pdfUrl?: string;
  notesContent?: string;
  durationSeconds?: number;
  displayOrder: number;
  isFreePreview: boolean;
  createdAt: string;
  updatedAt: string;
}

// ----------------------------------------------------------------------------
// 1. PLATFORMS
// ----------------------------------------------------------------------------
export const supabasePlatforms = {
  async getAll(): Promise<PlatformRecord[]> {
    const { data, error } = await supabase
      .from('platforms')
      .select('*')
      .order('display_order', { ascending: true });

    if (error) throw new Error(`Supabase platforms error: ${error.message}`);
    return (data || []).map((row: any) => ({
      id: row.id,
      name: row.name,
      tagline: row.tagline || '',
      description: row.description || '',
      accentColor: row.accent_color || '#00e5ff',
      externalUrl: row.external_url,
      logo: row.logo || '',
      displayOrder: row.display_order ?? 0,
      isAvailable: row.is_available !== false,
      totalBatches: row.total_batches ?? 0,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    }));
  },

  async create(platform: PlatformRecord): Promise<PlatformRecord> {
    const row = {
      id: platform.id,
      name: platform.name,
      tagline: platform.tagline || '',
      description: platform.description || '',
      accent_color: platform.accentColor || '#00e5ff',
      external_url: platform.externalUrl,
      logo: platform.logo || '',
      display_order: platform.displayOrder ?? 0,
      is_available: platform.isAvailable !== false,
      total_batches: platform.totalBatches ?? 0,
      created_at: platform.createdAt || new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const { error } = await supabase.from('platforms').upsert(row);
    if (error) throw new Error(`Supabase create platform error: ${error.message}`);
    return platform;
  },

  async update(id: string, updates: Partial<PlatformRecord>): Promise<void> {
    const rowUpdates: any = { updated_at: new Date().toISOString() };
    if (updates.name !== undefined) rowUpdates.name = updates.name;
    if (updates.tagline !== undefined) rowUpdates.tagline = updates.tagline;
    if (updates.description !== undefined) rowUpdates.description = updates.description;
    if (updates.accentColor !== undefined) rowUpdates.accent_color = updates.accentColor;
    if (updates.externalUrl !== undefined) rowUpdates.external_url = updates.externalUrl;
    if (updates.logo !== undefined) rowUpdates.logo = updates.logo;
    if (updates.displayOrder !== undefined) rowUpdates.display_order = updates.displayOrder;
    if (updates.isAvailable !== undefined) rowUpdates.is_available = updates.isAvailable;
    if (updates.totalBatches !== undefined) rowUpdates.total_batches = updates.totalBatches;

    const { error } = await supabase.from('platforms').update(rowUpdates).eq('id', id);
    if (error) throw new Error(`Supabase update platform error: ${error.message}`);
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase.from('platforms').delete().eq('id', id);
    if (error) throw new Error(`Supabase delete platform error: ${error.message}`);
  },

  subscribe(callback: (platforms: PlatformRecord[]) => void): () => void {
    const channel = supabase
      .channel('public:platforms')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'platforms' }, async () => {
        try {
          const list = await this.getAll();
          callback(list);
        } catch (e) {
          console.warn('Realtime platform fetch notice:', e);
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  },
};

// ----------------------------------------------------------------------------
// 2. STUDENTS
// ----------------------------------------------------------------------------
export const supabaseStudents = {
  async getAll(): Promise<StudentUser[]> {
    const { data, error } = await supabase
      .from('student_users')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw new Error(`Supabase students error: ${error.message}`);
    return (data || []).map((s: any) => ({
      id: s.id,
      username: s.username,
      name: s.name,
      passwordHash: s.password_hash,
      status: s.status,
      avatarUrl: s.avatar_url,
      activeDeviceId: s.active_device_id,
      activeSessionId: s.active_session_id,
      activeDeviceInfo: s.active_device_info,
      lastLoginAt: s.last_login_at,
      createdAt: s.created_at,
      updatedAt: s.updated_at,
    }));
  },

  async create(student: StudentUser): Promise<void> {
    const row = {
      id: student.id,
      username: student.username,
      name: student.name,
      password_hash: student.passwordHash,
      status: student.status,
      avatar_url: student.avatarUrl || null,
      active_device_id: student.activeDeviceId || null,
      active_session_id: student.activeSessionId || null,
      active_device_info: student.activeDeviceInfo || null,
      last_login_at: student.lastLoginAt || null,
      created_at: student.createdAt || new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const { error } = await supabase.from('student_users').upsert(row);
    if (error) throw new Error(`Supabase create student error: ${error.message}`);
  },

  async update(id: string, updates: Partial<StudentUser>): Promise<void> {
    const rowUpdates: any = { updated_at: new Date().toISOString() };
    if (updates.name !== undefined) rowUpdates.name = updates.name;
    if (updates.username !== undefined) rowUpdates.username = updates.username;
    if (updates.passwordHash !== undefined) rowUpdates.password_hash = updates.passwordHash;
    if (updates.status !== undefined) rowUpdates.status = updates.status;
    if (updates.avatarUrl !== undefined) rowUpdates.avatar_url = updates.avatarUrl;
    if (updates.activeDeviceId !== undefined) rowUpdates.active_device_id = updates.activeDeviceId;
    if (updates.activeSessionId !== undefined) rowUpdates.active_session_id = updates.activeSessionId;
    if (updates.activeDeviceInfo !== undefined) rowUpdates.active_device_info = updates.activeDeviceInfo;
    if (updates.lastLoginAt !== undefined) rowUpdates.last_login_at = updates.lastLoginAt;

    const { error } = await supabase.from('student_users').update(rowUpdates).eq('id', id);
    if (error) throw new Error(`Supabase update student error: ${error.message}`);
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase.from('student_users').delete().eq('id', id);
    if (error) throw new Error(`Supabase delete student error: ${error.message}`);
  },

  subscribe(callback: (students: StudentUser[]) => void): () => void {
    const channel = supabase
      .channel('public:student_users')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'student_users' }, async () => {
        try {
          const list = await this.getAll();
          callback(list);
        } catch (e) {
          console.warn('Realtime student fetch notice:', e);
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  },
};

// ----------------------------------------------------------------------------
// 3. BATCHES
// ----------------------------------------------------------------------------
export const supabaseBatches = {
  async getAll(platformId?: string): Promise<BatchRecord[]> {
    let query = supabase.from('batches').select('*').order('display_order', { ascending: true });
    if (platformId) {
      query = query.eq('platform_id', platformId);
    }
    const { data, error } = await query;
    if (error) throw new Error(`Supabase batches error: ${error.message}`);

    return (data || []).map((b: any) => ({
      id: b.id,
      platformId: b.platform_id,
      title: b.title,
      shortDescription: b.short_description || '',
      thumbnail: b.thumbnail || '',
      teacherName: b.teacher_name || '',
      subject: b.subject || '',
      category: b.category || 'ALL',
      batchUrl: b.batch_url,
      startDate: b.start_date || '',
      status: b.status || 'Active',
      displayOrder: b.display_order ?? 0,
      isFeatured: Boolean(b.is_featured),
      isAvailable: b.is_available !== false,
      createdAt: b.created_at,
      updatedAt: b.updated_at,
    }));
  },

  async create(batch: BatchRecord): Promise<BatchRecord> {
    const row = {
      id: batch.id,
      platform_id: batch.platformId,
      title: batch.title,
      short_description: batch.shortDescription || '',
      thumbnail: batch.thumbnail || '',
      teacher_name: batch.teacherName || '',
      subject: batch.subject || '',
      category: batch.category || 'ALL',
      batch_url: batch.batchUrl,
      start_date: batch.startDate || '',
      status: batch.status || 'Active',
      display_order: batch.displayOrder ?? 0,
      is_featured: Boolean(batch.isFeatured),
      is_available: batch.isAvailable !== false,
      created_at: batch.createdAt || new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const { error } = await supabase.from('batches').upsert(row);
    if (error) throw new Error(`Supabase create batch error: ${error.message}`);
    return batch;
  },

  async update(id: string, updates: Partial<BatchRecord>): Promise<void> {
    const rowUpdates: any = { updated_at: new Date().toISOString() };
    if (updates.title !== undefined) rowUpdates.title = updates.title;
    if (updates.platformId !== undefined) rowUpdates.platform_id = updates.platformId;
    if (updates.shortDescription !== undefined) rowUpdates.short_description = updates.shortDescription;
    if (updates.thumbnail !== undefined) rowUpdates.thumbnail = updates.thumbnail;
    if (updates.teacherName !== undefined) rowUpdates.teacher_name = updates.teacherName;
    if (updates.subject !== undefined) rowUpdates.subject = updates.subject;
    if (updates.category !== undefined) rowUpdates.category = updates.category;
    if (updates.batchUrl !== undefined) rowUpdates.batch_url = updates.batchUrl;
    if (updates.startDate !== undefined) rowUpdates.start_date = updates.startDate;
    if (updates.status !== undefined) rowUpdates.status = updates.status;
    if (updates.displayOrder !== undefined) rowUpdates.display_order = updates.displayOrder;
    if (updates.isFeatured !== undefined) rowUpdates.is_featured = updates.isFeatured;
    if (updates.isAvailable !== undefined) rowUpdates.is_available = updates.isAvailable;

    const { error } = await supabase.from('batches').update(rowUpdates).eq('id', id);
    if (error) throw new Error(`Supabase update batch error: ${error.message}`);
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase.from('batches').delete().eq('id', id);
    if (error) throw new Error(`Supabase delete batch error: ${error.message}`);
  },
};

// ----------------------------------------------------------------------------
// 4-8. CURRICULUM: COURSES, SUBJECTS, CHAPTERS, LESSONS
// ----------------------------------------------------------------------------
export const supabaseCurriculum = {
  async getCourses(batchId: string): Promise<CourseRecord[]> {
    const { data, error } = await supabase
      .from('courses')
      .select('*')
      .eq('batch_id', batchId)
      .order('display_order', { ascending: true });
    if (error) throw new Error(`Supabase courses error: ${error.message}`);
    return (data || []).map((c: any) => ({
      id: c.id,
      batchId: c.batch_id,
      title: c.title,
      description: c.description || '',
      displayOrder: c.display_order ?? 0,
      isAvailable: c.is_available !== false,
      createdAt: c.created_at,
      updatedAt: c.updated_at,
    }));
  },

  async getSubjects(courseId: string): Promise<SubjectRecord[]> {
    const { data, error } = await supabase
      .from('subjects')
      .select('*')
      .eq('course_id', courseId)
      .order('display_order', { ascending: true });
    if (error) throw new Error(`Supabase subjects error: ${error.message}`);
    return (data || []).map((s: any) => ({
      id: s.id,
      courseId: s.course_id,
      title: s.title,
      displayOrder: s.display_order ?? 0,
      createdAt: s.created_at,
      updatedAt: s.updated_at,
    }));
  },

  async getChapters(subjectId: string): Promise<ChapterRecord[]> {
    const { data, error } = await supabase
      .from('chapters')
      .select('*')
      .eq('subject_id', subjectId)
      .order('display_order', { ascending: true });
    if (error) throw new Error(`Supabase chapters error: ${error.message}`);
    return (data || []).map((ch: any) => ({
      id: ch.id,
      subjectId: ch.subject_id,
      title: ch.title,
      displayOrder: ch.display_order ?? 0,
      createdAt: ch.created_at,
      updatedAt: ch.updated_at,
    }));
  },

  async getLessons(chapterId: string): Promise<LessonRecord[]> {
    const { data, error } = await supabase
      .from('lessons')
      .select('*')
      .eq('chapter_id', chapterId)
      .order('display_order', { ascending: true });
    if (error) throw new Error(`Supabase lessons error: ${error.message}`);
    return (data || []).map((l: any) => ({
      id: l.id,
      chapterId: l.chapter_id,
      title: l.title,
      lessonType: l.lesson_type || 'video',
      videoUrl: l.video_url || '',
      pdfUrl: l.pdf_url || '',
      notesContent: l.notes_content || '',
      durationSeconds: l.duration_seconds ?? 0,
      displayOrder: l.display_order ?? 0,
      isFreePreview: Boolean(l.is_free_preview),
      createdAt: l.created_at,
      updatedAt: l.updated_at,
    }));
  },
};

// ----------------------------------------------------------------------------
// 9-12. SETTINGS (Global, Web Logo, Telegram, Payment QR, Fees)
// ----------------------------------------------------------------------------
export const supabaseSettings = {
  async get(): Promise<SettingsRecord | null> {
    const { data, error } = await supabase
      .from('app_settings')
      .select('*')
      .eq('id', 'global')
      .maybeSingle();

    if (error) throw new Error(`Supabase settings error: ${error.message}`);
    if (!data) return null;

    return {
      websiteName: data.website_name || 'FREE STUDY CAMPUS',
      tagline: data.tagline || 'Learn More. Grow More.',
      logo: data.logo || '',
      defaultTheme: data.default_theme || 'cyan',
      maintenanceMode: Boolean(data.maintenance_mode),
      announcementBanner: data.announcement_banner || '',
      contactLink: data.contact_link || 'https://t.me/freestudycampus',
      telegramChannelUrl: data.telegram_channel_url || 'https://t.me/freestudycampus',
      feeText: data.fee_text || '₹149',
      upiId: data.upi_id || '9472981955@ybl',
      qrImageUrl: data.qr_image_url || '',
      telegramBotUrl: data.telegram_bot_url || 'https://t.me/Freestudycampusbot',
      telegramBotHandle: data.telegram_bot_handle || '@Freestudycampusbot',
    };
  },

  async update(updates: Partial<SettingsRecord> & Record<string, any>): Promise<void> {
    const rowUpdates: any = {
      id: 'global',
      updated_at: new Date().toISOString(),
    };

    if (updates.websiteName !== undefined) rowUpdates.website_name = updates.websiteName;
    if (updates.tagline !== undefined) rowUpdates.tagline = updates.tagline;
    if (updates.logo !== undefined) rowUpdates.logo = updates.logo;
    if (updates.announcementBanner !== undefined) rowUpdates.announcement_banner = updates.announcementBanner;
    if (updates.telegramChannelUrl !== undefined) rowUpdates.telegram_channel_url = updates.telegramChannelUrl;
    if (updates.telegramBotUrl !== undefined) rowUpdates.telegram_bot_url = updates.telegramBotUrl;
    if (updates.telegramBotHandle !== undefined) rowUpdates.telegram_bot_handle = updates.telegramBotHandle;
    if (updates.contactLink !== undefined) rowUpdates.contact_link = updates.contactLink;
    if (updates.upiId !== undefined) rowUpdates.upi_id = updates.upiId;
    if (updates.feeText !== undefined) rowUpdates.fee_text = updates.feeText;
    if (updates.feeAmount !== undefined) rowUpdates.fee_amount = updates.feeAmount;
    if (updates.qrImageUrl !== undefined) rowUpdates.qr_image_url = updates.qrImageUrl;
    if (updates.paymentInstructions !== undefined) rowUpdates.payment_instructions = updates.paymentInstructions;
    if (updates.maintenanceMode !== undefined) rowUpdates.maintenance_mode = updates.maintenanceMode;
    if (updates.defaultTheme !== undefined) rowUpdates.default_theme = updates.defaultTheme;

    const { error } = await supabase.from('app_settings').upsert(rowUpdates);
    if (error) throw new Error(`Supabase update settings error: ${error.message}`);
  },

  subscribe(callback: (settings: SettingsRecord) => void): () => void {
    const channel = supabase
      .channel('public:app_settings')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'app_settings', filter: 'id=eq.global' }, async () => {
        try {
          const s = await this.get();
          if (s) callback(s);
        } catch (e) {
          console.warn('Realtime settings fetch notice:', e);
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  },
};
