import { supabase } from './supabase';
import { api } from './api';
import { notifyCrossTab } from './notificationService';

export type TicketStatus = 'Pending' | 'In Progress' | 'Resolved';

export interface SupportMessage {
  id: string;
  sender: 'student' | 'admin';
  senderName: string;
  senderUsername?: string;
  text: string;
  screenshotUrl?: string | null;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  studentId: string;
  studentName: string;
  studentUsername: string;
  subject: string;
  category?: string;
  description: string;
  screenshotUrl?: string | null;
  status: TicketStatus;
  adminReply?: string | null;
  adminRepliedAt?: string | null;
  adminLastReadAt?: string | null;
  studentLastReadAt?: string | null;
  messages: SupportMessage[];
  createdAt: string;
  updatedAt: string;
}

const LOCAL_STORAGE_KEY = 'fsc_support_tickets_v2';

export function normalizeTicket(t: any): SupportTicket {
  const messages: SupportMessage[] = Array.isArray(t.messages) && t.messages.length > 0
    ? t.messages
    : [
        {
          id: `msg_${t.id}_init`,
          sender: 'student',
          senderName: t.studentName || 'Student',
          senderUsername: t.studentUsername || '',
          text: t.description || '',
          screenshotUrl: t.screenshotUrl || null,
          createdAt: t.createdAt || new Date().toISOString(),
        },
        ...(t.adminReply
          ? [
              {
                id: `msg_${t.id}_reply`,
                sender: 'admin' as const,
                senderName: 'Campus Administrator',
                text: t.adminReply,
                createdAt: t.adminRepliedAt || t.updatedAt || new Date().toISOString(),
              },
            ]
          : []),
      ];

  return {
    id: String(t.id),
    studentId: String(t.studentId || ''),
    studentName: String(t.studentName || 'Student'),
    studentUsername: String(t.studentUsername || '').toLowerCase(),
    subject: String(t.subject || 'WhatsApp Chat with Admin Jyotish'),
    category: t.category || 'General Support',
    description: String(t.description || ''),
    screenshotUrl: t.screenshotUrl || null,
    status: (t.status as TicketStatus) || 'Pending',
    adminReply: t.adminReply || null,
    adminRepliedAt: t.adminRepliedAt || null,
    adminLastReadAt: t.adminLastReadAt || null,
    studentLastReadAt: t.studentLastReadAt || null,
    messages,
    createdAt: t.createdAt || new Date().toISOString(),
    updatedAt: t.updatedAt || new Date().toISOString(),
  };
}

let memoryTickets: SupportTicket[] = [];

function getLocalTickets(): SupportTicket[] {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(LOCAL_STORAGE_KEY) : null;
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed.map(normalizeTicket);
    }
  } catch {
    // ignore
  }
  return memoryTickets;
}

function saveLocalTickets(tickets: SupportTicket[]) {
  memoryTickets = tickets;
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(tickets));
    }
  } catch {
    // ignore
  }
}

// Global subscribers for real-time updates
const studentTicketListeners = new Map<string, Set<(tickets: SupportTicket[]) => void>>();
const adminTicketListeners = new Set<(tickets: SupportTicket[]) => void>();

function notifyStudentSubscribers(studentId: string, tickets: SupportTicket[]) {
  const set = studentTicketListeners.get(studentId);
  if (set) {
    set.forEach((fn) => {
      try {
        fn(tickets);
      } catch (e) {
        console.error('Error notifying student ticket subscriber:', e);
      }
    });
  }
}

function notifyAdminSubscribers(tickets: SupportTicket[]) {
  adminTicketListeners.forEach((fn) => {
    try {
      fn(tickets);
    } catch (e) {
      console.error('Error notifying admin ticket subscriber:', e);
    }
  });
}

/**
 * Saves or updates a student chat thread in Supabase database.
 * Uses announcements table with id `chat_${studentId}` for cloud persistence.
 */
async function syncChatToSupabase(ticket: SupportTicket) {
  try {
    const row = {
      id: `chat_${ticket.studentId}`,
      title: `Chat with ${ticket.studentName} (@${ticket.studentUsername})`,
      message: JSON.stringify(ticket),
      date: ticket.studentUsername,
      link: ticket.id,
      is_active: ticket.status !== 'Resolved',
      created_at: ticket.createdAt,
    };
    await supabase.from('announcements').upsert(row);
  } catch (err) {
    console.warn('Notice syncing chat to Supabase:', err);
  }
}

/**
 * Submits a new support complaint / starts a chat conversation with Admin.
 */
export async function submitSupportTicket(data: {
  studentId: string;
  studentName: string;
  studentUsername: string;
  subject: string;
  category?: string;
  description: string;
  screenshotUrl?: string | null;
}): Promise<{ success: boolean; ticket?: SupportTicket; error?: string }> {
  if (!data.studentId || (!data.description.trim() && !data.screenshotUrl)) {
    return { success: false, error: 'Please enter a message or select a photo.' };
  }

  const now = new Date().toISOString();
  const ticketId = `ticket_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const initialMessage: SupportMessage = {
    id: `msg_${Date.now()}_init`,
    sender: 'student',
    senderName: data.studentName.trim(),
    senderUsername: data.studentUsername.trim().toLowerCase(),
    text: data.description.trim(),
    screenshotUrl: data.screenshotUrl || null,
    createdAt: now,
  };

  const newTicket: SupportTicket = {
    id: ticketId,
    studentId: data.studentId,
    studentName: data.studentName.trim(),
    studentUsername: data.studentUsername.trim().toLowerCase(),
    subject: data.subject.trim() || 'WhatsApp Chat with Admin Jyotish',
    category: data.category?.trim() || 'General Support',
    description: data.description.trim(),
    screenshotUrl: data.screenshotUrl || null,
    status: 'Pending',
    adminReply: null,
    adminRepliedAt: null,
    messages: [initialMessage],
    createdAt: now,
    updatedAt: now,
  };

  // 1. Persist directly to Supabase
  await syncChatToSupabase(newTicket);

  // 2. Forward to Express server endpoint
  if (typeof window !== 'undefined' && typeof window.location !== 'undefined') {
    try {
      const res = await fetch('/api/support/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTicket),
      });
      if (res.ok) {
        const json = await res.json();
        if (json.ticket) {
          newTicket.id = json.ticket.id;
        }
      }
    } catch (serverErr) {
      console.warn('Notice syncing ticket to backend server:', serverErr);
    }
  }

  // 3. Update local cache
  const localList = getLocalTickets();
  const updatedList = [newTicket, ...localList.filter((t) => t.studentId !== newTicket.studentId)];
  saveLocalTickets(updatedList);

  // 4. Notify active listeners & cross-tab
  notifyStudentSubscribers(data.studentId, updatedList.filter((t) => t.studentId === data.studentId));
  notifyAdminSubscribers(updatedList);
  notifyCrossTab('ADMIN_NOTIFS_UPDATE');

  return { success: true, ticket: newTicket };
}

/**
 * Sends a message in an existing conversation thread (Student or Admin).
 * Supports text and photo attachments.
 */
export async function sendFollowUpMessage(
  ticketId: string,
  data: {
    sender: 'student' | 'admin';
    senderName: string;
    senderUsername?: string;
    text: string;
    screenshotUrl?: string | null;
  }
): Promise<{ success: boolean; message?: SupportMessage; ticket?: SupportTicket; error?: string }> {
  if (!data.text.trim() && !data.screenshotUrl) {
    return { success: false, error: 'Message cannot be empty.' };
  }

  const now = new Date().toISOString();
  const newMsg: SupportMessage = {
    id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    sender: data.sender,
    senderName: data.senderName,
    senderUsername: data.senderUsername,
    text: data.text.trim(),
    screenshotUrl: data.screenshotUrl || null,
    createdAt: now,
  };

  // 1. Update local cache immediately
  const local = getLocalTickets();
  let ticket = local.find((t) => t.id === ticketId || t.studentId === ticketId);

  // If not found in local cache, query Supabase cloud database
  if (!ticket) {
    try {
      const { data: supaRow } = await supabase
        .from('announcements')
        .select('*')
        .or(`id.eq.chat_${ticketId},link.eq.${ticketId},date.eq.${ticketId}`)
        .limit(1);

      if (supaRow && supaRow.length > 0 && typeof supaRow[0].message === 'string' && supaRow[0].message.startsWith('{')) {
        ticket = normalizeTicket(JSON.parse(supaRow[0].message));
        local.push(ticket);
      }
    } catch {
      // ignore
    }
  }

  if (ticket) {
    ticket.messages = [...(ticket.messages || []), newMsg];
    ticket.updatedAt = now;
    if (data.sender === 'admin') {
      ticket.adminReply = newMsg.text;
      ticket.adminRepliedAt = now;
    } else if (ticket.status === 'Resolved') {
      ticket.status = 'In Progress';
    }

    saveLocalTickets(local);
    notifyStudentSubscribers(ticket.studentId, local.filter((t) => t.studentId === ticket.studentId));
    notifyAdminSubscribers(local);

    // 2. Persist to Supabase database
    await syncChatToSupabase(ticket);
  }

  // 3. Send to server
  if (typeof window !== 'undefined' && typeof window.location !== 'undefined') {
    try {
      const res = await fetch(`/api/support/${encodeURIComponent(ticketId)}/message`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        const json = await res.json();
        if (json.ticket) {
          const normalized = normalizeTicket(json.ticket);
          const updated = local.map((t) => (t.id === ticketId ? normalized : t));
          saveLocalTickets(updated);
          notifyStudentSubscribers(normalized.studentId, updated.filter((t) => t.studentId === normalized.studentId));
          notifyAdminSubscribers(updated);
          if (data.sender === 'student') {
            notifyCrossTab('ADMIN_NOTIFS_UPDATE');
          } else {
            notifyCrossTab('STUDENT_NOTIFS_UPDATE', normalized.studentId);
          }
          return { success: true, message: json.message, ticket: normalized };
        }
      }
    } catch (err) {
      console.warn('Notice sending message to server:', err);
    }
  }

  if (ticket) {
    return { success: true, message: newMsg, ticket };
  }

  return { success: false, error: 'Conversation thread not found.' };
}

/**
 * Retrieves all tickets/conversations for a specific student.
 * Queries Supabase first as the single cloud source of truth.
 */
export async function fetchStudentTickets(studentId: string, username?: string): Promise<SupportTicket[]> {
  const cleanUser = (username || '').toLowerCase();
  const local = getLocalTickets().filter(
    (t) => t.studentId === studentId || (cleanUser && t.studentUsername === cleanUser)
  );

  // 1. Fetch from Supabase cloud database
  try {
    const query = cleanUser
      ? supabase.from('announcements').select('*').or(`id.eq.chat_${studentId},date.eq.${cleanUser}`).limit(1)
      : supabase.from('announcements').select('*').eq('id', `chat_${studentId}`).limit(1);

    const { data, error } = await query;

    if (!error && data && data.length > 0 && typeof data[0].message === 'string' && data[0].message.startsWith('{')) {
      const parsed = JSON.parse(data[0].message);
      const normalized = normalizeTicket(parsed);
      normalized.studentId = studentId;
      if (cleanUser) normalized.studentUsername = cleanUser;

      const allLocal = getLocalTickets();
      const updated = [
        normalized,
        ...allLocal.filter((t) => t.studentId !== studentId && t.studentUsername !== cleanUser),
      ];
      saveLocalTickets(updated);
      return [normalized];
    }
  } catch (err) {
    console.warn('Notice fetching student ticket from Supabase:', err);
  }

  // 2. Fetch from Express backend endpoint
  try {
    const res = await fetch(`/api/support/student/${encodeURIComponent(studentId)}`);
    if (res.ok) {
      const json = await res.json();
      if (Array.isArray(json.tickets) && json.tickets.length > 0) {
        const normalized = json.tickets.map(normalizeTicket);
        const allLocal = getLocalTickets();
        const updated = [
          ...normalized,
          ...allLocal.filter((t) => t.studentId !== studentId && t.studentUsername !== cleanUser),
        ];
        saveLocalTickets(updated);
        return normalized;
      }
    }
  } catch {
    // ignore
  }

  return local;
}

/**
 * Retrieves all support tickets across all students (Admin Only).
 */
export async function fetchAllTicketsAdmin(): Promise<SupportTicket[]> {
  await api.requireValidAdmin();
  let list: SupportTicket[] = [];

  // 1. Fetch from Supabase cloud database
  try {
    const { data, error } = await supabase
      .from('announcements')
      .select('*')
      .like('id', 'chat_%')
      .order('created_at', { ascending: false });

    if (!error && Array.isArray(data)) {
      for (const row of data) {
        try {
          if (typeof row.message === 'string' && row.message.startsWith('{')) {
            const parsed = JSON.parse(row.message);
            list.push(normalizeTicket(parsed));
          }
        } catch {
          // ignore
        }
      }
    }
  } catch {
    // ignore
  }

  // 2. Fetch from Express backend
  try {
    const res = await fetch('/api/admin/support');
    if (res.ok) {
      const json = await res.json();
      if (Array.isArray(json.tickets)) {
        const serverTickets = json.tickets.map(normalizeTicket);
        for (const st of serverTickets) {
          if (!list.some((t) => t.id === st.id || t.studentId === st.studentId)) {
            list.push(st);
          }
        }
      }
    }
  } catch {
    // ignore
  }

  if (list.length > 0) {
    saveLocalTickets(list);
    return list;
  }

  return getLocalTickets();
}

/**
 * Replies to a student's support ticket and updates status (Admin Only).
 */
export async function replySupportTicketAdmin(
  ticketId: string,
  replyText: string,
  status: TicketStatus = 'Resolved',
  photoUrl?: string | null
): Promise<{ success: boolean; error?: string }> {
  await api.requireValidAdmin();

  if (!replyText.trim() && !photoUrl) {
    return { success: false, error: 'Reply text or photo cannot be empty.' };
  }

  const now = new Date().toISOString();
  const local = getLocalTickets();
  let ticket = local.find((t) => t.id === ticketId || t.studentId === ticketId);

  // If not found in local cache, query Supabase cloud database
  if (!ticket) {
    try {
      const { data: supaRow } = await supabase
        .from('announcements')
        .select('*')
        .or(`id.eq.chat_${ticketId},link.eq.${ticketId}`)
        .limit(1);

      if (supaRow && supaRow.length > 0 && typeof supaRow[0].message === 'string' && supaRow[0].message.startsWith('{')) {
        ticket = normalizeTicket(JSON.parse(supaRow[0].message));
        local.push(ticket);
      }
    } catch {
      // ignore
    }
  }

  const adminMessage: SupportMessage = {
    id: `msg_${Date.now()}_reply`,
    sender: 'admin',
    senderName: 'Admin Jyotish',
    text: replyText.trim(),
    screenshotUrl: photoUrl || null,
    createdAt: now,
  };

  if (ticket) {
    ticket.adminReply = replyText.trim();
    ticket.adminRepliedAt = now;
    ticket.status = status;
    ticket.messages = [...(ticket.messages || []), adminMessage];
    ticket.updatedAt = now;

    saveLocalTickets(local);
    notifyStudentSubscribers(ticket.studentId, local.filter((t) => t.studentId === ticket.studentId));
    notifyAdminSubscribers(local);
    notifyCrossTab('STUDENT_NOTIFS_UPDATE', ticket.studentId);

    // Sync to Supabase
    await syncChatToSupabase(ticket);
  }

  // Sync to Express backend
  if (typeof window !== 'undefined' && typeof window.location !== 'undefined') {
    try {
      await fetch(`/api/admin/support/${encodeURIComponent(ticketId)}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reply: replyText.trim(), status, repliedAt: now }),
      });
    } catch (err) {
      console.warn('Server reply sync note:', err);
    }
  }

  return { success: true };
}

/**
 * Updates a ticket status (Pending, In Progress, Resolved) (Admin Only).
 */
export async function updateTicketStatusAdmin(
  ticketId: string,
  status: TicketStatus
): Promise<{ success: boolean; error?: string }> {
  await api.requireValidAdmin();
  const now = new Date().toISOString();

  const local = getLocalTickets();
  const ticket = local.find((t) => t.id === ticketId);
  if (ticket) {
    ticket.status = status;
    ticket.updatedAt = now;
    saveLocalTickets(local);
    notifyStudentSubscribers(ticket.studentId, local.filter((t) => t.studentId === ticket.studentId));
    notifyAdminSubscribers(local);
    await syncChatToSupabase(ticket);
  }

  try {
    await fetch(`/api/admin/support/${encodeURIComponent(ticketId)}/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, updatedAt: now }),
    });
  } catch {
    // ignore
  }

  return { success: true };
}

/**
 * Deletes a support ticket (Admin Only).
 */
export async function deleteSupportTicketAdmin(ticketId: string): Promise<{ success: boolean; error?: string }> {
  await api.requireValidAdmin();

  const local = getLocalTickets();
  const target = local.find((t) => t.id === ticketId);
  if (target) {
    try {
      await supabase.from('announcements').delete().eq('id', `chat_${target.studentId}`);
    } catch {
      // ignore
    }
  }

  try {
    await fetch(`/api/admin/support/${encodeURIComponent(ticketId)}`, { method: 'DELETE' });
  } catch {
    // ignore
  }

  const filtered = local.filter((t) => t.id !== ticketId);
  saveLocalTickets(filtered);
  notifyAdminSubscribers(filtered);

  return { success: true };
}

/**
 * Real-time subscription to support tickets for a specific student.
 */
export function subscribeStudentTickets(
  studentId: string,
  username: string | undefined,
  callback: (tickets: SupportTicket[]) => void
): () => void {
  if (!studentTicketListeners.has(studentId)) {
    studentTicketListeners.set(studentId, new Set());
  }
  studentTicketListeners.get(studentId)!.add(callback);

  // Initial load
  fetchStudentTickets(studentId, username).then(callback);

  // Periodic heartbeat poll (every 4 seconds)
  const intervalId = setInterval(() => {
    if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
      fetchStudentTickets(studentId, username).then(callback).catch(() => {});
    }
  }, 4000);

  // Supabase Realtime channel subscription
  let channel: any = null;
  const cleanUser = (username || '').toLowerCase();
  try {
    channel = supabase
      .channel(`public:chat_${studentId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'announcements',
        },
        async (payload) => {
          const rowId = (payload.new as any)?.id || (payload.old as any)?.id;
          const rowDate = (payload.new as any)?.date || (payload.old as any)?.date;
          if (rowId === `chat_${studentId}` || (cleanUser && rowDate === cleanUser)) {
            const fresh = await fetchStudentTickets(studentId, username);
            callback(fresh);
          }
        }
      )
      .subscribe();
  } catch {
    // ignore
  }

  return () => {
    studentTicketListeners.get(studentId)?.delete(callback);
    clearInterval(intervalId);
    if (channel) {
      try {
        supabase.removeChannel(channel);
      } catch {
        // ignore
      }
    }
  };
}

/**
 * Real-time subscription to all support tickets (Admin Only).
 */
export function subscribeAdminTickets(callback: (tickets: SupportTicket[]) => void): () => void {
  adminTicketListeners.add(callback);

  // Initial load
  fetchAllTicketsAdmin().then(callback).catch(() => {});

  // Periodic heartbeat poll
  const intervalId = setInterval(() => {
    if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
      fetchAllTicketsAdmin().then(callback).catch(() => {});
    }
  }, 4000);

  // Attach Supabase Realtime channel
  let channel: any = null;
  try {
    channel = supabase
      .channel('public:chat_admin')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'announcements',
        },
        async (payload) => {
          const rowId = (payload.new as any)?.id || (payload.old as any)?.id;
          if (rowId && String(rowId).startsWith('chat_')) {
            const fresh = await fetchAllTicketsAdmin();
            callback(fresh);
          }
        }
      )
      .subscribe();
  } catch {
    // ignore
  }

  return () => {
    adminTicketListeners.delete(callback);
    clearInterval(intervalId);
    if (channel) {
      try {
        supabase.removeChannel(channel);
      } catch {
        // ignore
      }
    }
  };
}

/**
 * Calculates how many unread messages from a student await Admin review.
 */
export function getAdminUnreadCount(ticket: SupportTicket): number {
  if (!ticket || !Array.isArray(ticket.messages) || ticket.messages.length === 0) {
    return 0;
  }
  const lastRead = ticket.adminLastReadAt || ticket.adminRepliedAt || null;
  if (!lastRead) {
    return ticket.messages.filter((m) => m.sender === 'student').length;
  }
  const readTimestamp = new Date(lastRead).getTime();
  return ticket.messages.filter(
    (m) => m.sender === 'student' && new Date(m.createdAt).getTime() > readTimestamp
  ).length;
}

/**
 * Calculates unread messages from Admin waiting for the Student.
 */
/**
 * Calculates unread messages from Admin waiting for the Student.
 */
export function getStudentUnreadCount(ticket: SupportTicket): number {
  if (!ticket) {
    return 0;
  }
  const lastRead = ticket.studentLastReadAt || null;
  const readTimestamp = lastRead ? new Date(lastRead).getTime() : 0;

  if (Array.isArray(ticket.messages) && ticket.messages.length > 0) {
    return ticket.messages.filter(
      (m) => m.sender === 'admin' && new Date(m.createdAt).getTime() > readTimestamp
    ).length;
  }

  // Fallback for legacy threads without messages array
  if (ticket.adminReply) {
    const replyTime = ticket.adminRepliedAt || ticket.updatedAt || ticket.createdAt;
    if (new Date(replyTime).getTime() > readTimestamp) {
      return 1;
    }
  }

  return 0;
}

/**
 * Marks a conversation thread as read by Admin.
 */
export async function markChatAsReadByAdmin(studentIdOrTicketId: string): Promise<void> {
  const local = getLocalTickets();
  let ticket = local.find((t) => t.id === studentIdOrTicketId || t.studentId === studentIdOrTicketId);
  if (!ticket) {
    try {
      const { data: supaRow } = await supabase
        .from('announcements')
        .select('*')
        .or(`id.eq.chat_${studentIdOrTicketId},link.eq.${studentIdOrTicketId}`)
        .limit(1);
      if (supaRow && supaRow.length > 0 && typeof supaRow[0].message === 'string' && supaRow[0].message.startsWith('{')) {
        ticket = normalizeTicket(JSON.parse(supaRow[0].message));
        local.push(ticket);
      }
    } catch {
      // ignore
    }
  }

  if (ticket) {
    const unread = getAdminUnreadCount(ticket);
    if (unread > 0 || !ticket.adminLastReadAt) {
      const now = new Date().toISOString();
      ticket.adminLastReadAt = now;
      saveLocalTickets(local);
      notifyAdminSubscribers(local);
      await syncChatToSupabase(ticket);
    }
  }
}

/**
 * Marks a conversation thread as read by the Student.
 */
export async function markChatAsReadByStudent(studentId: string, username?: string): Promise<void> {
  const local = getLocalTickets();
  const cleanUser = (username || '').toLowerCase();
  let ticket = local.find((t) => t.studentId === studentId || (cleanUser && t.studentUsername === cleanUser));

  if (!ticket) {
    try {
      const query = cleanUser
        ? supabase.from('announcements').select('*').or(`id.eq.chat_${studentId},date.eq.${cleanUser}`).limit(1)
        : supabase.from('announcements').select('*').eq('id', `chat_${studentId}`).limit(1);
      const { data: supaRow } = await query;
      if (supaRow && supaRow.length > 0 && typeof supaRow[0].message === 'string' && supaRow[0].message.startsWith('{')) {
        ticket = normalizeTicket(JSON.parse(supaRow[0].message));
        local.push(ticket);
      }
    } catch {
      // ignore
    }
  }

  if (ticket) {
    const unread = getStudentUnreadCount(ticket);
    if (unread > 0 || !ticket.studentLastReadAt) {
      const now = new Date().toISOString();
      ticket.studentLastReadAt = now;
      saveLocalTickets(local);
      notifyStudentSubscribers(studentId, [ticket]);
      await syncChatToSupabase(ticket);
    }
  }
}

/**
 * Allows Admin to proactively initiate or send a message to any registered student.
 */
export async function sendAdminMessageToStudent(
  student: { id: string; name: string; username: string; avatarUrl?: string | null },
  text: string,
  photoUrl?: string | null
): Promise<{ success: boolean; ticket?: SupportTicket; message?: SupportMessage; error?: string }> {
  await api.requireValidAdmin();

  if (!text.trim() && !photoUrl) {
    return { success: false, error: 'Message or photo cannot be empty.' };
  }

  const now = new Date().toISOString();
  const cleanUsername = student.username.trim().toLowerCase();
  const local = getLocalTickets();
  let ticket = local.find((t) => t.studentId === student.id || t.studentUsername === cleanUsername);

  // Check Supabase if not in memory
  if (!ticket) {
    try {
      const { data: supaRow } = await supabase
        .from('announcements')
        .select('*')
        .or(`id.eq.chat_${student.id},date.eq.${cleanUsername}`)
        .limit(1);

      if (supaRow && supaRow.length > 0 && typeof supaRow[0].message === 'string' && supaRow[0].message.startsWith('{')) {
        ticket = normalizeTicket(JSON.parse(supaRow[0].message));
        ticket.studentId = student.id;
        ticket.studentUsername = cleanUsername;
        local.push(ticket);
      }
    } catch {
      // ignore
    }
  }

  const adminMsg: SupportMessage = {
    id: `msg_${Date.now()}_admin_${Math.random().toString(36).substring(2, 6)}`,
    sender: 'admin',
    senderName: 'Admin Jyotish',
    text: text.trim() || (photoUrl ? '📷 Photo' : ''),
    screenshotUrl: photoUrl || null,
    createdAt: now,
  };

  if (ticket) {
    ticket.messages = [...(ticket.messages || []), adminMsg];
    ticket.adminReply = text.trim() || '📷 Photo';
    ticket.adminRepliedAt = now;
    ticket.adminLastReadAt = now;
    ticket.status = 'In Progress';
    ticket.updatedAt = now;

    saveLocalTickets(local);
    notifyStudentSubscribers(ticket.studentId, [ticket]);
    notifyAdminSubscribers(local);
    notifyCrossTab('STUDENT_NOTIFS_UPDATE', ticket.studentId);
    await syncChatToSupabase(ticket);
    return { success: true, ticket, message: adminMsg };
  }

  // Initialize new thread for student
  const newTicketId = `ticket_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const createdTicket: SupportTicket = {
    id: newTicketId,
    studentId: student.id,
    studentName: student.name || 'Student',
    studentUsername: cleanUsername,
    subject: 'Direct Message from Admin Jyotish',
    category: 'Admin Message',
    description: text.trim() || '📷 Photo',
    screenshotUrl: photoUrl || null,
    status: 'In Progress',
    adminReply: text.trim() || '📷 Photo',
    adminRepliedAt: now,
    adminLastReadAt: now,
    studentLastReadAt: null, // Deliberately null so student receives unread badge!
    messages: [adminMsg],
    createdAt: now,
    updatedAt: now,
  };

  const updatedList = [
    createdTicket,
    ...local.filter((t) => t.studentId !== student.id && t.studentUsername !== cleanUsername),
  ];
  saveLocalTickets(updatedList);
  notifyStudentSubscribers(student.id, [createdTicket]);
  notifyAdminSubscribers(updatedList);
  notifyCrossTab('STUDENT_NOTIFS_UPDATE', student.id);
  await syncChatToSupabase(createdTicket);

  return { success: true, ticket: createdTicket, message: adminMsg };
}

