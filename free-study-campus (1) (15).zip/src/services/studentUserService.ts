import { supabase, isSupabaseConfigured } from './supabase';
import { safeDataCache } from './safeDataCache';

export interface StudentUser {
  id: string;
  name: string; // e.g. "Student 1"
  username: string; // e.g. "student01"
  avatarUrl?: string | null;
  passwordHash: string;
  status: 'active' | 'disabled';
  activeSessionId?: string | null;
  activeDeviceId?: string | null;
  activeDeviceInfo?: string | null;
  lastLoginAt?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface StoredStudentSession {
  studentId: string;
  username: string;
  sessionId: string;
  loginAt: string;
  avatarUrl?: string | null;
}

const LOCAL_STORAGE_KEY = 'fsc_cached_student_users';
const SESSION_STORAGE_KEY = 'fsc_active_student_session_v2';
const CLIENT_DEVICE_ID_KEY = 'fsc_client_device_id_v2';

/**
 * Returns a persistent unique device identifier for this client.
 * Ensures the One-Device Lock reliably knows which device is currently logged in.
 */
export function getOrCreateDeviceId(): string {
  try {
    let id = localStorage.getItem(CLIENT_DEVICE_ID_KEY);
    if (!id) {
      id = `dev_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
      localStorage.setItem(CLIENT_DEVICE_ID_KEY, id);
    }
    return id;
  } catch {
    return 'dev_default';
  }
}

/**
 * Secure cryptographic SHA-256 hash using standard Web Crypto API.
 * Never stores student passwords in plain text.
 */
export async function hashPassword(password: string): Promise<string> {
  const clean = password.trim();
  const encoder = new TextEncoder();
  const data = encoder.encode(`fsc_salt_v1:${clean}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export function getClientDeviceInfo(): string {
  try {
    const ua = navigator.userAgent;
    let browser = 'Web Browser';
    if (ua.includes('Chrome')) browser = 'Chrome';
    else if (ua.includes('Firefox')) browser = 'Firefox';
    else if (ua.includes('Safari')) browser = 'Safari';
    else if (ua.includes('Edge')) browser = 'Edge';

    const isMobile = /Android|iPhone|iPad|iPod/i.test(ua);
    return `${isMobile ? 'Mobile Phone' : 'PC'} (${browser})`;
  } catch {
    return 'Web Device';
  }
}

function loadLocalCache(): StudentUser[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // ignore
  }
  return [];
}

function persistLocalCache(users: StudentUser[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(users));
  } catch {
    // ignore
  }
}

let cachedStudents: StudentUser[] = loadLocalCache();
const studentListeners = new Set<(users: StudentUser[]) => void>();
let supabaseChannel: any = null;

function mapSupabaseRowToStudent(row: any): StudentUser {
  return {
    id: String(row.id),
    name: row.name || 'Student',
    username: String(row.username || '').toLowerCase(),
    avatarUrl: row.avatar_url || null,
    passwordHash: row.password_hash || '',
    status: row.status === 'disabled' ? 'disabled' : 'active',
    activeSessionId: row.active_session_id || null,
    activeDeviceId: row.active_device_id || null,
    activeDeviceInfo: row.active_device_info || null,
    lastLoginAt: row.last_login_at || null,
    createdAt: row.created_at || new Date().toISOString(),
    updatedAt: row.updated_at || new Date().toISOString(),
  };
}

function mapStudentToSupabaseRow(s: StudentUser): any {
  return {
    id: s.id,
    name: s.name,
    username: s.username.toLowerCase(),
    avatar_url: s.avatarUrl || null,
    password_hash: s.passwordHash,
    status: s.status,
    active_session_id: s.activeSessionId || null,
    active_device_id: s.activeDeviceId || null,
    active_device_info: s.activeDeviceInfo || null,
    last_login_at: s.lastLoginAt || null,
    created_at: s.createdAt,
    updated_at: s.updatedAt,
  };
}

async function fetchFromSupabase(): Promise<StudentUser[]> {
  try {
    const { data, error } = await supabase
      .from('student_users')
      .select('*')
      .order('created_at', { ascending: true });

    if (error) {
      console.warn('Notice querying Supabase student_users table:', error.message);
      return cachedStudents;
    }

    if (Array.isArray(data) && data.length > 0) {
      const list = data.map(mapSupabaseRowToStudent);
      cachedStudents = list;
      persistLocalCache(list);
      return list;
    }
  } catch (err) {
    console.warn('Supabase fetch exception for student_users:', err);
  }
  return cachedStudents;
}

/**
 * Real-time listener for student accounts list (used by Admin Settings).
 */
export function subscribeStudentUsers(callback: (users: StudentUser[]) => void): () => void {
  studentListeners.add(callback);
  callback(cachedStudents);

  fetchFromSupabase().then((list) => {
    if (list.length === 0) {
      ensureInitialStudent1Exists().then((seeded) => {
        if (seeded) {
          callback([seeded]);
        }
      });
    } else {
      callback(list);
    }
  });

  if (!supabaseChannel) {
    try {
      supabaseChannel = supabase
        .channel('public:student_users')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'student_users' },
          async () => {
            const fresh = await fetchFromSupabase();
            studentListeners.forEach((fn) => {
              try {
                fn(fresh);
              } catch (e) {
                console.error('Error notifying student listener:', e);
              }
            });
          }
        )
        .subscribe();
    } catch (e) {
      console.warn('Realtime subscription notice for student_users:', e);
    }
  }

  return () => {
    studentListeners.delete(callback);
  };
}

/**
 * Ensures "Student 1" exists as the default user if the table is empty.
 */
export async function ensureInitialStudent1Exists(): Promise<StudentUser | null> {
  if (cachedStudents.length > 0) {
    return cachedStudents[0];
  }

  const existing = await fetchFromSupabase();
  if (existing.length > 0) {
    return existing[0];
  }

  const defaultHash = await hashPassword('student@123');
  const now = new Date().toISOString();

  const student1: StudentUser = {
    id: 'student-default-1',
    name: 'Student 1',
    username: 'student1',
    passwordHash: defaultHash,
    status: 'active',
    activeSessionId: null,
    activeDeviceId: null,
    activeDeviceInfo: null,
    lastLoginAt: null,
    createdAt: now,
    updatedAt: now,
  };

  try {
    await supabase.from('student_users').upsert(mapStudentToSupabaseRow(student1));
  } catch (e) {
    console.warn('Notice initializing student1 in Supabase:', e);
  }

  cachedStudents = [student1];
  persistLocalCache(cachedStudents);
  studentListeners.forEach((fn) => fn(cachedStudents));
  return student1;
}

/**
 * Searches students by username or name in Supabase (case-insensitive partial match).
 * Merges any remotely found records into local cache and notifies subscribers.
 */
export async function searchStudentsFromSupabase(query: string): Promise<StudentUser[]> {
  const clean = query.trim().toLowerCase().replace(/^@/, '');
  if (!clean) {
    return cachedStudents;
  }

  try {
    const { data, error } = await supabase
      .from('student_users')
      .select('*')
      .ilike('username', `%${clean}%`)
      .order('created_at', { ascending: true });

    if (!error && Array.isArray(data)) {
      const remote = data.map(mapSupabaseRowToStudent);
      const existingIds = new Set(cachedStudents.map((s) => s.id));
      const newlyDiscovered = remote.filter((r) => !existingIds.has(r.id));
      if (newlyDiscovered.length > 0) {
        cachedStudents = [...cachedStudents, ...newlyDiscovered];
        persistLocalCache(cachedStudents);
        studentListeners.forEach((fn) => {
          try {
            fn(cachedStudents);
          } catch (e) {
            console.error('Error notifying student listener:', e);
          }
        });
      }
      return remote;
    }
  } catch (err) {
    console.warn('Supabase searchStudentsFromSupabase notice:', err);
  }

  return cachedStudents.filter((s) =>
    s.username.toLowerCase().includes(clean) || s.name.toLowerCase().includes(clean)
  );
}

/**
 * Admin action: Creates a brand new student account with username & password.
 */
export async function createStudentUser(
  username: string,
  password: string,
  name?: string
): Promise<StudentUser> {
  const cleanUsername = username.trim().toLowerCase();
  const cleanPassword = password.trim();

  if (!cleanUsername || cleanUsername.length < 3) {
    throw new Error('Username must be at least 3 characters.');
  }
  if (!cleanPassword || cleanPassword.length < 4) {
    throw new Error('Password must be at least 4 characters.');
  }

  const exists = cachedStudents.some((s) => s.username.toLowerCase() === cleanUsername);
  if (exists) {
    throw new Error(`Username "${cleanUsername}" is already taken. Please choose another.`);
  }

  const passwordHash = await hashPassword(cleanPassword);
  const now = new Date().toISOString();
  const id = `student_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const studentName = name?.trim() || `Student ${cachedStudents.length + 1}`;

  const newStudent: StudentUser = {
    id,
    name: studentName,
    username: cleanUsername,
    passwordHash,
    status: 'active',
    activeSessionId: null,
    activeDeviceId: null,
    activeDeviceInfo: null,
    lastLoginAt: null,
    createdAt: now,
    updatedAt: now,
  };

  try {
    const { error } = await supabase
      .from('student_users')
      .insert(mapStudentToSupabaseRow(newStudent));

    if (error) {
      console.warn('Supabase insert student warning:', error.message);
    }
  } catch (err) {
    console.warn('Supabase exception in createStudentUser:', err);
  }

  cachedStudents = [...cachedStudents, newStudent];
  persistLocalCache(cachedStudents);
  studentListeners.forEach((fn) => fn(cachedStudents));

  return newStudent;
}

/**
 * Updates a student's username.
 */
export async function updateStudentUsername(id: string, newUsername: string): Promise<void> {
  const clean = newUsername.trim().toLowerCase();
  if (!clean || clean.length < 3) {
    throw new Error('Username must be at least 3 characters.');
  }

  const conflict = cachedStudents.find((s) => s.id !== id && s.username.toLowerCase() === clean);
  if (conflict) {
    throw new Error(`Username "${clean}" is already taken by another student.`);
  }

  const updatedAt = new Date().toISOString();

  try {
    await supabase
      .from('student_users')
      .update({ username: clean, updated_at: updatedAt })
      .eq('id', id);
  } catch (err) {
    console.warn('Supabase updateStudentUsername notice:', err);
  }

  cachedStudents = cachedStudents.map((s) =>
    s.id === id ? { ...s, username: clean, updatedAt } : s
  );
  persistLocalCache(cachedStudents);
  studentListeners.forEach((fn) => fn(cachedStudents));
}

/**
 * Updates a student's password and immediately terminates all active sessions.
 */
export async function updateStudentPassword(id: string, newPassword: string): Promise<void> {
  const clean = newPassword.trim();
  if (!clean || clean.length < 4) {
    throw new Error('Password must be at least 4 characters.');
  }

  const passwordHash = await hashPassword(clean);
  const updatedAt = new Date().toISOString();

  try {
    await supabase
      .from('student_users')
      .update({
        password_hash: passwordHash,
        active_session_id: null,
        active_device_id: null,
        active_device_info: null,
        updated_at: updatedAt,
      })
      .eq('id', id);
  } catch (err) {
    console.warn('Supabase updateStudentPassword notice:', err);
  }

  cachedStudents = cachedStudents.map((s) =>
    s.id === id
      ? {
          ...s,
          passwordHash,
          activeSessionId: null,
          activeDeviceId: null,
          activeDeviceInfo: null,
          updatedAt,
        }
      : s
  );
  persistLocalCache(cachedStudents);
  studentListeners.forEach((fn) => fn(cachedStudents));
}

/**
 * Toggles a student's status between 'active' and 'disabled'.
 */
export async function updateStudentStatus(
  id: string,
  status: 'active' | 'disabled'
): Promise<void> {
  const updatedAt = new Date().toISOString();
  const sessionUpdate =
    status === 'disabled'
      ? { active_session_id: null, active_device_id: null, active_device_info: null }
      : {};

  try {
    await supabase
      .from('student_users')
      .update({ status, ...sessionUpdate, updated_at: updatedAt })
      .eq('id', id);
  } catch (err) {
    console.warn('Supabase updateStudentStatus notice:', err);
  }

  cachedStudents = cachedStudents.map((s) =>
    s.id === id
      ? {
          ...s,
          status,
          ...(status === 'disabled'
            ? { activeSessionId: null, activeDeviceId: null, activeDeviceInfo: null }
            : {}),
          updatedAt,
        }
      : s
  );
  persistLocalCache(cachedStudents);
  studentListeners.forEach((fn) => fn(cachedStudents));
}

/**
 * Updates a student's profile photo.
 */
export async function updateStudentAvatar(id: string, avatarUrl: string): Promise<void> {
  const updatedAt = new Date().toISOString();
  try {
    await supabase
      .from('student_users')
      .update({ avatar_url: avatarUrl, updated_at: updatedAt })
      .eq('id', id);
  } catch (err) {
    console.warn('Supabase updateStudentAvatar notice:', err);
  }

  cachedStudents = cachedStudents.map((s) =>
    s.id === id ? { ...s, avatarUrl, updatedAt } : s
  );
  persistLocalCache(cachedStudents);

  const stored = getStoredSession();
  if (stored && stored.studentId === id) {
    saveStoredSession({ ...stored, avatarUrl });
  }

  studentListeners.forEach((fn) => fn(cachedStudents));
}

/**
 * Admin action: Force log out a student from their active device.
 */
export async function forceLogoutStudent(id: string): Promise<void> {
  const updatedAt = new Date().toISOString();
  try {
    await supabase
      .from('student_users')
      .update({
        active_session_id: null,
        active_device_id: null,
        active_device_info: null,
        updated_at: updatedAt,
      })
      .eq('id', id);
  } catch (err) {
    console.warn('Supabase forceLogoutStudent notice:', err);
  }

  cachedStudents = cachedStudents.map((s) =>
    s.id === id
      ? {
          ...s,
          activeSessionId: null,
          activeDeviceId: null,
          activeDeviceInfo: null,
          updatedAt,
        }
      : s
  );
  persistLocalCache(cachedStudents);
  studentListeners.forEach((fn) => fn(cachedStudents));
}

/**
 * Deletes a student account completely.
 */
export async function deleteStudentUser(id: string): Promise<void> {
  try {
    await supabase.from('student_users').delete().eq('id', id);
  } catch (err) {
    console.warn('Supabase deleteStudentUser notice:', err);
  }

  cachedStudents = cachedStudents.filter((s) => s.id !== id);
  persistLocalCache(cachedStudents);
  studentListeners.forEach((fn) => fn(cachedStudents));
}

/**
 * Student Login Flow with One-Device-Per-Account Enforcement via Supabase.
 */
export async function loginStudentUser(
  username: string,
  password: string
): Promise<{ success: boolean; student?: StudentUser; sessionId?: string; error?: string }> {
  const cleanUsername = username.trim().toLowerCase();
  const cleanPassword = password.trim();

  if (!cleanUsername || !cleanPassword) {
    return { success: false, error: 'Please enter both Username and Password' };
  }

  try {
    // 1. Fetch fresh list from Supabase or fallback
    let student: StudentUser | undefined;
    const liveList = await fetchFromSupabase();

    if (liveList.length === 0) {
      const seeded = await ensureInitialStudent1Exists();
      if (seeded && seeded.username.toLowerCase() === cleanUsername) {
        student = seeded;
      }
    } else {
      student = liveList.find((s) => s.username.toLowerCase() === cleanUsername);
    }

    if (!student) {
      return { success: false, error: 'Incorrect Username or Password' };
    }

    // 2. Verify Password Hash (SHA-256)
    const computedHash = await hashPassword(cleanPassword);
    if (student.passwordHash !== computedHash) {
      return { success: false, error: 'Incorrect Username or Password' };
    }

    // 3. Check account status
    if (student.status === 'disabled') {
      return {
        success: false,
        error: 'Your student account has been disabled by Admin. Please contact support.',
      };
    }

    const currentDeviceId = getOrCreateDeviceId();
    const currentDeviceInfo = getClientDeviceInfo();
    const storedSession = getStoredSession();

    // ========================================================
    // STRICT ONE-DEVICE LOGIN RULE:
    // If student already has an activeSessionId:
    // - Check if it's the SAME device (matching deviceId or existing stored session).
    // - If it's a SECOND device, BLOCK access completely!
    // ========================================================
    if (student.activeSessionId) {
      const isSameDevice =
        (student.activeDeviceId && student.activeDeviceId === currentDeviceId) ||
        (storedSession &&
          storedSession.sessionId === student.activeSessionId &&
          storedSession.studentId === student.id);

      if (!isSameDevice) {
        const deviceName = student.activeDeviceInfo || 'another phone/device';
        return {
          success: false,
          error: `Access Denied (1-Device Rule): This account is already active on ${deviceName}. Please logout from that device first or contact Admin to Force Logout.`,
        };
      }
    }

    // Generate new unique session ID
    const newSessionId = `sess_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const now = new Date().toISOString();

    try {
      await supabase
        .from('student_users')
        .update({
          active_session_id: newSessionId,
          active_device_id: currentDeviceId,
          active_device_info: currentDeviceInfo,
          last_login_at: now,
          updated_at: now,
        })
        .eq('id', student.id);
    } catch (e) {
      console.warn('Notice persisting session to Supabase:', e);
    }

    // Update in-memory and local cache
    cachedStudents = cachedStudents.map((s) =>
      s.id === student!.id
        ? {
            ...s,
            activeSessionId: newSessionId,
            activeDeviceId: currentDeviceId,
            activeDeviceInfo: currentDeviceInfo,
            lastLoginAt: now,
            updatedAt: now,
          }
        : s
    );
    persistLocalCache(cachedStudents);

    // Persist session locally
    const sessionObj: StoredStudentSession = {
      studentId: student.id,
      username: student.username,
      sessionId: newSessionId,
      loginAt: now,
      avatarUrl: student.avatarUrl || null,
    };
    saveStoredSession(sessionObj);

    return {
      success: true,
      student: {
        ...student,
        activeSessionId: newSessionId,
        activeDeviceId: currentDeviceId,
        activeDeviceInfo: currentDeviceInfo,
      },
      sessionId: newSessionId,
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Database error during login. Please check connection.';
    return { success: false, error: msg };
  }
}

/**
 * Student Logout Flow.
 * Clears active session in Supabase and removes local storage session.
 */
export async function logoutStudentUser(studentId?: string, sessionId?: string): Promise<void> {
  const stored = getStoredSession();
  const targetStudentId = studentId || stored?.studentId;

  if (targetStudentId) {
    try {
      await supabase
        .from('student_users')
        .update({
          active_session_id: null,
          active_device_id: null,
          active_device_info: null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', targetStudentId);
    } catch (e) {
      console.warn('Notice clearing session in Supabase during logout:', e);
    }

    cachedStudents = cachedStudents.map((s) =>
      s.id === targetStudentId
        ? {
            ...s,
            activeSessionId: null,
            activeDeviceId: null,
            activeDeviceInfo: null,
            updatedAt: new Date().toISOString(),
          }
        : s
    );
    persistLocalCache(cachedStudents);
  }

  clearStoredSession();
}

/**
 * Validates persistent session on boot / page refresh / reopen.
 */
export async function validateStoredSession(): Promise<{
  isValid: boolean;
  student?: StudentUser;
  sessionId?: string;
  reason?: string;
}> {
  const stored = getStoredSession();
  if (!stored || !stored.studentId || !stored.sessionId) {
    return { isValid: false, reason: 'No stored session found' };
  }

  try {
    let student = cachedStudents.find((s) => s.id === stored.studentId);

    // Fetch fresh record from Supabase
    try {
      const { data, error } = await supabase
        .from('student_users')
        .select('*')
        .eq('id', stored.studentId)
        .maybeSingle();

      if (!error && data) {
        student = mapSupabaseRowToStudent(data);
      }
    } catch {
      // ignore
    }

    if (!student) {
      clearStoredSession();
      return { isValid: false, reason: 'Account was removed by Admin' };
    }

    if (stored.avatarUrl !== (student.avatarUrl || null)) {
      saveStoredSession({ ...stored, avatarUrl: student.avatarUrl || null });
    }

    if (student.status === 'disabled') {
      clearStoredSession();
      return { isValid: false, reason: 'Account has been disabled by Admin' };
    }

    if (student.activeSessionId && student.activeSessionId !== stored.sessionId) {
      clearStoredSession();
      return {
        isValid: false,
        reason: 'Session ended: Admin changed password or logged you out.',
      };
    }

    return { isValid: true, student, sessionId: stored.sessionId };
  } catch (e) {
    console.warn('Network issue during session validation:', e);
    return {
      isValid: true,
      sessionId: stored.sessionId,
      student: stored.avatarUrl
        ? ({ id: stored.studentId, username: stored.username, avatarUrl: stored.avatarUrl } as StudentUser)
        : undefined,
    };
  }
}

/**
 * Real-time Watchdog for Active Student Session.
 */
export function subscribeStudentSessionWatchdog(
  studentId: string,
  sessionId: string,
  onSessionTerminated: (reason: string) => void,
  onStudentUpdated?: (student: StudentUser) => void
): () => void {
  try {
    const channel = supabase
      .channel(`watchdog:${studentId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'student_users',
          filter: `id=eq.${studentId}`,
        },
        (payload: any) => {
          if (payload.eventType === 'DELETE') {
            clearStoredSession();
            onSessionTerminated('Your student account was removed by Admin.');
            return;
          }

          if (payload.new) {
            const data = mapSupabaseRowToStudent(payload.new);

            if (data.status === 'disabled') {
              clearStoredSession();
              onSessionTerminated('Your student account has been disabled by Admin.');
              return;
            }

            if (data.activeSessionId !== sessionId) {
              clearStoredSession();
              onSessionTerminated(
                'Your session was terminated (password changed or logged out by Admin).'
              );
              return;
            }

            if (onStudentUpdated) {
              onStudentUpdated(data);
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  } catch (err) {
    console.warn('Watchdog notice on student_users:', err);
    return () => {};
  }
}

// Session Local Storage Helpers
export function getStoredSession(): StoredStudentSession | null {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.studentId && parsed.sessionId) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return null;
}

function saveStoredSession(session: StoredStudentSession) {
  try {
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
  } catch {
    // ignore
  }
}

export function clearStoredSession() {
  try {
    localStorage.removeItem(SESSION_STORAGE_KEY);
  } catch {
    // ignore
  }
}
