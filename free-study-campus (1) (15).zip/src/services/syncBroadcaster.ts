/**
 * Real-time Cross-Device, Cross-Tab & App LifeCycle Sync Broadcaster.
 * Ensures that changes made by Admin (New batch, Delete batch, Edit batch, Payment settings)
 * are instantly delivered to all active student screens, browser tabs, and devices without
 * requiring manual page reload.
 */

export type SyncMessageType = 'platforms' | 'authConfig' | 'settings' | 'admin_session_invalidated';

interface SyncEventPayload {
  type: SyncMessageType;
  payload: any;
  timestamp: number;
}

const SYNC_CHANNEL_NAME = 'free_study_campus_realtime_sync';
const SYNC_STORAGE_KEY = 'fsc_last_sync_event';

let broadcastChannel: BroadcastChannel | null = null;
try {
  if (typeof BroadcastChannel !== 'undefined') {
    broadcastChannel = new BroadcastChannel(SYNC_CHANNEL_NAME);
  }
} catch {
  // BroadcastChannel unavailable in older environments
}

const syncListeners = new Set<(event: SyncEventPayload) => void>();

// Attach listeners once
if (typeof window !== 'undefined') {
  if (broadcastChannel) {
    broadcastChannel.onmessage = (ev) => {
      if (ev?.data?.type) {
        syncListeners.forEach((fn) => {
          try {
            fn(ev.data);
          } catch (e) {
            console.error('Error in sync listener:', e);
          }
        });
      }
    };
  }

  // Cross-tab storage event fallback
  window.addEventListener('storage', (ev) => {
    if (ev.key === SYNC_STORAGE_KEY && ev.newValue) {
      try {
        const parsed = JSON.parse(ev.newValue) as SyncEventPayload;
        if (parsed?.type) {
          syncListeners.forEach((fn) => {
            try {
              fn(parsed);
            } catch (e) {
              console.error('Error in storage sync listener:', e);
            }
          });
        }
      } catch {
        // ignore
      }
    }
  });
}

/**
 * Broadcasts a change to all active tabs and windows on the device.
 */
export function broadcastSync(type: SyncMessageType, payload: any) {
  const event: SyncEventPayload = {
    type,
    payload,
    timestamp: Date.now(),
  };

  try {
    if (broadcastChannel) {
      broadcastChannel.postMessage(event);
    }
  } catch {
    // ignore
  }

  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(SYNC_STORAGE_KEY, JSON.stringify(event));
    }
  } catch {
    // ignore
  }
}

/**
 * Subscribes to real-time broadcast sync events.
 */
export function subscribeSyncBroadcast(callback: (event: SyncEventPayload) => void): () => void {
  syncListeners.add(callback);
  return () => {
    syncListeners.delete(callback);
  };
}
