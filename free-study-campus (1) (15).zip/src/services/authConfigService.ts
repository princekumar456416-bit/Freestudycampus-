import { supabase, isSupabaseConfigured } from './supabase';
import { safeDataCache } from './safeDataCache';
import { broadcastSync, subscribeSyncBroadcast } from './syncBroadcaster';
import { SAVED_PAYMENT_CONFIG } from './savedPaymentFallback';

export interface AuthConfig {
  studentPassword: string;
  adminPassword: string;
  feeText: string;
  feeAmount: number;
  telegramBotUrl: string;
  telegramBotHandle: string;
  upiId: string;
  qrImageUrl: string;
  paymentInstructions?: string;
  updatedAt: string;
}

export const DEFAULT_AUTH_CONFIG: AuthConfig = {
  studentPassword: SAVED_PAYMENT_CONFIG.studentPassword || 'PRIYANSHU@776301',
  adminPassword: SAVED_PAYMENT_CONFIG.adminPassword || 'JYOTISH@62025',
  feeText: SAVED_PAYMENT_CONFIG.feeText || '₹149',
  feeAmount: SAVED_PAYMENT_CONFIG.feeAmount || 149,
  telegramBotUrl: SAVED_PAYMENT_CONFIG.telegramBotUrl || 'https://t.me/Freestudycampusbot',
  telegramBotHandle: SAVED_PAYMENT_CONFIG.telegramBotHandle || '@Freestudycampusbot',
  upiId: SAVED_PAYMENT_CONFIG.upiId || '9472981955@ybl',
  qrImageUrl: SAVED_PAYMENT_CONFIG.qrImageUrl || '',
  paymentInstructions:
    SAVED_PAYMENT_CONFIG.paymentInstructions ||
    'Scan QR code, pay the verification fee, and send screenshot to our Telegram Bot to receive your account credentials instantly.',
  updatedAt: SAVED_PAYMENT_CONFIG.updatedAt || new Date().toISOString(),
};

const LOCAL_STORAGE_KEY = 'fsc_cached_auth_v1';

function loadInitialAuthCache(): AuthConfig {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        const studentPassword =
          parsed.studentPassword !== undefined
            ? String(parsed.studentPassword).trim()
            : DEFAULT_AUTH_CONFIG.studentPassword;
        const adminPassword =
          parsed.adminPassword !== undefined
            ? String(parsed.adminPassword).trim()
            : DEFAULT_AUTH_CONFIG.adminPassword;
        const feeText =
          parsed.feeText !== undefined
            ? String(parsed.feeText).trim()
            : DEFAULT_AUTH_CONFIG.feeText;
        const feeAmount =
          typeof parsed.feeAmount === 'number' && !isNaN(parsed.feeAmount)
            ? parsed.feeAmount
            : parseFloat(feeText.replace(/[^\d.]/g, '')) || DEFAULT_AUTH_CONFIG.feeAmount;

        const qrImageUrl =
          parsed.qrImageUrl && String(parsed.qrImageUrl).length > 20
            ? String(parsed.qrImageUrl)
            : DEFAULT_AUTH_CONFIG.qrImageUrl;

        return {
          studentPassword,
          adminPassword,
          feeText,
          feeAmount,
          telegramBotUrl:
            parsed.telegramBotUrl !== undefined
              ? String(parsed.telegramBotUrl).trim()
              : DEFAULT_AUTH_CONFIG.telegramBotUrl,
          telegramBotHandle:
            parsed.telegramBotHandle !== undefined
              ? String(parsed.telegramBotHandle).trim()
              : DEFAULT_AUTH_CONFIG.telegramBotHandle,
          upiId:
            parsed.upiId !== undefined
              ? String(parsed.upiId).trim()
              : DEFAULT_AUTH_CONFIG.upiId,
          qrImageUrl,
          paymentInstructions:
            parsed.paymentInstructions !== undefined
              ? String(parsed.paymentInstructions).trim()
              : DEFAULT_AUTH_CONFIG.paymentInstructions,
          updatedAt: parsed.updatedAt || new Date().toISOString(),
        };
      }
    }
  } catch {
    // ignore
  }
  return { ...DEFAULT_AUTH_CONFIG };
}

let cachedConfig: AuthConfig = loadInitialAuthCache();
let isInitialized = false;
let hasReceivedLiveSupabase = false;
const listeners = new Set<(config: AuthConfig) => void>();
const adminSessionListeners = new Set<(isValid: boolean, reason?: string) => void>();

/**
 * Computes a cryptographic SHA-256 token hash bound to the admin password.
 * When the admin password changes in Supabase, any token generated with
 * the old password becomes instantly invalid across all devices.
 */
export async function hashAdminPassword(password: string): Promise<string> {
  const clean = (password || '').trim();
  try {
    if (typeof crypto !== 'undefined' && crypto.subtle) {
      const encoder = new TextEncoder();
      const data = encoder.encode(`fsc_admin_pwd_salt_v2:${clean}`);
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      return Array.from(new Uint8Array(hashBuffer))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    }
  } catch {
    // Fallback if crypto.subtle is unavailable
  }
  let hash = 0;
  const str = `fsc_admin_fallback_v2:${clean}`;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash + str.charCodeAt(i)) | 0;
  }
  return `admin_hash_${Math.abs(hash)}_${clean.length}`;
}

/**
 * Real-time watchdog subscription for admin session validity.
 * Invoked whenever the admin password is changed globally in Supabase.
 */
export function subscribeAdminSessionWatchdog(
  callback: (isValid: boolean, reason?: string) => void
): () => void {
  adminSessionListeners.add(callback);
  return () => {
    adminSessionListeners.delete(callback);
  };
}

export function notifyAdminSessionTerminated(reason: string) {
  adminSessionListeners.forEach((fn) => {
    try {
      fn(false, reason);
    } catch (e) {
      console.error('Error notifying admin session listener:', e);
    }
  });
}

/**
 * Checks if the current device's stored admin token matches the live admin password.
 * If not, immediately wipes the stored token and triggers forced logout to the login screen.
 */
export async function checkAndInvalidateStaleAdminSession(
  liveAdminPassword?: string
): Promise<boolean> {
  if (typeof window === 'undefined') return true;
  const token = localStorage.getItem('fsc_admin_token') || localStorage.getItem('token');
  if (!token) return true; // not logged in

  const activePassword = (liveAdminPassword || cachedConfig.adminPassword || DEFAULT_AUTH_CONFIG.adminPassword).trim();
  const expectedToken = await hashAdminPassword(activePassword);

  if (token !== expectedToken) {
    localStorage.removeItem('fsc_admin_token');
    localStorage.removeItem('token');
    notifyAdminSessionTerminated('Admin password was changed globally. All sessions have been logged out. Please log in again.');
    return false;
  }
  return true;
}

/**
 * Validates whether the current client holds an active, valid admin session token
 * matching the latest admin password stored in Supabase.
 */
export async function verifyAdminSession(): Promise<boolean> {
  if (typeof window === 'undefined') return false;
  const token = localStorage.getItem('fsc_admin_token') || localStorage.getItem('token');
  if (!token) return false;

  try {
    const config = await getLatestAuthConfig();
    const activePassword = (config.adminPassword || DEFAULT_AUTH_CONFIG.adminPassword).trim();
    const expectedToken = await hashAdminPassword(activePassword);

    if (token === expectedToken) {
      return true;
    }

    localStorage.removeItem('fsc_admin_token');
    localStorage.removeItem('token');
    return false;
  } catch {
    const activePassword = (cachedConfig.adminPassword || DEFAULT_AUTH_CONFIG.adminPassword).trim();
    const expectedToken = await hashAdminPassword(activePassword);
    if (token === expectedToken) {
      return true;
    }
    localStorage.removeItem('fsc_admin_token');
    localStorage.removeItem('token');
    return false;
  }
}

export function getCachedAuthConfig(): AuthConfig {
  return cachedConfig;
}

function persistAuthCache(cfg: AuthConfig) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(cfg));
  } catch {
    // ignore
  }
}

function mapSupabaseSettingsToAuthConfig(row: any): Partial<AuthConfig> {
  const cfg: Partial<AuthConfig> = {};
  if (row.admin_password) cfg.adminPassword = String(row.admin_password).trim();
  if (row.student_password) cfg.studentPassword = String(row.student_password).trim();
  if (row.fee_text) cfg.feeText = String(row.fee_text).trim();
  if (typeof row.fee_amount === 'number') cfg.feeAmount = row.fee_amount;
  if (row.telegram_bot_url) cfg.telegramBotUrl = String(row.telegram_bot_url).trim();
  if (row.telegram_bot_handle) cfg.telegramBotHandle = String(row.telegram_bot_handle).trim();
  if (row.upi_id) cfg.upiId = String(row.upi_id).trim();
  if (row.qr_image_url) cfg.qrImageUrl = String(row.qr_image_url);
  if (row.payment_instructions) cfg.paymentInstructions = String(row.payment_instructions).trim();
  if (row.updated_at) cfg.updatedAt = row.updated_at;
  return cfg;
}

/**
 * Initializes real-time listener for Supabase authentication and payment settings.
 */
export function initAuthConfigListener() {
  if (isInitialized) return;
  isInitialized = true;

  // Initial fetch from Supabase
  (async () => {
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('*')
        .eq('id', 'global')
        .maybeSingle();

      if (!error && data) {
        hasReceivedLiveSupabase = true;
        const mapped = mapSupabaseSettingsToAuthConfig(data);
        cachedConfig = { ...cachedConfig, ...mapped };
        persistAuthCache(cachedConfig);
        listeners.forEach((fn) => {
          try {
            fn(cachedConfig);
          } catch (e) {
            console.error('Error notifying authConfig subscriber on initial load:', e);
          }
        });

        if (mapped.adminPassword) {
          checkAndInvalidateStaleAdminSession(mapped.adminPassword).catch(() => {});
        }
      }
    } catch (err: unknown) {
      console.warn('Supabase initial settings notice:', err);
    }
  })();

  // Attach real-time Postgres changes listener
  try {
    supabase
      .channel('public:app_settings_auth')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'app_settings',
          filter: 'id=eq.global',
        },
        (payload: any) => {
          if (payload.new) {
            hasReceivedLiveSupabase = true;
            const mapped = mapSupabaseSettingsToAuthConfig(payload.new);
            cachedConfig = { ...cachedConfig, ...mapped };
            persistAuthCache(cachedConfig);
            listeners.forEach((callback) => {
              try {
                callback(cachedConfig);
              } catch (e) {
                console.error('Error notifying authConfig subscriber:', e);
              }
            });

            if (mapped.adminPassword) {
              checkAndInvalidateStaleAdminSession(mapped.adminPassword).catch(() => {});
            }
          }
        }
      )
      .subscribe();
  } catch (error) {
    console.warn('Realtime subscription notice on app_settings:', error);
  }
}

// Background lifecycle listeners for mobile sleep, tab switching, and cross-tab sync
if (typeof window !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      getLatestAuthConfig()
        .then((cfg) => {
          if (cfg.adminPassword) {
            checkAndInvalidateStaleAdminSession(cfg.adminPassword).catch(() => {});
          }
        })
        .catch(() => {});
    }
  });

  window.addEventListener('online', () => {
    getLatestAuthConfig()
      .then((cfg) => {
        if (cfg.adminPassword) {
          checkAndInvalidateStaleAdminSession(cfg.adminPassword).catch(() => {});
        }
      })
      .catch(() => {});
  });

  // Periodic heartbeat watchdog: checks every 6s if admin is logged in to ensure immediate revocation
  setInterval(() => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('fsc_admin_token') || localStorage.getItem('token');
      if (token && document.visibilityState === 'visible') {
        getLatestAuthConfig()
          .then((cfg) => {
            if (cfg.adminPassword) {
              checkAndInvalidateStaleAdminSession(cfg.adminPassword).catch(() => {});
            }
          })
          .catch(() => {});
      }
    }
  }, 6000);

  subscribeSyncBroadcast((event) => {
    if (event.type === 'admin_session_invalidated') {
      localStorage.removeItem('fsc_admin_token');
      localStorage.removeItem('token');
      notifyAdminSessionTerminated(
        event.payload?.reason ||
        'Admin password was changed globally. All sessions have been logged out. Please log in again.'
      );
      return;
    }

    if (event.type === 'authConfig' && event.payload) {
      cachedConfig = { ...cachedConfig, ...event.payload };
      persistAuthCache(cachedConfig);
      listeners.forEach((fn) => {
        try {
          fn(cachedConfig);
        } catch (e) {
          console.error('Error notifying authConfig broadcast subscriber:', e);
        }
      });

      if (cachedConfig.adminPassword) {
        checkAndInvalidateStaleAdminSession(cachedConfig.adminPassword).catch(() => {});
      }
    }
  });
}

/**
 * Real-time subscriber to Auth Configuration.
 */
export function subscribeAuthConfig(callback: (config: AuthConfig) => void): () => void {
  initAuthConfigListener();
  listeners.add(callback);
  callback(cachedConfig);

  return () => {
    listeners.delete(callback);
  };
}

/**
 * Direct fetch for latest Auth Configuration from Supabase.
 */
export async function getLatestAuthConfig(): Promise<AuthConfig> {
  initAuthConfigListener();
  try {
    const { data, error } = await supabase
      .from('app_settings')
      .select('*')
      .eq('id', 'global')
      .maybeSingle();

    if (!error && data) {
      hasReceivedLiveSupabase = true;
      const mapped = mapSupabaseSettingsToAuthConfig(data);
      cachedConfig = { ...cachedConfig, ...mapped };
      persistAuthCache(cachedConfig);

      if (mapped.adminPassword) {
        checkAndInvalidateStaleAdminSession(mapped.adminPassword).catch(() => {});
      }

      return cachedConfig;
    }
  } catch (err) {
    console.warn('Notice fetching latest auth config from Supabase:', err);
  }
  return cachedConfig;
}

/**
 * Student Access Password Verification (Local & Supabase-backed).
 */
export async function verifyStudentAccessPassword(
  entered: string
): Promise<{ success: boolean; error?: string }> {
  const cleanEntered = (entered || '').trim();
  if (!cleanEntered) {
    return { success: false, error: 'Please enter the Student Access Password' };
  }

  try {
    const config = await getLatestAuthConfig();
    const currentPassword = (config.studentPassword || DEFAULT_AUTH_CONFIG.studentPassword).trim();

    if (cleanEntered === currentPassword) {
      return { success: true };
    }

    return { success: false, error: 'Incorrect Student Access Password' };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Database is synchronizing. Please retry.';
    return { success: false, error: msg };
  }
}

/**
 * Admin Password Verification (Local & Supabase-backed).
 */
export async function verifyAdminAccessPassword(
  entered: string
): Promise<{ success: boolean; error?: string }> {
  const cleanEntered = (entered || '').trim();
  if (!cleanEntered) {
    return { success: false, error: 'Incorrect Password' };
  }

  try {
    const config = await getLatestAuthConfig();
    const currentPassword = (config.adminPassword || DEFAULT_AUTH_CONFIG.adminPassword).trim();

    if (cleanEntered === currentPassword) {
      return { success: true };
    }

    return { success: false, error: 'Incorrect Password' };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Database is synchronizing. Please retry.';
    return { success: false, error: msg };
  }
}

/**
 * Updates the Student Access Password in Supabase.
 */
export async function setSupabaseStudentPassword(
  newPassword: string
): Promise<{ success: boolean; error?: string }> {
  const clean = (newPassword || '').trim();
  if (!clean) {
    return { success: false, error: 'Student Access Password cannot be empty.' };
  }

  const now = new Date().toISOString();
  try {
    await supabase.from('app_settings').upsert({
      id: 'global',
      student_password: clean,
      updated_at: now,
    });
  } catch (e) {
    console.warn('Notice updating student password in Supabase:', e);
  }

  cachedConfig.studentPassword = clean;
  cachedConfig.updatedAt = now;
  persistAuthCache(cachedConfig);
  listeners.forEach((fn) => fn(cachedConfig));
  return { success: true };
}

/**
 * Updates the Admin Password in Supabase.
 */
export async function setSupabaseAdminPassword(
  newPassword: string
): Promise<{ success: boolean; error?: string }> {
  const clean = (newPassword || '').trim();
  if (!clean) {
    return { success: false, error: 'Admin Password cannot be empty.' };
  }

  const now = new Date().toISOString();
  try {
    const { error } = await supabase
      .from('app_settings')
      .update({
        admin_password: clean,
        updated_at: now,
      })
      .eq('id', 'global');

    if (error) {
      const { error: upsertErr } = await supabase.from('app_settings').upsert({
        id: 'global',
        admin_password: clean,
        updated_at: now,
      });
      if (upsertErr) {
        return { success: false, error: upsertErr.message || 'Database update failed' };
      }
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'Notice updating admin password in Supabase';
    console.warn('Notice updating admin password in Supabase:', e);
    return { success: false, error: msg };
  }

  cachedConfig.adminPassword = clean;
  cachedConfig.updatedAt = now;
  persistAuthCache(cachedConfig);
  listeners.forEach((fn) => fn(cachedConfig));

  // Invalidate this client's stored token so re-login with new password is required
  if (typeof window !== 'undefined') {
    localStorage.removeItem('fsc_admin_token');
    localStorage.removeItem('token');
  }

  // Broadcast to other tabs & windows
  broadcastSync('authConfig', cachedConfig);
  broadcastSync('admin_session_invalidated', {
    reason: 'Admin password changed',
    updatedAt: now,
  });

  // Force-terminate active session on this device
  notifyAdminSessionTerminated('Admin password changed successfully. All sessions have been logged out.');

  return { success: true };
}

/**
 * Updates student payment settings (fee, telegram bot, upi, qr) in Supabase.
 */
export async function setSupabasePaymentSettings(data: {
  feeText?: string;
  feeAmount?: number;
  telegramBotUrl?: string;
  telegramBotHandle?: string;
  upiId?: string;
  qrImageUrl?: string;
  paymentInstructions?: string;
}): Promise<{ success: boolean; error?: string }> {
  try {
    const rowUpdates: Record<string, any> = {
      id: 'global',
      updated_at: new Date().toISOString(),
    };

    if (data.feeText !== undefined) {
      rowUpdates.fee_text = data.feeText.trim();
      const parsedNum = parseFloat(data.feeText.replace(/[^\d.]/g, ''));
      if (!isNaN(parsedNum)) {
        rowUpdates.fee_amount = parsedNum;
      }
    }
    if (data.feeAmount !== undefined && !isNaN(data.feeAmount)) {
      rowUpdates.fee_amount = data.feeAmount;
    }
    if (data.telegramBotUrl !== undefined) rowUpdates.telegram_bot_url = data.telegramBotUrl.trim();
    if (data.telegramBotHandle !== undefined) rowUpdates.telegram_bot_handle = data.telegramBotHandle.trim();
    if (data.upiId !== undefined) rowUpdates.upi_id = data.upiId.trim();
    if (data.qrImageUrl !== undefined) rowUpdates.qr_image_url = data.qrImageUrl;
    if (data.paymentInstructions !== undefined) rowUpdates.payment_instructions = data.paymentInstructions.trim();

    try {
      await supabase.from('app_settings').upsert(rowUpdates);
    } catch (e) {
      console.warn('Notice persisting payment settings to Supabase:', e);
    }

    const payload: Partial<AuthConfig> = {
      updatedAt: rowUpdates.updated_at,
    };
    if (data.feeText !== undefined) payload.feeText = data.feeText.trim();
    if (rowUpdates.fee_amount !== undefined) payload.feeAmount = rowUpdates.fee_amount;
    if (data.telegramBotUrl !== undefined) payload.telegramBotUrl = data.telegramBotUrl.trim();
    if (data.telegramBotHandle !== undefined) payload.telegramBotHandle = data.telegramBotHandle.trim();
    if (data.upiId !== undefined) payload.upiId = data.upiId.trim();
    if (data.qrImageUrl !== undefined) payload.qrImageUrl = data.qrImageUrl;
    if (data.paymentInstructions !== undefined) payload.paymentInstructions = data.paymentInstructions.trim();

    cachedConfig = { ...cachedConfig, ...payload } as AuthConfig;
    persistAuthCache(cachedConfig);
    listeners.forEach((fn) => fn(cachedConfig));
    broadcastSync('authConfig', cachedConfig);

    return { success: true };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Failed to update payment settings';
    return { success: false, error: msg };
  }
}
