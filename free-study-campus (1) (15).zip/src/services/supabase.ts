import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Retrieve Supabase credentials safely from Vite env or fallback
const supabaseUrl: string =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL) ||
  (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_URL) ||
  'https://pbhgemcqutnjkxfwocqz.supabase.co';

const supabaseAnonKey: string =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_ANON_KEY) ||
  (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_ANON_KEY) ||
  'sb_publishable_p--0oe9kkeIgsydTB1F0Yg_nSMlZZ77';

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabaseAnonKey &&
  supabaseUrl !== 'https://your-project.supabase.co' &&
  supabaseAnonKey !== 'your-anon-key'
);

let client: SupabaseClient;

try {
  client = createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
    realtime: {
      params: {
        eventsPerSecond: 10,
      },
    },
  });
} catch (err) {
  console.warn('Supabase client initialization warning:', err);
  // Fallback client placeholder to prevent runtime crashes if offline
  client = createClient(
    'https://pbhgemcqutnjkxfwocqz.supabase.co',
    'sb_publishable_p--0oe9kkeIgsydTB1F0Yg_nSMlZZ77'
  );
}

export const supabase = client;

/**
 * Health check to verify that the Supabase endpoint is reachable.
 * Tests public REST/Auth endpoint without modifying any database tables.
 */
export async function testSupabaseConnection(): Promise<{
  connected: boolean;
  status: string;
  latencyMs?: number;
  error?: string;
}> {
  if (!isSupabaseConfigured) {
    return {
      connected: false,
      status: 'NOT_CONFIGURED',
      error: 'Supabase URL or Anon Key is missing.',
    };
  }

  const start = Date.now();
  try {
    // Ping Supabase Auth settings / health endpoint
    const res = await fetch(`${supabaseUrl}/auth/v1/settings`, {
      method: 'GET',
      headers: {
        apikey: supabaseAnonKey,
        Authorization: `Bearer ${supabaseAnonKey}`,
      },
    });

    const latencyMs = Date.now() - start;

    if (res.ok) {
      return {
        connected: true,
        status: 'CONNECTED',
        latencyMs,
      };
    }

    // Even if auth settings returns 401 or 403, if HTTP responded, the server is reached
    return {
      connected: true,
      status: `REACHABLE (HTTP ${res.status})`,
      latencyMs,
    };
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    return {
      connected: false,
      status: 'UNREACHABLE',
      error: errorMsg,
    };
  }
}

export default supabase;
