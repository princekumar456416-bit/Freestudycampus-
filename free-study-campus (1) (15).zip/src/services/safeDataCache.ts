import {
  PlatformRecord,
  BatchRecord,
  AnnouncementRecord,
  UpcomingRecord,
  SettingsRecord,
  CourseRecord,
  SubjectRecord,
  ChapterRecord,
  LessonRecord,
} from './dbStore';

export interface ConnectionStatusInfo {
  isUsingSavedData: boolean;
  isQuotaExceeded: boolean;
  isUnavailable: boolean;
  message: string | null;
  lastError: string | null;
  lastSuccessTimestamp: number | null;
}

const CACHE_KEYS = {
  BATCHES: 'fsc_cached_batches_v1',
  PLATFORMS: 'fsc_cached_platforms_v1',
  COURSES: 'fsc_cached_courses_v1',
  SUBJECTS: 'fsc_cached_subjects_v1',
  CHAPTERS: 'fsc_cached_chapters_v1',
  LESSONS: 'fsc_cached_lessons_v1',
  ANNOUNCEMENTS: 'fsc_cached_announcements_v1',
  UPCOMING: 'fsc_cached_upcoming_v1',
  SETTINGS: 'fsc_cached_settings_v1',
  AUTH: 'fsc_cached_auth_v1',
  STATUS: 'fsc_connection_status_v1',
} as const;

// Default initial batches if cache is completely unpopulated
export const INITIAL_FALLBACK_BATCHES: BatchRecord[] = [
  {
    id: 'batch-pw-lakshya-jee',
    platformId: 'physics-wallah',
    title: 'Lakshya JEE 2027 Comprehensive Batch',
    shortDescription: 'Complete Class 12 & Dropper JEE Advanced program with chapter-wise modules and solved question banks.',
    thumbnail: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=600&auto=format&fit=crop&q=80',
    teacherName: 'Senior JEE Mentors',
    subject: 'Physics, Chemistry & Mathematics',
    category: 'JEE',
    batchUrl: 'https://pwthor.live/study/batches',
    startDate: '2026-09-01',
    status: 'Active',
    displayOrder: 1,
    isFeatured: true,
    isAvailable: true,
    createdAt: '2026-09-23T16:40:00.000Z',
    updatedAt: '2026-09-23T16:40:00.000Z',
  },
  {
    id: 'batch-pw-yakeen-neet',
    platformId: 'physics-wallah',
    title: 'Yakeen NEET 2027 Dropper Batch',
    shortDescription: 'High-yield NCERT diagram-based video lectures, formula notes, and daily practice test sheets.',
    thumbnail: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=600&auto=format&fit=crop&q=80',
    teacherName: 'Senior NEET Faculty',
    subject: 'Physics, Chemistry & Biology',
    category: 'NEET',
    batchUrl: 'https://pwthor.live/study/batches',
    startDate: '2026-09-15',
    status: 'Active',
    displayOrder: 2,
    isFeatured: true,
    isAvailable: true,
    createdAt: '2026-09-23T16:40:00.000Z',
    updatedAt: '2026-09-23T16:40:00.000Z',
  },
  {
    id: 'batch-tb-bihar-board-12',
    platformId: 'target-board',
    title: 'Target Board Class 12th State Board Super Batch',
    shortDescription: 'Dedicated Hindi and English medium syllabus coverage with model papers and question bank solutions.',
    thumbnail: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&auto=format&fit=crop&q=80',
    teacherName: 'Prince Sir & Team',
    subject: 'All Board Subjects',
    category: 'BOARD',
    batchUrl: 'https://targetboard.com.in',
    startDate: '2026-09-10',
    status: 'Active',
    displayOrder: 1,
    isFeatured: true,
    isAvailable: true,
    createdAt: '2026-09-23T16:40:00.000Z',
    updatedAt: '2026-09-23T16:40:00.000Z',
  },
];

export const INITIAL_FALLBACK_PLATFORMS: PlatformRecord[] = [
  {
    id: 'target-board',
    name: 'Target Board',
    tagline: 'Authorized Learning Partner',
    description: 'Comprehensive board exam preparation and study portal.',
    accentColor: '#00e5ff',
    externalUrl: 'https://targetboard.com.in',
    logo: 'TB',
    displayOrder: 1,
    isAvailable: true,
    totalBatches: 1,
    createdAt: '2026-09-23T16:40:00.000Z',
    updatedAt: '2026-09-23T16:40:00.000Z',
  },
  {
    id: 'learn-and-share',
    name: 'Learn and share',
    tagline: 'Authorized Learning Partner',
    description: 'Interactive concept videos and academic archives.',
    accentColor: '#00e5ff',
    externalUrl: 'https://Https. Pwthor. Com',
    logo: 'LS',
    displayOrder: 2,
    isAvailable: true,
    totalBatches: 0,
    createdAt: '2026-09-26T05:59:46.970Z',
    updatedAt: '2026-09-26T05:59:46.970Z',
  },
];

// In-memory active cache
const memoryCache = {
  batches: null as BatchRecord[] | null,
  platforms: null as PlatformRecord[] | null,
  courses: null as CourseRecord[] | null,
  subjects: null as SubjectRecord[] | null,
  chapters: null as ChapterRecord[] | null,
  lessons: null as LessonRecord[] | null,
  announcements: null as AnnouncementRecord[] | null,
  upcoming: null as UpcomingRecord[] | null,
  settings: null as SettingsRecord | null,
};

// Tracks collections explicitly confirmed empty by a healthy successful database query
const confirmedEmptyMap: Record<string, boolean> = {
  batches: false,
  platforms: false,
  courses: false,
  subjects: false,
  chapters: false,
  lessons: false,
  announcements: false,
};

let currentConnectionStatus: ConnectionStatusInfo = {
  isUsingSavedData: false,
  isQuotaExceeded: false,
  isUnavailable: false,
  message: null,
  lastError: null,
  lastSuccessTimestamp: null,
};

const statusListeners = new Set<(status: ConnectionStatusInfo) => void>();

function notifyStatusListeners() {
  statusListeners.forEach((fn) => {
    try {
      fn(currentConnectionStatus);
    } catch (err) {
      console.error('Error in connection status listener:', err);
    }
  });
}

/**
 * Checks if an error is a database quota exhaustion, rate limit, network timeout, or unavailable error.
 */
export function isDatabaseOrNetworkError(err: unknown): boolean {
  if (!err) return false;
  const str = (err instanceof Error ? `${err.name} ${err.message}` : String(err)).toLowerCase();
  return (
    str.includes('quota') ||
    str.includes('resource-exhausted') ||
    str.includes('unavailable') ||
    str.includes('offline') ||
    str.includes('network') ||
    str.includes('timeout') ||
    str.includes('failed-precondition') ||
    str.includes('permission-denied') ||
    str.includes('insufficient permissions') ||
    str.includes('aborted') ||
    str.includes('deadline-exceeded') ||
    str.includes('429') ||
    str.includes('503') ||
    str.includes('cancelled') ||
    str.includes('request failed') ||
    str.includes('pgrst')
  );
}

export const isDatabaseQuotaOrNetworkError = isDatabaseOrNetworkError;

export const safeDataCache = {
  /**
   * Sets connection state and notifies UI subscribers.
   * If database query or network fails, we NEVER treat data as confirmed empty.
   */
  reportConnectionIssue(err: unknown, fallbackUsed = true) {
    const errorStr = err instanceof Error ? err.message : String(err);
    const isQuota =
      errorStr.toLowerCase().includes('quota') ||
      errorStr.toLowerCase().includes('resource-exhausted') ||
      errorStr.toLowerCase().includes('429');

    // On connection error, clear confirmedEmpty flags so we NEVER say "No batches available"
    Object.keys(confirmedEmptyMap).forEach((key) => {
      confirmedEmptyMap[key] = false;
    });

    currentConnectionStatus = {
      isUsingSavedData: fallbackUsed,
      isQuotaExceeded: isQuota,
      isUnavailable: true,
      message: 'Connection temporarily unavailable. Showing saved data.',
      lastError: errorStr,
      lastSuccessTimestamp: currentConnectionStatus.lastSuccessTimestamp,
    };
    notifyStatusListeners();
  },

  /**
   * Reports successful connection with remote database.
   */
  reportConnectionSuccess() {
    if (currentConnectionStatus.isUsingSavedData || currentConnectionStatus.isUnavailable) {
      currentConnectionStatus = {
        isUsingSavedData: false,
        isQuotaExceeded: false,
        isUnavailable: false,
        message: null,
        lastError: null,
        lastSuccessTimestamp: Date.now(),
      };
      notifyStatusListeners();
    } else {
      currentConnectionStatus.lastSuccessTimestamp = Date.now();
    }
  },

  /**
   * Distinguish confirmed empty database from connection error:
   * Returns true ONLY if connection is healthy AND database responded confirming 0 documents.
   */
  setConfirmedEmpty(collectionName: string, isEmpty: boolean) {
    if (currentConnectionStatus.isUnavailable || currentConnectionStatus.isQuotaExceeded) {
      confirmedEmptyMap[collectionName] = false;
      return;
    }
    confirmedEmptyMap[collectionName] = isEmpty;
  },

  isConfirmedEmpty(collectionName: string): boolean {
    if (currentConnectionStatus.isUnavailable || currentConnectionStatus.isQuotaExceeded) {
      return false;
    }
    return Boolean(confirmedEmptyMap[collectionName]);
  },

  /**
   * Subscribe to connection status to show non-blocking notices in UI.
   */
  subscribeStatus(callback: (status: ConnectionStatusInfo) => void): () => void {
    statusListeners.add(callback);
    callback(currentConnectionStatus);
    return () => {
      statusListeners.delete(callback);
    };
  },

  getStatus(): ConnectionStatusInfo {
    return currentConnectionStatus;
  },

  // -------------------------------------------------------------
  // BATCHES CACHE (NEVER WIPED ON DATABASE QUOTA/ERROR)
  // -------------------------------------------------------------
  saveBatches(batches: BatchRecord[]): void {
    if (!Array.isArray(batches) || batches.length === 0) return;
    try {
      memoryCache.batches = [...batches];
      localStorage.setItem(CACHE_KEYS.BATCHES, JSON.stringify(batches));
      confirmedEmptyMap.batches = false;
    } catch (err) {
      console.warn('Failed to save batches to local cache:', err);
    }
  },

  hasCachedBatches(): boolean {
    if (memoryCache.batches && memoryCache.batches.length > 0) return true;
    try {
      const raw = localStorage.getItem(CACHE_KEYS.BATCHES);
      if (raw) {
        const parsed = JSON.parse(raw);
        return Array.isArray(parsed) && parsed.length > 0;
      }
    } catch {
      // ignore
    }
    return false;
  },

  getBatches(platformId?: string): BatchRecord[] {
    // 1. Memory cache
    if (memoryCache.batches && memoryCache.batches.length > 0) {
      let list = memoryCache.batches;
      if (platformId) {
        list = list.filter((b) => b.platformId === platformId);
      }
      return list;
    }

    // 2. LocalStorage cache
    try {
      const raw = localStorage.getItem(CACHE_KEYS.BATCHES);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          memoryCache.batches = parsed;
          let list = parsed;
          if (platformId) {
            list = list.filter((b) => b.platformId === platformId);
          }
          return list;
        }
      }
    } catch (err) {
      console.warn('Failed to read batches from localStorage cache:', err);
    }

    // 3. Fallback to default initial batches (never return empty if we can avoid it)
    memoryCache.batches = INITIAL_FALLBACK_BATCHES;
    let list = INITIAL_FALLBACK_BATCHES;
    if (platformId) {
      list = list.filter((b) => b.platformId === platformId);
    }
    return list;
  },

  // -------------------------------------------------------------
  // LIVE DATABASE SYNCHRONIZATION
  // -------------------------------------------------------------
  syncFromLiveDatabase(collectionName: 'platforms' | 'batches' | 'announcements', items: any[]): void {
    if (!Array.isArray(items)) return;
    try {
      if (collectionName === 'platforms') {
        memoryCache.platforms = [...items];
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem(CACHE_KEYS.PLATFORMS, JSON.stringify(items));
        }
        confirmedEmptyMap.platforms = (items.length === 0);
      } else if (collectionName === 'batches') {
        memoryCache.batches = [...items];
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem(CACHE_KEYS.BATCHES, JSON.stringify(items));
        }
        confirmedEmptyMap.batches = (items.length === 0);
      } else if (collectionName === 'announcements') {
        memoryCache.announcements = [...items];
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem(CACHE_KEYS.ANNOUNCEMENTS, JSON.stringify(items));
        }
        confirmedEmptyMap.announcements = (items.length === 0);
      }
    } catch (err) {
      console.warn('Failed to sync from live database:', err);
    }
  },

  // -------------------------------------------------------------
  // PLATFORMS CACHE
  // -------------------------------------------------------------
  savePlatforms(platforms: PlatformRecord[]): void {
    if (!Array.isArray(platforms)) return;
    try {
      memoryCache.platforms = [...platforms];
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(CACHE_KEYS.PLATFORMS, JSON.stringify(platforms));
      }
      confirmedEmptyMap.platforms = (platforms.length === 0);
    } catch (err) {
      console.warn('Failed to save platforms to local cache:', err);
    }
  },

  hasCachedPlatforms(): boolean {
    if (memoryCache.platforms && memoryCache.platforms.length > 0) return true;
    try {
      const raw = localStorage.getItem(CACHE_KEYS.PLATFORMS);
      if (raw) {
        const parsed = JSON.parse(raw);
        return Array.isArray(parsed) && parsed.length > 0;
      }
    } catch {
      // ignore
    }
    return false;
  },

  getPlatforms(): PlatformRecord[] {
    if (memoryCache.platforms !== null) {
      return memoryCache.platforms;
    }

    if (typeof localStorage === 'undefined') {
      return INITIAL_FALLBACK_PLATFORMS;
    }

    try {
      const raw = localStorage.getItem(CACHE_KEYS.PLATFORMS);
      if (raw !== null) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          memoryCache.platforms = parsed;
          return parsed;
        }
      }
    } catch (err) {
      console.warn('Failed to read platforms from localStorage cache:', err);
    }

    return INITIAL_FALLBACK_PLATFORMS;
  },

  // -------------------------------------------------------------
  // COURSES CACHE
  // -------------------------------------------------------------
  saveCourses(courses: CourseRecord[]): void {
    if (!Array.isArray(courses) || courses.length === 0) return;
    try {
      memoryCache.courses = [...courses];
      localStorage.setItem(CACHE_KEYS.COURSES, JSON.stringify(courses));
      confirmedEmptyMap.courses = false;
    } catch (err) {
      console.warn('Failed to save courses to cache:', err);
    }
  },

  getCourses(batchId?: string): CourseRecord[] {
    if (memoryCache.courses && memoryCache.courses.length > 0) {
      return batchId ? memoryCache.courses.filter((c) => c.batchId === batchId) : memoryCache.courses;
    }
    try {
      const raw = localStorage.getItem(CACHE_KEYS.COURSES);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          memoryCache.courses = parsed;
          return batchId ? parsed.filter((c: CourseRecord) => c.batchId === batchId) : parsed;
        }
      }
    } catch {
      // ignore
    }
    return [];
  },

  // -------------------------------------------------------------
  // SUBJECTS CACHE
  // -------------------------------------------------------------
  saveSubjects(subjects: SubjectRecord[]): void {
    if (!Array.isArray(subjects) || subjects.length === 0) return;
    try {
      memoryCache.subjects = [...subjects];
      localStorage.setItem(CACHE_KEYS.SUBJECTS, JSON.stringify(subjects));
      confirmedEmptyMap.subjects = false;
    } catch (err) {
      console.warn('Failed to save subjects to cache:', err);
    }
  },

  getSubjects(batchId?: string): SubjectRecord[] {
    if (memoryCache.subjects && memoryCache.subjects.length > 0) {
      return batchId ? memoryCache.subjects.filter((s) => s.batchId === batchId) : memoryCache.subjects;
    }
    try {
      const raw = localStorage.getItem(CACHE_KEYS.SUBJECTS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          memoryCache.subjects = parsed;
          return batchId ? parsed.filter((s: SubjectRecord) => s.batchId === batchId) : parsed;
        }
      }
    } catch {
      // ignore
    }
    return [];
  },

  // -------------------------------------------------------------
  // CHAPTERS CACHE
  // -------------------------------------------------------------
  saveChapters(chapters: ChapterRecord[]): void {
    if (!Array.isArray(chapters) || chapters.length === 0) return;
    try {
      memoryCache.chapters = [...chapters];
      localStorage.setItem(CACHE_KEYS.CHAPTERS, JSON.stringify(chapters));
      confirmedEmptyMap.chapters = false;
    } catch (err) {
      console.warn('Failed to save chapters to cache:', err);
    }
  },

  getChapters(subjectId?: string): ChapterRecord[] {
    if (memoryCache.chapters && memoryCache.chapters.length > 0) {
      return subjectId ? memoryCache.chapters.filter((c) => c.subjectId === subjectId) : memoryCache.chapters;
    }
    try {
      const raw = localStorage.getItem(CACHE_KEYS.CHAPTERS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          memoryCache.chapters = parsed;
          return subjectId ? parsed.filter((c: ChapterRecord) => c.subjectId === subjectId) : parsed;
        }
      }
    } catch {
      // ignore
    }
    return [];
  },

  // -------------------------------------------------------------
  // LESSONS CACHE
  // -------------------------------------------------------------
  saveLessons(lessons: LessonRecord[]): void {
    if (!Array.isArray(lessons) || lessons.length === 0) return;
    try {
      memoryCache.lessons = [...lessons];
      localStorage.setItem(CACHE_KEYS.LESSONS, JSON.stringify(lessons));
      confirmedEmptyMap.lessons = false;
    } catch (err) {
      console.warn('Failed to save lessons to cache:', err);
    }
  },

  getLessons(chapterId?: string): LessonRecord[] {
    if (memoryCache.lessons && memoryCache.lessons.length > 0) {
      return chapterId ? memoryCache.lessons.filter((l) => l.chapterId === chapterId) : memoryCache.lessons;
    }
    try {
      const raw = localStorage.getItem(CACHE_KEYS.LESSONS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          memoryCache.lessons = parsed;
          return chapterId ? parsed.filter((l: LessonRecord) => l.chapterId === chapterId) : parsed;
        }
      }
    } catch {
      // ignore
    }
    return [];
  },

  // -------------------------------------------------------------
  // ANNOUNCEMENTS CACHE
  // -------------------------------------------------------------
  saveAnnouncements(announcements: AnnouncementRecord[]): void {
    if (!Array.isArray(announcements)) return;
    try {
      memoryCache.announcements = [...announcements];
      localStorage.setItem(CACHE_KEYS.ANNOUNCEMENTS, JSON.stringify(announcements));
      confirmedEmptyMap.announcements = false;
    } catch (err) {
      console.warn('Failed to save announcements to local cache:', err);
    }
  },

  getAnnouncements(): AnnouncementRecord[] {
    if (memoryCache.announcements) {
      return memoryCache.announcements;
    }

    try {
      const raw = localStorage.getItem(CACHE_KEYS.ANNOUNCEMENTS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          memoryCache.announcements = parsed;
          return parsed;
        }
      }
    } catch (err) {
      console.warn('Failed to read announcements from localStorage cache:', err);
    }

    return [];
  },

  // -------------------------------------------------------------
  // UPCOMING CACHE
  // -------------------------------------------------------------
  saveUpcoming(upcoming: UpcomingRecord[]): void {
    if (!Array.isArray(upcoming)) return;
    try {
      memoryCache.upcoming = [...upcoming];
      localStorage.setItem(CACHE_KEYS.UPCOMING, JSON.stringify(upcoming));
    } catch (err) {
      console.warn('Failed to save upcoming batches to cache:', err);
    }
  },

  getUpcoming(): UpcomingRecord[] {
    if (memoryCache.upcoming && memoryCache.upcoming.length > 0) {
      return memoryCache.upcoming;
    }
    try {
      const raw = localStorage.getItem(CACHE_KEYS.UPCOMING);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          memoryCache.upcoming = parsed;
          return parsed;
        }
      }
    } catch (err) {
      console.warn('Failed to read upcoming from localStorage cache:', err);
    }
    return [];
  },

  // -------------------------------------------------------------
  // SETTINGS CACHE
  // -------------------------------------------------------------
  saveSettings(settings: SettingsRecord): void {
    if (!settings) return;
    try {
      memoryCache.settings = { ...settings };
      localStorage.setItem(CACHE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (err) {
      console.warn('Failed to save settings to cache:', err);
    }
  },

  getSettings(): SettingsRecord | null {
    if (memoryCache.settings) {
      return memoryCache.settings;
    }
    try {
      const raw = localStorage.getItem(CACHE_KEYS.SETTINGS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          memoryCache.settings = parsed;
          return parsed;
        }
      }
    } catch (err) {
      console.warn('Failed to read settings from localStorage cache:', err);
    }
    return null;
  },
};
