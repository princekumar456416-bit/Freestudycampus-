import { supabase } from './supabase';
import { api, subscribeAnnouncements } from './api';

export interface AppNotification {
  id: string;
  targetRole: 'admin' | 'student';
  studentId?: string;
  studentUsername?: string;
  title: string;
  message: string;
  ticketId?: string;
  type: 'ticket_created' | 'ticket_replied' | 'status_updated' | 'announcement';
  read: boolean;
  createdAt: string;
}

const studentNotifListeners = new Map<string, Set<(notifs: AppNotification[]) => void>>();
const adminNotifListeners = new Set<(notifs: AppNotification[]) => void>();

let cachedStudentNotifs = new Map<string, AppNotification[]>();
let cachedAdminNotifs: AppNotification[] = [];

/**
 * Broadcast Channel for instant multi-tab notification updates.
 */
let notifBroadcastChannel: BroadcastChannel | null = null;
try {
  if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
    notifBroadcastChannel = new BroadcastChannel('fsc_notifications_channel');
    notifBroadcastChannel.onmessage = (event) => {
      const data = event.data;
      if (data?.type === 'STUDENT_NOTIFS_UPDATE' && data.studentId) {
        fetchStudentNotifications(data.studentId).catch(() => {});
      } else if (data?.type === 'ADMIN_NOTIFS_UPDATE') {
        fetchAdminNotifications().catch(() => {});
      }
    };
  }
} catch {
  // ignore
}

export function notifyCrossTab(type: 'STUDENT_NOTIFS_UPDATE' | 'ADMIN_NOTIFS_UPDATE', studentId?: string) {
  try {
    notifBroadcastChannel?.postMessage({ type, studentId });
  } catch {
    // ignore
  }
}

function getReadAnnouncementIds(studentId: string): Set<string> {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(`fsc_read_announcements_${studentId}`) : null;
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) return new Set(arr);
    }
  } catch {
    // ignore
  }
  return new Set();
}

function saveReadAnnouncementIds(studentId: string, set: Set<string>) {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(`fsc_read_announcements_${studentId}`, JSON.stringify(Array.from(set)));
    }
  } catch {
    // ignore
  }
}

/**
 * Fetch notifications for a student, merging server query notifications and campus announcements.
 */
export async function fetchStudentNotifications(studentId: string): Promise<AppNotification[]> {
  const notifs: AppNotification[] = [];

  // 1. Fetch server ticket notifications if available
  try {
    const baseUrl = typeof window !== 'undefined' && window.location?.origin ? window.location.origin : '';
    const res = await fetch(`${baseUrl}/api/notifications/student/${encodeURIComponent(studentId)}`);
    if (res.ok) {
      const json = await res.json();
      if (Array.isArray(json.notifications)) {
        notifs.push(...json.notifications);
      }
    }
  } catch (err) {
    // ignore
  }

  // 2. Fetch live campus announcements from Supabase
  try {
    const announcements = await api.getAnnouncements();
    const readSet = getReadAnnouncementIds(studentId);

    for (const ann of announcements) {
      if (ann.isActive !== false) {
        notifs.push({
          id: `ann_${ann.id}`,
          targetRole: 'student',
          studentId,
          title: `Announcement: ${ann.title}`,
          message: ann.message,
          type: 'announcement',
          read: readSet.has(ann.id),
          createdAt: ann.createdAt || new Date().toISOString(),
        });
      }
    }
  } catch (err) {
    console.warn('Notice loading announcements for notifications:', err);
  }

  // Sort newest first
  notifs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  cachedStudentNotifs.set(studentId, notifs);
  triggerStudentListeners(studentId, notifs);
  return notifs;
}

/**
 * Mark student notification as read.
 */
export async function markStudentNotificationRead(studentId: string, notificationId?: string, markAll = false): Promise<void> {
  const current = cachedStudentNotifs.get(studentId) || [];
  const readAnnouncements = getReadAnnouncementIds(studentId);

  if (markAll) {
    current.forEach((n) => {
      if (n.type === 'announcement' && n.id.startsWith('ann_')) {
        readAnnouncements.add(n.id.replace('ann_', ''));
      }
    });
  } else if (notificationId && notificationId.startsWith('ann_')) {
    readAnnouncements.add(notificationId.replace('ann_', ''));
  }
  saveReadAnnouncementIds(studentId, readAnnouncements);

  const updated = current.map((n) => {
    if (markAll || n.id === notificationId) {
      return { ...n, read: true };
    }
    return n;
  });

  cachedStudentNotifs.set(studentId, updated);
  triggerStudentListeners(studentId, updated);

  try {
    const baseUrl = typeof window !== 'undefined' && window.location?.origin ? window.location.origin : '';
    await fetch(`${baseUrl}/api/notifications/student/${encodeURIComponent(studentId)}/read`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notificationId, markAll }),
    });
    notifyCrossTab('STUDENT_NOTIFS_UPDATE', studentId);
  } catch (err) {
    // ignore
  }
}

/**
 * Subscribe to real-time student notifications.
 */
export function subscribeStudentNotifications(
  studentId: string,
  callback: (notifs: AppNotification[]) => void
): () => void {
  if (!studentNotifListeners.has(studentId)) {
    studentNotifListeners.set(studentId, new Set());
  }
  studentNotifListeners.get(studentId)!.add(callback);

  // Initial call with cache
  if (cachedStudentNotifs.has(studentId)) {
    callback(cachedStudentNotifs.get(studentId)!);
  }

  // Fetch immediately
  fetchStudentNotifications(studentId).then(callback).catch(() => {});

  // Periodic lightweight heartbeat poll (every 5 seconds) to guarantee real-time sync across devices
  const intervalId = setInterval(() => {
    if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
      fetchStudentNotifications(studentId).then(callback).catch(() => {});
    }
  }, 5000);

  // Re-fetch when announcements change in real-time
  let unsubAnnouncements: (() => void) | null = null;
  try {
    if (typeof subscribeAnnouncements === 'function') {
      unsubAnnouncements = subscribeAnnouncements(() => {
        fetchStudentNotifications(studentId).then(callback).catch(() => {});
      });
    }
  } catch {
    // ignore
  }

  return () => {
    studentNotifListeners.get(studentId)?.delete(callback);
    clearInterval(intervalId);
    if (unsubAnnouncements) {
      unsubAnnouncements();
    }
  };
}

function triggerStudentListeners(studentId: string, notifs: AppNotification[]) {
  const set = studentNotifListeners.get(studentId);
  if (set) {
    set.forEach((fn) => {
      try {
        fn(notifs);
      } catch (e) {
        console.error('Error notifying student listener:', e);
      }
    });
  }
}

/**
 * Fetch all notifications for Admin.
 */
export async function fetchAdminNotifications(): Promise<AppNotification[]> {
  try {
    const res = await fetch('/api/admin/notifications');
    if (res.ok) {
      const json = await res.json();
      if (Array.isArray(json.notifications)) {
        cachedAdminNotifs = json.notifications;
        triggerAdminListeners(json.notifications);
        return json.notifications;
      }
    }
  } catch (err) {
    console.warn('Notice fetching admin notifications:', err);
  }
  return cachedAdminNotifs;
}

/**
 * Mark admin notification as read.
 */
export async function markAdminNotificationRead(notificationId?: string, markAll = false): Promise<void> {
  // Optimistic update
  const updated = cachedAdminNotifs.map((n) => (markAll || n.id === notificationId ? { ...n, read: true } : n));
  cachedAdminNotifs = updated;
  triggerAdminListeners(updated);

  try {
    await fetch('/api/admin/notifications/read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notificationId, markAll }),
    });
    notifyCrossTab('ADMIN_NOTIFS_UPDATE');
  } catch (err) {
    console.warn('Notice marking admin notification read:', err);
  }
}

/**
 * Subscribe to real-time admin notifications.
 */
export function subscribeAdminNotifications(callback: (notifs: AppNotification[]) => void): () => void {
  adminNotifListeners.add(callback);

  if (cachedAdminNotifs.length > 0) {
    callback(cachedAdminNotifs);
  }

  fetchAdminNotifications().then(callback).catch(() => {});

  // Periodic heartbeat poll for admin
  const intervalId = setInterval(() => {
    if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
      fetchAdminNotifications().catch(() => {});
    }
  }, 5000);

  // Supabase Realtime channel if available
  let channel: any = null;
  try {
    channel = supabase
      .channel('public:notifications:admin')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'notifications', filter: 'target_role=eq.admin' },
        () => {
          fetchAdminNotifications().catch(() => {});
        }
      )
      .subscribe();
  } catch {
    // ignore
  }

  return () => {
    adminNotifListeners.delete(callback);
    clearInterval(intervalId);
    if (channel) {
      try {
        supabase.removeChannel(channel);
      } catch {
        // ignore
      }
    }
  };
}

function triggerAdminListeners(notifs: AppNotification[]) {
  adminNotifListeners.forEach((fn) => {
    try {
      fn(notifs);
    } catch (e) {
      console.error('Error notifying admin listener:', e);
    }
  });
}
