import fs from 'fs';
import path from 'path';

function escapeSql(str: any): string {
  if (str === null || str === undefined) return 'NULL';
  if (typeof str === 'boolean') return str ? 'TRUE' : 'FALSE';
  if (typeof str === 'number') return String(str);
  return "'" + String(str).replace(/'/g, "''") + "'";
}

const backupPath = path.resolve(process.cwd(), 'data/firestore_export_backup.json');
const backupData = JSON.parse(fs.readFileSync(backupPath, 'utf8'));

let sql = `-- ============================================================================
-- FREE STUDY CAMPUS - SUPABASE LIVE DATA SEED SCRIPT
-- Generated from Firebase Live Audit: 23 Platforms, 17 Student Users, Settings & Credentials
-- ============================================================================

-- 1. APP SETTINGS (₹149 Fee, Custom QR, Web Logo, Telegram)
`;

const s = backupData.settings || {};
sql += `INSERT INTO public.app_settings (
  id, website_name, tagline, logo, announcement_banner, telegram_channel_url,
  telegram_bot_url, telegram_bot_handle, contact_link, upi_id, fee_text,
  fee_amount, qr_image_url, payment_instructions, maintenance_mode, default_theme, updated_at
) VALUES (
  'global',
  ${escapeSql(s.websiteName || 'FREE STUDY CAMPUS')},
  ${escapeSql(s.tagline || 'Learn More. Grow More.')},
  ${escapeSql(s.logo || '')},
  ${escapeSql(s.announcementBanner || '')},
  ${escapeSql(s.telegramChannelUrl || 'https://t.me/freestudycampus')},
  ${escapeSql(s.telegramBotUrl || 'https://t.me/Freestudycampusbot')},
  ${escapeSql(s.telegramBotHandle || '@Freestudycampusbot')},
  ${escapeSql(s.contactLink || 'https://t.me/freestudycampus')},
  ${escapeSql(s.upiId || '9472981955@ybl')},
  ${escapeSql(s.feeText || '₹149')},
  ${Number(s.feeAmount ?? 149)},
  ${escapeSql(s.qrImageUrl)},
  ${escapeSql(s.paymentInstructions || '')},
  ${Boolean(s.maintenanceMode)},
  ${escapeSql(s.defaultTheme || 'cyan')},
  ${escapeSql(s.updatedAt || new Date().toISOString())}
) ON CONFLICT (id) DO UPDATE SET
  website_name = EXCLUDED.website_name,
  tagline = EXCLUDED.tagline,
  logo = EXCLUDED.logo,
  announcement_banner = EXCLUDED.announcement_banner,
  telegram_channel_url = EXCLUDED.telegram_channel_url,
  telegram_bot_url = EXCLUDED.telegram_bot_url,
  telegram_bot_handle = EXCLUDED.telegram_bot_handle,
  contact_link = EXCLUDED.contact_link,
  upi_id = EXCLUDED.upi_id,
  fee_text = EXCLUDED.fee_text,
  fee_amount = EXCLUDED.fee_amount,
  qr_image_url = EXCLUDED.qr_image_url,
  payment_instructions = EXCLUDED.payment_instructions,
  maintenance_mode = EXCLUDED.maintenance_mode,
  default_theme = EXCLUDED.default_theme,
  updated_at = EXCLUDED.updated_at;\n\n`;

// 2. AUTH CREDENTIALS
const a = backupData.appConfig || {};
sql += `-- 2. AUTH CREDENTIALS (Admin: JYOTISH@62025, Student: PRIYANSHU@776301)
INSERT INTO public.auth_credentials (
  id, student_password, admin_password, fee_text, fee_amount, upi_id,
  qr_image_url, telegram_bot_url, telegram_bot_handle, payment_instructions, updated_at
) VALUES (
  'authentication',
  ${escapeSql(a.studentPassword || 'PRIYANSHU@776301')},
  ${escapeSql(a.adminPassword || 'JYOTISH@62025')},
  ${escapeSql(a.feeText || '₹149')},
  ${Number(a.feeAmount ?? 149)},
  ${escapeSql(a.upiId || '9472981955@ybl')},
  ${escapeSql(a.qrImageUrl)},
  ${escapeSql(a.telegramBotUrl || 'https://t.me/Freestudycampusbot')},
  ${escapeSql(a.telegramBotHandle || '@Freestudycampusbot')},
  ${escapeSql(a.paymentInstructions || '')},
  ${escapeSql(a.updatedAt || new Date().toISOString())}
) ON CONFLICT (id) DO UPDATE SET
  student_password = EXCLUDED.student_password,
  admin_password = EXCLUDED.admin_password,
  fee_text = EXCLUDED.fee_text,
  fee_amount = EXCLUDED.fee_amount,
  upi_id = EXCLUDED.upi_id,
  qr_image_url = EXCLUDED.qr_image_url,
  telegram_bot_url = EXCLUDED.telegram_bot_url,
  telegram_bot_handle = EXCLUDED.telegram_bot_handle,
  payment_instructions = EXCLUDED.payment_instructions,
  updated_at = EXCLUDED.updated_at;\n\n`;

// 3. PLATFORMS (23 Records)
sql += `-- 3. PLATFORMS (23 Live Records)\n`;
for (const p of backupData.platforms) {
  sql += `INSERT INTO public.platforms (id, name, tagline, description, accent_color, external_url, logo, display_order, is_available, total_batches, created_at, updated_at)
VALUES (
  ${escapeSql(p.id)},
  ${escapeSql(p.name)},
  ${escapeSql(p.tagline || '')},
  ${escapeSql(p.description || '')},
  ${escapeSql(p.accentColor || '#00e5ff')},
  ${escapeSql(p.externalUrl || '')},
  ${escapeSql(p.logo || '')},
  ${Number(p.displayOrder ?? 0)},
  ${p.isAvailable !== false},
  ${Number(p.totalBatches ?? 0)},
  ${escapeSql(p.createdAt || new Date().toISOString())},
  ${escapeSql(p.updatedAt || new Date().toISOString())}
) ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  tagline = EXCLUDED.tagline,
  description = EXCLUDED.description,
  accent_color = EXCLUDED.accent_color,
  external_url = EXCLUDED.external_url,
  logo = EXCLUDED.logo,
  display_order = EXCLUDED.display_order,
  is_available = EXCLUDED.is_available,
  total_batches = EXCLUDED.total_batches,
  updated_at = EXCLUDED.updated_at;\n`;
}

// 4. STUDENT USERS (17 Records)
sql += `\n-- 4. STUDENT USERS (17 Active Student Accounts)\n`;
for (const std of backupData.studentUsers) {
  sql += `INSERT INTO public.student_users (id, username, name, password_hash, status, avatar_url, active_device_id, active_session_id, active_device_info, last_login_at, created_at, updated_at)
VALUES (
  ${escapeSql(std.id)},
  ${escapeSql(std.username)},
  ${escapeSql(std.name || std.username)},
  ${escapeSql(std.passwordHash)},
  ${escapeSql(std.status || 'active')},
  ${escapeSql(std.avatarUrl)},
  ${escapeSql(std.activeDeviceId)},
  ${escapeSql(std.activeSessionId)},
  ${escapeSql(std.activeDeviceInfo)},
  ${escapeSql(std.lastLoginAt)},
  ${escapeSql(std.createdAt || new Date().toISOString())},
  ${escapeSql(std.updatedAt || new Date().toISOString())}
) ON CONFLICT (id) DO UPDATE SET
  username = EXCLUDED.username,
  name = EXCLUDED.name,
  password_hash = EXCLUDED.password_hash,
  status = EXCLUDED.status,
  avatar_url = EXCLUDED.avatar_url,
  active_device_id = EXCLUDED.active_device_id,
  active_session_id = EXCLUDED.active_session_id,
  active_device_info = EXCLUDED.active_device_info,
  last_login_at = EXCLUDED.last_login_at,
  updated_at = EXCLUDED.updated_at;\n`;
}

fs.writeFileSync(path.resolve(process.cwd(), 'supabase_seed_data.sql'), sql, 'utf8');
console.log('Seed SQL generated successfully at supabase_seed_data.sql');
