// End-to-end automated verification test suite for Batch Demo features
const BASE_URL = 'http://localhost:3000';

async function runTests() {
  console.log('=== STARTING BATCH DEMO AUTOMATED VERIFICATION SUITE ===\n');
  let passCount = 0;
  let testCount = 0;

  function assert(condition, message) {
    testCount++;
    if (condition) {
      console.log(`✓ PASS: ${message}`);
      passCount++;
    } else {
      console.error(`✗ FAIL: ${message}`);
    }
  }

  try {
    // 1. Fetch public batch demos (unauthenticated)
    console.log('1. Testing Public Batch Demos API (No Student Login Required)...');
    const pubRes = await fetch(`${BASE_URL}/api/batch-demos`);
    assert(pubRes.ok, 'GET /api/batch-demos returns HTTP 200 without login');
    const pubData = await pubRes.json();
    assert(pubData.success === true, 'Public response has success: true');
    assert(Array.isArray(pubData.demos), 'Public response contains demos array');
    console.log(`   Found ${pubData.demos.length} active demo(s)`);

    // 2. Fetch admin batch demos
    console.log('\n2. Testing Admin Batch Demos API...');
    const adminRes = await fetch(`${BASE_URL}/api/admin/batch-demos`);
    assert(adminRes.ok, 'GET /api/admin/batch-demos returns HTTP 200');
    const adminData = await adminRes.json();
    assert(adminData.success === true, 'Admin response has success: true');
    assert(Array.isArray(adminData.demos), 'Admin response contains all demos array');

    // 3. Create a new demo option (PHYSICS WALLAH DEMO)
    console.log('\n3. Testing Demo Creation: PHYSICS WALLAH DEMO...');
    const createRes = await fetch(`${BASE_URL}/api/admin/batch-demos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'PHYSICS WALLAH DEMO',
        platformName: 'Physics Wallah',
        videoUrl: 'https://youtu.be/dQw4w9WgXcQ',
        description: 'Physics Wallah official batch sample class & curriculum demo',
        isAvailable: true,
      }),
    });
    assert(createRes.ok, 'POST /api/admin/batch-demos returns HTTP 200');
    const createdData = await createRes.json();
    assert(createdData.success === true, 'Created demo response has success: true');
    assert(createdData.demo && createdData.demo.id, 'Demo ID created successfully');
    const demo1Id = createdData.demo?.id;

    // 4. Create another demo option (UNACADEMY DEMO)
    console.log('\n4. Testing Demo Creation: UNACADEMY DEMO...');
    const createRes2 = await fetch(`${BASE_URL}/api/admin/batch-demos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'UNACADEMY DEMO',
        platformName: 'Unacademy',
        videoUrl: 'https://www.youtube.com/watch?v=kJQP7kiw5Fk',
        description: 'Unacademy live batch concept walkthrough',
        isAvailable: true,
      }),
    });
    assert(createRes2.ok, 'Created second demo (UNACADEMY DEMO)');
    const createdData2 = await createRes2.json();
    const demo2Id = createdData2.demo?.id;

    // 5. Create another demo option (TARGET BOARD DEMO)
    console.log('\n5. Testing Demo Creation: TARGET BOARD DEMO...');
    const createRes3 = await fetch(`${BASE_URL}/api/admin/batch-demos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'TARGET BOARD DEMO',
        platformName: 'Target Board',
        videoUrl: 'https://www.youtube.com/watch?v=3JZ_D3ELwOQ',
        description: 'Target Board matric & intermediate batch demo lecture',
        isAvailable: true,
      }),
    });
    assert(createRes3.ok, 'Created third demo (TARGET BOARD DEMO)');
    const createdData3 = await createRes3.json();
    const demo3Id = createdData3.demo?.id;

    // 6. Test Edit Demo
    console.log('\n6. Testing Edit Batch Demo...');
    const editRes = await fetch(`${BASE_URL}/api/admin/batch-demos/${demo1Id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'PHYSICS WALLAH YAKEEN DEMO (UPDATED)',
        platformName: 'Physics Wallah',
        videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      }),
    });
    assert(editRes.ok, 'PUT /api/admin/batch-demos/:id updates demo successfully');
    const editData = await editRes.json();
    assert(editData.demo.title.includes('UPDATED'), 'Demo title was updated correctly');

    // 7. Test Reorder Demos
    console.log('\n7. Testing Reorder Batch Demos...');
    const reorderRes = await fetch(`${BASE_URL}/api/admin/batch-demos/reorder`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        orderedIds: [demo3Id, demo2Id, demo1Id],
      }),
    });
    assert(reorderRes.ok, 'POST /api/admin/batch-demos/reorder updates order successfully');

    // 8. Test Disable Demo
    console.log('\n8. Testing Enable/Disable Demo...');
    const disableRes = await fetch(`${BASE_URL}/api/admin/batch-demos/${demo2Id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        isAvailable: false,
      }),
    });
    assert(disableRes.ok, 'Disabled demo2 successfully');

    // Verify disabled demo is excluded from public endpoint
    const pubAfterDisable = await fetch(`${BASE_URL}/api/batch-demos`).then(r => r.json());
    const demo2InPublic = pubAfterDisable.demos.find(d => d.id === demo2Id);
    assert(!demo2InPublic, 'Disabled demo is NOT visible to students');

    // 9. Test Delete Demo
    console.log('\n9. Testing Delete Batch Demo...');
    const delRes = await fetch(`${BASE_URL}/api/admin/batch-demos/${demo3Id}`, {
      method: 'DELETE',
    });
    assert(delRes.ok, 'DELETE /api/admin/batch-demos/:id returns HTTP 200');
    const pubAfterDel = await fetch(`${BASE_URL}/api/batch-demos`).then(r => r.json());
    const demo3InPublic = pubAfterDel.demos.find(d => d.id === demo3Id);
    assert(!demo3InPublic, 'Deleted demo is completely removed');

    // Clean up demo1 and demo2
    await fetch(`${BASE_URL}/api/admin/batch-demos/${demo1Id}`, { method: 'DELETE' });
    await fetch(`${BASE_URL}/api/admin/batch-demos/${demo2Id}`, { method: 'DELETE' });

    console.log(`\n=== RESULTS: ${passCount}/${testCount} TESTS PASSED ===\n`);
  } catch (err) {
    console.error('Test suite error:', err);
  }
}

runTests();
