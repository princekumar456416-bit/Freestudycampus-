import sharp from 'sharp';
import fs from 'fs';

const logoPath = 'public/logo.png';
const logoBuffer = fs.readFileSync(logoPath);

async function generate() {
  console.log('Rendering high-resolution PWA icons from Free Study Campus public/logo.png...');

  // 1. 512x512 PNG
  await sharp(logoBuffer)
    .resize(512, 512, { fit: 'contain', background: '#080608' })
    .png({ quality: 100, compressionLevel: 9 })
    .toFile('public/pwa-512x512.png');
  console.log('✓ Created public/pwa-512x512.png');

  // 2. 192x192 PNG
  await sharp(logoBuffer)
    .resize(192, 192, { fit: 'contain', background: '#080608' })
    .png({ quality: 100, compressionLevel: 9 })
    .toFile('public/pwa-192x192.png');
  console.log('✓ Created public/pwa-192x192.png');

  // 3. Apple touch icon 180x180 (iOS Safari requirement)
  await sharp(logoBuffer)
    .resize(180, 180, { fit: 'contain', background: '#080608' })
    .png({ quality: 100 })
    .toFile('public/apple-touch-icon.png');
  console.log('✓ Created public/apple-touch-icon.png');

  // 4. Favicon 64x64 PNG
  await sharp(logoBuffer)
    .resize(64, 64, { fit: 'contain', background: '#080608' })
    .png({ quality: 100 })
    .toFile('public/favicon.png');
  console.log('✓ Created public/favicon.png');

  // 5. Favicon 32x32 ICO
  await sharp(logoBuffer)
    .resize(32, 32, { fit: 'contain', background: '#080608' })
    .png()
    .toFile('public/favicon.ico');
  console.log('✓ Created public/favicon.ico');

  // 6. Maskable 512x512 with safe padding (Android Adaptive Icon Standard: 80% inner with #080608 background)
  const inner512 = await sharp(logoBuffer).resize(410, 410, { fit: 'contain' }).toBuffer();
  await sharp({
    create: {
      width: 512,
      height: 512,
      channels: 4,
      background: '#080608',
    },
  })
    .composite([{ input: inner512, gravity: 'center' }])
    .png({ quality: 100 })
    .toFile('public/pwa-maskable-512x512.png');
  console.log('✓ Created public/pwa-maskable-512x512.png');

  // 7. Maskable 192x192
  const inner192 = await sharp(logoBuffer).resize(154, 154, { fit: 'contain' }).toBuffer();
  await sharp({
    create: {
      width: 192,
      height: 192,
      channels: 4,
      background: '#080608',
    },
  })
    .composite([{ input: inner192, gravity: 'center' }])
    .png({ quality: 100 })
    .toFile('public/pwa-maskable-192x192.png');
  console.log('✓ Created public/pwa-maskable-192x192.png');

  console.log('All high-resolution icons successfully generated from public/logo.png!');
}

generate().catch((err) => {
  console.error('Icon generation failed:', err);
  process.exit(1);
});
