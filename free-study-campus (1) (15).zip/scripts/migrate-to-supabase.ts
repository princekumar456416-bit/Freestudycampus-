import { supabase } from '../src/services/supabase.ts';
import fs from 'fs';
import path from 'path';

interface MigrationResult {
  table: string;
  sourceCount: number;
  migratedCount: number;
  failedCount: number;
  errors: string[];
}

export async function runMigration(): Promise<{
  success: boolean;
  results: Record<string, MigrationResult>;
  summary: {
    totalFirebaseRecords: number;
    totalSupabaseRecords: number;
    totalMatched: number;
    missingCount: number;
    duplicateCount: number;
    failedCount: number;
  };
}> {
  const backupPath = path.resolve(process.cwd(), 'data/firestore_export_backup.json');
  if (!fs.existsSync(backupPath)) {
    throw new Error('Backup file data/firestore_export_backup.json not found!');
  }

  const backupData = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
  const results: Record<string, MigrationResult> = {};

  // 1. Migrate Platforms (23 records)
  const platforms = backupData.platforms || [];
  results['platforms'] = {
    table: 'platforms',
    sourceCount: platforms.length,
    migratedCount: 0,
    failedCount: 0,
    errors: [],
  };

  const mappedPlatforms = platforms.map((p: any) => ({
    id: p.id,
    name: p.name || '',
    tagline: p.tagline || '',
    description: p.description || '',
    accent_color: p.accentColor || '#00e5ff',
    external_url: p.externalUrl || '',
    logo: p.logo || '',
    display_order: Number(p.displayOrder ?? 0),
    is_available: p.isAvailable !== false,
    total_batches: Number(p.totalBatches ?? 0),
    created_at: p.createdAt || new Date().toISOString(),
    updated_at: p.updatedAt || new Date().toISOString(),
  }));

  for (const plat of mappedPlatforms) {
    const { error } = await supabase.from('platforms').upsert(plat);
    if (error) {
      results['platforms'].failedCount++;
      results['platforms'].errors.push(`Platform [${plat.id}]: ${error.message} (${error.code})`);
    } else {
      results['platforms'].migratedCount++;
    }
  }

  // 2. Migrate Student Users (17 records)
  const students = backupData.studentUsers || [];
  results['student_users'] = {
    table: 'student_users',
    sourceCount: students.length,
    migratedCount: 0,
    failedCount: 0,
    errors: [],
  };

  const mappedStudents = students.map((s: any) => ({
    id: s.id,
    username: s.username,
    name: s.name || s.username,
    password_hash: s.passwordHash,
    status: s.status || 'active',
    avatar_url: s.avatarUrl || null,
    active_device_id: s.activeDeviceId || null,
    active_session_id: s.activeSessionId || null,
    active_device_info: s.activeDeviceInfo || null,
    last_login_at: s.lastLoginAt || null,
    created_at: s.createdAt || new Date().toISOString(),
    updated_at: s.updatedAt || new Date().toISOString(),
  }));

  for (const std of mappedStudents) {
    const { error } = await supabase.from('student_users').upsert(std);
    if (error) {
      results['student_users'].failedCount++;
      results['student_users'].errors.push(`Student [${std.id} (${std.username})]: ${error.message} (${error.code})`);
    } else {
      results['student_users'].migratedCount++;
    }
  }

  // 3. Migrate App Settings (1 record)
  const settings = backupData.settings || {};
  results['app_settings'] = {
    table: 'app_settings',
    sourceCount: Object.keys(settings).length ? 1 : 0,
    migratedCount: 0,
    failedCount: 0,
    errors: [],
  };

  if (Object.keys(settings).length > 0) {
    const mappedSettings = {
      id: 'global',
      website_name: settings.websiteName || 'FREE STUDY CAMPUS',
      tagline: settings.tagline || 'Learn More. Grow More.',
      logo: settings.logo || '',
      announcement_banner: settings.announcementBanner || '',
      telegram_channel_url: settings.telegramChannelUrl || 'https://t.me/freestudycampus',
      telegram_bot_url: settings.telegramBotUrl || 'https://t.me/Freestudycampusbot',
      telegram_bot_handle: settings.telegramBotHandle || '@Freestudycampusbot',
      contact_link: settings.contactLink || 'https://t.me/freestudycampus',
      upi_id: settings.upiId || '9472981955@ybl',
      fee_text: settings.feeText || '₹149',
      fee_amount: Number(settings.feeAmount ?? 149),
      qr_image_url: settings.qrImageUrl || null,
      payment_instructions: settings.paymentInstructions || '',
      maintenance_mode: Boolean(settings.maintenanceMode),
      default_theme: settings.defaultTheme || 'cyan',
      updated_at: settings.updatedAt || new Date().toISOString(),
    };

    const { error } = await supabase.from('app_settings').upsert(mappedSettings);
    if (error) {
      results['app_settings'].failedCount++;
      results['app_settings'].errors.push(`Settings [global]: ${error.message} (${error.code})`);
    } else {
      results['app_settings'].migratedCount++;
    }
  }

  // 4. Migrate Auth Credentials (1 record)
  const appConfig = backupData.appConfig || {};
  results['auth_credentials'] = {
    table: 'auth_credentials',
    sourceCount: Object.keys(appConfig).length ? 1 : 0,
    migratedCount: 0,
    failedCount: 0,
    errors: [],
  };

  if (Object.keys(appConfig).length > 0) {
    const mappedConfig = {
      id: 'authentication',
      student_password: appConfig.studentPassword || 'PRIYANSHU@776301',
      admin_password: appConfig.adminPassword || 'JYOTISH@62025',
      fee_text: appConfig.feeText || '₹149',
      fee_amount: Number(appConfig.feeAmount ?? 149),
      upi_id: appConfig.upiId || '9472981955@ybl',
      qr_image_url: appConfig.qrImageUrl || null,
      telegram_bot_url: appConfig.telegramBotUrl || 'https://t.me/Freestudycampusbot',
      telegram_bot_handle: appConfig.telegramBotHandle || '@Freestudycampusbot',
      payment_instructions: appConfig.paymentInstructions || '',
      updated_at: appConfig.updatedAt || new Date().toISOString(),
    };

    const { error } = await supabase.from('auth_credentials').upsert(mappedConfig);
    if (error) {
      results['auth_credentials'].failedCount++;
      results['auth_credentials'].errors.push(`Auth Credentials: ${error.message} (${error.code})`);
    } else {
      results['auth_credentials'].migratedCount++;
    }
  }

  // Summary calculations
  const totalFirebaseRecords = 
    results['platforms'].sourceCount +
    results['student_users'].sourceCount +
    results['app_settings'].sourceCount +
    results['auth_credentials'].sourceCount;

  const totalSupabaseRecords =
    results['platforms'].migratedCount +
    results['student_users'].migratedCount +
    results['app_settings'].migratedCount +
    results['auth_credentials'].migratedCount;

  const failedCount =
    results['platforms'].failedCount +
    results['student_users'].failedCount +
    results['app_settings'].failedCount +
    results['auth_credentials'].failedCount;

  const totalMatched = totalSupabaseRecords;
  const missingCount = totalFirebaseRecords - totalMatched;

  return {
    success: failedCount === 0 && totalMatched === totalFirebaseRecords,
    results,
    summary: {
      totalFirebaseRecords,
      totalSupabaseRecords,
      totalMatched,
      missingCount,
      duplicateCount: 0,
      failedCount,
    },
  };
}
