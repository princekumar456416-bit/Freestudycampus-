-- ============================================================================
-- FREE STUDY CAMPUS - SUPABASE QUICK SETUP SQL
-- Copy and paste this ENTIRE block into Supabase SQL Editor and click RUN
-- ============================================================================

-- 1. PLATFORMS TABLE
CREATE TABLE IF NOT EXISTS public.platforms (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  tagline TEXT DEFAULT '',
  description TEXT DEFAULT '',
  accent_color TEXT DEFAULT '#00e5ff',
  external_url TEXT NOT NULL,
  logo TEXT DEFAULT '',
  display_order INTEGER DEFAULT 0,
  is_available BOOLEAN DEFAULT true,
  total_batches INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. BATCHES TABLE
CREATE TABLE IF NOT EXISTS public.batches (
  id TEXT PRIMARY KEY,
  platform_id TEXT NOT NULL REFERENCES public.platforms(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  short_description TEXT DEFAULT '',
  thumbnail TEXT DEFAULT '',
  teacher_name TEXT DEFAULT '',
  subject TEXT DEFAULT '',
  category TEXT DEFAULT 'ALL',
  batch_url TEXT NOT NULL,
  start_date TEXT DEFAULT '',
  status TEXT DEFAULT 'Active',
  display_order INTEGER DEFAULT 0,
  is_featured BOOLEAN DEFAULT false,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. STUDENT USERS (1-Device Session Locking)
CREATE TABLE IF NOT EXISTS public.student_users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  avatar_url TEXT,
  active_device_id TEXT,
  active_session_id TEXT,
  active_device_info TEXT,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. APP SETTINGS (₹149 Fee, QR, Telegram Bot, Logo)
CREATE TABLE IF NOT EXISTS public.app_settings (
  id TEXT PRIMARY KEY DEFAULT 'global',
  website_name TEXT DEFAULT 'FREE STUDY CAMPUS',
  tagline TEXT DEFAULT 'Learn More. Grow More.',
  logo TEXT DEFAULT '',
  announcement_banner TEXT DEFAULT '',
  telegram_channel_url TEXT DEFAULT 'https://t.me/freestudycampus',
  telegram_bot_url TEXT DEFAULT 'https://t.me/Freestudycampusbot',
  telegram_bot_handle TEXT DEFAULT '@Freestudycampusbot',
  contact_link TEXT DEFAULT 'https://t.me/freestudycampus',
  upi_id TEXT DEFAULT '9472981955@ybl',
  fee_text TEXT DEFAULT '₹149',
  fee_amount NUMERIC DEFAULT 149,
  qr_image_url TEXT,
  payment_instructions TEXT DEFAULT 'Scan QR code, pay the verification fee, and send screenshot to our Telegram Bot to receive your account credentials instantly.',
  maintenance_mode BOOLEAN DEFAULT false,
  default_theme TEXT DEFAULT 'cyan',
  admin_password TEXT DEFAULT 'JYOTISH@62025',
  student_password TEXT DEFAULT 'PRIYANSHU@776301',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. ANNOUNCEMENTS TABLE
CREATE TABLE IF NOT EXISTS public.announcements (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  date TEXT NOT NULL,
  link TEXT DEFAULT '',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. UPCOMING BATCHES TABLE
CREATE TABLE IF NOT EXISTS public.upcoming_batches (
  id TEXT PRIMARY KEY,
  batch_name TEXT NOT NULL,
  platform TEXT NOT NULL,
  description TEXT DEFAULT '',
  thumbnail TEXT DEFAULT '',
  expected_date TEXT DEFAULT '',
  external_url TEXT DEFAULT '',
  status TEXT DEFAULT 'Upcoming',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- RLS POLICIES (Full Access for App Client)
-- ----------------------------------------------------------------------------
ALTER TABLE public.platforms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.upcoming_batches ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow all platforms" ON public.platforms;
CREATE POLICY "Allow all platforms" ON public.platforms FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all batches" ON public.batches;
CREATE POLICY "Allow all batches" ON public.batches FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all student_users" ON public.student_users;
CREATE POLICY "Allow all student_users" ON public.student_users FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all app_settings" ON public.app_settings;
CREATE POLICY "Allow all app_settings" ON public.app_settings FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all announcements" ON public.announcements;
CREATE POLICY "Allow all announcements" ON public.announcements FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all upcoming_batches" ON public.upcoming_batches;
CREATE POLICY "Allow all upcoming_batches" ON public.upcoming_batches FOR ALL USING (true) WITH CHECK (true);

-- 7. SUPPORT TICKETS & NOTIFICATIONS TABLES (Student Help & Support)
CREATE TABLE IF NOT EXISTS public.support_tickets (
  id TEXT PRIMARY KEY,
  student_id TEXT NOT NULL,
  student_name TEXT NOT NULL,
  student_username TEXT NOT NULL,
  category TEXT DEFAULT 'General Query',
  subject TEXT NOT NULL,
  description TEXT NOT NULL,
  screenshot_url TEXT,
  status TEXT DEFAULT 'Pending' CHECK (status IN ('Pending', 'In Progress', 'Resolved')),
  admin_reply TEXT,
  admin_replied_at TIMESTAMPTZ,
  messages JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.support_tickets ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'General Query';
ALTER TABLE public.support_tickets ADD COLUMN IF NOT EXISTS messages JSONB DEFAULT '[]'::jsonb;

ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all support_tickets" ON public.support_tickets;
CREATE POLICY "Allow all support_tickets" ON public.support_tickets FOR ALL USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.support_notifications (
  id TEXT PRIMARY KEY,
  target_role TEXT NOT NULL CHECK (target_role IN ('admin', 'student')),
  student_id TEXT,
  student_username TEXT,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  ticket_id TEXT,
  type TEXT NOT NULL,
  read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.support_notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all support_notifications" ON public.support_notifications;
CREATE POLICY "Allow all support_notifications" ON public.support_notifications FOR ALL USING (true) WITH CHECK (true);

ALTER PUBLICATION supabase_realtime ADD TABLE public.support_tickets;
ALTER PUBLICATION supabase_realtime ADD TABLE public.support_notifications;

-- 8. BATCH DEMOS TABLE (Official Platform Video Demos)
CREATE TABLE IF NOT EXISTS public.batch_demos (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  platform_name TEXT NOT NULL,
  platform_logo TEXT DEFAULT '',
  video_url TEXT NOT NULL,
  video_id TEXT NOT NULL,
  description TEXT DEFAULT '',
  display_order INT DEFAULT 1,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.batch_demos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all batch_demos" ON public.batch_demos;
CREATE POLICY "Allow all batch_demos" ON public.batch_demos FOR ALL USING (true) WITH CHECK (true);

ALTER PUBLICATION supabase_realtime ADD TABLE public.batch_demos;

-- ----------------------------------------------------------------------------
-- INITIAL SEED: GLOBAL SETTINGS & STUDENT 1
-- ----------------------------------------------------------------------------
INSERT INTO public.app_settings (
  id, website_name, tagline, telegram_channel_url, telegram_bot_url,
  telegram_bot_handle, upi_id, fee_text, fee_amount, admin_password, student_password
) VALUES (
  'global', 'FREE STUDY CAMPUS', 'Learn More. Grow More.',
  'https://t.me/freestudycampus', 'https://t.me/Freestudycampusbot',
  '@Freestudycampusbot', '9472981955@ybl', '₹149', 149, 'JYOTISH@62025', 'PRIYANSHU@776301'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO public.student_users (
  id, username, name, password_hash, status
) VALUES (
  'student_01_init', 'student01', 'Student 1',
  '4c9f1a0ba11dcf73663a871cb6cf6ce3e728448fba816d773ad70be319e1ff51', 'active'
) ON CONFLICT (username) DO NOTHING;
