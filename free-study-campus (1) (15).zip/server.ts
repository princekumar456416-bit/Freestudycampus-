import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import apiRouter from './server/routes.ts';
import { initDb } from './server/db.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isProd = process.env.NODE_ENV === 'production';
const PORT = process.env.PORT || 3000;

async function startServer() {
  const app = express();

  // JSON Body parsing with support for image data URLs
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // CORS handling for live deployments and proxies
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
      return;
    }
    next();
  });

  // Initialize DB with seed records
  initDb();

  // Mount API Router
  app.use('/api', apiRouter);

  // Serve PWA manifest with standard JSON content type and no-cache
  app.get(['/manifest.json', '/manifest.webmanifest'], (_req, res) => {
    try {
      const manifestPath = path.resolve(__dirname, 'public/manifest.json');
      res.setHeader('Content-Type', 'application/manifest+json');
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.sendFile(manifestPath);
    } catch {
      const manifestPath = path.resolve(__dirname, 'public/manifest.json');
      res.setHeader('Content-Type', 'application/manifest+json');
      res.sendFile(manifestPath);
    }
  });

  // Serve service worker with root scope allowed and no-cache
  app.get('/sw.js', (_req, res) => {
    const swPath = path.resolve(__dirname, 'public/sw.js');
    res.setHeader('Content-Type', 'application/javascript');
    res.setHeader('Service-Worker-Allowed', '/');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.sendFile(swPath);
  });

  // Serve public static assets
  app.use(express.static(path.resolve(__dirname, 'public')));

  if (!isProd) {
    // Vite Dev Middleware
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production static asset serving
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.resolve(distPath, 'index.html'));
      });
    } else {
      console.warn('Production dist directory not found. Please run npm run build.');
    }
  }

  app.listen(PORT, () => {
    console.log(`FREE STUDY CAMPUS server running on http://localhost:${PORT}`);
    console.log(`Admin ID: ${process.env.ADMIN_EMAIL || 'admin@campus.edu'} (MPIN verified server-side only)`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup failure:', err);
  process.exit(1);
});
